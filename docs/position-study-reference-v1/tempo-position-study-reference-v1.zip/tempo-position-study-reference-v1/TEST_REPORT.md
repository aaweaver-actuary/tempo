# Reference-kit verification — November 2, 2026

## Executed locally

- `python -m pytest -q tests`: **26 passed** on Python 3.13.5.
- `node --test browser/*.test.mjs`: **4 passed** on Node 22.16.0.
- `python -m compileall -q reference`: **completed**.

Tests cover typed input validation, shared Italian opening prefixes, single-route candidate selection, due/correct/Again/observe/pending, assisted/unknown first-response holds, same-day no duplicate Good, genuine wrong after earlier Good, stale positive after intervening Again, donor selection and FSRS JSON field re-keying, exact effect replay, abbreviated issued plan and source-mode holds, and immutable offline payload/no offline position pilot.

## Important unexecuted checks

1. No `python-chess` nor `fsrs` dependency available here. Network package installation failed due to DNS/network isolation. No legal source replay under python-chess, no `FSRS Card.from_dict` roundtrip, and no real due interval computation were run. The graph fixtures are **trusted-source-shaped synthetics**, not independent legality certificates.
2. No PostgreSQL instance, actual Tempo review/queue/runtime adapter, official schema migration, source/currentness certificate, docker/browser Study, CI, mobile phone session or user installation was tested. All `_ref` schema SQL is demonstration only. No user DB changes.
3. No actual current donor candidate census, position counts, shared physical-card across-repertoire risk or real 7/30-day retention observation is available. Existing October/November user-reported counts concern physical graph cards and recombination, not distinct position schedule readiness.
4. No distinct independent reviewer has approved this reference kit. Existing source owner and `AGENTS.md` may impose stronger naming/locking/limit rules than the standalone examples.

## Release evidence needed

Only N2/#878 can claim assembled release validation after A1 independent contract review and source consumers are integrated. First position-owning deployment requires opt-in migration readiness, reversible/roll-forward compatible image and actual user's normal Study observations; passing this kit does not qualify those claims.
