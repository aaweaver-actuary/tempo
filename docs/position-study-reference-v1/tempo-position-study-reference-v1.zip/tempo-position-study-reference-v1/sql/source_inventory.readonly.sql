-- E1 READ-ONLY REFERENCE. Current graph may require additional current-publication
-- and integrity-certificate filters before numbers are trustworthy.
-- Do not run a whole-repertoire scan in an interactive request or live DB
-- without a bounded, approved read-only operator preflight.
WITH current_publication AS (
  SELECT repertoire_id, max(generation) AS generation
  FROM opening_graph_publications
  WHERE state='ready'
  GROUP BY repertoire_id
),
uses AS (
  SELECT DISTINCT s.repertoire_id, s.line_id, s.card_id
  FROM opening_graph_steps s
  JOIN current_publication p
    ON p.repertoire_id=s.repertoire_id AND p.generation=s.generation
), card_ownership AS (
  SELECT card_id, count(DISTINCT repertoire_id) AS repertoire_owners
  FROM repertoire_cards
  GROUP BY card_id
)
SELECT CASE WHEN owners.repertoire_owners > 1
            THEN 'shared_across_repertoires' ELSE 'one_repertoire' END AS cohort_risk,
       count(DISTINCT uses.card_id) AS distinct_physical_cards,
       count(DISTINCT (uses.repertoire_id,uses.line_id)) AS published_line_uses
FROM uses
LEFT JOIN card_ownership owners ON owners.card_id=uses.card_id
GROUP BY 1 ORDER BY 1;
-- This still does NOT count distinct (repertoire,normalized legal position).
-- For that, use existing PositionIndex or source-certified decision FEN keys,
-- and enforce selected own response/integrity before mapping any FSRS donor.
