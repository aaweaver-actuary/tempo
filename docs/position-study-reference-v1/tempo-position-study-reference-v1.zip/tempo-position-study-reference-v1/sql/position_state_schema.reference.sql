-- REFERENCE ONLY. NOT A MIGRATION. DO NOT APPLY TO LIVE POSTGRESQL.
-- F1/D2/D3/F3 owners must reconcile actual serving DB/schema before writing DDL.
-- No triggers on legacy cards/reviews. No DDL version reservation.
CREATE TABLE IF NOT EXISTS study_position_owner_epoch_ref (
  repertoire_id text PRIMARY KEY,
  epoch text NOT NULL,
  mode text NOT NULL CHECK (mode IN ('legacy','shadow','staged','active','paused')),
  source_digest text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS study_position_schedule_ref (
  repertoire_id text NOT NULL,
  variant text NOT NULL DEFAULT 'standard' CHECK (variant='standard'),
  position_key text NOT NULL,
  approved_uci text NOT NULL,
  definition_version text NOT NULL,
  owner_epoch text NOT NULL,
  version bigint NOT NULL DEFAULT 1 CHECK (version>=1),
  fsrs_internal_card_id bigint NOT NULL UNIQUE,
  fsrs_json text NOT NULL,
  due_at timestamptz NOT NULL,
  introduced_at timestamptz,
  donor_card_id text,
  donor_card_revision integer,
  donor_fingerprint text,
  PRIMARY KEY (repertoire_id,variant,position_key)
);
CREATE INDEX IF NOT EXISTS study_position_due_ref
 ON study_position_schedule_ref(owner_epoch,due_at,repertoire_id,position_key);
CREATE TABLE IF NOT EXISTS study_position_attempt_plan_ref (
  attempt_id text PRIMARY KEY,
  original_card_id text NOT NULL,
  original_card_revision integer NOT NULL,
  queue_entry_id bigint NOT NULL,
  repertoire_id text NOT NULL,
  owner_epoch text NOT NULL,
  plan_digest text NOT NULL,
  source_digest text NOT NULL,
  local_day date NOT NULL,
  plan_json jsonb NOT NULL,
  issued_at timestamptz NOT NULL
);
CREATE TABLE IF NOT EXISTS study_position_grade_ref (
  effect_id text PRIMARY KEY,
  attempt_id text NOT NULL,
  decision_index integer NOT NULL,
  repertoire_id text NOT NULL,
  variant text NOT NULL CHECK (variant='standard'),
  position_key text NOT NULL,
  definition_version text NOT NULL,
  owner_epoch text NOT NULL,
  local_day date NOT NULL,
  grade text NOT NULL CHECK (grade IN ('good','again','observe')),
  observed_at timestamptz NOT NULL,
  accepted_at timestamptz NOT NULL,
  request_digest text NOT NULL,
  fsrs_before_json text,
  fsrs_after_json text,
  UNIQUE (attempt_id,decision_index,grade)
);
-- One positive Good / position / local day. Failed real first moves are NOT
-- blocked by this unique constraint; their effect IDs make retries idempotent.
CREATE UNIQUE INDEX IF NOT EXISTS study_position_once_good_per_day_ref
 ON study_position_grade_ref(repertoire_id,variant,position_key,local_day,owner_epoch,definition_version)
 WHERE grade='good';
-- NOTE: for a production migration, receipt identity and source/failure
-- provenance need stronger owner-specific FK/fence, version/epoch controls,
-- actual Study transaction lock ordering and explicit schema registration.
