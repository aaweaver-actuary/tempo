-- REFERENCE READ ONLY, against proposed _ref tables only (not current Tempo).
-- H1 should batch by exact position due and current opt-in epoch, not scan graph.
SELECT state.repertoire_id, state.variant, state.position_key,
       state.approved_uci, state.definition_version, state.version,
       state.due_at, state.owner_epoch
FROM study_position_schedule_ref state
JOIN study_position_owner_epoch_ref epoch
  ON epoch.repertoire_id=state.repertoire_id
 AND epoch.epoch=state.owner_epoch
 AND epoch.mode='active'
WHERE state.repertoire_id = $1
  AND state.due_at <= $2::timestamptz
  AND (state.due_at, state.position_key) > ($3::timestamptz, $4::text)
ORDER BY state.due_at, state.position_key
LIMIT $5; -- bounded 1..100 by application
-- Current graph/conflict/current-issuer proof still required before issuance.
