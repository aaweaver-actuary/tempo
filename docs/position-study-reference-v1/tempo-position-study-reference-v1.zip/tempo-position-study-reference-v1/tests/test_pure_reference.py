from datetime import datetime, timedelta, timezone
from types import SimpleNamespace
import json
import pytest
from reference.contracts import (PositionKey,PositionDefinition,DecisionOccurrence,
    DueAtIssuance,FirstResponse,AcceptedEvidence,GradeProposal,Hold,RouteOption)
from reference.graph import index_routes, options_for_target
from reference.planner import CleanPresentationProof, choose_plan
from reference.grades import propose_grade, ProofLedger
from reference.donor import Donor,select_donor,clone_state,inspect_fsrs
from reference.migration_preflight import prepare_seed_plan
from reference.source_adapter import routes_from_validated_index
from reference.game_mapping import FirstDeparture,resolve_lapse
from reference.source_change import compare_definition
from reference.due import PositionDueState,due_page
from reference.owner_epoch import OwnerEpoch,may_issue_position_attempt
from reference.issued_plan import freeze_issued_plan
from reference.metrics import summarize
from conftest import START,DAY,NOW,F_C3,F_NG5,SOURCE,d


def due(defn, *, is_due=True, study_day=DAY, epoch='E',version=1):
    return DueAtIssuance(defn,is_due,study_day,epoch,version,NOW)

def evidence(defn, *, response=None, assisted=False, complete=True, review=True, saved=True,
             disposition=None,
             attempt_id='at1',event_id='evt1',manual=False,epoch='E'):
    action=FirstResponse(attempt_id,0,defn,response if response is not None else defn.expected_uci,
                         assisted,NOW,event_id,manual)
    actual_disposition = disposition or ("expected" if action.correct else "wrong")
    return AcceptedEvidence(action,saved,actual_disposition,complete,review,epoch,'digest-1',NOW)


def test_position_key_separates_scope_and_turn():
    assert PositionKey('r',START)!=PositionKey('other',START)
    assert PositionKey('r',START)!=PositionKey('r',START.replace(' w ', ' b '))
    with pytest.raises(ValueError): PositionKey('r', START+' 0 1')


def test_route_inventory_deduplicates_route_alias_without_conflating_branch(routes):
    index=index_routes(routes)
    assert len(options_for_target(index,routes[0].decisions[0].definition.key))==2
    assert len(options_for_target(index,routes[0].decisions[-1].definition.key))==1
    assert isinstance(options_for_target(index,PositionKey('italian',START.replace(' w ',' b '))),Hold)


def test_conflicting_repertoire_response_holds(routes):
    r=routes[0]
    bad=DecisionOccurrence(0,PositionDefinition(r.decisions[0].definition.key,'d2d4','v1'),START)
    changed=RouteOption('bad',r.start_fen,('d2d4',),r.learner_color,(bad,),SOURCE,True)
    idx=index_routes((*routes,changed))
    assert isinstance(idx[r.decisions[0].definition.key],Hold)


def test_italian_second_branch_starts_at_first_distinct_decision(routes):
    gui,knight=routes
    proof=CleanPresentationProof('saved_knight','digest-1',knight.moves_uci,
      tuple(x.definition.key for x in knight.decisions),True,True,True)
    plan=choose_plan(gui.decisions[-1].definition.key,(gui,),clean_proofs=(proof,))
    assert plan.route_id=='g'
    assert plan.starting_fen==F_C3
    assert plan.moves_uci==('c2c3',)
    assert len(plan.skipped_prefix_decisions)==3
    assert plan.exposed_positions==(gui.decisions[-1].definition.key,)


def test_failed_or_partial_proof_cannot_skip(routes):
    gui,knight=routes
    for flags in [(False,True,True),(True,False,True),(True,True,False)]:
        proof=CleanPresentationProof('a','digest-1',knight.moves_uci,
          tuple(x.definition.key for x in knight.decisions),*flags)
        plan=choose_plan(gui.decisions[-1].definition.key,(gui,),clean_proofs=(proof,))
        assert plan.starting_fen==gui.start_fen
        assert plan.skipped_prefix_decisions==()


def test_changed_source_digest_blocks_skip(routes):
    gui,knight=routes
    proof=CleanPresentationProof('clean','old_digest',knight.moves_uci,
       tuple(x.definition.key for x in knight.decisions),True,True,True)
    plan=choose_plan(gui.decisions[-1].definition.key,(gui,),clean_proofs=(proof,))
    assert plan.starting_fen==gui.start_fen


def test_deterministic_route_choice_for_two_transposed_authored_paths(routes):
    gui,knight=routes
    # Pure route selection receives exact identity facts certified by owner.
    selected=choose_plan(gui.decisions[0].definition.key,(knight,gui))
    assert selected.route_id=='g'
    assert choose_plan(gui.decisions[0].definition.key,(gui,knight))==selected


def test_due_correct_good_and_nondue_correct_observe(routes):
    definition=routes[0].decisions[-1].definition
    x=propose_grade(evidence(definition),due(definition))
    y=propose_grade(evidence(definition),due(definition,is_due=False))
    assert x.grade=='good' and y.grade=='observe'


def test_pending_correct_never_good_until_completed_review(routes):
    definition=routes[0].decisions[-1].definition
    p=propose_grade(evidence(definition,complete=False,review=False),due(definition))
    assert p.grade=='pending'


def test_nondue_actual_wrong_immediately_again_even_in_incomplete_attempt(routes):
    definition=routes[0].decisions[-1].definition
    p=propose_grade(evidence(definition,response='d2d4',complete=False,review=False),
                    due(definition,is_due=False))
    assert p.grade=='again'


def test_unsaved_first_wrong_holds(routes):
    definition=routes[0].decisions[-1].definition
    p=propose_grade(evidence(definition,response='d2d4',saved=False),due(definition))
    assert p==Hold('evidence_not_durable')


def test_assistance_before_correct_no_good(routes):
    definition=routes[0].decisions[-1].definition
    assert propose_grade(evidence(definition,assisted=True),due(definition)).grade=='observe'


def test_ledger_one_good_and_later_new_wrong_today(routes):
    definition=routes[0].decisions[-1].definition
    first=propose_grade(evidence(definition),due(definition))
    second=propose_grade(evidence(definition,event_id='evt2',attempt_id='at2'),due(definition))
    wrong=propose_grade(evidence(definition,response='d2d4',event_id='evt3',attempt_id='at3'),due(definition,is_due=False))
    ledger=ProofLedger()
    assert ledger.accept(first).grade=='good'
    assert ledger.accept(second).grade=='observe'
    assert ledger.accept(first).grade=='good' # exact same original disposition, no side effect
    assert ledger.accept(wrong).grade=='again'
    assert len(ledger.history)==2
    forged=GradeProposal(first.position,first.policy_version,first.event_id,first.study_day,
                         first.owner_epoch,first.issued_position_revision,'again','forged',first.observed_at,first.accepted_at)
    assert ledger.accept(forged)==Hold('event_id_reused_with_changed_payload')


def test_donor_selection_is_order_invariant_and_clone_rekeys(routes):
    key=routes[0].decisions[0].definition.key
    blob=json.dumps({'card_id':15,'state':2,'step':None,'stability':11.0,'difficulty':5.1,
      'due':'2026-11-03T12:00:00+00:00','last_review':'2026-11-01T12:00:00+00:00'})
    a=Donor('a',key,1,NOW,blob,True,True)
    b=Donor('b',key,1,NOW+timedelta(days=5),blob,True,True)
    assert select_donor(key,(b,a)).card_id=='a'
    assert select_donor(key,(a,b)).card_id=='a'
    j=clone_state(blob,allocated_new_card_id=101)
    assert inspect_fsrs(j)['card_id']==101
    assert inspect_fsrs(blob)['card_id']==15
    assert inspect_fsrs(j)['stability']==inspect_fsrs(blob)['stability']
    seeds,holds=prepare_seed_plan({key:(a,b)})
    assert seeds[0].donor_card_id=='a' and not holds


def test_invalid_fsrs_donor_not_chosen(routes):
    key=routes[0].decisions[0].definition.key
    bad=Donor('x',key,1,NOW,'{}',True,True)
    assert select_donor(key,(bad,))==Hold('no_valid_current_introduced_donor')


def test_frozen_issued_plan_requires_due_snapshots_for_all_tested_moves(routes):
    gui,knight=routes
    plan=choose_plan(gui.decisions[-1].definition.key,(gui,))
    part=freeze_issued_plan('original',1,90,'attempt',
      (due(gui.decisions[-1].definition),),plan,gui.decisions[-1].definition)
    assert part==Hold('due_snapshot_must_cover_all_actual_learner_decisions')
    all_dues=tuple(due(x.definition) for x in gui.decisions)
    valid=freeze_issued_plan('original',1,90,'attempt',all_dues,plan,
                              gui.decisions[-1].definition)
    assert len(valid.plan_id)==64 and valid.original_card_id=='original'


def test_games_preserves_original_effect_identity(routes):
    definition=routes[0].decisions[0].definition
    event=FirstDeparture('game_original','italian',definition.key.position,
      definition.expected_uci,True,'digest-1')
    target=resolve_lapse(event,definition,'digest-1')
    assert target.original_effect_key=='game_original'
    assert resolve_lapse(FirstDeparture('id','italian',definition.key.position,
      definition.expected_uci,False,'digest-1'),definition,'digest-1')==Hold('opponent_first_gap_not_a_lapse')


def test_source_changes_preserve_same_position_answer_only(routes):
    before=routes[0].decisions[0].definition
    assert compare_definition(before,before).retain_schedule
    after=PositionDefinition(before.key,'d2d4','v1')
    assert compare_definition(before,after).needs_review


def test_due_page_is_bounded_and_stable(routes):
    a=PositionDueState(routes[0].decisions[0].definition,NOW,'E','active')
    b=PositionDueState(routes[0].decisions[-1].definition,NOW+timedelta(days=1),'E','active')
    assert due_page((b,a),NOW,owner_epoch='E',limit=1)==(a,)
    with pytest.raises(ValueError): due_page((a,),NOW,owner_epoch='E',limit=10000)


def test_owner_epoch_blocks_uncertain_shared_physical_card():
    rec=OwnerEpoch('italian','E','active','digest-1',True)
    assert may_issue_position_attempt(rec,repertoire_id='italian',source_digest='digest-1',
                                         original_card_owner_proved=False)==Hold('physical_card_admission_scope_ambiguous')


def test_metric_counter_uses_actual_event_not_skipped_positions(routes):
    definition=routes[0].decisions[-1].definition
    good=propose_grade(evidence(definition),due(definition))
    bad=propose_grade(evidence(definition,response='d2d4',event_id='new',attempt_id='new'),due(definition,is_due=False))
    stats=summarize(((good,True),(good,True),(bad,False)),NOW,NOW+timedelta(minutes=2))
    assert stats.distinct_positions_with_real_first_response==1
    assert stats.actual_response_events==2
    assert stats.nondue_incorrect_count==1
    assert stats.distinct_positions_per_minute==.5


def test_source_index_adapter_holds_unavailable():
    result=routes_from_validated_index(SimpleNamespace(complete=False,available=True),
                                       membership_complete=False,current_integrity=True)
    assert isinstance(result,Hold)


def test_unverified_alternate_cannot_be_graded_as_wrong(routes):
    definition=routes[0].decisions[-1].definition
    for disposition in ('unverified','alternate'):
        saved=evidence(definition,response='d2d4',disposition=disposition)
        assert propose_grade(saved,due(definition,is_due=False))==Hold('first_response_not_authoritatively_classified')


def test_outdated_positive_witness_cannot_overwrite_later_again(routes):
    definition=routes[0].decisions[-1].definition
    stale_good=propose_grade(evidence(definition,event_id='good',attempt_id='g'),due(definition,version=1))
    new_wrong=propose_grade(evidence(definition,response='d2d4',event_id='wrong',attempt_id='w'),due(definition,is_due=False,version=1))
    ledger=ProofLedger()
    assert ledger.accept(new_wrong).grade=='again'
    late=ledger.accept(stale_good)
    assert late.grade=='observe'
    assert late.reason=='stale_due_issuance'
    assert len(ledger.history)==1


def test_authored_route_remains_available_when_only_physical_mapping_is_ambiguous(routes):
    route = routes[0]
    step_objects = [SimpleNamespace(route_complete=True, ply=d.ply,
        key=SimpleNamespace(position=d.definition.key.position),
        policy_id=d.definition.policy_version,full_fen=d.fen,learner_turn=True,
        next_move=d.definition.expected_uci,
        starting_fen=route.start_fen,route_moves=route.moves_uci,
        learner_color=route.learner_color) for d in route.decisions]
    mock_index=SimpleNamespace(
        complete=False, available=True,
        diagnostics=(SimpleNamespace(code='ambiguous_physical_mapping'),),
        snapshot_id='s',source_revision='rev',digest='digest-1',
        routes={('italian','g'):tuple(step_objects)},
    )
    approved=routes_from_validated_index(mock_index,
                                          membership_complete=True,current_integrity=True)
    assert isinstance(approved,tuple) and len(approved)==1
    assert len(approved[0].decisions)==4
    blocked=routes_from_validated_index(mock_index,
                                         membership_complete=True,current_integrity=False)
    assert blocked==Hold('authored_source_unavailable_or_not_current')
    mock_index.diagnostics=(SimpleNamespace(code='own_response_conflict'),)
    refused=routes_from_validated_index(mock_index,
                                         membership_complete=True,current_integrity=True)
    assert refused.reason=='authored_source_diagnostics'
