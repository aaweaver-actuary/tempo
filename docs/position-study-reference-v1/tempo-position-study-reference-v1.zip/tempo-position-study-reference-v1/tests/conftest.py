from datetime import date, datetime, timezone
import pytest
from reference.contracts import PositionKey, PositionDefinition, DecisionOccurrence, RouteOption, SourceCertificate

START = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq -'
F_NF3 = 'rnbqkbnr/pppp1ppp/8/4p3/4P3/8/PPPP1PPP/RNBQKBNR w KQkq -'
F_BC4 = 'r1bqkbnr/pppp1ppp/2n5/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R w KQkq -'
F_NG5 = 'r1bqkb1r/pppp1ppp/2n2n2/4p3/2B1P3/5N2/PPPP1PPP/RNBQK2R w KQkq -'
F_C3 = 'r1bqk1nr/pppp1ppp/2n5/2b1p3/2B1P3/5N2/PPPP1PPP/RNBQK2R w KQkq -'
DAY = date(2026,11,2)
NOW = datetime(2026,11,2,13,0,tzinfo=timezone.utc)
SOURCE = SourceCertificate('snapshot','rev-2','digest-1',True,True)

def d(fen, uci, rep='italian'):
    return PositionDefinition(PositionKey(rep,fen),'e2e4' if uci=='E4' else uci,'v1')

def italian_routes():
    common=[(0,d(START,'e2e4'), START),
            (2,d(F_NF3,'g1f3'),F_NF3),
            (4,d(F_BC4,'f1c4'),F_BC4)]
    base=['e2e4','e7e5','g1f3','b8c6','f1c4']
    def route(name, reply, answer, fen):
        moves=tuple([*base,reply,answer])
        decisions=tuple(DecisionOccurrence(p,x,f) for p,x,f in [*common,(6,d(fen,answer),fen)])
        return RouteOption(name,START,moves,'white',decisions,SOURCE,True)
    return (route('g','f8c5','c2c3',F_C3),
            route('n','g8f6','f3g5',F_NG5))

@pytest.fixture
def routes():return italian_routes()
