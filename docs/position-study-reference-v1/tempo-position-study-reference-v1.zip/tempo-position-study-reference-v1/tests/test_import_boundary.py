"""Reference import graph: no reverse Repertoire/Learning/DB dependencies."""
import ast
from pathlib import Path

REFERENCE = Path(__file__).resolve().parents[1] / 'reference'
FORBIDDEN = ('backend', 'app', 'tempo_legacy_database', 'tempo_learning_database',
             'psycopg', 'fastapi', 'sqlalchemy', 'fsrs', 'chess', 'requests')


def test_reference_has_no_implementation_layer_imports():
    for file in REFERENCE.glob('*.py'):
        parsed=ast.parse(file.read_text(encoding='utf-8'),filename=str(file))
        imported=[]
        for node in ast.walk(parsed):
            if isinstance(node,ast.Import): imported.extend(x.name for x in node.names)
            elif isinstance(node,ast.ImportFrom) and node.module: imported.append(node.module)
        unexpected=[m for m in imported if m.split('.')[0] in FORBIDDEN]
        assert unexpected==[],f'{file}: forbidden imports {unexpected}'
