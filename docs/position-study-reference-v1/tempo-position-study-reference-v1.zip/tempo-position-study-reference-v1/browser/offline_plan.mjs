// Pure reference for L1; no browser storage, network, due computation or FSRS.
import { decodeIssuedPlan } from './issued_plan.mjs';
export function retainOfflinePlan(prepared, raw) {
  const plan = decodeIssuedPlan(raw);
  if (!prepared || typeof prepared !== 'object') throw Error('missing_prepared_queue');
  if (!prepared.position_mode_enabled) throw Error('position_mode_requires_explicit_authorization');
  if (prepared.online_only) throw Error('position_pilot_online_only');
  const saved = prepared.plans?.[plan.attempt_id];
  if (saved) {
    if (JSON.stringify(saved)!==JSON.stringify(plan)) throw Error('attempt_plan_payload_conflict');
    return prepared;
  }
  return Object.freeze({ ...prepared,
    plans: Object.freeze({ ...(prepared.plans??{}), [plan.attempt_id]: plan }),
  });
}
