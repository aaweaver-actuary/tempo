import { test } from 'node:test';
import { strict as assert } from 'node:assert';
import { decodeIssuedPlan } from './issued_plan.mjs';
const raw = () => ({
  version: 1, plan_id: 'a'.repeat(64), original_card_id: 'c1',
  original_card_revision: 3, queue_entry_id: 44, attempt_id: 'A-99',
  owner_epoch: 'epoch1', route_id: 'italian-g', target_ply: 6,
  starting_fen: 'r1bqk1nr/pppp1ppp/2n5/2b1p3/2B1P3/5N2/PPPP1PPP/RNBQK2R w KQkq - 4 4',
  moves_uci: ['c2c3'], decision_slots: [{move_offset:0,position_key:'position-c3',expected_uci:'c2c3'}],
  source_digest:'signed-current-digest',local_day:'2026-11-02',skipped_prefix_proof_ids:['saved-clean-italian-1']
});
test('accepts a frozen server-issued suffix retaining original attempt', () => {
  const p=decodeIssuedPlan(raw());
  assert.equal(p.queue_entry_id,44);
  assert.deepEqual(p.moves_uci,['c2c3']);
  assert.ok(Object.isFrozen(p));
  assert.ok(Object.isFrozen(p.moves_uci));
});
test('refuses unknown fields and fabricated response',()=>{
  assert.throws(()=>decodeIssuedPlan({...raw(),fsrs_due:true}),/unknown_plan_field/);
  assert.throws(()=>decodeIssuedPlan({...raw(),decision_slots:[{move_offset:0,position_key:'p',expected_uci:'e2e4'}]}),/invalid_issued_plan/);
});
