import {test} from 'node:test';
import {strict as assert} from 'node:assert';
import {retainOfflinePlan} from './offline_plan.mjs';
const p = {version:1,plan_id:'a'.repeat(64),original_card_id:'c',original_card_revision:1,
queue_entry_id:1,attempt_id:'a1',owner_epoch:'E',route_id:'r',target_ply:0,
starting_fen:'8/8/8/8/8/8/8/8 w - - 0 1',moves_uci:['e2e4'],
decision_slots:[{move_offset:0,position_key:'start',expected_uci:'e2e4'}],
source_digest:'current-source',local_day:'2026-11-02',skipped_prefix_proof_ids:[]};
test('online-only position cohort refuses offline issuance',()=>{
 assert.throws(()=>retainOfflinePlan({position_mode_enabled:true,online_only:true},p),/online_only/);
});
test('retaining same sealed plan is idempotent and changed payload conflicts',()=>{
 const saved=retainOfflinePlan({position_mode_enabled:true,online_only:false},p);
 assert.equal(retainOfflinePlan(saved,p),saved);
 assert.throws(()=>retainOfflinePlan(saved,{...p,route_id:'other'}),/payload_conflict/);
});
