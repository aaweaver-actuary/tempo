"""Ports only; these are not a second orchestrator/scheduler framework."""
from typing import Protocol
from .contracts import PositionKey, RouteOption, DueAtIssuance, GradeProposal, Hold
from .planner import Plan, CleanPresentationProof
from .issued_plan import IssuedPlan


class StudyDuePositions(Protocol):
    def due_page(self, repertoire_id: str, limit: int) -> tuple[DueAtIssuance, ...]: ...


class RepertoireRouteOptions(Protocol):
    def routes_for(self, position: PositionKey) -> tuple[RouteOption, ...] | Hold: ...


class SavedDailyCleanCoverage(Protocol):
    def completed_clean_prefix_proofs(self, repertoire_id: str) -> tuple[CleanPresentationProof, ...]: ...


class StudyIssuedAttemptOwner(Protocol):
    def issue(self, proposed: Plan, due: tuple[DueAtIssuance, ...],
              original_queue_entry_id: int) -> IssuedPlan | Hold: ...


class StudyGradeOwner(Protocol):
    def apply(self, effects: tuple[GradeProposal, ...], attempt_id: str): ...

# A product composition root supplies implementations; it must not be imported
# back into Repertoire, pure planning or the Learning scheduling library.
