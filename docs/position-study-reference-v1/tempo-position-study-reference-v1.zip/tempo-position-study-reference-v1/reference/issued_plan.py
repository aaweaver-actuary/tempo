"""Frozen Study-only issuance plan; graph option and schedule state kept apart."""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, date
from .contracts import PositionKey, PositionDefinition, DueAtIssuance, Hold
from .planner import Plan
import hashlib
import json


@dataclass(frozen=True)
class IssuedPlan:
    plan_id: str
    original_card_id: str
    original_card_revision: int
    queue_entry_id: int
    attempt_id: str
    owner_epoch: str
    local_day: date
    route: Plan
    due_positions: tuple[DueAtIssuance, ...]
    source_definition: PositionDefinition
    issued_at: datetime


def freeze_issued_plan(original_card_id: str, original_card_revision: int,
                       queue_entry_id: int, attempt_id: str,
                       due_positions: tuple[DueAtIssuance, ...],
                       plan: Plan, source_definition: PositionDefinition):
    if (not original_card_id or original_card_revision < 1
            or queue_entry_id <= 0 or not attempt_id or not due_positions):
        return Hold('invalid_original_attempt_or_due_proof')
    if source_definition.key != plan.position:
        return Hold('target_answer_mismatch')
    if len(plan.exposed_positions) != len(due_positions) or (
        set(plan.exposed_positions) != {d.definition.key for d in due_positions}):
        return Hold('due_snapshot_must_cover_all_actual_learner_decisions')
    epoch = due_positions[0].owner_epoch
    day = due_positions[0].study_day
    if any(d.owner_epoch != epoch or d.study_day != day for d in due_positions):
        return Hold('issued_scope_mismatch')
    if not any(d.definition == source_definition for d in due_positions):
        return Hold('target_definition_unavailable')
    identity = [original_card_id, original_card_revision, queue_entry_id, attempt_id,
                epoch, day.isoformat(), plan.route_id, plan.target_ply,
                plan.starting_fen, list(plan.moves_uci), [(p.repertoire_id,p.position) for p in plan.skipped_prefix_decisions], plan.source_digest,
                [(d.definition.key.repertoire_id,d.definition.key.position,d.definition.policy_version,
                  d.due,d.position_revision) for d in due_positions]]
    digest = hashlib.sha256(json.dumps(identity,separators=(',',':'),ensure_ascii=True).encode()).hexdigest()
    return IssuedPlan(digest,original_card_id,original_card_revision,
                      queue_entry_id,attempt_id,epoch,day,plan,due_positions,
                      source_definition,due_positions[0].issued_at)
