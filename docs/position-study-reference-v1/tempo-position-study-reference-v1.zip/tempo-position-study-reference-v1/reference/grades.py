"""Pure proposal classification and an in-memory proof ledger; NOT a DB writer.

A production owner must fence the response definition/owner epoch under a
borrowed transaction, and must recheck current Grade receipts atomically.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from .contracts import AcceptedEvidence, DueAtIssuance, GradeProposal, Hold


def propose_grade(evidence: AcceptedEvidence, due: DueAtIssuance):
    response = evidence.first_response
    if not evidence.saved:
        return Hold("evidence_not_durable")
    if evidence.owner_epoch != due.owner_epoch:
        return Hold("owner_epoch_changed")
    if response.definition != due.definition:
        return Hold("response_definition_changed")
    if evidence.disposition in {"unverified", "alternate"}:
        return Hold("first_response_not_authoritatively_classified")
    if response.correct != (evidence.disposition == "expected"):
        return Hold("first_response_disposition_conflict")
    if response.correct:
        if response.assistance_before:
            grade, reason = "observe", "assisted_correct_not_recall"
        elif not evidence.terminal_complete or not evidence.aggregate_review_saved:
            grade, reason = "pending", "correct_waits_for_completed_saved_review"
        elif due.due:
            grade, reason = "good", "due_clean_first_response"
        else:
            grade, reason = "observe", "nondue_correct_no_schedule"
    else:
        grade, reason = "again", "actual_first_wrong_or_manual_failure"
    return GradeProposal(response.definition.key, response.definition.policy_version,
                         response.event_id, due.study_day, due.owner_epoch,
                         due.position_revision, grade,
                         reason, response.observed_at, evidence.accepted_at)


@dataclass
class ProofLedger:
    """Demonstration only: the DB owner enforces these constraints atomically."""
    accepted: dict[str, tuple[GradeProposal, GradeProposal]] = field(default_factory=dict)
    credited_goods: set[tuple] = field(default_factory=set)
    current_revisions: dict = field(default_factory=dict)
    history: list[GradeProposal] = field(default_factory=list)

    def accept(self, proposal: GradeProposal):
        prior = self.accepted.get(proposal.event_id)
        if prior is not None:
            if prior[0] != proposal:
                return Hold("event_id_reused_with_changed_payload")
            return prior[1]  # exact original disposition, no new side effect
        key = (proposal.position, proposal.study_day, proposal.owner_epoch,
               proposal.policy_version)
        grade = proposal.grade
        current_revision = self.current_revisions.get(proposal.position, proposal.issued_position_revision)
        stale_good = grade == "good" and current_revision != proposal.issued_position_revision
        if grade == "good" and (key in self.credited_goods or stale_good):
            grade = "observe"
        final = GradeProposal(proposal.position, proposal.policy_version, proposal.event_id,
                              proposal.study_day, proposal.owner_epoch,
                              proposal.issued_position_revision, grade,
                              ("stale_due_issuance" if stale_good else "already_good_today")
                              if grade != proposal.grade else proposal.reason,
                              proposal.observed_at, proposal.accepted_at)
        self.accepted[proposal.event_id] = (proposal, final)
        if grade == "good":
            self.credited_goods.add(key)
        if grade in {"good", "again"}:
            self.history.append(final)
            self.current_revisions[proposal.position] = current_revision + 1
        return final
