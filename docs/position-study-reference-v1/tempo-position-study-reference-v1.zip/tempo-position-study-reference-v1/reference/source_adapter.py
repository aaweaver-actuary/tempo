"""Structural reference adapter from Tempo's already-existing PositionIndex.

Import this only from product composition in the real application, NOT from
Study/Learning. The current source index itself is authoritative and retains
full legal position, source and route proof. No source caching/lifecycle here.
"""
from __future__ import annotations
from .contracts import (PositionKey, PositionDefinition, DecisionOccurrence,
                        SourceCertificate, RouteOption, Hold)


def routes_from_validated_index(index, *, membership_complete: bool,
                                current_integrity: bool):
    # Existing PositionIndex.complete can be false from *physical-card mapping*
    # ambiguity. That is NOT an authored chess conflict or a reason to create
    # multiple position schedules. External snapshot owner must explicitly prove
    # membership completeness and current integrity on the same source digest.
    if not membership_complete or not current_integrity or not getattr(index, 'available', False):
        return Hold('authored_source_unavailable_or_not_current')
    nonblocking = {'ambiguous_physical_mapping', 'physical_mapping_unknown'}
    fatal = tuple(d.code for d in getattr(index, 'diagnostics', ())
                  if d.code not in nonblocking)
    if fatal:
        return Hold('authored_source_diagnostics', ','.join(sorted(set(fatal))))
    source = SourceCertificate(index.snapshot_id, index.source_revision,
                               index.digest, True, True)
    out = []
    for (repertoire_id, route_id), occurrences in sorted(index.routes.items()):
        if not occurrences:
            continue
        first = occurrences[0]
        if any(not v.route_complete for v in occurrences):
            return Hold('route_incomplete', route_id)
        decisions = tuple(
            DecisionOccurrence(
                ply=step.ply,
                definition=PositionDefinition(PositionKey(repertoire_id, step.key.position),
                                              step.next_move, str(step.policy_id)),
                fen=step.full_fen)
            for step in occurrences if step.learner_turn and step.next_move)
        if not decisions:
            continue
        try:
            out.append(RouteOption(route_id, first.starting_fen,
                                   tuple(first.route_moves), first.learner_color,
                                   decisions, source, legal_verified=True))
        except (ValueError, TypeError) as exc:
            return Hold('published_route_contract_invalid', str(exc))
    return tuple(out)
