"""Pure Games first-own-departure target mapping; no game-effect rewrites."""
from dataclasses import dataclass
from .contracts import PositionKey, PositionDefinition, Hold


@dataclass(frozen=True)
class FirstDeparture:
    source_effect_key: str
    repertoire_id: str
    position_key: str
    selected_response_uci: str
    learner_was_first_to_deviate: bool
    source_digest: str


@dataclass(frozen=True)
class PositionGameTarget:
    original_effect_key: str
    definition: PositionDefinition
    source_digest: str


def resolve_lapse(departure: FirstDeparture, current: PositionDefinition,
                  current_source_digest: str):
    if not departure.learner_was_first_to_deviate:
        return Hold('opponent_first_gap_not_a_lapse')
    if (current.key != PositionKey(departure.repertoire_id,departure.position_key)
        or current.expected_uci != departure.selected_response_uci):
        return Hold('first_boundary_answer_or_position_changed')
    if departure.source_digest != current_source_digest:
        return Hold('source_digest_changed')
    return PositionGameTarget(departure.source_effect_key,current,current_source_digest)
