"""One deterministic legal route per target; no FSRS, graph search, or SQL.

The required legal/FEN proof lives with the external Repertoire PositionIndex.
Only a COMPLETED, SAVED, WHOLE CLEAN earlier presentation may skip context.
"""
from __future__ import annotations
from dataclasses import dataclass
from .contracts import PositionKey, RouteOption, Hold


@dataclass(frozen=True)
class CleanPresentationProof:
    attempt_id: str
    source_digest: str
    played_uci: tuple[str, ...]
    first_response_positions: tuple[PositionKey, ...]
    complete: bool
    saved_review: bool
    all_clean_unassisted: bool


@dataclass(frozen=True)
class Plan:
    position: PositionKey
    route_id: str
    target_ply: int
    starting_fen: str
    moves_uci: tuple[str, ...]
    skipped_prefix_decisions: tuple[PositionKey, ...]
    exposed_positions: tuple[PositionKey, ...]
    prefix_credit_attempt_id: str | None
    source_digest: str


def _skip_proved(route: RouteOption, target_ply: int, proof: CleanPresentationProof):
    if (not proof.complete or not proof.saved_review or not proof.all_clean_unassisted
            or proof.source_digest != route.certificate.source_digest):
        return None
    shared = 0
    for a, b in zip(route.moves_uci, proof.played_uci):
        if a != b:
            break
        shared += 1
    if shared <= 0:
        return None
    skip_decisions = tuple(d for d in route.decisions
                           if d.ply < shared and d.ply < target_ply)
    if not skip_decisions:
        return None
    if not all(d.definition.key in proof.first_response_positions
               for d in skip_decisions):
        return None
    # Skip to the next *learner* decision, never leave an opponent cue to be
    # mistaken for a tested learner response.
    later = tuple(d for d in route.decisions
                  if d.ply >= shared and d.ply <= target_ply)
    if not later:
        return None
    return later[0], tuple(d.definition.key for d in skip_decisions)


def choose_plan(target: PositionKey, routes: tuple[RouteOption, ...],
                *, clean_proofs: tuple[CleanPresentationProof, ...] = ()):  # no randomness
    candidates = []
    for route in routes:
        for decision in route.decisions:
            if decision.definition.key == target:
                candidates.append((route, decision))
    if not candidates:
        return Hold('no_exact_target_route')
    for route, target_decision in sorted(candidates,
                                         key=lambda x: (x[0].route_id, x[1].ply)):
        if (not route.legal_verified or not route.certificate.complete
                or not route.certificate.current_integrity):
            continue
        start = route.start_fen
        moves = route.moves_uci
        skipped: tuple[PositionKey, ...] = ()
        credit_id = None
        # Deterministically choose maximal VERIFIED prefix skip on selected
        # authored route, not cheapest transposition / arbitrary legal jump.
        applicable = []
        for proof in clean_proofs:
            credit = _skip_proved(route, target_decision.ply, proof)
            if credit:
                first_uncovered, covered = credit
                applicable.append((first_uncovered.ply, proof.attempt_id,
                                   first_uncovered, covered))
        if applicable:
            first_uncovered_ply, credit_id, chosen, skipped = sorted(
                applicable, key=lambda x: (-x[0], x[1]))[0]
            start = chosen.fen
            moves = route.moves_uci[first_uncovered_ply:]
        start_ply = len(route.moves_uci) - len(moves)
        exposed = tuple(d.definition.key for d in route.decisions if d.ply >= start_ply)
        return Plan(target, route.route_id, target_decision.ply,
                    start, moves, skipped, exposed, credit_id, route.certificate.source_digest)
    return Hold('no_certified_target_route')
