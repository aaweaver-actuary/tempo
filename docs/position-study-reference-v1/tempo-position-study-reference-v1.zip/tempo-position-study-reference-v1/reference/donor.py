"""Pure preflight donor choice and FSRS blob re-keying; not live FSRS application.

A production allocator must supply unique internal FSRS card IDs in its DB.
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
import json
from .contracts import PositionKey, Hold

REQUIRED_FSRS = {"card_id", "state", "step", "stability", "difficulty", "due", "last_review"}


@dataclass(frozen=True)
class Donor:
    card_id: str
    position: PositionKey
    revision: int
    due_at: datetime
    fsrs_json: str
    current_source: bool
    introduced: bool
    archived: bool = False


def inspect_fsrs(blob: str):
    try:
        state = json.loads(blob)
        if not isinstance(state, dict) or not REQUIRED_FSRS <= state.keys():
            raise ValueError("missing FSRS fields")
        if state["card_id"] is None:
            raise ValueError("missing internal card_id")
        for key in ("due", "last_review"):
            if key == "last_review" and state[key] is None:
                continue
            if datetime.fromisoformat(state[key]).utcoffset() is None:
                raise ValueError("naive FSRS date")
        return state
    except (ValueError, TypeError, KeyError) as exc:
        raise ValueError("invalid_fsrs_state") from exc


def select_donor(position: PositionKey, candidates: tuple[Donor, ...]):
    eligible: list[Donor] = []
    for item in candidates:
        if (item.position != position or item.archived or not item.current_source
                or not item.introduced or item.revision < 1 or item.due_at.utcoffset() is None):
            continue
        try:
            inspect_fsrs(item.fsrs_json)
        except ValueError:
            continue
        eligible.append(item)
    if not eligible:
        return Hold("no_valid_current_introduced_donor")
    return min(eligible, key=lambda x: (x.due_at, x.card_id, x.revision))


def clone_state(source_fsrs_json: str, *, allocated_new_card_id: int) -> str:
    """Rekey complete memory state; not a supported FSRS upgrade validator.

    Roundtrip through Card.from_dict/from_json in real Tempo D1 integration.
    """
    if not isinstance(allocated_new_card_id, int) or allocated_new_card_id <= 0:
        raise ValueError("new_internal_id_must_be_allocated_positive_int")
    state = inspect_fsrs(source_fsrs_json)
    state["card_id"] = allocated_new_card_id
    return json.dumps(state, sort_keys=True, separators=(",", ":"))
