"""Pure counters over accepted position first-response records; no DB queries."""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
from .contracts import GradeProposal


@dataclass(frozen=True)
class Summary:
    distinct_positions_with_real_first_response: int
    actual_response_events: int
    nondue_incorrect_count: int
    due_good_count: int
    due_again_count: int
    context_repeats: int
    elapsed_minutes: float | None
    distinct_positions_per_minute: float | None


def summarize(events: tuple[tuple[GradeProposal, bool], ...],
              started_at: datetime | None, completed_at: datetime | None) -> Summary:
    """Input (accepted effect, was_due_at_issue). One row per observed event ID.

    Excludes skipped/unplayed positions; duplicate events are not counted twice.
    "+"/Again schedule effects may include other non-Study sources in production;
    caller must filter to actual learner first response events.
    """
    original = {}
    for proposal, was_due in events:
        original.setdefault(proposal.event_id, (proposal, was_due))
    vals = list(original.values())
    distinct = len({p.position for p, _ in vals if p.grade != 'pending'})
    count = sum(p.grade != 'pending' for p, _ in vals)
    due_good = sum(p.grade == 'good' and due for p, due in vals)
    due_again = sum(p.grade == 'again' and due for p, due in vals)
    nondue_wrong = sum(p.grade == 'again' and not due for p, due in vals)
    repeated = max(0, count - distinct)
    minutes = None
    if started_at is not None and completed_at is not None and completed_at > started_at:
        minutes = (completed_at-started_at).total_seconds()/60
    return Summary(distinct,count,nondue_wrong,due_good,due_again,repeated,minutes,
                   distinct/minutes if minutes and minutes > 0 else None)
