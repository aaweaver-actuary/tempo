"""Pure reference pagination over already-loaded position states.

Production H1 must use the matching indexed SQL reader, never load all states
in a hot request. This reference is suitable for deterministic fixture tests.
"""
from datetime import datetime
from dataclasses import dataclass
from .contracts import PositionDefinition


@dataclass(frozen=True)
class PositionDueState:
    definition: PositionDefinition
    due_at: datetime
    owner_epoch: str
    mode: str


def due_page(values: tuple[PositionDueState, ...], now: datetime, *,
             owner_epoch: str, after: tuple | None = None, limit: int = 50):
    if not 1 <= limit <= 100 or now.utcoffset() is None:
        raise ValueError('bad_bounded_due_page')
    matches = [x for x in values if x.owner_epoch == owner_epoch and
               x.mode == 'active' and x.due_at <= now]
    matches.sort(key=lambda s: (s.due_at,s.definition.key.repertoire_id,
                                s.definition.key.position))
    if after is not None:
        matches = [s for s in matches if (s.due_at,s.definition.key.repertoire_id,
                                          s.definition.key.position) > after]
    return tuple(matches[:limit])
