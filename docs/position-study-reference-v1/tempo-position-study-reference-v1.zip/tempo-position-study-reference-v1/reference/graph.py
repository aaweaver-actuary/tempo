"""Bounded pure map of *certified* Repertoire route facts to target options.

This is NOT a chess legality oracle or a replacement for PositionIndex.
The source adapter, outside Study, must validate routes with existing index.
"""
from __future__ import annotations
from collections import defaultdict
from .contracts import PositionKey, RouteOption, Hold


def index_routes(routes: tuple[RouteOption, ...], *, max_routes: int = 10000, max_uses: int = 100000):
    if len(routes) > max_routes:
        return Hold("route_inventory_too_large")
    candidates: dict[PositionKey, list[RouteOption]] = defaultdict(list)
    responses: dict[PositionKey, set[str]] = defaultdict(set)
    uses = 0
    for route in routes:
        for decision in route.decisions:
            uses += 1
            if uses > max_uses:
                return Hold("decision_inventory_too_large")
            key = decision.definition.key
            candidates[key].append(route)
            responses[key].add(decision.definition.expected_uci)
    conflicts = frozenset(k for k, v in responses.items() if len(v) != 1)
    # Do not expose an ambiguous selected response as a route candidate.
    return {
        key: (Hold("own_response_conflict") if key in conflicts else
              tuple(sorted(set(values), key=lambda r: r.route_id)))
        for key, values in candidates.items()
    }


def options_for_target(index, key: PositionKey):
    if isinstance(index, Hold):
        return index
    return index.get(key, Hold("position_not_in_current_graph"))
