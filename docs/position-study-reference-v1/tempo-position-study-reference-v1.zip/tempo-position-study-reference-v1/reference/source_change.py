"""Pure disposition of source changes; no migration or scheduling writes."""
from __future__ import annotations
from dataclasses import dataclass
from .contracts import PositionDefinition


@dataclass(frozen=True)
class DefinitionChange:
    retain_schedule: bool
    needs_review: bool
    reason: str


def compare_definition(before: PositionDefinition, after: PositionDefinition):
    if before.key != after.key:
        return DefinitionChange(False, True, 'different_exact_position')
    if before.expected_uci != after.expected_uci:
        return DefinitionChange(False, True, 'selected_response_changed')
    if before.policy_version != after.policy_version:
        return DefinitionChange(False, True, 'content_policy_changed')
    return DefinitionChange(True, False, 'same_position_and_approved_response')
