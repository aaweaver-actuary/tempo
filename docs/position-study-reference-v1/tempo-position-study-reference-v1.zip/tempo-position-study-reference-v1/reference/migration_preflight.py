"""Pure dry-run seed plan: no database or filesystem writes."""
from dataclasses import dataclass
from .contracts import PositionKey, Hold
from .donor import Donor, select_donor


@dataclass(frozen=True)
class SelectedSeed:
    position: PositionKey
    donor_card_id: str
    donor_card_revision: int
    source_fsrs_json: str


def prepare_seed_plan(donors_by_position: dict[PositionKey, tuple[Donor, ...]]):
    rows: list[SelectedSeed] = []
    holds: dict[PositionKey, Hold] = {}
    for key in sorted(donors_by_position):
        found = select_donor(key, donors_by_position[key])
        if isinstance(found, Hold):
            holds[key] = found
        else:
            rows.append(SelectedSeed(key, found.card_id, found.revision,
                                     found.fsrs_json))
    return tuple(rows), holds
