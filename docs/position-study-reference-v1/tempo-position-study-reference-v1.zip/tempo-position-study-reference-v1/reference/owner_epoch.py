"""Pure owner-epoch gate. Does NOT enable live cohorts or lock a database."""
from dataclasses import dataclass
from typing import Literal
from .contracts import Hold

Mode = Literal['legacy','shadow','staged','active','paused']


@dataclass(frozen=True)
class OwnerEpoch:
    repertoire_id: str
    epoch: str
    mode: Mode
    source_digest: str
    migration_complete: bool


def may_issue_position_attempt(record: OwnerEpoch, *, repertoire_id: str,
                               source_digest: str, original_card_owner_proved: bool):
    if record.repertoire_id != repertoire_id:
        return Hold('wrong_owner_repertoire')
    if record.mode != 'active':
        return Hold('position_owner_not_active')
    if record.source_digest != source_digest:
        return Hold('stale_owner_source')
    if not record.migration_complete:
        return Hold('migration_unfinished')
    if not original_card_owner_proved:
        return Hold('physical_card_admission_scope_ambiguous')
    return True
