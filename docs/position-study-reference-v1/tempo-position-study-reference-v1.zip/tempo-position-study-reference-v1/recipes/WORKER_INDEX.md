# All 34 worker tasks — reference code and exact integration status

The original GitHub issues #847–#880 are **leaf implementation scopes**, not a requirement to produce 34 PRs. This table is the narrow handoff from the preparation package to those issues. Every task has a reference artifact, but only pure pieces are locally executable. **Do not treat recipes, SQL examples, or self-certified graph witnesses as production-verified implementations.**

Source revision: `ea68e5d7038c02b813e690584c022bf5f0d9edb6`. Coordinator: https://github.com/aaweaver-actuary/tempo/issues/832.

| Leaf | Evidence level | Reference artifact | Exact task boundary / remaining integration |
|---|---|---|---|
| [A1 #847](https://github.com/aaweaver-actuary/tempo/issues/847) | Pure reference | `reference/contracts.py; reference/ports.py` | Freeze stable exact-position ID separate from approved-response definition and due/receipt identity; use existing graph export. |
| [A2 #848](https://github.com/aaweaver-actuary/tempo/issues/848) | Tested fixtures | `tests/conftest.py; tests/test_pure_reference.py` | Tests of keys, first-response policy, transpositions, complete-prefix proof, and donor state. |
| [B1 #849](https://github.com/aaweaver-actuary/tempo/issues/849) | Pure adapter (not native-tested) | `reference/source_adapter.py; reference/graph.py` | Map existing Repertoire PositionIndex to bounded, source-certified route options; no new graph database. |
| [B2 #850](https://github.com/aaweaver-actuary/tempo/issues/850) | Tested pure | `reference/planner.py` | Choose deterministic route and longest proved identical authored shared prefix; return a legal-source witness, no FSRS. |
| [C1 #851](https://github.com/aaweaver-actuary/tempo/issues/851) | Tested pure | `reference/grades.py:propose_grade` | Explicit expected/wrong/illegal/manual failure vs alternate/unverified disposition and due Good rules. |
| [C2 #852](https://github.com/aaweaver-actuary/tempo/issues/852) | Tested in-memory policy | `reference/grades.py:ProofLedger` | One credited Good/local day, genuine later Wrong Again, stale due Good observe; production needs DB serialization. |
| [C3 #853](https://github.com/aaweaver-actuary/tempo/issues/853) | Tested pure | `reference/planner.py:CleanPresentationProof` | Only earlier complete + saved + whole clean + identical authored moves can skip prefix. |
| [D1 #854](https://github.com/aaweaver-actuary/tempo/issues/854) | Tested blob rewrite; FSRS not native-tested | `reference/donor.py:clone_state` | Re-key one copied donor FSRS JSON; real worker must call FSRS 6.3.2 supported decoder and ensure ID uniqueness. |
| [D2 #855](https://github.com/aaweaver-actuary/tempo/issues/855) | SQL design only | `sql/position_state_schema.reference.sql; reference/due.py` | Exact schedule state key and due read; implement in actual DB owner. |
| [D3 #856](https://github.com/aaweaver-actuary/tempo/issues/856) | Transaction recipe only | `sql/grade_transaction.pseudocode.sql; recipes/TRANSACTION_AND_ROLLOUT.md` | One borrowed transaction; unique per-attempt/position event receipt; no legacy FSRS duplicate. |
| [E1 #857](https://github.com/aaweaver-actuary/tempo/issues/857) | Read-only SQL recipe | `sql/source_inventory.readonly.sql` | Bounded population and cross-repertoire physical owner census; cannot substitute for actual exact-position count. |
| [E2 #858](https://github.com/aaweaver-actuary/tempo/issues/858) | Tested pure | `reference/donor.py:select_donor; reference/migration_preflight.py` | One valid current donor, deterministic earliest due, stable tie-break, explicit hold counts. |
| [F1 #859](https://github.com/aaweaver-actuary/tempo/issues/859) | Additive schema draft only | `sql/position_state_schema.reference.sql` | State/owner/issued plan/grades constraints; numbering and native schema readiness remain F1/DB owner work. |
| [F2 #860](https://github.com/aaweaver-actuary/tempo/issues/860) | Pure seed preflight only | `reference/migration_preflight.py; reference/donor.py` | Generate shadow seed plan; DB restartable backfill must be implemented against actual schema. |
| [F3 #861](https://github.com/aaweaver-actuary/tempo/issues/861) | Tested pure mode gate | `reference/owner_epoch.py` | No position issue/grade unless active owner epoch, current source and proven original admission; no activation. |
| [F4 #880](https://github.com/aaweaver-actuary/tempo/issues/880) | Operator recipe only | `recipes/TRANSACTION_AND_ROLLOUT.md:F1/F2/F3/F4` | Disposable activation/pause/rollforward; requires independently verified startup and backup. |
| [G1 #862](https://github.com/aaweaver-actuary/tempo/issues/862) | Tested pure | `reference/issued_plan.py; reference/contracts.py` | Freeze original card/attempt and all exposed due witnesses with source digest and version. |
| [G2 #863](https://github.com/aaweaver-actuary/tempo/issues/863) | Schema/issue recipe only | `reference/issued_plan.py; sql/position_state_schema.reference.sql` | Actual Study issuance writer persists plan immutably under original queue/attempt and scope locks. |
| [G3 #864](https://github.com/aaweaver-actuary/tempo/issues/864) | Negative evidence receipt recipe only | `reference/grades.py; recipes/TRANSACTION_AND_ROLLOUT.md:G1/G2/G3` | Durable first genuine wrong before complete aggregate review; never grade alternate/unverified. |
| [H1 #865](https://github.com/aaweaver-actuary/tempo/issues/865) | Tested bounded pure + SQL | `reference/due.py; sql/due_positions.reference.sql` | Read due exact positions by owner epoch with stable cursor and index; no graph traversal on GET. |
| [H2 #866](https://github.com/aaweaver-actuary/tempo/issues/866) | Composition recipe only | `reference/ports.py; reference/planner.py` | Queue owner passes bounded due targets/source candidates to frozen issuer; retain original head/priority. |
| [I1 #867](https://github.com/aaweaver-actuary/tempo/issues/867) | Transaction recipe only | `sql/grade_transaction.pseudocode.sql; recipes/TRANSACTION_AND_ROLLOUT.md:D3/I1` | Sole central review mode switch: position FSRS OR legacy card FSRS, never both. |
| [I2 #868](https://github.com/aaweaver-actuary/tempo/issues/868) | Tested pure counterexamples | `tests/test_pure_reference.py` | Replay, stale Good, repeated Wrong, two regimes; native DB integration tests still needed. |
| [J1 #869](https://github.com/aaweaver-actuary/tempo/issues/869) | Tested pure | `reference/game_mapping.py` | Resolve first-own-departure source to exact position while preserving original Games event key. |
| [J2 #870](https://github.com/aaweaver-actuary/tempo/issues/870) | Integration recipe only | `recipes/TRANSACTION_AND_ROLLOUT.md:J2` | Urgent position Again/introduction and settlement; no Games collector activation. |
| [K1 #871](https://github.com/aaweaver-actuary/tempo/issues/871) | Tested JavaScript validator | `browser/issued_plan.mjs; browser/issued_plan.test.mjs` | Translate to existing strict Zod DTO; never trust browser-computed due/route. |
| [K2 #872](https://github.com/aaweaver-actuary/tempo/issues/872) | UI recipe only | `recipes/TRANSACTION_AND_ROLLOUT.md:K2/L2; browser/issued_plan.mjs` | Render suffix starting FEN and original decision-index identity; no React integration yet. |
| [L1 #873](https://github.com/aaweaver-actuary/tempo/issues/873) | Tested JavaScript payload | `browser/offline_plan.mjs; browser/offline_plan.test.mjs` | Accept exact sealed offline plan or explicitly refuse online-only pilot; legacy offline unchanged. |
| [L2 #874](https://github.com/aaweaver-actuary/tempo/issues/874) | Offline integration recipe only | `recipes/TRANSACTION_AND_ROLLOUT.md:K2/L2` | Replay first wrong and completed responses through existing browser outbox; no local FSRS. |
| [M1 #875](https://github.com/aaweaver-actuary/tempo/issues/875) | Pure guard + integration recipe | `reference/owner_epoch.py; recipes/TRANSACTION_AND_ROLLOUT.md:M1` | R11 inert only for position-owned cohorts, all historical recombination data preserved. |
| [M2 #876](https://github.com/aaweaver-actuary/tempo/issues/876) | Tested pure | `reference/source_change.py` | Same exact position/approved response maintains state; changed response/policy fences. |
| [N1 #877](https://github.com/aaweaver-actuary/tempo/issues/877) | Synthetic test fixtures; chess replay not tested | `tests/conftest.py; tests/test_pure_reference.py` | Named Italian and London source witness sets; legal replay must be independently proven via python-chess in repo. |
| [N2 #878](https://github.com/aaweaver-actuary/tempo/issues/878) | Independent integration recipe only | `recipes/TRANSACTION_AND_ROLLOUT.md:N2` | One real disposable Postgres+browser package and source/image/schema/rollback evidence. |
| [N3 #879](https://github.com/aaweaver-actuary/tempo/issues/879) | Tested pure metric model | `reference/metrics.py` | Distinct positions tested/minute and nondue wrong from accepted events; 7/30d requires future data. |

## How cheap agents should use this kit

An agent handling a **pure/tested** leaf can use the named reference module and its focused tests as an *algorithmic starting point*, not blindly transplant the module. In the Tempo repo, choose the existing package owner and existing canonical FEN/FSRS APIs; preserve one-way import direction. Read the selected issue source pins and run the actual named owner tests.

A worker handling **SQL/schema/integration recipe** must not claim source code complete by copying a pseudocode block. Required work is actual DB identity, source revision/currentness fencing, integration with selected Study owner transaction, idempotency and per-instance qualified tests. A strong agent plus independently verified PostgreSQL acceptance is required.

The reference classification is not an automated model-capability verdict. A changed source owner, changed schema or missing runtime can elevate a supposedly cheap task.

## Smallest useful PR groupings (not mandatory)

1. Identity/source routes: A1+A2+B1 and their tests (one owner for shared contracts; the cheap fixtures can precede it).
2. Pure policy: B2+C1+C2+C3+M2, strictly within separate modules/ports; review conditional semantics before merging.
3. Read-only viability: E1+E2+H1+N3; report current data gap, no new scheduling owner.
4. Issuance contract: G1+K1+L1 as separate back/front typed DTO adoption, then G2 and K2 only after real source authority exists.
5. FSRS/migration: D1 then D2/D3 with F1/D3 single DB owner, F2 shadow seed, F3 disabled epoch. F4 actual operation separate.
6. Integration: H2, I1, J2, L2, M1 and N2 as a **serial** owner-correct release candidate, not a parallel shared-file swarm.

A PR can combine adjacent pure work if it preserves interfaces and reduces coordination. Never let a large PR change the physical-card scheduler and new position scheduler in parallel without the central review owner.
