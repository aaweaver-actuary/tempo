# Transaction, source-proof and rollout reference recipes (high-risk leaves)

This file gives **implementation ordering and invariants**, not runnable production code. Implementers must use the actual Learning, Study and Repertoire owners and their locks. No new services, background workers or graph DB are required.

## D3 / I1 — one position-grade transaction

1. Keep the original `ReviewCommand` identity, queue entry and client attempt ID. A generated presentation may start at a later FEN without changing those identities.
2. In the existing Review owner's borrowed writer, lock the original attempt and read its immutable stored issued-plan and version. Confirm the cohort owner epoch, original card admission repertoire, source/response policy, due-at-issue snapshot and recovered attempt lineage. Do not use browser-supplied FEN/grade as authority.
3. Accept actual first responses in server-validated event order. **Wrong** events require a durably acknowledged event, source-authorized classification (`wrong`, `illegal` or explicit manual-failure, not `alternate`/`unverified`), and an idempotency key `(original attempt, decision occurrence, first-response event)`. Apply Again on current schedule at acceptance time, not at an arbitrarily backdated client timestamp. Even when the full attempt is incomplete, first wrong must persist; if evidence cannot be verified, hold without discarding the original journal.
4. **Good** is eligible only if due at issued time, exact current response version, first response correct and unassisted, completed and saved attempt, no same-day earlier Good, and position state has not changed since the issued version. An outdated positive becomes an observation/held effect, not a backdated FSRS rewrite.
5. Lock position schedule rows in stable position-key order (card-before-queue lock constraints still apply). Use a unique accepted receipt per real first-response event and a unique Good/position/local day index. A duplicate event/identical digest returns the saved original receipt. Same ID/different digest is a conflict. An independent later first mistake can produce a new Again after a previous Good; guided correction cannot.
6. Apply the existing `fsrs` mathematics once per `good` or `again` through a **new position scheduling adapter**, saving complete FSRS state and current position revision. Do **not** invoke the existing physical-card `store.schedule` for the opted-in cohort. Write the original attempt's audit/reconciliation receipt and necessary queue effects in the same accepted transaction without any optional producer call.
7. Abort on failed mandatory save; never claim partial success. If a separate durable first-wrong receipt was accepted earlier, its retry/settlement must return the same result without a second penalty. Legacy card-mode follows original scheduling path unchanged.

### Why no generic event bus

A new event bus would add cross-layer ordering, exactly-once and owner problems. Use one Study-owned durable receipt and an injected narrow `PositionGradePort` inside the existing borrowed transaction. The Repertoire source is just immutable input.

## F1/F2/F3/F4 — migration and owner-epoch

- F1: reserve a schema version only after current serving schema owner and schema 56 baseline are rechecked; produce additive tables and indexes for stable position, mutable response version, full FSRS, original donor and accepted receipts, plus stage/active/paused epoch. Existing card rows, original review histories and R11 changes remain untouched. The included `_ref` DDL illustrates keys only, *not* a migration to execute.
- F2: source-revision checked, bounded *shadow* preflight and one-time seed per position; select a single current introduced valid physical card donor, earliest due then stable ID. Rekey internal FSRS ID through supported decoder/allocator, never reuse one internal card ID for four positions, never copy synthetic reviews. Record skipped/ambiguous donor reasons and reproducible receipt. Abort on source change or preexisting actual position-owned review; resume idempotently.
- F3: implement **inactive/readable owner-epoch fence first**, so queue/review can independently build against it. `shadow`/`staged` mode can never schedule position FSRS, even if seeding exists.
- F4: *later*, use supported operator and explicit selected cohort, known completed donor seed, current source/integrity, no unsettled old issued attempts, proof all shared physical-card admission scopes are unambiguous, backup/compatible image. Activate atomically; pause blocks new issuance but never discards accepted position reviews. Do not downgrade to old image if those reviews cannot be faithfully mapped back to physical cards. Provide safe roll-forward path.

## G1/G2/G3 — issue and negative evidence

- G1: versioned `IssuedPlan` contains only original queue and attempt ID, stable position IDs + current response versions, source digest/certificate, exact chosen route/target ply, legal start FEN and trailing UCI, every exposed learner decision's due-at-issue and position-state version, skipped-prefix source proofs, local day, owner epoch and content digest. A route-option export **must not** include due/FSRS/DB state.
- G2: select from B1/B2 **already legal** routes, freeze and persist plan before browser can play. No rerolling transposition after reconnect, no half-issued attempt and no whole graph recompute inside review/queue GET. Treat absent/changed source as a hold for new issuance; original saved attempts use their original source proof for reconciliation.
- G3: verify existing standalone `opening_evidence` partial checkpoint storage can retain a *first wrong* before aggregate completion; if not, extend that owner narrowly. A saved `unverified` alternate move is **not** failure. Preserve sequence and source response version; use a receipt/idempotency key. Do not pretend ordinary aggregate Review always executes when a browser closes.

## H1/H2 — bounded due and queue

- H1 returns due position keys with owner epoch and current version using an indexed bounded query, not an exhaustive Repertoire graph traversal at queue GET.
- H2 uses injected source-route options + pure planner to issue a frozen valid presentation. An accepted earlier incidental due Good can satisfy a due target without a second queue entry; an actual contextual Again yields urgent correct position effect. An ambiguous shared *physical card across repertoires* blocks only the affected pilot cohort. Preserve original issued head, new introduction budget, priority receipts and normal non-position Study.

## J2 — Games

Original `GameEffectKey` and original first-own-departure witness never change. `J1` only maps the witness to stable `PositionKey` and current expected answer. Under position-owner epoch, apply one legitimate Again (not synthetic aggregate Good), prioritize the position through the Study queue and settle only after authentic saved Study completion. `opponent-first` is repertoire gap, not Again. Games optional failure or inactive mode cannot stop normal Study. Same logical event retried never doubles effects.

## K2/L2 — browser/offline

K2 renders the frozen plan. Its move index is the *displayed suffix* index, but the server-provided `decision_index` is the original immutable move/observation identity; never create a second source of truth with client line slicing. L2 retains exact immutable payload in outbox and replays by original attempt ID. Online-only first pilot explicitly refuses new offline position attempts if immutable negative evidence and source recovery are not qualified. Legacy card offline mode is unaffected.

## M1 — R11

The optional `after_saved_review` combiner is **inactive** for any active position-owned cohort. It may still operate for legacy card-owned cohorts. Never delete `study_recombination_*` historical state, generated cards or accepted game targets to simplify migration. Cohort scope must be proved by admission source, not card primary owner.

## N2 — independent acceptance

One selected disposable assembled PostgreSQL+browser candidate must show source proof -> chosen frozen route -> real played learner moves -> durable accepted first responses -> due-only positive Good and nondue real wrong Again -> FSRS position state update while legacy card state remains identical -> original review/queue settlement. Include Italian and exact London transposition, stale client, two tabs, interrupted wrong, source change, migrated donor, Games and retained R11. Release evidence separates source, code, test, packaged image/schema, installed and active. The present kit proves **none** of these cross-boundary journeys.
