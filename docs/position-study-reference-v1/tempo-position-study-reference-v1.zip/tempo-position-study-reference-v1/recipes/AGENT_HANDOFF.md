# Cost-controlled coordinator and worker handoff

## Coordinator preparation prompt (do not implement)

Use the existing user's `/p harden` role for https://github.com/aaweaver-actuary/tempo/issues/832 and read the latest A1 interface decision. Compare baseline source SHA, current PR owners, and worker scopes with this reference kit. Do not create a new graph database, independent scheduler, event bus, or optional background worker. Preserve source responsibility, one schedule writer and original immutable attempt IDs. If any code in the reference kit differs from current production source, source ownership wins; record the discrepancy and update the relevant small worker issue, not a second programme. Explicitly name uncertainties in current saved review, selected graph-currentness proof, schema/FSRS decoder, cross-repertoire physical owner and offline replay. Stop at dispatch-ready revised issue material; no code write, merge, deployment or live DB.

## Example for a cheap pure worker — B2

**Goal:** implement only #850 pure legal route choice and prefix proof, following A1/#847 and B1/#849 frozen values. Read this kit's `reference/planner.py` as reference algorithm, not as a new graph or schedule owner. Inputs are already validated immutable source options; return a frozen one-route plan/hold, never mutate database, call FSRS, traverse new graph edges or read the local clock. Tests: Italian alternate branches reversed order, source edit stale proof, partial/assisted first attempt must not skip, exact London transposed path, no target and an entirely already-covered exercise. Use a named isolated pure test command; share only one PR containing the new pure function and focused tests. Stop and hand the typed result to G1/G2. If source has different DTO names, adapt at composition; no Repertoire↔Learning implementation imports.

## Example for a senior DB worker — I1

**Goal:** implement only #867 owner-epoch branch of the actual Review command. Ensure A1/C2/D3/G2/G3/H2/F3 interfaces are released and #657/#668 has given the central writer slot. Keep legacy card FSRS unmodified for non-opt-in and never write both physical and position FSRS for the same event. Use the original borrowed writer transaction, immutable attempt ID, and real evidence completion/partial wrong receipt. Source/currentness/answer/due snapshots must be fenced and positive Good deduplicated at accepted grade ledger. No background producers in review. Reuse existing FSRS math; no new scheduler process. Focus native tests on four cases: due first correct Good, nondue correct zero schedule, actual nondue first wrong Again despite abandoned exercise, and two-tab retry/duplicate Good only once. Add zero-dual-write assertions for every case. Return a precise code diff, test command/receipt and backup/rollback gap. Do not merge or enable production.

## Execution discipline

- Every cheap agent gets **one leaf issue and at most one patch slice**. It should not see the entire 34-task project unless its own narrow contract is ambiguous.
- The coordinator controls shared file grants, pins source revision, import boundary enforcement and schema numbering. Cheap agents can author a single pure module+test or read-only report; senior agents do actual transaction adoption.
- Do not batch rerun broad pytest / Playwright for a pure-doc or fixture conflict. Reserve one resource-heavy disposable PostgreSQL/browser verifier (N2) and reuse evidence only when changed inputs do not invalidate it.
- If the user later authorizes implementation, make the first release **one vertical offline-independent pilot** that verifies exact position schedule ownership in disposable DB, not full cross-repertoire modernization. Current real Study installation requires separate authorization, data backup, source-currentness read, and explicit safety switch.

## Spec changes already fixed

Stable schedule ID vs response definition; first error before completion; no positive duplicate per day; stale issued due snapshot vs accepted schedule; one complete donor per position and new FSRS internal card ID; online-only position pilot if offline cannot prove original issuer; no R11 new joins in position owner; legacy Events/Games identity retained; source graph export via existing `RepertoireSnapshotPort` instead of new graph store.
