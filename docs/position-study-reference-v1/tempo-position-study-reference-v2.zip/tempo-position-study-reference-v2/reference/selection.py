"""Reference pure composition seam for cheap workers B1/B2/C3/G1/H1.

This does not load any database or authorize issuance. The real composition
root must supply a current Repertoire-authorized route batch and Study-owned
due/coverage receipts, then call an owning Study transaction to issue the plan.
"""
from __future__ import annotations

from dataclasses import dataclass

from .contracts import DueAtIssuance, Hold, PositionDefinition, PositionKey, RouteOption
from .graph import index_routes, options_for_target
from .issued_plan import IssuedPlan, freeze_issued_plan
from .planner import CleanPresentationProof, choose_plan


@dataclass(frozen=True)
class SelectionRequest:
    """Detached immutable inputs; no graph/FSRS/database implementation objects."""
    target: PositionDefinition
    routes: tuple[RouteOption, ...]
    dues: tuple[DueAtIssuance, ...]  # includes NONDUE for tested context
    clean_proofs: tuple[CleanPresentationProof, ...]
    original_card_id: str
    original_card_revision: int
    original_queue_entry_id: int
    attempt_id: str


def select_and_freeze(request: SelectionRequest) -> IssuedPlan | Hold:
    """One deterministic path, then a pure, non-authoritative proposed frozen plan.

    The production issuer MUST recheck source/epoch/issued head and persist the
    plan atomically. A returned IssuedPlan does NOT prove such a write occurred.
    """
    target: PositionKey = request.target.key
    if not request.routes:
        return Hold("no_authorized_routes")
    index = index_routes(request.routes)
    choices = options_for_target(index, target)
    if isinstance(choices, Hold):
        return choices
    if not request.dues:
        return Hold('missing_due_witnesses')
    if len({(d.study_day, d.owner_epoch) for d in request.dues}) != 1:
        return Hold('mixed_daily_due_scope')
    day, epoch = request.dues[0].study_day, request.dues[0].owner_epoch
    plan = choose_plan(target, choices, clean_proofs=request.clean_proofs,
                       study_day=day, owner_epoch=epoch)
    if isinstance(plan, Hold):
        return plan
    if len(plan.moves_uci) > 40 or len(plan.exposed_positions) > 20:
        return Hold('issued_presentation_exceeds_wire_bound')

    selected = [route for route in choices if route.route_id == plan.route_id]
    if len(selected) != 1:
        return Hold("selected_route_identity_ambiguous")
    route = selected[0]
    # Stable output order is the legal on-board order, not the order in which
    # SQL happened to return due states or a client's untrusted requested IDs.
    remaining = tuple(d for d in route.decisions
                      if d.ply >= len(route.moves_uci) - len(plan.moves_uci))
    if not remaining:
        return Hold("no_learner_decisions_to_test")
    by_position = {}
    for due in request.dues:
        if due.definition.key in by_position:
            return Hold("duplicate_position_due_witness")
        by_position[due.definition.key] = due
    if len(set(d.definition.key for d in remaining)) != len(remaining):
        # A twice-visited position in one exercise needs a separate occurrence
        # contract and must not be silently graded twice.
        return Hold("repeated_position_in_one_presentation")
    if set(by_position) != {d.definition.key for d in remaining}:
        return Hold("due_witnesses_do_not_match_selected_route")
    for occurrence in remaining:
        witness = by_position[occurrence.definition.key]
        if witness.definition != occurrence.definition:
            return Hold("source_response_vs_due_witness_conflict")
        if witness.owner_epoch != request.dues[0].owner_epoch:
            return Hold("mixed_position_owner_epoch")
    ordered_witnesses = tuple(by_position[d.definition.key] for d in remaining)
    return freeze_issued_plan(
        original_card_id=request.original_card_id,
        original_card_revision=request.original_card_revision,
        queue_entry_id=request.original_queue_entry_id,
        attempt_id=request.attempt_id,
        due_positions=ordered_witnesses,
        plan=plan,
        source_definition=request.target,
    )
