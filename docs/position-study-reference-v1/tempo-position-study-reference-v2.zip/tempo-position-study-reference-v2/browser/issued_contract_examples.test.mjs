import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { decodeIssuedPlan } from './issued_plan.mjs';

for (const name of ['italian_suffix','italian_full']) {
  test(`versioned reference issue wire ${name} decodes`, () => {
    const data = JSON.parse(readFileSync(new URL(`../wire/examples/${name}.json`,import.meta.url)));
    const result = decodeIssuedPlan(data);
    assert.equal(result.version,1);
    assert.equal(result.queue_entry_id,data.queue_entry_id);
    assert.equal(Object.isFrozen(result),true);
    assert.deepEqual(result.moves_uci,data.moves_uci);
  });
}

test('mismatched expected learner move fails even when JSON shape is otherwise valid', () => {
  const data=JSON.parse(readFileSync(new URL('../wire/examples/italian_suffix.json',import.meta.url)));
  data.decision_slots[0].expected_uci='e2e4';
  assert.throws(()=>decodeIssuedPlan(data),/invalid_issued_plan/);
});

test('no learner decision cannot be a playable issued attempt', () => {
  const data=JSON.parse(readFileSync(new URL('../wire/examples/italian_suffix.json',import.meta.url)));
  data.decision_slots=[];
  assert.throws(()=>decodeIssuedPlan(data),/invalid_issued_plan/);
});

test('unknown nested decision field fails closed like the JSON schema', () => {
  const data=JSON.parse(readFileSync(new URL('../wire/examples/italian_suffix.json',import.meta.url)));
  data.decision_slots[0].fsrs_due=true;
  assert.throws(()=>decodeIssuedPlan(data),/invalid_issued_plan/);
});
