// Reference-only runtime validator for an immutable server-authorized plan.
// Worker K1 should translate to existing strict Zod schemas in the Tempo repo.
// This module does NOT compute due dates, source validity, prefix eligibility
// or a new chess route. Only the original server receipt authorizes play.
const uci = /^[a-h][1-8][a-h][1-8][qrbn]?$/;
const hexdigest = /^[0-9a-f]{64}$/;
const allowedDecision = new Set(['move_offset','position_key','expected_uci']);
const allowed = new Set([
  'version', 'plan_id', 'original_card_id', 'original_card_revision',
  'queue_entry_id', 'attempt_id', 'owner_epoch', 'route_id', 'target_ply',
  'starting_fen', 'moves_uci', 'decision_slots', 'source_digest',
  'local_day', 'skipped_prefix_proof_ids',
]);
function object(value) { return !!value && typeof value === 'object' && !Array.isArray(value); }
function str(value) { return typeof value === 'string' && value.length > 0; }
export function decodeIssuedPlan(raw) {
  if (!object(raw) || Object.keys(raw).some(k => !allowed.has(k))) throw Error('unknown_plan_field');
  const { version, plan_id, original_card_id, original_card_revision, queue_entry_id,
    attempt_id, owner_epoch, route_id, target_ply, starting_fen, moves_uci,
    decision_slots, source_digest, local_day, skipped_prefix_proof_ids } = raw;
  if (version !== 1 || !hexdigest.test(plan_id) || !str(original_card_id) ||
    !Number.isSafeInteger(original_card_revision) || original_card_revision < 1 ||
    !Number.isSafeInteger(queue_entry_id) || queue_entry_id < 1 ||
    !str(attempt_id) || !str(owner_epoch) || !str(route_id) ||
    !Number.isSafeInteger(target_ply) || target_ply < 0 ||
    !str(starting_fen) || !str(source_digest) ||
    !/^\d{4}-\d{2}-\d{2}$/.test(local_day) ||
    !Array.isArray(moves_uci) || moves_uci.length > 40 || moves_uci.some(m => !uci.test(m)) ||
    !Array.isArray(decision_slots) || decision_slots.length === 0 || decision_slots.length > 20 ||
    decision_slots.some(d => !object(d) || Object.keys(d).some(k => !allowedDecision.has(k)) || !Number.isSafeInteger(d.move_offset) ||
      d.move_offset < 0 || d.move_offset >= moves_uci.length || !str(d.position_key) ||
      !uci.test(d.expected_uci) || d.expected_uci !== moves_uci[d.move_offset]) ||
    !Array.isArray(skipped_prefix_proof_ids) || skipped_prefix_proof_ids.some(x => !str(x))) {
    throw Error('invalid_issued_plan');
  }
  const offsets = decision_slots.map(d => d.move_offset);
  if (new Set(offsets).size !== offsets.length || offsets.some((x,i) => i && offsets[i-1] > x))
    throw Error('duplicate_or_unordered_decisions');
  return Object.freeze({ ...raw, moves_uci: Object.freeze([...moves_uci]),
    decision_slots: Object.freeze(decision_slots.map(s => Object.freeze({...s}))),
    skipped_prefix_proof_ids: Object.freeze([...skipped_prefix_proof_ids]) });
}
