# Tempo position-owned Study — expected interfaces v2

**Preparation/reference only.** This document defines *proposed* interfaces for the existing
[#832 coordinator](https://github.com/aaweaver-actuary/tempo/issues/832). It is not a
change to Tempo's public API, schema, or FSRS authority. Source review pin:
`ea68e5d7038c02b813e690584c022bf5f0d9edb6`.

## 0. Four ownership rules that must survive every PR

| Owner | May accept | Must NEVER import, compute or write |
| --- | --- | --- |
| **Repertoire** (current source) | `RepertoireSnapshotPort.snapshot(repertoire_id)`; immutable legal route, exact position/response, source currentness/conflict proof | FSRS, Study queue, learning due dates, accepted grade ledger |
| **Study/Learning** | `PositionKey`, issuer's stored `IssuedPlan`, saved first-response evidence, due witness, grade-effect receipt | Repertoire `PositionIndex` implementation, source DB connection, graph traversal, alternate-path search |
| **Pure composition/planner** | Detached route options + due witnesses + saved whole-clean prefix certificates | Any SQL, FSRS, queue write, server ownership switch, web client state |
| **Browser** | Strict server-issued exercise moves/starting FEN and attempt identity | Graph search, due eligibility, prefix-credit decisions, FSRS transitions |

Existing canonical chess source **is**
`app.contracts.product_v02.repertoire.RepertoireSnapshotPort.snapshot` followed by
`app.repertoire.position_index.build_index`. The current index may be incomplete
because **physical-card mappings** are ambiguous; that is not, by itself, an
ambiguous approved chess move. Repertoire must supply a separately verified
*authored-route source certificate*, as described in [P-11](https://github.com/aaweaver-actuary/tempo/issues/832#issuecomment-6580113746).
Do not fake a certificate with a boolean in production.

## 1. Stable pure values — shared language

Use `reference/contracts.py` as the normative **algorithmic example**, not as
an import to transplant into every product package:

```python
PositionKey(repertoire_id: str, position: str, variant='standard')
# position: exactly four normalized legal FEN fields, no clocks

PositionDefinition(key: PositionKey, expected_uci: str, policy_version: str)
# Answer and policy version are separately fenced; not part of learning key.

SourceCertificate(snapshot_id, source_revision, source_digest,
                  complete, current_integrity)

DecisionOccurrence(ply: int, definition: PositionDefinition, fen: str)
RouteOption(route_id, start_fen, moves_uci, learner_color,
            decisions, certificate, legal_verified)

DueAtIssuance(definition, due: bool, study_day: date,
              owner_epoch: str, position_revision: int, issued_at: datetime)

FirstResponse(attempt_id, index, definition, actual_uci,
              assistance_before: bool, observed_at, event_id, manual_failure=False)
AcceptedEvidence(first_response, saved, disposition, terminal_complete,
                 aggregate_review_saved, owner_epoch, source_digest, accepted_at)

GradeProposal(position, policy_version, event_id, study_day, owner_epoch,
              issued_position_revision, grade, reason, observed_at, accepted_at)
Hold(reason, detail='')
```

**Important:** `DueAtIssuance` is a **Study-owned witness for EVERY learner
position physically shown**, even if `due=False`; it is not delivered by the
Repertoire graph. The browser wire may omit actual due/FSRS values entirely;
the server retains them in its authoritative issued-attempt record.

## 2. Exact function/port boundaries and return types

These are **expected consumer contracts**, with working reference logic when
possible. Smaller workers should implement a single named boundary, preserve
specified Hold codes, and build against supplied fixture data.

| Owner leaf | Proposed call | Output | Existing runnable reference or stub | Reject/hold if |
| --- | --- | --- | --- | --- |
| A1 #847 | `PositionKey(...); PositionDefinition(...)` | Immutable key/value | `reference/contracts.py` | Wrong position/answer policy or owner |
| B1 #849 | `routes_from_validated_index(index, *, membership_complete, current_integrity)` | `tuple[RouteOption,...] \| Hold` | `reference/source_adapter.py` | Fatal content/legality/source conflict; ambiguous physical binding alone is NOT fatal |
| B1 #849 | `index_routes(route_options)`; `options_for_target(index,key)` | `tuple[RouteOption,...] \| Hold` | `reference/graph.py` | Own response conflict, absent target, bounds |
| B2 #850 | `choose_plan(target, routes, *, clean_proofs, study_day, owner_epoch)` | `Plan \| Hold` | `reference/planner.py` | No certified path, bad prefix certificate, target already clean today |
| C1 #851 | `propose_grade(accepted_evidence, due_at_issue)` | `GradeProposal \| Hold` | `reference/grades.py` | Unverified/alternate move, unsaved evidence, version/epoch mismatch |
| C2 #852 | `ProofLedger.accept(proposal)` | Final accepted GradeProposal or Hold | `reference/grades.py` | Duplicate changed receipt; repeat Good or stale Good becomes Observe |
| C3 #853 | `CleanPresentationProof(...)` | Saved whole-clean and same-day prefix proof | `reference/planner.py` | Different day/epoch/root, unknown help, partial/failed review, changed source |
| D1 #854 | `select_donor(key, candidates)`; `clone_state(fsrs_json, allocated_new_card_id=...)` | Valid donor/FSRS JSON or Hold | `reference/donor.py` | Ineligible donor, invalid blob, duplicate actual internal FSRS ID (real DB check) |
| E1/E2 #857–858 | `source_inventory.readonly.sql` + `select_donor` | Population and deterministic candidate report | `sql/` + `reference/migration_preflight.py` | Stale graph, ambiguous repertoire owner or missing source proof |
| G1 #862 | `freeze_issued_plan(original_card_id, ..., due_positions, plan, target_definition)` | Pure `IssuedPlan \| Hold` (NOT a persisted attempt) | `reference/issued_plan.py` | Wrong original attempt, missing context due witnesses, owner/day mismatch |
| G1/H2 integration | `select_and_freeze(SelectionRequest(...))` | Deterministic **pure proposed** `IssuedPlan \| Hold` | **`reference/selection.py` + `tests/test_selection_contract.py`** | Any unproved source/coverage/issued context; no DB allowed |
| H1 #865 | `due_page(states, now, *, owner_epoch, after, limit)` | Bounded due witnesses | `reference/due.py` | Invalid bound, non-current owner/source |
| J1 #869 | `resolve_lapse(first_departure, current_definition, source_digest)` | `PositionGameTarget \| Hold` | `reference/game_mapping.py` | Opponent-first, changed answer/currentness; original effect ID unchanged |
| M2 #876 | `compare_definition(previous,current)` | Retain/hold source-change disposition | `reference/source_change.py` | Different exact position, answer or policy |
| N3 #879 | `summarize(accepted_position_events, started, ended)` | Reproducible metric counters | `reference/metrics.py` | Missing timestamps => unavailable, no invented efficiency |
| F3 #861 | `may_issue_position_attempt(epoch, repertoire_id, source_digest, original_card_owner_proved)` | True or Hold | `reference/owner_epoch.py` | Not active or stale/ambiguous owner, no silent fallback |
| K1 #871 | `decodeIssuedPlan(raw)` | Frozen/validated **browser display payload** | `browser/issued_plan.mjs` and versioned JSON schema | Unknown field, wrong UCI/offset, invalid attempt identity |
| L1 #873 | `offline_plan` v1 helper | Persist original immutable attempt or hold | `browser/offline_plan.mjs` | Position-owned pilot not certified for offline; old legacy mode unaffected |

**DO NOT confuse a pure `IssuedPlan` value from `freeze_issued_plan` with an
accepted server issuance.** The real Study issuer G2 must persist it atomically
under the source, owner-epoch, original queue/head and attempt locks. The
`plan_id` is a digest/identifier, **not a cryptographic signature**; client-side
validation cannot establish its server authenticity.

## 3. Senior adapter interfaces — templates, not implementations

Their exact concrete location depends on the current actual Learning database
owner; keep these **internal** and borrower-transaction-only. No `commit()` or
connection factory inside a leaf adapter.

```python
class PositionScheduleReadPort(Protocol):
    def read_due_page(self, *, repertoire_id: str, owner_epoch: str,
                      after: tuple | None, limit: int) -> tuple[DueAtIssuance, ...]: ...
    def read_current(self, position: PositionKey) -> PositionState | Hold: ...

class IssuedPositionAttemptPort(Protocol):
    def issue_in_borrowed_transaction(self, original_queue_id: int,
            proposal: IssuedPlan, *, source_epoch: str) -> IssuedReceipt | Hold: ...
    def replay_exact_attempt(self, attempt_id: str) -> IssuedReceipt | Hold: ...

class GradeEffectWritePort(Protocol):
    def apply_in_borrowed_transaction(self, accepted: tuple[GradeProposal, ...],
            original_attempt_id: str, *, owner_epoch: str) -> tuple[GradeReceipt, ...]: ...

class PositionOwnerEpochReadPort(Protocol):
    def fence_in_borrowed_transaction(self, repertoire_id: str,
            epoch: str, source_digest: str) -> PositionOwnerReceipt | Hold: ...
```

The names `PositionState`, `IssuedReceipt`, `GradeReceipt`, and
`PositionOwnerReceipt` are **proposed as internal data values**, not existing
Python classes and not permission to implement a new framework. Worker G2
must not implement FSRS; D3 must not issue/plan routes; H2 must not write
Learning Grade receipts; I1 is the only existing central review writer.

### Actual publication transaction (G2)

1. Read bounded current source certificate / target route facts OUTSIDE the
   interactive writer; all prior calculations are detached.
2. Obtain current due and prior whole-clean prefix proofs from Study's owner.
3. Select one route and freeze a proposal purely; no database mutations yet.
4. Enter the **existing** supported Study issuance transaction; fence source,
   owner epoch, due/credit scope, original authorized queue head and attempt.
5. Insert the exact frozen proposal **once** under immutable attempt ID. A
   matching retry returns the existing receipt byte-for-byte; a mismatched
   payload for the same ID is a conflict, not a reroll.
6. Reuse the old original queue/card attempt identity as recovery provenance.

### Actual grade transaction (D3/I1)

1. Verify the saved server first-response evidence and original issued plan.
2. With one borrowed transaction, lock schedule positions in stable key order.
3. For **wrong**: apply Again only for a new verified first-error receipt,
   including nondue context and abandoned attempts. A repeated guided move
   or identical sender replay is not another FSRS transition.
4. For **correct**: only accept Good after a complete saved attempt, if due at
   issuance, original definition/owner epoch still valid, no intervening
   position state version change and no previous Good for that position/day.
   Otherwise record observation, not an FSRS update.
5. In opted-in cohort, never independently advance the physical-card schedule.
   Non-opted-in cohort follows existing card scheduler unchanged.
6. Store exact accepted event receipt with pre/post FSRS state, replay key and
   original queue/attempt ID; settle queue with original writer. A failure rolls
   the whole accepted unit back. **No graph imports** or optional Games worker
   calls in this transaction.

### Failure receipt (G3)

A wrong first response may be persisted while the exercise has not completed.
The current per-decision evidence journal and completion review are distinct.
Do not invent a `Good` from partial context; use existing standalone checkpoint
semantics where genuinely available, add an immutable receipt if required and
make retries idempotent. If offline first-error durability cannot be qualified,
keep position-owned pilot online-only with an explicit unavailability state.

## 4. One golden end-to-end pure example

```python
from reference.selection import SelectionRequest, select_and_freeze
from reference.contracts import DueAtIssuance, Hold

# Inputs are detached Repertoire-certified source and Study-owned witnesses.
result = select_and_freeze(SelectionRequest(
    target=target_definition,
    routes=certified_route_options,
    dues=due_witnesses_for_all_physically_tested_learner_positions,
    clean_proofs=saved_complete_clean_today,
    original_card_id="original-card-id", original_card_revision=3,
    original_queue_entry_id=61, attempt_id="stable-study-attempt-id",
))
# result is an IssuedPlan or typed Hold. It has NOT touched a DB.
# Only the owning G2 server adapter may persist an IssuedPlan.
```

Run reference tests:

```sh
python -m pytest -q tests/test_selection_contract.py tests/test_wire_schemas.py
node --test browser/issued_contract_examples.test.mjs
```

The versioned **browser-only display** contract is
`wire/issued_plan.v1.schema.json`, with both full Italian and shortened Giuoco
Piano examples in `wire/examples/`. It intentionally omits FSRS state/due dates,
which remain in the server-side `IssuedPlan`.

## 5. Acceptance rule for cheap workers

Each worker's PR description must answer five concrete questions:

1. **Inputs:** Which existing owner supplies data, at what source/epoch/revision?
2. **Outputs:** Which exact typed value or Hold code does it return? Show one
   valid fixture and one invalid fixture.
3. **Imports:** Does it use only pure values? Does it depend on another domain's
   implementation or database connection? If yes, reject or move to composition.
4. **Tests:** Which file-specific Python/Node test fails if the worker's actual
   fault reappears? A reference test does not establish native PostgreSQL proof.
5. **Handoff:** Which downstream worker consumes this exact interface? No worker
   may silently change a persisted key or protocol version to fit its code.

**Strong reviewer-only tasks:** actual FSRS 6.3.2 clone/roundtrip, source/current
certificate, PostgreSQL lock ordering, offline duplicate recovery, physical
card → exact position seeding, Games original effect mapping/settlement, and
actual enabled cohort/rollback. Those cannot be qualified by a mocked port.
