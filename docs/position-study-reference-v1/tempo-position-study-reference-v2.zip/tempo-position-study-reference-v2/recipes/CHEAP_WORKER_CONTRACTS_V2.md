# Ready-to-assign contract handoffs for cheaper agents

**Source pin:** `ea68e5d7038c02b813e690584c022bf5f0d9edb6`. The current
GitHub issue (linked below) controls actual file ownership and any newer
implementation; these reference interfaces provide *expected return shapes*.
Only one writer per source file. No new migration, background worker, database
connection or product-level imports from these cheap tasks.

| Cheap leaf | Canonical input | Required output | Exact demonstration or test | Downstream consumer |
| --- | --- | --- | --- | --- |
| [A2 #848](https://github.com/aaweaver-actuary/tempo/issues/848) | Legal synthetic FEN/route fixtures | Immutable `PositionKey`/`PositionDefinition` goldens | `tests/conftest.py`, `tests/test_pure_reference.py` | A1/B1/C1/N2 |
| [B1 #849](https://github.com/aaweaver-actuary/tempo/issues/849) | Existing **verified** `RepertoireSnapshot` + `PositionIndex` | `tuple[RouteOption,...] \| Hold` | `reference/source_adapter.py`, `graph.py` | B2/H2/G2 |
| [B2 #850](https://github.com/aaweaver-actuary/tempo/issues/850) | Exact target, bounded route options, same-day whole-clean proofs | `Plan \| Hold` | `reference/planner.py` and selection tests | G2 |
| [C1 #851](https://github.com/aaweaver-actuary/tempo/issues/851) | Original first-response event + due witness | Good/Again/Observe/Pending proposal or Hold | `reference/grades.py` + grading matrix | C2/D3 |
| [C3 #853](https://github.com/aaweaver-actuary/tempo/issues/853) | Saved whole-clean presentation, original source root/day/epoch | `CleanPresentationProof` and eligible skip prefix | `reference/planner.py` + wrong-day/root/partial tests | B2 |
| [E1 #857](https://github.com/aaweaver-actuary/tempo/issues/857) | Current published graph+card owner reads in a **read-only** role | By-repertoire unique position and donor inventory + holds | `sql/source_inventory.readonly.sql`, not live-authoritative | E2/F2 |
| [E2 #858](https://github.com/aaweaver-actuary/tempo/issues/858) | Current distinct eligible donor candidates | One complete chosen donor or Hold | `reference/donor.py` | F2 |
| [G1 #862](https://github.com/aaweaver-actuary/tempo/issues/862) | Pure `Plan`, due witnesses, original attempt ID | Pure `IssuedPlan \| Hold` | `reference/selection.py`, `issued_plan.py`, `wire/` | G2/K1 |
| [J1 #869](https://github.com/aaweaver-actuary/tempo/issues/869) | Selected first-own game departure + source version | `PositionGameTarget \| Hold`; original effect ID unchanged | `reference/game_mapping.py` | J2 |
| [K1 #871](https://github.com/aaweaver-actuary/tempo/issues/871) | Server-issued JSON wire v1 | Strict validated immutable display payload | `wire/issued_plan.v1.schema.json`, `browser/issued_plan.mjs` | K2/L1 |
| [L1 #873](https://github.com/aaweaver-actuary/tempo/issues/873) | Sealed original attempted Study presentation | Immutable offline cache or explicit unsupported hold | `browser/offline_plan.mjs` | L2 |
| [N1 #877](https://github.com/aaweaver-actuary/tempo/issues/877) | Italian, London, overlapping/exact positions | Legal positive/negative goldens, no fabricated learner decisions | `tests/conftest.py`; native `python-chess` still required | All workers, N2 |
| [N3 #879](https://github.com/aaweaver-actuary/tempo/issues/879) | Accepted position events and wall-time | Distinct tested positions/minute, due/Again counters, missing denominators | `reference/metrics.py` | N2 |

**Potential upgrade from cheaper to medium:** if a leaf has to adjudicate
source currentness, revise schemas, execute a transaction, preserve previously
accepted attempts or resolve true physical/shared owner ambiguity, stop and
handoff to the named senior owner. No “temporary” SQL in a pure package.

## Acceptance fixture contracts

The smallest complete end-to-end reference is
`tests/test_selection_contract.py:test_saved_whole_clean_prefix_returns_one_suffix_and_immutable_digest`.
It exercises a chosen target and a prior saved full-line proof. The negative
tests `test_yesterdays_complete_review_does_not_skip_todays_prefix` and
`test_same_moves_from_another_start_position_cannot_credit_prefix` explicitly
prevent cross-day and cross-root false successes. The issued plan browser
examples show the identical move-slot identity in Python JSON and Node.

Workers are free to change **internal** algorithm implementation if the same
public outputs/holds and tests remain true. Do not merge the reference files
whole into the product. Native source, FSRS and PostgreSQL tests remain separate.
