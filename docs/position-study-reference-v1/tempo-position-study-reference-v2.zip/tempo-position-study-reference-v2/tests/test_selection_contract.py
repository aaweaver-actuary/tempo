"""First implementation handoff: B1/B2/C3/G1 can use identical goldens."""
from dataclasses import replace
from datetime import datetime, timezone

from conftest import NOW, DAY, F_C3, italian_routes
from reference.contracts import DueAtIssuance, Hold
from reference.issued_plan import IssuedPlan
from reference.planner import CleanPresentationProof
from reference.selection import SelectionRequest, select_and_freeze


def request_for(credit: bool):
    gui, knight = italian_routes()
    proof = CleanPresentationProof(
        "saved-knight", "digest-1", knight.moves_uci,
        tuple(d.definition.key for d in knight.decisions),
        True, True, True, DAY, "epoch-1", knight.start_fen,
    )
    # With valid clean-prefix credit, only the branch suffix is actually
    # tested. Without it, every own move requires a due/non-due witness.
    source_decisions = (gui.decisions[-1],) if credit else gui.decisions
    dues = tuple(DueAtIssuance(d.definition, d is gui.decisions[-1], DAY,
                               "epoch-1", 1, NOW) for d in source_decisions)
    return SelectionRequest(
        target=gui.decisions[-1].definition,
        routes=(gui,),
        dues=dues,
        clean_proofs=(proof,) if credit else (),
        original_card_id="legacy-card", original_card_revision=3,
        original_queue_entry_id=61, attempt_id="attempt-1",
    )


def test_full_route_includes_due_and_nondue_context():
    issued = select_and_freeze(request_for(False))
    assert isinstance(issued, IssuedPlan)
    assert len(issued.due_positions) == 4
    assert sum(d.due for d in issued.due_positions) == 1
    assert issued.route.starting_fen.endswith("w KQkq -")
    assert issued.route.skipped_prefix_decisions == ()


def test_saved_whole_clean_prefix_returns_one_suffix_and_immutable_digest():
    issued = select_and_freeze(request_for(True))
    assert isinstance(issued, IssuedPlan)
    assert issued.route.starting_fen == F_C3
    assert issued.route.moves_uci == ("c2c3",)
    assert len(issued.route.skipped_prefix_decisions) == 3
    assert len(issued.due_positions) == 1
    assert issued.plan_id == select_and_freeze(request_for(True)).plan_id


def test_unproven_or_incorrect_context_witness_cannot_issue():
    original = request_for(False)
    assert select_and_freeze(replace(original, dues=original.dues[-1:])) == Hold(
        "due_witnesses_do_not_match_selected_route")
    extra = replace(original.dues[0], due=True)
    assert select_and_freeze(replace(original, dues=original.dues+(extra,))) == Hold(
        "duplicate_position_due_witness")
    edited = replace(original.dues[-1], owner_epoch="other")
    assert select_and_freeze(replace(original, dues=original.dues[:-1]+(edited,))) == Hold(
        "mixed_daily_due_scope")


def test_journal_does_not_prove_queue_issuance():
    issued = select_and_freeze(request_for(False))
    assert isinstance(issued, IssuedPlan)
    # There is no persistence port here: the result is a proposed frozen plan.
    assert issued.queue_entry_id == 61
    assert issued.original_card_id == "legacy-card"


def test_complete_clean_target_does_not_generate_second_attempt_today():
    original = request_for(True)
    gui = original.routes[0]
    completed = CleanPresentationProof(
        "completed-gui", "digest-1", gui.moves_uci,
        tuple(d.definition.key for d in gui.decisions),
        True, True, True, DAY, "epoch-1", gui.start_fen,
    )
    assert select_and_freeze(replace(original, clean_proofs=(completed,))) == Hold(
        "position_already_cleanly_tested_today")


def test_yesterdays_complete_review_does_not_skip_todays_prefix():
    from datetime import timedelta
    req = request_for(True)
    yesterday = replace(req.clean_proofs[0], study_day=DAY-timedelta(days=1))
    # The optimistic suffix's single due witness is now insufficient: prove
    # a complete new route or explicitly hold, never silently skip.
    assert select_and_freeze(replace(req, clean_proofs=(yesterday,))) == Hold(
        "due_witnesses_do_not_match_selected_route")


def test_same_moves_from_another_start_position_cannot_credit_prefix():
    req = request_for(True)
    wrong_root = replace(req.clean_proofs[0], start_fen="8/8/8/8/8/8/8/8 w - -")
    assert select_and_freeze(replace(req, clean_proofs=(wrong_root,))) == Hold(
        "due_witnesses_do_not_match_selected_route")


def test_unscoped_clean_proof_rejected_before_planning():
    from reference.planner import choose_plan
    req = request_for(True)
    assert choose_plan(req.target.key,req.routes,clean_proofs=req.clean_proofs) == Hold(
        "daily_prefix_scope_unproven")
