"""Contract freeze catches future cheap-worker field drift before UI integration.

This validates JSON shape only. Production issuer must still verify legal chess,
source/owner epoch, digest, original queue and all due/credit receipts.
"""
import json
from pathlib import Path
import pytest

ROOT = Path(__file__).resolve().parents[1]
jsonschema = pytest.importorskip("jsonschema")
SCHEMA = json.loads((ROOT / "wire/issued_plan.v1.schema.json").read_text())

@pytest.mark.parametrize("name", ["italian_suffix", "italian_full"])
def test_example_matches_versioned_schema(name):
    obj = json.loads((ROOT / f"wire/examples/{name}.json").read_text())
    jsonschema.Draft202012Validator(SCHEMA).validate(obj)
    assert obj["decision_slots"][-1]["expected_uci"] == obj["moves_uci"][obj["decision_slots"][-1]["move_offset"]]


def test_unknown_field_fails_closed():
    obj = json.loads((ROOT / "wire/examples/italian_suffix.json").read_text())
    obj["fsrs_state"] = "FORBIDDEN IN PRESENTATION WIRE"
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.Draft202012Validator(SCHEMA).validate(obj)


def test_mismatched_decision_slot_rejected_by_reference_decoder_is_a_separate_gate():
    # JSON schema checks shape, while browser/issuer also validate semantic
    # move offsets. Higher-level legality/currentness are NOT this schema's job.
    obj = json.loads((ROOT / "wire/examples/italian_suffix.json").read_text())
    obj["decision_slots"][0]["expected_uci"] = "e2e4"
    jsonschema.Draft202012Validator(SCHEMA).validate(obj)
    assert obj["decision_slots"][0]["expected_uci"] != obj["moves_uci"][0]
