# Preparation baseline

Prepared November 12, 2026, after the user's corrective brief. This is a planning snapshot, not a claim that the new packet has executed.

| Fact | Evidence level and value |
| --- | --- |
| Repository | `aaweaver-actuary/tempo` |
| Fresh remote main | `091ad318b1afaadcb25e5ca44ff526120a202336`, tree `e727a9d8580122b215f9f7f941b32129ea1a8249`; fetched again for this packet |
| Previous deep-review interval | `799b66234b8be386a33d980df10b8b1d9a9d8b36` → current main |
| Reviewed merges | #991, #992, #993, #995, #997–#1008; already merged, not outstanding merge requests |
| Recorded installed product | `d79ae4fcc4b006985114d85b5fb9a5aca8becbf1`, schema 65, five-image identity, verification reported at 2026-11-12 2:31:39 p.m. Eastern |
| Modes in supplied brief | Study-only on, managed feedback inactive; verify live before installation |
| Installed→reviewed-main delta | 18 test/fixture/runner/audit paths; no product or schema implementation change |
| Current audit | 55 IDs: 14 Closed, 37 Open, 4 Needs decision; original criteria unchanged |
| Real installed review-to-next | Not observed in supplied evidence; outstanding final acceptance |
| Briefly resumed streams | Follow-up report says all three stopped with no edits, commits, pushes, PR changes, tests or installation changes; one clean worktree/branch and a temporary spec copy remained. This is reported state; inspect the actual owning host before reusing or cleaning them. |

The packet author refreshed Git and PR metadata and inspected current source. No product implementation, new source merge, native/browser release run or local installation was performed while preparing this packet.

## Reuse this evidence accurately

The preceding independent deep review is included in `reference/deep-review.zip`. It contains current-source traces and meaningful probes:

- Backend: 241 passes, 9 stale API/fake failures, 2 native cases deliberately deselected. The nine failures are listed by node ID and source-attributed to pre-existing test maintenance.
- Frontend: 327 existing tests passed, browser TypeScript exited 0, two frozen-exercise consumer probes passed. Four adversarial invariant assertions fail on both baseline and current main, demonstrating three initial-202 acknowledgment cases and unknown-store cutover.
- Qualification boundaries: 66 passes without skips; overlap with other selections exists. Pure runner/route probes confirm finite selectors, absent supported HTTP routes and weak E01 SQL assertions.
- Prior native/browser/install outcomes in PRs and audit records are reported evidence; the packet author did not retrieve every underlying Mac report or repeat those executions. Reuse them only after comparing relevant inputs and evidence availability.

Docker/native/real-browser capability was absent or unexercised in the preparing cloud environment. That does not establish capability on the fresh owner's host. Dependency and native/browser setup commands belong to the verified task environment, not a historical absolute venv path from a log.

## Known actionable mechanisms

1. Initial command `202` confirmation trusts the returned operation ID. A simulated foreign acknowledgment can cause the original review to be marked committed from a foreign receipt; missing/foreign settings acknowledgments can clear original key/body. FE001 remains open.
2. Manual prefix preview/accept/reject and four supported frozen-exercise endpoints are absent from the actual router despite current consumers and handlers. Frozen exercises have positive queue/prepared-storage/mapper/view reachability. Native command proof alone does not restore HTTP use.
3. Settings uses host `date.today()`. With UTC host at 02:00Z and America/New_York settings, it requests the next calendar day; an earlier configured-day request can return without a refresh signal. The control flow was reproduced with storage fakes; native/UI impact remains to be proved.
4. Nonempty unknown IndexedDB stores are exported intact but ignored in retained-authority facts. A foreign cutover can therefore proceed without a hold. No live deletion or prevalence was observed.
5. E02 labels its maintained selection partial, but its native prefix replacement also changes shared full/durability/study coverage. The browser replay case ignores the resend response. Scope and assertions need correction.
6. FE005 physical registry coupling, FE007 effectful diagnostics, D02/D03 compatibility/grading, BE003 remaining calendar adoption, F02 witness extraction and the larger fixed audit remain unfinished. Adjacent passing work does not close them.

## Current records need reconciliation

The root progress still calls #1004 an open draft. Current E03 is a saved/pasted read-only Game Review proof using three current relations, while some docs still describe historical ten-relation feedback evidence. Correct these records with bounded accepted evidence; do not rewrite historical audit facts or close E02 wholesale by relabeling it.

Fresh-owner first action: verify current main, actual branches/worktrees and resource custody, then choose the next ready task from this packet. Any newer relevant source delta changes the working pin and may invalidate affected evidence; it does not require restarting an unchanged whole-repository audit.
