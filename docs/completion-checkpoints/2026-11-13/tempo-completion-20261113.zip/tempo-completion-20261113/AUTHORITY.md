# Direct execution authority

Andy requested this new packet for a fresh integration agent to finish the outstanding work in a substantial coordinated push. Earlier direct instructions explicitly authorized scoped GitHub pushes, accepted merges and installation on the local machine. This document carries that authority into each role. It supplies user authorization; it does not create credentials, host access or an exemption from platform controls.

## All assigned implementers

You may read current sources and relevant evidence; create isolated task branches/worktrees; install normal project development dependencies in the task environment; implement your assigned task and necessary bounded consumer/test corrections; run applicable tests on verified disposable resources; commit; push your scoped ordinary non-force branch to `aaweaver-actuary/tempo`; open/update the corresponding PR; publish the scoped technical evidence/review comments required by this work; and address concrete review findings. Do not stop to ask Andy whether you may push a useful draft.

You may merge your exact scoped PR/head after its applicable acceptance and review are complete **and the integration owner releases that head for merge**. The owner may instead perform the merge. This release coordinates an already-authorized action; it is not a new permission request to Andy. An implementation worker does not operate the live installation unless the owner explicitly assigns that operator role.

## Integration owner

You may start first, reconcile existing work, assign and resume bounded workers/reviewers, reserve and release shared files/resources, resolve reversible implementation choices, make necessary integration/proof repairs, push support branches, publish/update scoped PRs, mark accepted drafts ready, and merge accepted exact heads in dependency order. Use an authenticated supported GitHub connector or CLI. Observe expected-head guards and actual branch protection. Do not force-push main, weaken required checks or rewrite another owner's branch.

You may accept a coherent subset and release it while independent tasks continue. You may combine small compatible patches when this improves review without hiding their acceptance. You may choose among source-supported options in the four candidate decisions and other explicit bounded decision tasks; changing retained product support, deleting protected data, or introducing a new product/system is outside this authority.

Use proportionate technical review, including a Guardian-like look at coupling and ownership. A real independent reviewer may cover both in one pass. Current repository guidance does not require a dedicated Guardian agent or machine receipt for every change. Record actual review coverage and material unreviewed risk honestly; do not manufacture approvals or a new universal release gate.

You own the existing audit HTML/workbook and current progress record updates. Preserve original observations/acceptance and record actual task/source/install states separately. Only the owner updates shared audit files unless a specific updater is delegated that reservation.

## Designated registered-machine operator

You or the integration owner's explicitly designated operator may install the exact accepted merged product release on Andy's verified registered local Tempo installation. This includes the normal supported CLI plan/update/start workflow, immutable image selection/build as required, scoped service stop/restart, and supported required forward migrations with the normal backup/recovery safeguards. Use the already-approved `--no-ci` path when hosted CI remains unavailable; record `ci-disabled` and do not call it a CI pass. This option follows main, so reserve a short merge freeze and verify the full accepted main SHA before invocation and installed identities afterward.

Identify the actual registration, checkout, Docker daemon/context, persistent volumes, browser origin, active modes and schema before changing live state. `/Users/andy/tempo` is historical context, not proof that a checkout or daemon is the registered target. A cloud disposable installation is not the user's local installation.

Preserve current modes and graceful active-attempt/journal recovery. The assignment does not authorize live volume purges, uncertain row deletion, learning-history resets, synthetic human reviews, optional/retired feature activation or an image-only assumed database rollback. Use disposable synthetic data for automated qualification. For the last real-use criterion, prepare the app and observe Andy complete a genuine review; use bounded read-only confirmation. That interaction is evidence of real use, not another general installation approval.

## Access and failures

Missing tokens, denied host execution, unavailable Docker or a Mac connection are capability failures. Finish available authorized work; name the exact blocked action and error, missing capability and next capable operator. Do not ask a broad “may I push/merge/install?” question covered above. Use supported platform approval flows where they actually apply; this packet cannot override them. If automatic review denies an action, report the denied action and reason, and attempt only a materially safer supported alternative.

No Slack/email/other personal outreach is authorized by this packet. Necessary technical GitHub PR/review communication is within the delivery scope stated above.
