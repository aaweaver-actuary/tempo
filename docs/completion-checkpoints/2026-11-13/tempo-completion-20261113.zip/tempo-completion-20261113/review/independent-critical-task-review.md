# Independent review of critical task instructions

Reviewed on 2026-11-13. This is a source-backed review of the proposed task instructions, not approval of future code or evidence that any product test passed. No product files were edited, dependencies installed, tests run, or live targets inspected.

## Scope and outcome

Reviewed backend B02, B03 and B31, and frontend C10, FE05, C20 and C21 against source commit `091ad318b1afaadcb25e5ca44ff526120a202336`. Read B01 as the explicit calendar-policy prerequisite. Root owns the separate dependency-graph review.

The reviewed instructions agree with current source and retained product scope after two execution-critical clarifications were incorporated into the frontend plan and one focused leased-generation regression was added to B02. The remaining calendar policy choices are explicitly owned by B01; B02/B03 must not invent them during implementation.

Reviewed plan snapshots:

| Artifact | SHA256 |
| --- | --- |
| `analysis/backend-plan.json` after the leased-generation clarification | `7bd202fb126c7ee840475acd2220916b02e3044bc678acd91d17077fa7e42df2` |
| `analysis/frontend-plan.json` after the two clarifications | `5e7d19ac03f02eff95acc564413507b86dca5cc1d14a2825f88102637a7706aa` |

These hashes identify what was reviewed. Later plan edits need a focused comparison; this review does not automatically approve their contents.

## Findings and disposition

| ID | Tasks | Finding | Disposition |
| --- | --- | --- | --- |
| CR-01 | C20, C21 | A pending self-assessment is a completed original parent command receipt, while the human review remains unfinished. Conflating those states deadlocks the dependent command or advances the queue too early. | Corrected in the reviewed frontend snapshot, including the three-stage negative regression. |
| CR-02 | FE05 | An unknown store bound to the target authority and an unknown global store have different consequences. The current policy intentionally blocks authority-null facts during resume/recover as well as cutover. | Corrected with the exact transition matrix; no new global per-request hold. |
| CR-03 | B02 | The backward-day coalescing proof should explicitly cover an already leased future-day generation, not only a queued task. | Corrected in the backend plan with the exact leased/partially advanced future-day, backward-zone request and resumed-old-slice regression. |

### CR-01: parent command completion must not mean completed human review

Current `backend/app/study_attempt_commands.py:submit_study_attempt` persists the original attempt and returns `{attempt_id, assessment, pending_self_assessment: true}` when the answer requires self-assessment. That response does not include the final `persisted: true` review envelope. `backend/app/services/study_attempts.py:finish_study_attempt` later returns the final result with nested `review` and `persisted: true`.

The browser's `app/lib/study-command-client.ts:predecessorSettled` permits the dependent self-assessment only when the matching parent intent is `committed`. Its current `assessResponse` treats the initial parent result as a completed command unless the producer explicitly reports `needs_analysis`. Therefore a new decoder that labels `pending_self_assessment: true` as an unsettled command would prevent the child from ever dispatching. Conversely, treating that parent response as a completed human review would allow premature advancement or counting.

The corrected C20/C21 instructions now require three separate observations:

1. An unconfirmed or foreign parent acknowledgment leaves the child unsent.
2. The validated original parent receipt commits only the parent command intent, releases the same dependent child, and leaves the human attempt unfinished.
3. Only the validated final child result advances/counts the human review once. Repeated recovery cannot duplicate it; malformed or foreign child results remain pending.

This correction preserves the existing v1 wire envelope and request hash. It does not add a new state machine or require a new grader version.

### CR-02: unknown retained facts need the exact authority matrix

`database/browser/study-connection-storage.ts:readRetainedStudyData` reads all existing object stores without upgrading them. `inspectRetainedStudyAuthority` currently derives facts from known intent, opening-attempt and training formats but does not report nonempty additional stores. FE05's planned unknown facts close that observation gap.

The existing predicate in `app/lib/study-client.ts:assertStudyAuthority` has these consequences:

| Fact | Cutover | Registered resume/recover |
| --- | --- | --- |
| Terminal, any authority | Allowed by this fact | Allowed by this fact |
| Nonterminal or unknown, bound to target authority | Allowed by this fact | Allowed by this fact |
| Nonterminal or unknown, bound to another registered authority | Held | Allowed by this fact |
| Nonterminal or unknown, bound to unregistered foreign authority | Held | Held |
| Nonterminal or unknown, authority null | Held | Held |

An empty unknown store adds no retained-work fact. A named offline database can supply its already validated authority binding; arbitrary fields inside an unknown row cannot establish one. Existing known metadata, teaching and event stores must not be reclassified solely because they are not intent queues.

The corrected FE05 card states this matrix instead of promising unconditional same-authority resume. It also states that existing normal-build requests do not call the transition guard per request. The implementation must preserve that scope: the change supplies accurate inspection facts and must not install a product-wide request lock. Raw retained keys/values and export remain available, including when a transition is held.

### CR-03: exercise the existing task-generation fence while changing days

`backend/app/services/durable_tasks.py:_request_current_queue_in_transaction` locks the singleton `daily_queue/current` task. If its saved day is greater than the newly requested day, it returns before `signal_queue_refresh_in_transaction`. Replacing only that return can have effects beyond signaling: the existing upsert advances generation, replaces payload and clears lease state. `advance_task_slice_in_transaction` accepts effects/checkpoints only for the matching task generation and lease.

B01 appropriately requires an explicit policy for preserving the accepted later-day task while permitting a newly selected earlier current day. B02 requires preservation of accepted payload, generation history, receipt and issued-origin dates, plus actual worker progress to a ready projection. The corrected card now explicitly adds the following native case:

- Start an accepted future-day task, lease it and pause it after a real checkpoint.
- Apply an east-to-west settings change using one observed instant and the newly saved effective zone.
- Attempt to resume the old slice after the new request is durable.
- Prove the old slice cannot publish or checkpoint under a different day/generation/lease, the original accepted identity is not silently retargeted, and the newly selected current-day obligation is processed to a ready projection.
- Inject rollback at the settings/request boundary and preserve its original receipt replay without a second refresh.

This is a bounded proof of the existing transaction/generation rules. It does not justify another scheduler, blanket task deletion, or a broad historical migration campaign.

## Checks without a material contradiction

### C10: original operation identity and terminal validation

The current `app/lib/operation-status.ts:confirmOperationResponse` reads the ID from a 202 response and polls it; an absent ID returns the original response. C10 correctly requires exact equality with the submitted original ID before polling, notifications or journal mutation.

The card also correctly distinguishes generic durable commands from queue GET issuance. `backend/app/command_dispatch.py:dispatch_command` accepts caller operation IDs subject to its 128-character bound, whereas `app/domain/adapters/operation-result-adapter.ts:decodeOperationAcceptance` currently applies a queue-oriented alphabet. Reusing that alphabet as a universal persisted-ID rule would be an unwarranted compatibility change. The proposed strict helper instead retains exact identity and the gateway bound while keeping server-allocated queue IDs separate.

`app/lib/opening-evidence-review.ts:saveEvidenceAwareReview` can append `:aggregate-only` to the sent key. C10 explicitly requires the exact sent key, including that suffix, and does not permit position evidence fallback. `app/lib/settings-save.ts:saveLocalSettings` currently clears a pending save after a complete receipt or any successful direct/confirmed response without validating the Settings body. The planned use of the existing complete `settingsResponseSchema` before clearing addresses that gap while preserving original key/body and existing failed/blocked/retry policy.

### B02/B03: current day and accepted historical day remain distinct

`backend/app/settings_commands.py:apply_settings` currently writes the saved settings and requests `date.today()`. The proposed single aware instant plus newly saved effective Study zone is consistent with `capture_study_calendar` and `study_calendar_at`. The plan properly requires an atomic settings/refresh/receipt boundary and receipt replay without recapturing time.

`backend/app/services/postgres_queue_refresh.py:execute_postgres_queue_refresh_slice` currently falls back to host day even when `_refresh_cycle_epoch` is already present. The initial epoch branch pins a chosen day only when that epoch is absent. B03 explicitly covers both shapes and requires one-time resolution under existing lease/generation fences before queue effects. It preserves an explicit accepted day and prohibits deriving missing historical authority from the current zone or host clock.

B01's unresolved compatibility variants remain real design decisions. A trustworthy original fact must justify resolution; otherwise the declared durable hold must preserve identity and permit unrelated valid current work. This review does not turn those owner decisions into completed implementation.

### B31/C20/C21: four retained routes, unchanged v1 authority

SPEC's November 10 pass-2 amendment retains generated exercises as frozen ordinary exercises while retiring standalone authoring and optional producers. The current browser runner still calls present, attempt, self-assess and feedback endpoints; the retained command handlers exist. Restoring those four routes through the current owners is consistent with that scope.

The task cards preserve the important current contracts:

- `StudyAttemptRequest.model_dump(mode="json")` participates in the original answer hash; no new default provenance field or grader-version change is introduced by route restoration.
- Submission and self-assessment dispatch the existing command names and original idempotency keys. Practice cannot name a queue; review requires the existing card/queue/revision binding and writer locks.
- Present exposes prompt-visible fields, not accepted lines, required answers, correct option IDs, explanation or rubric.
- Feedback binds an existing attempt to the same study/exercise and its persisted revision; a newer current revision is not substituted. Existing pending self-assessment must still be able to inspect its bound feedback.
- Original receipt lookup can precede support classification, but a missing receipt never authorizes POST to a retired or unknown endpoint. Held unrelated work remains inspectable and does not abort bounded recovery of supported work; dependent records retain their ordering.

`database/tempo_storage/http_composition/availability.py` explicitly limits its retired queue predicate to new issuance and preserves original retained-attempt semantics. The cards therefore correctly separate current frozen support, original-receipt recovery and exact retired/ambiguous holds instead of treating every `study-command` or historical generated record as retired. No authoring, provider, analysis or alternate Learning service is required.

## Review limit

No dynamic behavior was exercised. The conclusions concern plan validity against the pinned source. Implementation still requires the named focused proofs, applicable owned native/browser acceptance, exact candidate provenance, and the packet's separate merge/install/user-interaction gates. A future task's success cannot be inferred from this review.
