# Independent review of the owner instructions and assembler

## Scope and status

Reviewed the root-authored `OWNER-PROMPT.txt`, `AUTHORITY.md`, `MISSION-AND-DONE.md`, `COMMON-WORKER.md`, `runbooks/EVIDENCE-AND-RELEASE.md`, `roles/GOAL-CHECKER.txt`, and `assemble_packet.py`. The final pass also inspected generated task/ownership/crosswalk data, `plan/SEQUENCING.md`, `runbooks/INSTALLATION.md`, and `tools/check_packet.py`. Consulted the preserved prior authority, current source test entrypoints, and task-plan schemas only where needed to check the root's coordination and assembly. This is a planning review. No product implementation, GitHub mutation, installation, live operation, or product test was performed.

The reviewer authored the backend planning input. This review does **not** claim independent acceptance of that backend task substance. Checks of the root's path normalization, original-ID handling, cross-plan graph, and generated instructions concern integration correctness rather than independent technical approval of the backend proposals.

**Final result: ACCEPTED for the reviewed planning and coordination scope.** All four concrete findings below are resolved. The final assembled graph, ownership, crosswalks, prompt references, and structural checker pass the stated checks. This accepts the reviewed execution instructions; it is not approval of product code, runtime qualification, merged source, installation, or future completion claims.

## Findings and corrections

| ID | Severity | Finding | Required correction | Observed status |
| --- | --- | --- | --- | --- |
| OR-01 | P1 — dispatch safety | The original `path_record` retained parenthetical scope notes in path keys. Several reservations for `backend/app/main.py` therefore became different strings; multi-path strings also became invalid single paths. The ownership table could incorrectly label overlapping writers exclusive. | Normalize each write reservation to its exact repository-relative path; preserve scope notes separately; expand explicitly listed paths; make unresolved consumer sets explicit owner resolution conditions. Compute collisions from the normalized paths. | Corrected and inspected in the root assembler and final generated ownership. All 555 normalized claims match task write records; all 179 shared claims are marked shared. The three generic consumer sets became unresolved owner conditions. |
| OR-02 | P2 — final checker usability | The Goal Checker referred to `plan/finding-coverage.json` and `plan/prior-packet-coverage.json`, while assembly emits `plan/findings-55.json` and `plan/original-25.json`. | Use the actual generated filenames consistently. | Corrected and directly inspected in `roles/GOAL-CHECKER.txt`. |
| OR-03 | P2 — execution versus preparation ambiguity | Generated P15 excluded “Any installation now,” even though its receiving worker is assigned the authorized installation. The unqualified exclusion could cause a weaker worker to stop at the very action the packet requests. | Scope the exclusion to installation before this candidate's applicable qualification and merge. Preparation-only wording must describe packet authorship rather than add an execution permission gate. | Corrected and inspected. P15 now excludes installation only before the candidate's applicable qualification and merge. Its initial planning-phase sentence is conditional context; the receiving owner's execution authority is explicit in the mission, authority, and prompt. No unconditional installation prohibition remains. |
| OR-04 | P2 — ledger consistency | The optional structural completion check accepted a terminal task with an evidence reference even if its `acceptance_residuals` remained nonempty. That array is an explicit current-ledger field initialized with every acceptance criterion. | Include nonempty acceptance residuals in the structural incomplete list. Reject explicit stage-field contradictions when a status claims qualified/merged completion. Preserve the manual Goal Checker's responsibility to inspect whether evidence is true. | Corrected and inspected. The checker requires empty residuals plus the applicable released/qualified fields and rejects a merge status without its merged flag/head. Ephemeral synthetic checker fixtures confirmed rejection of an outstanding residual and of a contradictory merge claim. These fixtures were deleted and are not product evidence. |

The prompt-clarity follow-up to print preserved `scope_note` values in WRITE RESERVATION lines has also been applied. Useful limitations such as “mount only” remain visible in individual prompts. This adds no product acceptance gate.

## Cross-plan graph watchpoints

The initial proof/storage draft expressed several dependencies in prose. The root and its author are replacing these with concrete stage-aware inputs. The final graph must preserve the following distinctions:

- S01's input is the finite port/caller decision or a released contract-design event. It cannot wait for completed B26, because B26 consumes S01/S02.
- P04's reference to P07's runner-file lease is a reservation, not a dependency on completed P07. P07 consumes P04/P05 proof repairs.
- T01 needs the applicable lifecycle design decision before implementation. P13 must be able to test T01's exact reviewed source before T01 can merge. A merged-T01 prerequisite for that proof would deadlock the required acceptance.
- A source release permits downstream implementation. Native/browser/lifecycle qualification, merge, installation, and genuine installed use remain distinct; a conditional checkpoint prerequisite must not become a global implementation barrier.

The final graph resolves these watchpoints: S01 waits for B00; B26 waits for the S contracts; P04's runner lease is an owner condition; P07 waits for P04/P05/P06 source; T01 has no P13 completion prerequisite; P13 consumes T01 source; and applicable P13 acceptance gates T01 merge. P12 releases its exact reviewed browser inventory before P14, and they may share actual qualification execution. No source or stage cycle was found.

## Final graph and generated-structure checks

Read-only structural assertions checked the generated packet after all three planning inputs were assembled. They did not execute product tests.

| Check | Result |
| --- | --- |
| Unique task IDs and present prompts | 129 tasks; 129 prompt files |
| Start graph | 245 edges; acyclic; all referenced tasks and stages exist |
| Event producers | 43; all producers refer to existing tasks |
| Original continuation | All 25 IDs present; exact original acceptance preserved; every successor exists and every referenced historical prompt is included |
| Fixed audit | All 55 IDs present; exact original acceptance, summary, file observations, and preparation status preserved |
| Remaining finding assignment | All 37 open plus four decision findings have task coverage; no unassigned nonclosed row |
| Read-first paths | No unexplained missing existing path; nine explicit future files each have a named transitive producer dependency and that producer's exact write claim |
| Ownership | 555 exact paths; 179 shared; task and ownership maps match; no annotated or multiple-path literal keys remain |
| Initial dispatch | C10, B01, and P06 have no unmet source prerequisite |

The root's generated graph deliberately permits source-released upstream branches to feed an exact qualification candidate before merge. The qualified prerequisites on P15 preserve the later installation gate. Shared-file reservations still apply even when a task is source-ready.

The final independent invocation of `python -B tools/check_packet.py --source /workspace/scratch/98ef0fd314f3/deep-review/source` returned `structure_valid: true`, no errors, no warnings, and `evidence_truth_verified: false`. Three ephemeral checker cases verified a structurally populated synthetic ledger, rejection of a terminal status with an unfinished criterion, and rejection of a claimed merge without its merge fields. No synthetic state was written to the actual run ledger or retained in this packet.

The inspected final `plan/tasks.json` SHA-256 is `e3c5e912c9f94e3dec5ceb2a3ce4b67177b7aa5a036100976349562767519170`. Its source pin remains `091ad318b1afaadcb25e5ca44ff526120a202336`.

## Positive conclusions from inspected material

- The owner instructions distinguish the original 25 tasks from new task IDs and preserve accepted inherited work without treating an unrelated wider-audit task as retroactive failure of an accepted narrow slice.
- The mission distinguishes an early coherent release from final completion. A probe needs a concrete result and successor, while its parent finding remains open until the required implementation and proof are complete.
- Authority stays within scoped development, ordinary pushes/PRs, owner-released accepted merges, and the already-authorized registered installation workflow. Credentials, branch protections, platform controls, exact target identification, and protected retained data remain binding. The planning author's role is not mistaken for implementation authorization in this session.
- No universal separate Guardian receipt or redundant whole-product test is imposed on every leaf. The root instructions require proportionate independent review and evidence at the changed boundary, with one heavy native/browser/lifecycle operator.
- The inspected root npm script names (`build:packages`, `test:unit`, `typecheck:browser`) and `make python-file FILE=...` entrypoint exist in the pinned source. The runbook correctly tells the operator to verify interpreter, working directory, selectors, and current runner constraints on the actual host.
- Installed-use evidence is deliberately separate from disposable browser qualification. The owner may complete all independent work while the genuine human review observation remains pending, but cannot label the whole assignment complete.
- The `--no-ci`/main-freeze instructions preserve the distinction between explicit authorization, hosted CI status, selected source, and observed installation. They do not waive actual repository protections or authorize retired feature activation.

## Author-side correction recorded separately

A structural original-ID check found nonexistent original `D00` in the backend author's B31 metadata. The reviewer corrected its own planning generator/JSON/Markdown to map B31 to original D02 only and reported that correction. The root assembler now asserts membership in the exact original25 ID set. B36's generic read-first label was replaced by existing `tests/REGRESSIONS.md` plus an explicit owner condition supplying the exact current changed-test inventory. These are author-side metadata corrections, not independent approval of the backend implementation designs.

## Review limits

No reviewed instruction or structural defect remains open. This review does not prove future implementation, exhaustively re-audit every proposed technical design, independently approve the reviewer's own backend task substance, or establish host access, runtime results, source merges, installation, or genuine user interaction. Those remain the receiving integration owner's assigned evidence obligations. No new whole-program review or product qualification is required merely to resolve these already-corrected packet findings.
