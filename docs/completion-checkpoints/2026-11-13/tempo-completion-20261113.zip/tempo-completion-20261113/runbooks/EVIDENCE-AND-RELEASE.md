# Evidence, release and resumption

## One ledger and exact handoffs

Use the existing repository progress area `tempo-low-fruit-20261112/progress/`. If an active completion ledger already exists, extend it; otherwise adopt `ledger/STATE-TEMPLATE.json` as `completion-run.json` there. Do not maintain two independent current status tables. Existing PR comments/reports remain evidence links. Record actual task owner, base/head, phase, dependencies released, tests, review, merge/install state and next action.

The new packet does not erase earlier accepted results. Copy their evidence references and pins into the inherited-work records. Recheck only criteria affected by changed executable code, package/dependency inputs, fixtures, schema, configuration or environment, plus actual required release gates. A changed headline SHA alone neither invalidates all old evidence nor validates reuse.

## Test selection

Pure values/decoders/import direction and UI-only presentation use their owning focused checks. Application orchestration gets real consumer tests with fakes that enforce the current public contract. Native SQL, locks, rollback, concurrent publication, durable identities and lifecycle transitions need the applicable genuine PostgreSQL test. IndexedDB transaction behavior and HTTP receipt/reload recovery need real browser/transport when fake tests do not establish them.

One heavy operator owns the disposable native/browser/lifecycle slot. Preserve the current runner's resource budget, preflight, project/database markers, image/source verification, cleanup and failure reporting. Do not use arbitrary live DSNs, disable guards, claim a skipped selection passed, or add several independent stacks on the Mac merely because multiple workers are available.

Each task prompt lists existing commands and proposed test assertions separately. Confirm its working directory and compatible interpreter/dependencies at the actual host. The root package currently provides `npm run build:packages`, `npm run test:unit -- <owning files>`, and `npm run typecheck:browser`. Python selection uses the repository's supported `make python-file FILE=...` interface with a compatible environment; read its current target before invocation. Node/pytest arguments and current runner selection constraints must be preserved.

## Known evidence traps to avoid

- An HTTP202 is acceptance of processing, not proof of durable completion. Compare the original command identity before following acknowledgments and validate the terminal payload before clearing a journal.
- An unchanged review count after resend proves no observed duplicate, not successful replay. Assert the original receipt/result too.
- A native prefix command does not exercise preview/accept/reject HTTP routes or their actual UI.
- Queue identity rendered in the DOM does not establish an enabled, playable board. Make a legal input on each successor claimed playable; do not invent extra completed reviews.
- Total browser-stage duration is not per-transition cadence. Label timing boundaries honestly; SQL inspection time is not pure UI latency.
- A mock cursor returning preloaded data for any SQL cannot establish correct projection or locking. Use discriminating assertions and native evidence where required.
- A historical proof or old producer may be obsolete. Give it an explicit supported/retired/mixed disposition before replacing or deleting it; preserve mixed retained assertions and accepted data obligations.
- `ci-disabled`, missing review submissions and no check statuses are not successes. They also do not automatically create requirements beyond actual repository rules.

## Release checkpoints

The owner may release an early coherent correction while the wider audit continues. Freeze only the candidate inputs needed for the next run; do not freeze the entire programme unnecessarily. Record exact commits/trees, component results, applicable native/browser selections, independent integrated review, unresolved limitations and cleanup. After conflict resolution or a changed dependency, renew the affected proof and review.

Merge accepted exact heads in dependency order. Keep useful scoped PRs rather than one unreviewable giant diff; very small related changes can share a PR if every task remains traceable. Never merge a draft solely because it is conflict-free or has a large reported test count.

Use the supported installation workflow described in the installation runbook and current CLI source. The initial d79 installation does not establish that new product changes are installed. Rehearse the actual installed→target update/recovery path where required. Inspect actual schema; do not substitute a historical current63 profile for65 or assume an old image is a safe data rollback.

## Final installed use

After the accepted product is installed and identity/mode/health checks pass, make the normal Study page ready for Andy. Ask only for the genuine remaining action: complete one ordinary due review while the operator observes. Keep the existing original attempt and journal; do not reset/reseed the queue or fabricate a review. Observe save confirmation and an authoritative usable successor. Confirm the original receipt and no duplicate effect using bounded read-only evidence. Store only appropriate redacted live evidence in public technical records.

If Andy is not available, finish other authorized tasks and checkpoint `LIVE_ACCEPTANCE_PENDING`, naming the exact source, installed identity and observation step. This is a human-evidence dependency, not missing general permission to merge/install. Resume at that step when possible.

## Resumption

Before context/quota/host interruption, persist the exact current heads, active worker/resource custody, released contracts, unfinished acceptance and next ready IDs. Do not advertise nonexistent background execution. A fresh owner reads the checkpoint, verifies actual refs/resources, adopts valid work and resumes the next decisive action. Old historical prompts remain references; this packet's scope and the latest direct user steering govern the continuation.
