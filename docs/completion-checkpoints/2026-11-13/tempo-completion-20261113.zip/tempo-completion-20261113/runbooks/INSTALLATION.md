# Qualify and install the actual accepted product

This runbook is for the integration owner or designated registered-machine operator after the applicable acceptance passes. Andy has explicitly authorized that delivery phase in AUTHORITY.md. These commands were inspected in the preparation source; this packet has not executed them on the live machine.

## Establish the target and candidate

Use the actual registered Tempo installation. Read the registration through the supported CLI and inspect only the relevant redacted identity information. Verify checkout, remote/main, Docker context/daemon, existing persistent volumes, browser origin, deployed source/images, schema and migration state. Preserve other owners' work and active attempts. A remembered `/Users/andy/tempo` path or a cloud disposable stack does not establish the live target.

The prior receipt reported d79ae4fcc4b006985114d85b5fb9a5aca8becbf1, schema65, five product images, Study-only on and managed feedback inactive. Confirm the current state; do not assume it. The preparation main contains only test/harness/audit changes after that product, so its newer headline SHA alone is not a reason to reinstall. Product, dependency, packaging or lifecycle changes from this assignment require their affected acceptance and an updated product release.

Before a live update, finish the relevant local/native/assembled acceptance on the exact candidate. Use P13 for the applicable actual65→target lifecycle/recovery path when affected. At preparation, the existing historical `current63` profile refuses schema64 or later. Do not weaken that refusal or label it schema65 proof. Preserve original migration contents/checksums and supported backup/recovery behavior.

## Supported commands

Run `tempo status`, then `tempo doctor --verbose`, then `tempo start --plan` for read-only target and update assessment. The plan command can truthfully report a pending or unavailable hosted gate. That is not installation acceptance and does not authorize bypassing data/recovery checks.

The normal update/install command is `tempo start`. While hosted CI remains unavailable, the already-approved path is `tempo start --no-ci --no-open`. Record `ci-disabled`; local tests do not become hosted CI. `--no-ci` is supported for start/restart, not an invented `tempo migrate --no-ci` command.

The normal no-CI path follows current main. The integration owner must reserve a short merge freeze, fetch and verify the intended full accepted main SHA before invocation, and confirm the actual selected/deployed identity afterward. If main changed to unqualified product inputs, stop before installing those inputs and qualify or reconcile them. Do not improvise a source reset or use a random branch as the release.

If the management command is genuinely unregistered, inspect the current CLI install prerequisites before `./tempo install`. That operation registers the command/checkout; it is not product installation. Do not overwrite an existing registration. Existing `.env`, private secrets and product volumes remain authoritative; never substitute an empty database to make startup pass.

`--candidate-ref`/`--candidate-sha` are specific reviewed rehearsal controls in the current CLI. They are not a replacement for normal accepted-main deployment or permission to repeat a historical Defense-selection cut. No additional history retirement is assigned here.

Let the supported CLI perform coherent image preparation, maintenance admission, required backup verification, migrations and service startup. Do not manually remove migration guards, force healthy status, prune volumes or assume older images can safely roll back a changed database. If maintenance fails, preserve its original backup/guard/journal and follow the actual current recovery procedure. Use `tempo migrate --retry` only after the documented failure inspection establishes it as the supported next action.

## Observe the outcome

Run `tempo status` and `tempo doctor --verbose` after successful completion. Record the exact source revision, immutable image identities, complete schema/migration identity, active modes and workers, deployment/backup state, service health and relevant browser origin. Healthy HTTP or containers alone are insufficient. Distinguish product-input equivalence when a later docs-only main is intentionally not reinstalled.

Then prepare the normal Study page for Andy. Observe one genuine due review saved under its original identity and an authoritative playable successor. Use the normal UI and bounded read-only receipt/effect verification; do not fabricate the review, reseed live work, clear journals or change modes. Disposable browser proof remains separately labeled. If the genuine interaction is unavailable, finish other work and retain the exact installed record with `SOURCE_MERGED_INSTALLED — LIVE_ACCEPTANCE_PENDING`.

## Source references

The preparation commands and behavior were checked in `tempo`, `scripts/tempo-cli.mjs` (`help`, `parseArguments`, update flow), `docs/TEMPO-CLI.md`, and `tools/tempo-cli/README.md`. Current copies govern at execution. The applicable native/browser/lifecycle runner inputs and constraints are detailed in P12–P15, the proof plan and the existing repository test guide. This runbook adds no new host access or platform bypass.
