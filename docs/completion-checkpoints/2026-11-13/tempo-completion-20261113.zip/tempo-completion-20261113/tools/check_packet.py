#!/usr/bin/env python3
"""Validate the handoff's structure, never the truth of future product evidence."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import sys

def read(path):
    return json.loads(path.read_text())

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',type=Path,help='Optional existing Tempo checkout for declared source-path checks')
    parser.add_argument('--state',type=Path,help='Optional actual run ledger; report structural completion only')
    args=parser.parse_args()
    root=Path(__file__).resolve().parents[1]
    errors=[]
    warnings=[]
    plan=read(root/'plan/tasks.json')
    tasks={t['task_id']:t for t in plan['tasks']}
    original=read(root/'plan/original-25.json')['rows']
    findings=read(root/'plan/findings-55.json')['rows']
    audit=read(root/'reference/audit-current.json')
    if len(tasks)!=len(plan['tasks']):errors.append('Duplicate new task IDs')
    if len(original)!=25 or len({r['original_task_id'] for r in original})!=25:errors.append('Original25 coverage differs')
    if len(findings)!=55 or {r['finding_id'] for r in findings}!={r['id'] for r in audit['findings']}:errors.append('Fixed55 coverage differs')
    old_ids={r['original_task_id'] for r in original}
    audit_by={r['id']:r for r in audit['findings']}
    for f in findings:
        if f['original_acceptance']!=audit_by[f['finding_id']]['acceptance']:errors.append('Changed original criterion: '+f['finding_id'])
        if f['status_at_preparation']!='Closed' and not f['task_ids']:errors.append('No assignment: '+f['finding_id'])
        for identifier in f['task_ids']:
            if identifier not in tasks:errors.append('Unknown finding task: '+identifier)
    graph={identifier:[d['task_id'] for d in t['start_requires']] for identifier,t in tasks.items()}
    active=[];seen=set()
    def visit(identifier):
        if identifier in active:
            errors.append('Source dependency cycle: '+' -> '.join(active+[identifier]));return
        if identifier in seen:return
        if identifier not in tasks:
            errors.append('Unknown dependency: '+identifier);return
        active.append(identifier)
        for dep in graph[identifier]:visit(dep)
        active.pop();seen.add(identifier)
    for identifier,t in tasks.items():
        visit(identifier)
        if not (root/t['prompt']).is_file():errors.append('Missing prompt: '+t['prompt'])
        if set(t['original_task_ids'])-old_ids:errors.append('Unknown original ID: '+identifier)
        for item in t['write_paths']:
            if ' ' in item['path'] or ' (' in item['path'] or ' and ' in item['path']:errors.append('Unnormalized lease: '+item['path'])
        for item in t['read_first']:
            if item.get('introduced_by'):
                producer=tasks.get(item['introduced_by'])
                if not producer or item['path'] not in {p['path'] for p in producer['write_paths']}:errors.append('Missing proposed-path producer: '+identifier+' '+item['path'])
                ancestors=set()
                def collect(n):
                    for dep in graph.get(n,[]):
                        if dep not in ancestors:
                            ancestors.add(dep);collect(dep)
                collect(identifier)
                if item['introduced_by'] not in ancestors:errors.append('Proposed read lacks predecessor release: '+identifier+' '+item['path'])
            elif args.source and item.get('relative_to')=='repository':
                p=item['path']
                matches=list(args.source.glob(p)) if any(c in p for c in '*?[') else ([args.source/p] if (args.source/p).exists() else [])
                if not matches:errors.append('Missing declared existing read: '+identifier+' '+p)
    ownership=read(root/'plan/ownership.json')['claims']
    expected={}
    for identifier,t in tasks.items():
        for p in t['write_paths']:expected.setdefault(p['path'],set()).add(identifier)
    actual={r['path']:set(r['task_ids']) for r in ownership}
    if expected!=actual:errors.append('Ownership map differs from exact task paths')
    for row in ownership:
        if len(row['task_ids'])>1 and not row['shared']:errors.append('Missed shared lease: '+row['path'])
    for filename,count,rawkey in [('storage-functions-264.json',264,'storage_functions'),('proof-rows-758.json',758,'proof_details')]:
        rows=read(root/'plan'/filename)
        if len(rows)!=count or [r['audit_row'] for r in rows]!=audit[rawkey]:errors.append('Original row coverage differs: '+filename)
        for row in rows:
            ids=row.get('task_ids',[row.get('task_id')])
            if not ids or any(identifier not in tasks for identifier in ids):errors.append('Unknown ledger assignment: '+filename+' '+str(row.get('row_id')))
            if row.get('closed') is not False:errors.append('Planning row wrongly closed: '+filename+' '+str(row.get('row_id')))
    required=['START-HERE.md','OWNER-PROMPT.txt','LAUNCHER.txt','MISSION-AND-DONE.md','AUTHORITY.md','COMMON-WORKER.md','CURRENT-STATE.md','plan/SEQUENCING.md','roles/REVIEWER.txt','roles/GOAL-CHECKER.txt','runbooks/EVIDENCE-AND-RELEASE.md','runbooks/INSTALLATION.md','ledger/STATE-TEMPLATE.json','ledger/HANDOFF-TEMPLATE.json']
    for name in required:
        if not (root/name).is_file():errors.append('Missing required file: '+name)
    result={'task_count':len(tasks),'original_task_count':len(original),'finding_count':len(findings),'dependency_edges':sum(map(len,graph.values())),'structure_valid':not errors,'errors':errors,'warnings':warnings,'evidence_truth_verified':False}
    if args.state:
        state=read(args.state)
        terminal={'accepted_and_merged','accepted_evidence_only','accepted_no_change'}
        missing=[]
        for identifier in tasks:
            item=state.get('tasks',{}).get(identifier,{})
            if (item.get('status') not in terminal or not item.get('evidence')
                or item.get('acceptance_residuals') or item.get('qualified') is not True
                or item.get('source_released') is not True):missing.append(identifier)
            if item.get('status')=='accepted_and_merged' and (item.get('merged') is not True or not item.get('head_sha')):missing.append(identifier+':merge_contradiction')
        for row in original:
            item=state.get('original_tasks',{}).get(row['original_task_id'],{})
            if item.get('status') not in {'accepted','accepted_inherited','accepted_no_change'} or not item.get('evidence'):missing.append('original:'+row['original_task_id'])
        for row in findings:
            item=state.get('findings',{}).get(row['finding_id'],{})
            if item.get('status') not in {'closed','closed_inherited','resolved_intentional'} or not item.get('evidence'):missing.append('finding:'+row['finding_id'])
        if not state.get('installed_release'):missing.append('installed_release')
        live=state.get('live_review_to_playable_next',{})
        if not live.get('observed') or not live.get('evidence'):missing.append('genuine_live_review_to_playable_next')
        if state.get('active_file_leases') or state.get('heavy_resource_owner'):missing.append('active_custody')
        if state.get('known_external_blockers'):missing.append('external_blockers')
        result['completion_fields_present']=not missing
        result['incomplete_items']=missing
        result['completion_warning']='Structural fields do not validate evidence. The Goal Checker must inspect actual acceptance, source, reviews, installation and genuine use.'
    print(json.dumps(result,indent=2))
    return 1 if errors or (args.state and not result['completion_fields_present']) else 0

if __name__=='__main__':
    sys.exit(main())
