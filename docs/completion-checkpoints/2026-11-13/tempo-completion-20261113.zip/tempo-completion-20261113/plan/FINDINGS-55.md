# Fixed audit coverage

Original observations, source locations and acceptance remain preserved in findings-55.json and reference/audit-current.json. Task assignment does not itself close a finding.

| Finding | Preparation state | Exact task coverage |
| --- | --- | --- |
| BE001 | Open | B00, B04, B05 |
| BE002 | Open | B12, B13 |
| BE003 | Open | B01, B02, B03 |
| BE004 | Open | B07, B08 |
| BE005 | Open | B09, B10, B11 |
| BE006 | Closed | Preserve inherited acceptance; recheck only affected inputs |
| BE007 | Open | B16, B17 |
| BE008 | Open | B14, B15 |
| BE009 | Open | B18, B19, B20, B21 |
| BE010 | Open | B22 |
| BE011 | Open | B23 |
| BE012 | Open | B24, B25 |
| BE013 | Open | B00, B26 |
| BE014 | Closed | Preserve inherited acceptance; recheck only affected inputs |
| BE015 | Needs decision | B00, B06 |
| BE016 | Closed | Preserve inherited acceptance; recheck only affected inputs |
| BE017 | Closed | Preserve inherited acceptance; recheck only affected inputs |
| BE018 | Open | B27 |
| BE019 | Open | B28, B29, B30 |
| BE020 | Closed | Preserve inherited acceptance; recheck only affected inputs |
| BE021 | Open | B32, B33, B34, B35, B36, P01, P02, P03, P04, P05 |
| BE022 | Closed | Preserve inherited acceptance; recheck only affected inputs |
| FE001 | Open | C10, C11, C12, C13, C14 |
| FE002 | Open | FE20, FE21 |
| FE003 | Open | FE25, FE26, FE29, FE35 |
| FE004 | Open | FE27, FE28, FE29, FE33, FE35 |
| FE005 | Open | FE05, FE06 |
| FE006 | Open | FE22, FE23, FE24 |
| FE007 | Open | FE08, FE09, FE10 |
| FE008 | Open | B31, C20, C21, C24, FE30, FE36 |
| FE009 | Open | C22, C23, C24 |
| FE010 | Open | FE30, FE31, FE32, FE36 |
| FE011 | Closed | Preserve inherited acceptance; recheck only affected inputs |
| FE012 | Needs decision | FE30, FE33, FE36 |
| FE013 | Needs decision | FE34 |
| RT001 | Closed | Preserve inherited acceptance; recheck only affected inputs |
| RT002 | Open | T03 |
| RT003 | Open | T02 |
| RT004 | Open | P07, T04 |
| RT005 | Open | T01, P13 |
| RT006 | Closed | Preserve inherited acceptance; recheck only affected inputs |
| ST001 | Closed | Preserve inherited acceptance; recheck only affected inputs |
| ST002 | Open | S01, S02, P14 |
| ST003 | Open | S03, S04, P12 |
| ST004 | Open | S05, P12 |
| ST005 | Open | P14, S08, S09, S10, S11, S12, S13, S14, S15, S16, S17, S18, S19, S20, S21, S22, S23, S24, S25, S26, S27, S28, S29, S30, S31, S34 |
| ST006 | Open | P02, S06, P14 |
| ST007 | Closed | Preserve inherited acceptance; recheck only affected inputs |
| ST008 | Closed | Preserve inherited acceptance; recheck only affected inputs |
| ST009 | Closed | Preserve inherited acceptance; recheck only affected inputs |
| ST010 | Closed | Preserve inherited acceptance; recheck only affected inputs |
| ST011 | Needs decision | T05 |
| ST012 | Open | P01, P02, P03, P04, P05, P06, P07, P08, P16, P17, P13, P12, P14, P09, P10, P11, P18, P19, P20, P21, P22, P24 |
| ST013 | Open | P01, P04, P05, P06, P07, P08, P17, P13, P12, P14, P09, P10, P11, P18, P19, P20, P21, P22, P24 |
| ST014 | Open | S07, P14 |
