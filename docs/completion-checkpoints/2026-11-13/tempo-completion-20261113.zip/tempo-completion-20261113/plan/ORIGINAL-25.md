# Original continuation crosswalk

The exact original acceptance text and supporting prompt paths are in original-25.json. This table summarizes present disposition and explicitly keeps inherited completion separate from new wider work.

| Original task | Preparation disposition | New work or maintenance |
| --- | --- | --- |
| Q0 | Qualified release/installation reported in #1002; final live observation remains and concrete protocol residual is assigned. | C10, C11, C12, C13, C14, P12, P14, P15, P16 |
| A01 | Current owner guide slice delivered via #998/#1003. Newly changed contracts update their owning docs. | P17 |
| A02 | Storage guide slice closed. Newly stale proof text is maintenance, not wholesale reopening. | P17 |
| B01 | Unused alias slice delivered; broader BE005 remains separate. | B09, B10, B11 |
| B02 | Six-counter contribution sharing delivered. Wider Study purge ownership remains separate. | B23 |
| B03 | Scheduling initialization delivered with reported native/assembled acceptance. | P14 |
| B04 | Complete the exact positive caller/disposition probe. | B00 |
| E00 | Exact native bridge delivered; preserve selector/refusal and affected-input requalification. | P14, P17 |
| E01 | Rebound current PGN file passes; three SQL assertion blind spots require repair. | P01, P17 |
| E02 | Two retained-owner cases, historical rollback disposition, actual prefix HTTP, replay and assembled proof remain. | P04, P05, P06, P07, P08, P12, P14, P16, P17 |
| E03 | Current read-only three-relation Game Review proof delivered; maintain accurate docs and affected requalification. | P17, P14 |
| E04 | T01 changes lifecycle inputs; actual65 update/recovery must be qualified without bypassing current63 refusal. | T01, P13 |
| G00 | Complete every calendar row and two explicit compatibility choices. | B01 |
| G01 | Pure conversion and captured context delivered; preserve recorded-day/current-day separation. | B01, P14 |
| G02 | Historical missing-day supported task disposition remains. | B03, P14 |
| G03 | Settings host-day and backward-day refresh boundary remain. | B01, B02, P14 |
| G04 | Finite prior proof does not establish whole calendar adoption. | B01, B02, B03, P12, P14 |
| C01 | Server-issued queue GET was fixed; durable command initial expected-ID remains distinct. | C10, C11, C12, C13, C14, P12, P16 |
| C02 | Semantic facts exist; unknown retained-store hold and physical registry boundary remain. | FE05, FE06, P12 |
| C03 | Inert factory and explicit composition delivered. Wider actual consumer boundaries remain separate. | FE06 |
| D01 | Retired adapters removed; retained validation/recovery checks pass. | P17 |
| D02 | Ordinary frozen exercises have active producers/callers. Restore finite transport and preserve ambiguous/retired recovery. | C20, B31, C21, C24, P12 |
| D03 | Resolve v1 compatibility, shared parity vectors and retained provenance before claiming completion. | C22, C23, C24, P12 |
| F01 | Duplicate Rust constructor removed; one active native/WASM algorithm remains. | T05 |
| F02 | Extract exact witness policy and qualify affected current lifecycle before merge. | T01, P13 |
