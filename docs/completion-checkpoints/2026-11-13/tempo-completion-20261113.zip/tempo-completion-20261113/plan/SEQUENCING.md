# Sequencing and parallel dispatch

## Start first with one owner

The integration owner verifies current source and inherited work, adopts the existing run ledger and reserves shared paths. It then dispatches the following three tasks. These are independent source assignments and require no whole-program planning restart.

| Worker | First task | Concrete output | Immediate successor |
| --- | --- | --- | --- |
| Browser worker | C10 | Canonical original-ID confirmation; review/settings adoption and terminal-result validation | C11, C12 and C13 can then split across free workers; C14 closes remaining callers |
| Backend worker | B01 | Complete calendar row map and explicit current-day/historical missing-day decisions | B02 fixes settings and coalescing; B03 handles supported historical tasks |
| HTTP/proof worker | P06 | Three retained manual prefix routes with current owner contracts | P07 consumes their real transport; B31 later uses the released main.py mount slot |

When a slot frees, prioritize FE05 (unknown retained-store hold), C20 (four-route frozen exercise contract), P01–P03 (known proof weaknesses/failures), and B00 (bulk/direct-review/port reachability). C20 and B00 are finite decision outputs; a weaker implementation worker should receive their resolved contract, not be asked to decide the entire architecture.

## Waves are priorities, not global barriers

| Wave | Work | What releases the next work |
| --- | --- | --- |
| 1. Current retained behavior | C10–C14; FE05–FE10; B00–B03; P01–P08; C20; B31; C21–C24; P16 | Original identities, preserved unknown data, supported transport, explicit calendar/grader contracts and truthful proof selection |
| 2. Actual public contracts | B12–B15/B26; S01–S05 and applicable storage batches; FE20–FE29; T01/P13 | Typed semantic values, constructible runtime/adapters, actual consumer adoption, current lifecycle proof |
| 3. Sole owners and remaining consumers | B04–B11/B16–B30; FE30–FE36; remaining S batches | One state-transition/policy owner, current supported mode behavior, explicit descriptors and accurate storage boundaries |
| 4. Enforcement and proof inventory | B32–B36; P09–P11/P18–P24; T02–T05; P17 | Complete retained/retired dispositions, registry/guards/selection that enforce actual owners, accurate audit evidence |
| 5. Final coordinated delivery | P12/P14 affected final cohort; P15; final Goal Checker and audit update | Accepted exact source, correct installation and genuine live review-to-playable-next observation |

Independent later-wave tasks may start earlier. Examples include FE20 board capabilities, FE34 intentional FSRS contract decision, B10/B11 bounded Redis capabilities, B28 pure interpretation, T01 witness source, T02 registry classification, and T05 after its owner decision. Do not wait for every interface task before starting a safe unrelated leaf.

The first continuation checkpoint completes the older packet's unfinished acceptance and the concrete later review defects. The second completes the wider fixed audit. P12–P15 can be used for an early coherent release and again only where later changed inputs invalidate relevant evidence. This is one programme; the checkpoints do not silently defer the second half.

## Readiness and evidence stages

`plan/tasks.json` records concrete `start_requires` edges. Unless it explicitly says `qualified`, a prerequisite is a **source release**: the exact bounded contract/implementation and applicable component evidence have been reviewed and made available. Downstream implementation can use an explicit dependency branch before merge.

Source release is distinct from qualification, merge, installation and observed use. A worker may push its useful branch/PR while the integrated native/browser slot remains pending. The owner releases a merge only after all applicable acceptance for that exact head/candidate passes and actual repository protections are met. An implementation task never declares the larger audit finding closed merely because its own slice passes.

Some stages must remain distinct to avoid deadlocks:

| Relationship | Correct sequence |
| --- | --- |
| Witness extraction and lifecycle | T01 reviewed source → P13 applicable current65 proof → T01 merge. P13 does not require T01 already merged. |
| Browser inventory and shared native/browser run | P12 releases exact authored case inventory → P14 executes the coherent cohort; the same successful run can qualify both. Do not make their completed acceptance depend on each other. |
| Position port design and actual types | B00 releases the port/caller decision → S01/S02 define actual semantic capability types → B26 adopts the checked interfaces. S01 does not wait for B26. |
| Frozen exercise transport and grader | C20 freezes the existing server-v1 transport contract → B31 restores four routes → C21 adopts recovery. C22/C23 parity and C24 provenance proceed with their own dependencies; route restoration does not wait for an invented new grader version. |
| Independent shell disposition | FE30 classifies and decides supported entry scope → FE31/FE32 adopt current command owners → FE36 applies final entry disposition. FE30 does not wait for FE36. |

The parent command for a frozen attempt may have a complete receipt with `pending_self_assessment: true` while the human review remains incomplete. Commit that validated parent command so its retained child can proceed; only the actual completed review advances/counts. This distinction is part of C20/C21 acceptance.

## Shared files and ownership

`ownership.json` is the full exact-path inventory, including proposed files and all repeated claims. The owner leases one writer per path, or retains the shared file and applies a precise worker patch. A shared file does not serialize all other files of both tasks.

| Shared area | Required order or rule |
| --- | --- |
| `backend/app/main.py` | P06 mount → B31 mount → B04/B05 bulk wrappers → B06 direct-review wrappers → B27 retired-input edge → B21 final composition. B17 edge mapping is separately leased before final composition. |
| Calendar and queue worker helpers | B01 decision → B02 → B03 → relevant B04/B05/B09 structural adoption. Keep accepted-generation day semantics fixed. |
| `learning_review_adapter.py` | B06 decision/adoption → B14 → B15 → B16. Storage result batches consume the released values. |
| Admission/deletion tests | P02/P03 fix existing fixtures first; B07/B23 and later storage batches extend those corrected assertions. |
| Browser receipt confirmation | C10 shared strict helper → C11/C12/C13 disjoint callers → C14 final adoption/removal. |
| Authority registry/client composition | FE05 → FE06 → S03 → S04; FE36 consumes the later supported-entry disposition without concurrent registry edits. |
| Retained offline/frozen flows | C14 → C21 → C24; FE10 and FE33 take their separately leased sections afterward. |
| Session and outbox composition | C11/C21 → FE23 → FE24; S04 follows FE24. No reverse FE24→S04 dependency. |
| Home, queue and controller | FE25 contracts → FE26/FE28 adopted owners → FE29 completion → FE33 modes → FE35 state narrowing. One Home writer at a time. |
| Audit HTML/XLSX/progress, registry and test inventories | Integration owner by default; delegate a narrow lease or integrate exact submitted patch. No competing current status trackers. |

All 555 concrete proposed write claims are reservations, not a demand to modify every file. Source classification may prove a narrower change or justified no-work result. Any remaining dynamic consumer scope must be resolved to exact files by its preceding probe and leased before editing.

## Capacity and review

Default to three light creators, one owner and a reviewer using a freed slot. If the host has only four total slots, reuse a creator slot for review. Four to six light creators are appropriate only after independent files/contracts and available CPU/memory are established. More creators do not increase Docker/database/browser capacity.

One designated operator owns heavy qualification, resource admission, the exact candidate, logs and cleanup. Workers do not independently start stacks. Plan shared cases once per coherent release, retain exact source/fixture/runtime identities and rerun only checks invalidated by later changes. Raw count alone never substitutes for original receipt, actual HTTP, transaction rollback or playable-board evidence.

At every handoff, the owner picks the next ready task with the greatest immediate payoff: unblock a current behavioral defect or contract, release a shared file, or close a concrete proof gap. If no task is ready, inspect the named dependency or external capability. Do not create another broad audit, speculate about unrelated improvements or poll a blocked gate indefinitely.
