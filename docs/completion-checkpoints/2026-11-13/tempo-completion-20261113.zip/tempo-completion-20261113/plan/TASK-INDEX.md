# Task index

Prepared against `091ad318b1afaadcb25e5ca44ff526120a202336`. 129 bounded tasks; 25 original continuation rows; 55 fixed audit findings. These are task cards, not a requirement for 129 agents or PRs.

New IDs belong to this packet. Earlier IDs are fields named `original_task_id` or `original_task_ids`; new B01 and original B01 have different scopes. Dispatch only the linked new prompt.

The owner starts C10, B01 and P06, then releases successors by actual capability. Read SEQUENCING.md and tasks.json for stages. A missing task dependency is not permission to ignore a shared-file lease or an explicit owner condition.

| Task | Assignment | Start after source release | Findings |
| --- | --- | --- | --- |
| [B00](../prompts/B00.txt) | Finish B04: exact bulk, direct-review and unused-port reachability map | Independent; check conditions | BE001, BE013, BE015 |
| [B01](../prompts/B01.txt) | Finish G00: calendar row dispositions and two finite compatibility decisions | Independent; check conditions | BE003 |
| [B02](../prompts/B02.txt) | Fix settings follow-up and backward-day queue coalescing | B01 | BE003 |
| [B03](../prompts/B03.txt) | Resolve supported historical missing-day queue tasks exactly once | B01, B02 | BE003 |
| [B04](../prompts/B04.txt) | Remove unreachable bulk seeding and duplicate admission writers | B00 | BE001 |
| [B05](../prompts/B05.txt) | Migrate fixture ordering to active publication and delete bulk presentation writes | B00, B04 | BE001 |
| [B06](../prompts/B06.txt) | Retire or explicitly constrain direct review compatibility entrypoints | B00 | BE015 |
| [B07](../prompts/B07.txt) | Move position admission owner reads and admission proof SQL to storage | P02 | BE004 |
| [B08](../prompts/B08.txt) | Move checkpoint writer capability check and shared owner lock into storage | B07 | BE004 |
| [B09](../prompts/B09.txt) | Finish private queue, bounded-read and source-token capability cleanup | B04, B05, B07, B34 | BE005 |
| [B10](../prompts/B10.txt) | Encapsulate Redis admission keys and lease policy in current storage owner | Independent; check conditions | BE005 |
| [B11](../prompts/B11.txt) | Encapsulate wake ownership keys without changing broker protocol | Independent; check conditions | BE005 |
| [B12](../prompts/B12.txt) | Type next-exercise facts, head identity and issuance variants | Independent; check conditions | BE002 |
| [B13](../prompts/B13.txt) | Use typed next-exercise capabilities and remove HTTP closure side channel | B12, B05 | BE002 |
| [B14](../prompts/B14.txt) | Type Learning schedule and reconciliation port values | B06 | BE008 |
| [B15](../prompts/B15.txt) | Type Learning submission, completion and final result contracts | B14 | BE008 |
| [B16](../prompts/B16.txt) | Make review failures transport-neutral and preserve durable wire errors | B15, B08 | BE007 |
| [B17](../prompts/B17.txt) | Remove HTTP errors from remaining retained authoring and Study policies | B16, B27, B29 | BE007 |
| [B18](../prompts/B18.txt) | Export explicit core Study and Tactics command descriptors | B02, B03, B16, B22, B31, B09 | BE009 |
| [B19](../prompts/B19.txt) | Export explicit authoring mutation command descriptors | B24, B25, B27, B30, B17 | BE009 |
| [B20](../prompts/B20.txt) | Export remaining retained control command descriptors | B02, B23 | BE009 |
| [B21](../prompts/B21.txt) | Compose explicit supported command sets and isolate essential startup | B18, B19, B20, B31, P06 | BE009 |
| [B22](../prompts/B22.txt) | Move standalone tactic schedule and queue transitions behind Study capability | B03 | BE010 |
| [B23](../prompts/B23.txt) | Give Study the transaction-bound card retirement and evidence purge capability | P03 | BE011 |
| [B24](../prompts/B24.txt) | Centralize authored reset/preserve learning transitions with explicit columns | B33 | BE012 |
| [B25](../prompts/B25.txt) | Move prefix split learning state and queue/history transfer to Study | B24, P06 | BE012 |
| [B26](../prompts/B26.txt) | Remove fictitious position ports and bind accurate current capability surfaces | B00, B07, B08, S01, S02, B12, B14 | BE013 |
| [B27](../prompts/B27.txt) | Reject retired Coverage inputs before authoring and remove their storage branch | Independent; check conditions | BE018 |
| [B28](../prompts/B28.txt) | Extract one pure legal source interpretation kernel from current position index | Independent; check conditions | BE019 |
| [B29](../prompts/B29.txt) | Use source kernel for conflict listing and strict import/change validation | B28 | BE019 |
| [B30](../prompts/B30.txt) | Use source kernel for integrity scans and paste preview response comparison | B28, B29, B27 | BE019 |
| [B31](../prompts/B31.txt) | Restore exactly four frozen ordinary exercise runtime endpoints | C20, P06 | FE008 |
| [B32](../prompts/B32.txt) | Retire executable tests exclusive to removed authoring/producer systems | Independent; check conditions | BE021 |
| [B33](../prompts/B33.txt) | Rebind retained review and scheduling regressions to current owners | Independent; check conditions | BE021 |
| [B34](../prompts/B34.txt) | Repair retained queue timing/read probes and mixed route tests | P02 | BE021 |
| [B35](../prompts/B35.txt) | Finish backend recovery and diagnostic fixture disposition | Independent; check conditions | BE021 |
| [B36](../prompts/B36.txt) | Reconcile every BE021 reference and final backend finding coverage | P01, P02, P03, B32, B33, B34, B35, B31, B21 | BE021 |
| [C10](../prompts/C10.txt) | Fence initial 202 confirmation with the original ID; fix review and settings first | Independent; check conditions | FE001 |
| [C11](../prompts/C11.txt) | Bind the remaining Study journal confirmations to their frozen delivery IDs | C10 | FE001 |
| [C12](../prompts/C12.txt) | Bind repertoire-edit confirmations and retained annotation save to original keys | C10 | FE001 |
| [C13](../prompts/C13.txt) | Bind deletion and repertoire settings acknowledgments; validate rename completion | C10 | FE001 |
| [C14](../prompts/C14.txt) | Finish 202 adoption for phone and tactics; remove permissive confirmation entry | C11, C12, C13 | FE001 |
| [C20](../prompts/C20.txt) | Freeze the retained-exercise HTTP and recovery contract before either side changes | Independent; check conditions | FE008 |
| [C21](../prompts/C21.txt) | Wire supported frozen exercises and preserve held retained work without queue-wide failure | C20, B31, C14 | FE008 |
| [C22](../prompts/C22.txt) | Choose and document bounded grader-v1 compatibility; repair the pure Python test owner | C20 | FE009 |
| [C23](../prompts/C23.txt) | Align browser grading and validation to current Python v1 using shared boundary vectors | C22 | FE009 |
| [C24](../prompts/C24.txt) | Record new offline grading provenance and reconcile retained v1 answers without rewriting them | C23, C21 | FE009, FE008 |
| [FE05](../prompts/FE05.txt) | Hold foreign authority cutover when an inspected retained store is unknown and nonempty | Independent; check conditions | FE005 |
| [FE06](../prompts/FE06.txt) | Move physical authority registry layout and database naming into the storage adapter | FE05 | FE005 |
| [FE08](../prompts/FE08.txt) | Publish pure validation facts while retaining the current browser collector facade | Independent; check conditions | FE007 |
| [FE09](../prompts/FE09.txt) | Adopt pure validation in both domain adapters and computation contracts | FE08 | FE007 |
| [FE10](../prompts/FE10.txt) | Inject validation collection at worker and browser composition boundaries | FE09, C14 | FE007 |
| [FE20](../prompts/FE20.txt) | Publish the small board adapter capabilities needed by current Study policy | Independent; check conditions | FE002 |
| [FE21](../prompts/FE21.txt) | Render current Study and dialogs through the shared board package | FE20 | FE002 |
| [FE22](../prompts/FE22.txt) | Construct one typed Study session runtime with a complete adapter table | C21 | FE006 |
| [FE23](../prompts/FE23.txt) | Separate delivery adapters from outbox/session composition without changing settlement | FE22, C14, C24 | FE006 |
| [FE24](../prompts/FE24.txt) | Assemble explicit default Study runtime and remove registration side effects | FE23, FE06 | FE006 |
| [FE25](../prompts/FE25.txt) | Publish semantic review ports and map the existing browser owners behind them | FE24 | FE003 |
| [FE26](../prompts/FE26.txt) | Run the review controller through injected ports and preserve presentation fences | FE25 | FE003 |
| [FE27](../prompts/FE27.txt) | Extract the bounded queue HTTP protocol into an independently testable capability | C14 | FE004 |
| [FE28](../prompts/FE28.txt) | Move queue acquisition/reconciliation out of the view into one port-based application owner | FE27, FE25, C21 | FE004 |
| [FE29](../prompts/FE29.txt) | Move durable attempt completion and failure preparation out of Home | FE26, FE28 | FE004, FE003 |
| [FE30](../prompts/FE30.txt) | Classify the independent serving entry and release the supported-shell decision | FE06, C21 | FE008, FE010, FE012 |
| [FE31](../prompts/FE31.txt) | Give current Tactics one retained command lifecycle before transport | FE24, FE30, C14 | FE010 |
| [FE32](../prompts/FE32.txt) | Use one burial lifecycle and a bounded reader for existing local markers | FE24, FE30, C14 | FE010 |
| [FE33](../prompts/FE33.txt) | Document provisional offline repeats and isolate demo queue policy with conformance | FE30, C24, FE29 | FE012, FE004 |
| [FE34](../prompts/FE34.txt) | Record intentional FSRS-shaped scheduling API as the current abstraction | Independent; check conditions | FE013 |
| [FE35](../prompts/FE35.txt) | Restrict queue/attempt writes to named invariant-preserving actions | FE26, FE28, FE29, FE33 | FE003, FE004 |
| [FE36](../prompts/FE36.txt) | Apply the independent entry retirement after current command consumers adopt their owner | FE30, FE31, FE32 | FE008, FE010, FE012 |
| [P01](../prompts/P01.txt) | Make the three rebound E01 SQL tests reject wrong queries and missing locks | Independent; check conditions | ST012, ST013, BE021 |
| [P02](../prompts/P02.txt) | Dispose all five stale position-admission tests against current owners | Independent; check conditions | ST012, BE021, ST006 |
| [P03](../prompts/P03.txt) | Repair the four current card-deletion borrowed-connection test failures | Independent; check conditions | ST012, BE021 |
| [P04](../prompts/P04.txt) | Replace the obsolete real-game queue case with paused-history preservation | Independent; check conditions | ST012, ST013, BE021 |
| [P05](../prompts/P05.txt) | Rebind the retired opening-reconciliation queue case to retained review recovery | P04, C11, B00 | ST012, ST013, BE021 |
| [P06](../prompts/P06.txt) | Restore the three retained manual prefix-split HTTP routes | Independent; check conditions | ST012, ST013 |
| [P07](../prompts/P07.txt) | Restore truthful HTTP coverage and acceptance scope in every shared runner mode | P04, P05, P06 | ST012, ST013, RT004 |
| [P08](../prompts/P08.txt) | Give the historical 49→48→49 rollback case a finite, explicit supported disposition | Independent; check conditions | ST012, ST013 |
| [P16](../prompts/P16.txt) | Require successful original-review replay and a playable final successor | C11, P07 | ST012 |
| [P17](../prompts/P17.txt) | Reconcile E00/E01/E03/E02 evidence descriptions with actual current proof | P01, P04, P05, P06, P07, P08, P16 | ST012, ST013 |
| [S01](../prompts/S01.txt) | Separate typed position source values from the concrete sealed SQL capability | B00 | ST002 |
| [S02](../prompts/S02.txt) | Type introduction and owner-fence contracts without weakening their seals | S01, P02, B07 | ST002 |
| [S03](../prompts/S03.txt) | Inject workspace and IndexedDB dependencies into the offline storage instance | FE06, FE08 | ST003 |
| [S04](../prompts/S04.txt) | Inject intent-store validation and portable-backup diagnostics at composition | S03, FE08, FE24 | ST003 |
| [S05](../prompts/S05.txt) | Make the opening journal own IndexedDB lifetime and commit-boundary results | S03, S04, C11 | ST004 |
| [S06](../prompts/S06.txt) | Use explicit supported transaction capabilities for eligibility and frozen-order locks | P02, B07 | ST006 |
| [S07](../prompts/S07.txt) | Separate queue-abandonment request/policy from SQL and operator transport | T02 | ST014 |
| [T01](../prompts/T01.txt) | Share the exact cut62 witness policy and qualify its current lifecycle use | Independent; check conditions | RT005 |
| [T02](../prompts/T02.txt) | Make the existing component registry describe every current executable owner | Independent; check conditions | RT003 |
| [T03](../prompts/T03.txt) | Enforce the actual public boundaries through the existing parser and registry | T02, FE09, S01, S03, S04 | RT002 |
| [T04](../prompts/T04.txt) | Select proof by changed owner and effect instead of blanket Study filenames | T02, T03, P07 | RT004 |
| [T05](../prompts/T05.txt) | Declare and prove the Rust component fixture input contract | T02 | ST011 |
| [P13](../prompts/P13.txt) | Qualify the actual schema65 installation lifecycle and recovery path | T01 | RT005, ST012, ST013 |
| [P12](../prompts/P12.txt) | Declare and demonstrate the exact assembled browser journeys | P06, P07, P16 | ST003, ST004, ST012, ST013 |
| [P14](../prompts/P14.txt) | Run one coordinated exact native and HTTP qualification cohort | P01, P02, P03, P04, P05, P06, P07, P08, P16, P12 | ST002, ST005, ST006, ST012, ST013, ST014 |
| [P15](../prompts/P15.txt) | Use the normal CLI for authorized installation and observe genuine live Study | P12, P14, P13 | Release |
| [S08](../prompts/S08.txt) | Settle and adopt typed storage boundary: Position issuance identity and lock facts | S01, S02, B07 | ST005 |
| [S09](../prompts/S09.txt) | Settle and adopt typed storage boundary: Position issuance attempt and completion evidence facts | S08, B00 | ST005 |
| [S10](../prompts/S10.txt) | Settle and adopt typed storage boundary: Position grading and checkpoint receipt contracts | S01, S02, B08, B26 | ST005 |
| [S11](../prompts/S11.txt) | Settle and adopt typed storage boundary: Learning review and reconciliation snapshots | B14, B15, B06 | ST005 |
| [S12](../prompts/S12.txt) | Settle and adopt typed storage boundary: Queue command and operation receipt facts | P01, B18 | ST005 |
| [S13](../prompts/S13.txt) | Settle and adopt typed storage boundary: Queue application seeding, eligibility and publication projections | S06, B07 | ST005 |
| [S14](../prompts/S14.txt) | Settle and adopt typed storage boundary: Opening, tactic and capacity admission facts | P02, B07, B22, S06 | ST005 |
| [S15](../prompts/S15.txt) | Settle and adopt typed storage boundary: Queue refresh and HTTP head projection contracts | B12, B13 | ST005 |
| [S16](../prompts/S16.txt) | Settle and adopt typed storage boundary: Queue placement, retained origins and frozen-order state facts | S06 | ST005 |
| [S17](../prompts/S17.txt) | Settle and adopt typed storage boundary: PGN import and card-edit storage projections | P01, B19 | ST005 |
| [S18](../prompts/S18.txt) | Settle and adopt typed storage boundary: Card and repertoire deletion retention facts | P03, B23 | ST005 |
| [S19](../prompts/S19.txt) | Settle and adopt typed storage boundary: Integrity scan and publication adapter facts | B30 | ST005 |
| [S20](../prompts/S20.txt) | Settle and adopt typed storage boundary: Integrity read and repair command contracts | S19, B19 | ST005 |
| [S21](../prompts/S21.txt) | Settle and adopt typed storage boundary: Repertoire branch, paste, canonical-prefix and move-membership facts | B19, B27, B28, B29 | ST005 |
| [S22](../prompts/S22.txt) | Settle and adopt typed storage boundary: Manual prefix split command and lineage facts | P06, P07, B25 | ST005 |
| [S23](../prompts/S23.txt) | Settle and adopt typed storage boundary: Opening graph worker persistence facts | B28 | ST005 |
| [S24](../prompts/S24.txt) | Settle and adopt typed storage boundary: Durable task identity and read models | B02, B03 | ST005 |
| [S25](../prompts/S25.txt) | Settle and adopt typed storage boundary: Durable task claim and transition facts | S24, B02, B03 | ST005 |
| [S26](../prompts/S26.txt) | Settle and adopt typed storage boundary: Settings and current mode facts | B02 | ST005 |
| [S27](../prompts/S27.txt) | Settle and adopt typed storage boundary: Background activity, refresh and readiness facts | B02, B03 | ST005 |
| [S28](../prompts/S28.txt) | Settle and adopt typed storage boundary: Tactics catalog, capture and attempt facts | B22 | ST005 |
| [S29](../prompts/S29.txt) | Settle and adopt typed storage boundary: Retained exercise attempt facts after route restoration | B31, C23 | ST005 |
| [S30](../prompts/S30.txt) | Settle and adopt typed storage boundary: Retained HTTP read projections and command lock facts | B18, B19, B20 | ST005 |
| [S31](../prompts/S31.txt) | Settle and adopt typed storage boundary: Read-only Game Review storage values | Independent; check conditions | ST005 |
| [S34](../prompts/S34.txt) | Settle and adopt typed storage boundary: Bounded published repertoire source facts | S01 | ST005 |
| [P09](../prompts/P09.txt) | Reconcile current proof contract: Background diagnostic and admission proofs | B21 | ST012, ST013 |
| [P10](../prompts/P10.txt) | Reconcile current proof contract: Current opening checkpoint, original evidence and immutability proofs | P05, B08 | ST012, ST013 |
| [P11](../prompts/P11.txt) | Reconcile current proof contract: Deletion and repertoire allowance native proofs | P03, B23 | ST012, ST013 |
| [P18](../prompts/P18.txt) | Reconcile current proof contract: Historical position seed/operator/source-fixture support decisions | B00 | ST012, ST013 |
| [P19](../prompts/P19.txt) | Reconcile current proof contract: Frozen order proof inputs and native SQL | S06 | ST012, ST013 |
| [P20](../prompts/P20.txt) | Reconcile current proof contract: Tactic capture and retained corpus/history native proofs | B22, B31 | ST012, ST013 |
| [P21](../prompts/P21.txt) | Reconcile current proof contract: Current queue dispatch, opening admission and capacity proof closures | P02, B07, B12, B13 | ST012, ST013 |
| [P22](../prompts/P22.txt) | Reconcile current proof contract: Historical schema and retired packaged collection proof decisions | B21, B35 | ST012, ST013 |
| [P24](../prompts/P24.txt) | Reconcile current proof contract: Mixed native review suite after retained split and receipt repairs | P05, P06, B06 | ST012, ST013 |
