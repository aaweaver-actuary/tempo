# Rules shared by the bounded worker prompts

Your task prompt is the exact assignment. The integration owner supplies its current base/head, released dependencies and file reservation. Do not replace it with an old A–G programme or inspect every historical issue before starting.

1. Read current AGENTS.md/SPEC amendments, your task's named owner guidance, exact symbols and tests. Check branch/status and preserve another owner's work. If a source path moved, find its current owning symbol and report the mapping before changing scope.
2. State the existing failure or boundary, observable intended result and one meaningful negative case. Use the supplied reproduction when applicable. Do not manufacture a red test for a pure mechanical change or run a whole product suite to characterize a narrow leaf.
3. Implement the smallest coherent change, including the named actual consumers. Use existing public owners and adapters. A type alias, facade, helper or new folder without adoption is not task completion. Do not introduce another scheduler, workflow framework, generic repository or global journal.
4. Preserve original IDs/bodies/clocks/receipts, accepted-generation identity, currentness/source fences, lock order and atomic effect+receipt+checkpoint boundaries. Retired or ambiguous records get the assigned explicit preservation/disposition, not silent deletion or universal feature retirement.
5. Run the task's verified focused commands in a compatible task-owned environment. Proposed tests are new assertions to add under the named owning suite; they are not pre-existing passing commands. Record actual exit and cases, not only a screenshot of a process starting. A native test collected/deselected/skipped is not executed acceptance.
6. Request the proportionate independent review through the integration owner or an available distinct reviewer. Give the actual diff, base/head, changed consumers, tests and known risks. The same reviewer can cover architecture; do not create a second approval ceremony.
7. Commit and push the scoped branch and open/update its PR under the explicit authority in AUTHORITY.md. Publish a useful draft if component acceptance is done but the owner's native/browser slot is still pending. Do not wait for unrelated tasks or ask Andy again whether pushing is allowed.
8. Handoff the exact head and released capability, file list, executed evidence, any incomplete acceptance and the next owner. Stop editing when your task boundary is accepted; the integration owner chooses your next task. You may merge only when that owner releases the exact accepted head; only a designated local operator installs.

## If reality differs from the prompt

An ordinary reversible implementation choice is yours. A missing dependency, wrong owner assumption, persisted-format change, lock/transaction change or changed supported behavior goes to the integration owner with one concrete proposed correction and the affected acceptance. Continue independent safe work within your reservation. Do not silently widen the task or conceal the mismatch.

After two failures with the same mechanism, inspect the first useful failure and the actual dependency/fixture; do not repeat a heavy run unchanged. Classify product defect, stale fixture, environment/access issue or invalid evidence. Keep failure receipts. Do not increase global deadlines, suppress errors, skip cases or erase retained work to get a pass.

## Handoff fields

Use `ledger/HANDOFF-TEMPLATE.json` or the existing equivalent. Required facts: task ID, owner, base/head, changed paths, released interface, actual commands/results/case IDs, source/environment applicability, review outcome, merge/install state, residual, next owner/action and task-owned cleanup. The template is a convenience, not a new repository gate. Update the existing run ledger rather than creating a competing tracker.

Only the integration owner edits shared audit files, test inventories, registry/guard files or route/composition roots unless explicitly leased to your task. If your patch requires one of those files, give the precise patch or request its reservation before editing.
