# Supporting material and precedence

The current execution instructions are in the packet root, `prompts/`, `roles/`, `plan/` and `runbooks/`. The source preparation pin is recorded in CURRENT-STATE.md. At execution, current direct user steering and actual current repository guidance apply. Inspect any later source delta once and adjust affected tasks; do not discard valid completed work.

`audit-current.json`, `tempo-architecture-audit.html` and `tempo-architecture-registry.xlsx` preserve the fixed audit and its original observations/criteria. The audit is a source-backed work inventory, not proof that every historical file/line still applies. The packet's finding map assigns every remaining criterion and retains the 14 closed findings as inherited evidence.

`prior-continuation/` and its ZIP contain the original 25-task packet, the A–G creator prompts, previous sequencing and additional supporting materials. They are historical context. Do not reissue their entire assignments or use their older base SHA as the current source. Their unfinished criteria are explicitly mapped in `plan/original-25.json`.

`deep-review/` and its ZIP contain the later independent technical review, exact negative reproductions and verification receipts. Deliberately failing probes expose baseline defects; they are not implementation patches. Prior test results are historical evidence with their recorded source/environment limits, not tests newly executed while preparing this packet.

`source-guidance/` contains selected relevant repository instructions at the preparation pin for portability. Read their current counterparts in the execution checkout before changing code. Do not execute a historical runbook against live data merely because it is included here.

`user-state-brief.md` preserves the supplied corrective brief. `source-provenance.json` records preparation/source facts. No private personal-planning export or full source repository is required to execute this packet.
