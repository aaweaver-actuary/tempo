# Tempo coordinated qualification and continuation

Start the integration owner first. The owner runs the first qualification session, releases ready Creator tasks, integrates their results, and delivers accepted changes through GitHub and the registered local installation.

## Read only what you need

1. Read `AUTHORITY.md` and `prompts/00-integration-owner.txt`. They provide the current assignment and explicit delivery authority.
2. Read `plan/SEQUENCE.md`, `plan/TASK-INDEX.md` and `plan/tasks.json` to choose the next ready task. Read `reference/current-state.json` for the reviewed source baseline and existing PRs.
3. Start `prompts/Q0-qualify-merge-install.txt`. It is the single prompt for the final coordinated qualification of #991, #992, #993 and #995, including its bounded runner prerequisites. Its supporting command map is `plan/QUALIFICATION-RUNBOOK.md`.
4. Dispatch the matching files in `prompts/A-...` through `prompts/G-...` when their dependencies and file reservations clear. These are logical work packets; they do not require seven concurrent agent teams.
5. Maintain the existing project/PR progress records. `handoffs/TEMPLATE.json` is a small suggested delta, not a new approval system. One owner updates the existing root audit HTML/workbook at accepted checkpoints.

The latest remote state must be refreshed before execution. This packet was prepared against main `799b66234b8be386a33d980df10b8b1d9a9d8b36` on November 12, 2026. It is a continuation of the reviewed work, not a restart. #988, #989, #990 and #994 are already merged; #996 records the audit update. The four held PRs have published review repairs and independent component evidence. They still need the stated native/browser/assembled qualification.

## Which material controls

The user's current instruction and current repository `AGENTS.md`/`SPEC.md` govern. This packet's execution prompts supersede the earlier packet's launch, scope and authority instructions where they differ. In particular, the owner may dispatch/resume workers, scoped GitHub publication and accepted merges are authorized, and the ready release may be installed on the verified registered Mac. Do not ask Andy for the same authorization again.

`reference/historical-packet/` is archived context only. Do not execute its completed A/B tasks, its previous manual-launch rule, or its older statements that the packet grants no delivery authority. `reference/source-context/` contains pinned instruction snapshots for portability; inspect the actual target checkout before acting. The included audit HTML and workbook are the accepted snapshot, not a claim that future tasks are done.

## Finish line

Deliver Q0, then the ready bounded continuation slices. Run conditional tasks only when their stated trigger holds. Merge accepted coherent increments; do not wait for all 55 findings. Install at the defined release checkpoints when the registered target and applicable acceptance are ready. Preserve clear separate states for implemented, component-tested, assembled-demonstrated, merge-qualified, merged, installed, and activated. Stop after the assigned ready work, or leave one precise capability or product-decision blocker and a resumable next action.

No product edits, new acceptance runs, merges or local installation were performed while preparing this continuation packet.
