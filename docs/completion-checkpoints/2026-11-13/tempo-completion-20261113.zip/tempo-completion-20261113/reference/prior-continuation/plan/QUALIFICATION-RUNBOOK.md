# Current qualification runner map

Prepared against `aaweaver-actuary/tempo` main `799b66234b8be386a33d980df10b8b1d9a9d8b36` and the four pinned pending heads in Q0. This is a map of actual source, not a report of successful execution. Refresh the source if refs advance. The source snapshot requires PostgreSQL schema **65**; the `docs/testing.md` paragraph still naming schema 64 is stale relative to the executable schema constant.

## Prerequisites and finite selection

| Item | Actual source / command | Qualification consequence |
| --- | --- | --- |
| Repository rules | `AGENTS.md`; `CONTRIBUTING.md`; `docs/testing.md` | Preserve single Study owner, receipts, original identities, native isolation and installed-state distinction. Current assignment authorizes pushes, merges after acceptance and installation. |
| Node | `package.json` engines: `>=22.13.0` | Use a compatible supported environment, not the age of a cached binary as evidence. |
| Python | `backend/pyproject.toml`: `>=3.12,<3.15`; `scripts/resolve-python.mjs` resolves `TEMPO_PYTHON`, then root/backend `.venv`, then `python3` | Verify the selected interpreter and required dependencies. Native psycopg/FSRS/chess and pytest are real prerequisites. |
| Docker/browser preflight | `make preflight` → `node scripts/check-test-capabilities.mjs --docker --loopback --workspace-mount` | Checks daemon, loopback and read-only checkout mount via pinned ARM64 Playwright image. It is not a browser test. Do not bypass failure. |
| Browser runtime | `playwright.config.ts` requires `TEMPO_DOCKER_URL`; one worker, `fullyParallel: false`, `retries: 0`, America/New_York calendar | Let the disposable runner supply the URL/project/token. Do not point regular Playwright at the registered live origin. |
| Disposable stack | `database/tests/test-postgres-docker.mjs`; `docker-compose.postgres.test.yml` | Creates unique `tempo-pg-regressions-<pid>-<random>` project, credentials, volumes and loopback port; enforces development budget/isolation and cleans up. Reuse its single lifetime. |
| Browser assets | `AGENTS.md`; `docs/testing.md`; current checked-in asset/preparation guidance | Verify digest-bound browser WASM/build inputs and compatible dependencies; do not substitute arbitrary fixtures or a stale build. |

## Supported commands as of the prepared snapshot

These are alternative scopes. Do not run each command as an additional gate. Read/list is distinct from execution; a zero-selected or skipped required case fails qualification.

| Need | Exact command or form | Notes |
| --- | --- | --- |
| Inspect browser plan | `node database/tests/test-postgres-docker.mjs --list --mode browser --browser-grep 'PATTERN'` | Read-only; pattern must be a valid JavaScript regex. Choose the final union from actual test titles and verify counts. |
| Run one coordinated browser selection | `node database/tests/test-postgres-docker.mjs --mode browser --browser-grep 'PATTERN'` | After preflight. Builds candidate images once, starts fresh native state, checks service health, runs selected Playwright cases, cleans up. Use one union for Q0, extended by E00's reviewed native-stage registration. |
| Make equivalent by title | `make view VIEW='PATTERN'` | Runs capability preflight, then `run-focused-postgres-browser.mjs grep`, which delegates to browser mode. |
| One browser spec | `make ui-file FILE=position-study-acceptance.spec.ts` | `FILE` must be a basename from `tests/browser`, not a path. Do not use a separate stack per spec when one union serves Q0. |
| One Game Review spec | `make ui-file FILE=minimal-game-review-acceptance.spec.ts` | Concrete existing acceptance, not an additional mandatory invocation after the combined run. |
| Focused Python file | `make python-file FILE=backend/tests/test_scheduling_boundary.py` | Make sets `PYTHONPATH=backend:database` and invokes selected Python, pytest `-q -o cache_dir=.pytest_cache --rootdir=.`. |
| Focused frontend file | `make unit-file FILE=tests/unit/game-review-contract.test.ts` | `npm run test:unit -- FILE`; the npm pre-hook prepares shared packages. Available on #995. |
| Browser source types | `npm run typecheck:browser` | Prepare shared packages as documented; this script itself is `tsc -p tsconfig.browser.json --noEmit --incremental false`. |
| Inventory/runner discovery | `node tools/component-build/test-lane.mjs frontend --list` | Lists the actual owning lane and validates inventory; it is not a passing component suite. Use specific file runs for causal fixes. |
| Scheduling and maturity files | `backend/tests/test_scheduling_boundary.py`, `backend/tests/test_opening_baseline_maturity.py`, `backend/tests/test_scheduling_review_application.py` | #991 has the helper/ownership registration fix. The grimp-backed guard must genuinely execute; installing grimp only makes it possible. |
| Codec files | `backend/tests/test_position_first_response_codec.py`; `backend/tests/test_position_issued_plan_contracts.py`; `database/tests/position_study/test_position_issued_plans.py`; named native node below | #992 moves the codec and preserves checkpoint compatibility aliases. Select real affected consumers, not all tests under historical modules. |

`--browser-file` and `--browser-grep` are mutually exclusive. Neither works with explicit non-browser modes. The default runner mode is `full`; always state `--mode browser` for Q0's focused combined proof. Inherited `TEMPO_PG_BROWSER_FILE` or `TEMPO_PG_BROWSER_GREP` are refused, so clear obsolete inherited filters. `--mode study` requires an explicit browser grep and adds study-native/durability/isolation stages; it is not merely a synonym for browser mode.

The top-level PostgreSQL runner's `--list` is read-only but still imports its JavaScript dependencies. In the fresh source-only worktree used to prepare this packet, it stopped at missing `chess.js` before listing. This is not a failed browser test. The dependency-free option/plan modules were inspected directly and confirmed the exact browser arguments and six stages: compose_config, image_build, startup, service_health, browser, cleanup. Prepare compatible dependencies before relying on the top-level list command.

Current `--native-check` accepts only `redis-fixture-isolation` and only with browser/study mode. There is no current `position-rollback` or `game-review` native flag. Do not pretend a proposed selector is implemented.

## Exact browser cases and the remaining gaps

| Acceptance | Existing file and title | What it does / remaining work |
| --- | --- | --- |
| Position first response and recovery | `tests/browser/position-study-acceptance.spec.ts`: `position Study keeps its server-issued suffix and first-wrong journal across reload and offline` | A real disposable fixture, actual application issuing/refetch behavior, first-response/grade inspection and legacy offline review journal. Execute on the integrated #992 code. |
| Current opening progression/maturity | `tests/browser/opening-progression.spec.ts`: `one real short-prefix practice admits its child while parent is learning 390` and corresponding `1280` case | Completes a real short practice, polls authoritative queue for admitted child and checks mature/learning/locked statistics. It does not by itself play the next child or assert the precise durable receipt. Add the smallest necessary assertions to establish the assigned saved-review → authoritative playable next journey. |
| Bounded review successor/replay | `tests/browser/post-review-progression.spec.ts`: `issue186_completed_tactic_has_bounded_progression: prepared abort`; `fallback abort`; `fallback timeout`; `flush_settlement_audit overlapping reconnect preserves issued successor and one durable review` | Real review and receipt/queue persistence, held/failed responses, actual next-board move, restart/replay. Use relevant selected cases for failure semantics; tactics alone do not prove opening maturity extraction. |
| Optional broader packaged recovery | `tests/browser/study-recovery.spec.ts`: `packaged recovery records thirty authoritative playable transitions` | A maintained 30-transition proof. Reuse existing input-equivalent evidence; do not automatically add this to Q0 if the concrete selected proof suffices and no gate requires it. Never weaken its 30-transition requirement if it is selected. |
| Import receipt recovery | `tests/browser/recovery.spec.ts`: `unknown PGN receipt recovers the same operation after reload and matching file reselection` | Existing browser receipt/journal path. Unknown is not malformed or foreign; add a focused fault injection where needed and preserve a real underlying operation for valid settlement/replay. |
| Real integrity recovery | `tests/browser/recovery.spec.ts`: `repair choices advance before a delayed save and survive reload through real PostgreSQL receipts` | Actual PostgreSQL receipts and pending choices, reload, retry. Extend or add a bounded adjacent malformed/foreign response case for the #993/#995 combination. |
| Integrity UI preservation | `tests/browser/recovery.spec.ts`: `repair confirmation during a held training piece preserves the drag and active attempt`; `asynchronous repair validation retry survives reload without repeating the retry command` | Existing focused interaction coverage includes mocked responses. Useful preserved UI proof, but do not label it a native receipt pass. |
| Minimal Game Review | `tests/browser/minimal-game-review-acceptance.spec.ts`: `minimal Game Review compares pasted and saved games against current repertoire without Study writes` | Actual packaged stack. Imports current repertoire, seeds owned saved game, waits for stable baseline, exercises pasted/saved comparisons, verifies visible departure and exact before/after snapshots. |

A practical initial **planning** pattern, before adding specifically named receipt variants, is `position Study keeps its server-issued suffix|one real short-prefix practice admits its child|flush_settlement_audit overlapping reconnect|unknown PGN receipt recovers|repair choices advance before a delayed save|minimal Game Review compares`. This string is not a complete acceptance claim: verify each actual selected title and add the narrow malformed/foreign and playable-opening assertions. Do not label discovery/listing or this proposed pattern as test execution.

## Native late rollback bridge: actual current contract

The node ID is `database/tests/position_study/test_position_grade_effects.py::test_native_two_decisions_and_late_failure_rollback`. It uses `TEMPO_POSITION_TEST_DSN`; without it, the case calls `pytest.skip`. It checks that `current_database()` starts with `tempo_position_test_`, creates a UUID-named schema, builds its minimal native fixture from `057_position_study.sql`, injects a failure on the second grade write, verifies rollback, races duplicate completion, replays successfully, checks a legacy sentinel and drops its schema in `finally`.

At #992's head, the import points to `app.study.position_learning.first_response_codec`, correcting the retired module path. Collection is not native execution. The ordinary product database is named `tempo`, so it is deliberately inadmissible for this test. The backend application image installs `backend/requirements.txt`; pytest is a development dependency declared in `backend/pyproject.toml`, not installed by that Dockerfile. A runner cannot assume `python -m pytest` already exists in the `schema` service image.

E00's bounded bridge must therefore do all of the following before Q0 can claim this proof:

- Register an explicitly named selection in the current option/plan/action mechanism, preserving its read-only `--list` behavior and unique stages ending in cleanup.
- Identify the current disposable project's PostgreSQL/credentials/resource owner; create a fresh owned `tempo_position_test_<unique>` database there. Never borrow a registered target or weaken the database refusal.
- Supply a supported genuine pytest environment, exact assembled source and current imports. Make test-only prerequisites explicit; avoid installing development tools into a live application image or host installation.
- Run the exact node ID with the owned DSN and correct backend/database/test import roots; record expected and executed case identity and non-skipped pass/failure. Reject missing, duplicate, skipped or zero tests.
- Drop only that owned database and retain the outer runner's service/volume/image cleanup on all failure paths. Include the small necessary runner-selection/failure/cleanup tests and evidence, without a new test framework.

The final executable native command is a deliverable of this bridge, not an existing supported command that this packet can truthfully prescribe today.

## Installation: exact supported interface and conditional schema work

| Purpose | Existing command | Constraint |
| --- | --- | --- |
| Read state | `tempo status`; `tempo doctor --verbose`; `tempo start --plan` | Read-only. `--plan` previews; it is not update evidence. Global `tempo` routes to registration, not necessarily the current directory. |
| Normal update | `tempo start --no-open` | Uses exact-main complete hosted verification when available, then normal images/backup/migration/readiness flow. |
| Approved CI-disabled update | `tempo start --no-ci --no-open` | Authorized while hosted CI is disabled. Selects current main. Freeze and verify accepted main before and installed full SHA after. No assertion of green hosted CI. |
| Service recreation | `tempo restart` (with supported `--no-ci --no-open` if needed) | Same checked update path plus recreation. Do not run gratuitously after successful start. |
| Stop / backup | `tempo stop`; `tempo backup` | Stop retains data. Backup stops writers, takes and restore-verifies backup, restores service state. Use operationally when required, not as a synthetic acceptance ritual. |
| Register once | `./tempo install` | Only from intended existing unregistered installation, with its `.env`, private secrets, four product volumes and verified identity. Refuses to overwrite registration; does not update/start product. |
| Retry interrupted migration | `tempo migrate --retry` | Only after inspecting/reconciling recorded recovery state through the supported procedure. No blind retry or manual ledger patch. `--no-ci` is accepted only on start/restart, not migrate. |
| Exact candidate rehearsal | `tempo start --no-ci --no-open --candidate-ref refs/heads/codex/NAME --candidate-sha FULL_SHA` | Existing restricted reviewed branch rehearsal interface; not a general main `--sha` option or authorization to install unrelated/unmerged work. Candidate options reject `--plan`. |

The current installation registration defaults to `~/.config/tempo/config.json`; records live under `~/.local/share/tempo`. Historically the main study checkout is `/Users/andy/tempo` on the Mac. Verify live registration, Docker daemon/context/project, actual target, volumes and current state; never infer it from that path alone.

`database/tempo_storage/ddl/schema_version.py` currently defines **65**. `scripts/lifecycle-source-preflight.mjs::checkLifecycleSource` rejects source versions >=64. `--mode lifecycle-current` is a schema-63 historical profile, and `--mode lifecycle` retains deeper historical work. Neither presently qualifies an earlier-schema-to-65 upgrade. There is historical installed schema-65 evidence, but inspect the actual applied ledger first. If the registered installation already has the required schema and the changed installation boundary needs no additional proof, do a bounded supported update. If a real pending transition or required lifecycle gate is found, qualify that exact missing transition before install; do not disable the refusal or automatically rerun a historical migration matrix.

For a successful installation record distinguish full source SHA, immutable image IDs and revision labels, deployment-receipt consistency, actual schema ledger, modes, workers, maintenance state, API/readiness and observed UI. A 200 response alone is not a revision/receipt/history proof. Do not fabricate a live review for verification. Record an installed human save-to-next as unobserved if no legitimate user review occurs, while retaining disposable assembly evidence.

## Evidence locations already provided by source

- Runner scenario reports: `test-results/performance/postgres-scenarios-<mode>-<project>.json` or explicit `TEMPO_TEST_TIMING_DIR`.
- Browser output directory: runner selects `test-results/browser-postgres-<pid>`; Playwright retains traces/screenshots on failure.
- Docker ownership/cleanup record: `test-results/tempo-cli/<project>/ownership.json`.
- Existing native selector writes `test-results/native/<project>.json`; E00 should preserve the current mechanism and bind new selected case evidence honestly.
- Current audit progress: `tempo-low-fruit-20261112/progress/merge-review.json`, baseline `40172873fdf5d134a35b872b24858917287cb81e`, accepted source reviewed through `b679496e257bc8b72d6a99e38235d5d502c1dd27` at packet preparation.

Keep secrets/DSNs with embedded credentials out of saved evidence and PR text. Use existing reports plus one compact human-readable release result; no new receipt platform is needed.
