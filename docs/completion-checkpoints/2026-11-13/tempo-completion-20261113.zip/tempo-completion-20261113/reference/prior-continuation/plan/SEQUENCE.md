# Sequence and release checkpoints

This is an event-driven work queue for one active integration session, not seven simultaneous teams or a new orchestration service. Read `tasks.json` for each task's exact predecessor and scope; each Creator prompt owns its detailed acceptance. A predecessor becoming usable means its reviewed interface/branch is released when that is permitted, not necessarily that it has already merged. The owner records the actual dependency SHA and file release.

## Start the owner first

Refresh main, the four held PRs, existing progress and actual host capability. Establish one integration candidate and shared-file owner. Inspect the registered Mac early enough to identify a real schema/host blocker without touching it as a development workspace.

Release E00 first: the existing native rollback case needs an honest runner entry, genuine pytest environment and owned `tempo_position_test_*` database. It is the most direct prerequisite for qualifying already-written code. In another isolated coding slot, start A01/A02 or F01. B01 can follow immediately when a slot is free. These do not depend on the pending product changes.

The owner begins Q0 planning and finite browser-fixture/assertion preparation while E00 is built. Avoid overlapping edits to the runner, its options/plan/actions or inventories. Q0 can incorporate E00's reviewed branch alongside #992 before either merges. Requiring E00 to merge before the only proof that lets #992 merge would create a needless cycle.

## Checkpoint 1 — Complete the held release

Build one explicit candidate from current main, the actual #991/#992/#993/#995 heads, and only the necessary reviewed runner/browser repairs. Do not continually absorb new independent code into a running proof. Freeze candidate input identities while it runs.

Q0 covers the actual native late rollback/replay case, opening save-to-playable-next, position first-response/reload/offline, malformed/foreign receipts, combined integrity repair and minimal Game Review with no Study writes. Existing unit/type/guard evidence is reused only when its inputs still match. New fixture or product repairs receive their focused proof and review.

After applicable acceptance and review, merge in actual dependency order, using expected-head guards. The default product order is #991, #992, then the #993/#995 acceptance cohort; place supporting PRs where their source dependencies permit. A combined proof can qualify multiple PRs. Compare the merged result's relevant source/build/test inputs with the tested candidate; unrelated merge metadata alone does not invalidate the evidence.

Install the exact accepted merged release on the verified registered Mac when applicable gates and access are ready. Current source requires schema 65. Actual installed state controls whether E04 must prove a missing transition. F02 lifecycle code is outside this first release unless its separate applicable proof is complete. Preserve a short main merge freeze while the CLI selects/builds the intended release. Record genuine installed identity and functional observations separately from disposable acceptance.

Record `Q0_SOURCE_ACCEPTED`, `Q0_HARNESS_RELEASED`, `Q0_MERGED` and `Q0_INSTALLED` as separate events. E04 may start from a released qualified source candidate/harness before installation; if it is needed for that installation, it must not wait for `Q0_INSTALLED`. E04 may likewise consume F02's reviewed source branch before F02 merges. These distinctions prevent a qualification/merge/install dependency cycle.

If Mac access is unavailable, source merging can still finish when source acceptance passes. Record installation as blocked with its exact next capable operator, and continue independent ready work. Do not stop all source work to ask again for installation permission.

## Checkpoint 2 — Small independent improvements

As Q0 releases source and test ownership, the following work becomes available:

| Stream | Next useful work | Actual dependency |
| --- | --- | --- |
| A | A01 backend/learning guides; A02 storage/current-versus-historical guides | Current source; a small follow-up for later released interface facts |
| B | B01 proven-unused private aliases; B02 shared six-counter observation policy | B01 independent; B02 needs released checkpoint from #992 and card-deletion region |
| C | C01 initial queue acknowledgement through the canonical protocol boundary | Accepted/released #993 and its relevant recovery tests |
| D | D01 unused retired endpoint adapters; D02 compatibility classification | Q0 releases frontend shared tests; classification precedes any held-record change |
| E | E01 the six stale retained-import failures and four related static guards; E02 current Study native proof; E03 packaged read-only Game Review proof | Selected current contracts; E02 uses E00 and released #992; E03 uses Q0's valid Game Review case |
| F | F01 remove the uncalled Rust UCI constructor and newly dead helpers | Current caller/public-surface check and scoped Rust proof |

The owner can merge A/B01/F01 independently as soon as their actual acceptance is complete; they need not wait for a release checkpoint meeting. E proof cleanup is case-by-case: rebind retained behavior, retire exclusively removed behavior with source evidence, and leave unrelated failing proof recorded. Do not remove a mixed file or xfail a current requirement merely to get green.

C01 changes queue acquisition and B02 changes an active observation consumer, so the next release selects the affected assembled journey on the new integrated inputs. Reuse Q0's harness and valid unaffected evidence; create fresh task-owned resources when needed. D02's finite investigation is useful even if the implementation remains blocked by a real compatibility ambiguity.

Install the accepted coherent cleanup release when it is useful and ready. If the next scheduling slice is already ready for the same freeze and does not enlarge the proof unnecessarily, combine the checkpoints. Do not delay a useful qualified update solely to collect every possible task.

## Checkpoint 3 — Scheduling and bounded state boundaries

B03 moves fresh-position initialization into the existing scheduling owner while leaving allocation, fences and insertion in storage. It needs the E00 native environment and its exact introduction case registered by E/owner. G00's current clock map and G01's pure calendar/replay work can be prepared independently; G02's edits to `position_queue_admission.py` wait for B03 to release that file. Calendar consumer adoption then proceeds through G02/G03, followed by G04's native and assembled acceptance.

Use explicit configured-zone cases near midnight and DST. Preserve the currently declared local/unknown-zone fallback until the contract is actually changed; do not replace an implicit global clock with a new ambient global. Calendar code is one authority for the existing policy, not a new scheduler or a reason to rewrite historical event times.

Three conditional continuations can use separate source slots while this proceeds:

- **C02/C03:** one semantic retained-authority storage port, then a factory independent of default browser composition, only if the initial bounded map supports that scope. Stop at a real expansion into journals, migrations or multiple composition roots.
- **D02 implementation/D03:** preserve supported frozen exercises and hold only demonstrably retired work; adopt or retire the dual-runtime grader only after current support and stored-record compatibility are established. A missing public owner is a concrete product gap, not a license to resurrect standalone Studies.
- **F02/E04:** share the migration witness rule only with its applicable lifecycle proof. Prefer releasing F02 when the necessary lifecycle proof already exists or E04 is independently needed for the actual installation. A short extraction alone is a weak reason to buy a new 6–16 hour lifecycle-harness project. Keep it out of otherwise ready releases until qualified.

The owner selects one coordinated native/browser acceptance for the actual combined release and installs after merge. A lifecycle run may need its own admitted lifetime; it is not automatically the same scenario as product browser proof. Every heavy run has one owner and a finite selection.

## Parallelism that is safe and worthwhile

With four available agent slots, default to **owner + two implementers + one rotating reviewer**. A third implementer can temporarily replace the reviewer until a slice is ready. Do not launch seven Creators each with their own Manager/Worker/Guardian hierarchy. Use logical packet assignments and resume a packet when a slot frees.

| Moment | Implementer slot 1 | Implementer slot 2 | Owner/reviewer responsibility |
| --- | --- | --- | --- |
| Opening | E00 native bridge | A guides or F01 Rust | Q0 source/host reconciliation; review first completed slice |
| Q0 running | Source-only A/B01/F01 work with disjoint inputs | Next cheap independent slice | One admitted qualification owner; no edits to active candidate |
| Q0 source released | B02 or E01/E02 | C01 or D01 | Review, shared inventories and next assembled selection |
| Scheduling tranche | B03 then G consumer adoption | G pure prep, or C02/D02 when released | Serialize native resources; preserve shared admission ownership |
| Conditional lifecycle | E04 proof owner | Independent source-only task | F02 follows only when proof/paths are released |

Actual host capacity and task reservations override this example. Separate worktrees/build outputs and one writer per reserved file keep concurrency real. A stopped or completed Creator does not retain a slot merely to wait. The integration owner can absorb a tiny edit when delegation costs more than it saves.

## Effort and completion expectations

Estimates in the task table are focused implementation/review time, not elapsed guarantees. This is a multi-session tranche. The cleanest leaf changes are roughly 45 minutes to 4 hours each; the calendar work is about 12–24 focused engineering hours, and a genuinely missing current lifecycle path may add 6–16 hours plus native execution. Q0's host/runner/fixture work and native builds dominate uncertainty. Parallelism overlaps independent source work; it cannot remove a real acceptance or migration prerequisite. Do not promise an installation date from source inspection or sum overlapping task estimates as elapsed time.

The already-implemented cohort has five plausible additional full closures after its missing acceptance: BE006, BE016, ST009, FE007 and FE011. FE001 and FE008 remain residual work. A/F01/C01/B03/G add six further full-closure candidates. C02/C03, D02/D03 and F02 are conditional candidates, while B01/B02 and E deliberately make bounded partial progress. These are planning judgments; original acceptance decides the actual status.

## After this tranche

Finish B04's bounded reachability map and `AFTER-THIS-TRANCHE.md`'s next recommendations. `finding-dispositions.csv` accounts for all 55 families with their original acceptance and the current next action. That map is not authorization to implement every deferred family. Stop or hand off the next concrete slice instead of beginning a repository-wide ownership rewrite.
