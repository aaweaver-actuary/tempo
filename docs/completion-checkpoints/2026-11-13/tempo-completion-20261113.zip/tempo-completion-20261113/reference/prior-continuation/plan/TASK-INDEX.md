# Task index

These are planned actions, not completed work. Open the matching prompt for exact scope and acceptance. Source, merge and install events are separate.

| Task | Owner | Outcome | Start after | Estimated focused hours |
| --- | --- | --- | --- | --- |
| Q0 | Integration / designated qualification operator | Qualify the four held PRs, merge accepted source and install the release | OWNER_ASSIGNED | Host/fixture dependent |
| A01 | A | Repair current backend/Learning owner guides | OWNER_ASSIGNED | 2–4 |
| A02 | A | Reconcile storage owner guides and historical indexes | OWNER_ASSIGNED | 2–4 |
| B01 | B | Remove proven-unused private import/re-export aliases | OWNER_ASSIGNED | 0.5–2 |
| B02 | B | Share pure six-counter observation contribution policy | Q0_BACKEND_FILES_RELEASED, B01_PRIVATE_ALIASES_REVIEWED | 1.5–4 |
| B03 | B | Move fresh position FSRS state policy to scheduling owner | Q0_BACKEND_FILES_RELEASED, E00_NATIVE_BRIDGE_REVIEWED | 4–8 |
| B04 | B | Time-box bulk queue / unused Protocol reachability probe | B01_PRIVATE_ALIASES_REVIEWED | 1–1.5 |
| E00 | E | Bridge exact native grade-effects pytest into owned runner | OWNER_ASSIGNED | 2–6 |
| E01 | E | Classify/rebind six stale retained-import regression cases | E00_NATIVE_BRIDGE_REVIEWED | 1–3 |
| E02 | E | Restore selected current Study queue/save proof stages | E00_NATIVE_BRIDGE_REVIEWED, OWNER_RUNNER_FILES_RELEASED | 3–8 |
| E03 | E | Rebind packaged reader proof to minimal read-only Game Review | E00_NATIVE_BRIDGE_REVIEWED, OWNER_RUNNER_FILES_RELEASED | 2–6 |
| E04 | E | Conditionally add applicable current lifecycle proof | OWNER_CURRENT_LIFECYCLE_REQUIREMENT, Q0_HARNESS_RELEASED_OR_EXPLICIT_CANDIDATE_HANDOFF | 6–16 |
| G00 | G | Map actual Study day authorities and capture boundaries | OWNER_ASSIGNED | 1–2 |
| G01 | G | Unify pure conversion and review/replay context | G00_CALLSITE_MAP, Q0_BACKEND_FILES_RELEASED | 3–5 |
| G02 | G | Propagate captured day through active Study/Tactics/queue | G01_POLICY_REVIEWED, B03_INITIAL_STATE_REVIEWED, B01_PRIVATE_ALIASES_REVIEWED | 4–8 |
| G03 | G | Adopt context in authoring follow-ups/startup/maintenance | G01_POLICY_REVIEWED, G02_COMMANDS_REVIEWED, B02_COUNTS_REVIEWED | 4–8 |
| G04 | G | Qualify complete calendar adoption on native/assembled candidate | G02_COMMANDS_REVIEWED, G03_CALLERS_REVIEWED, OWNER_HEAVY_RESOURCE_LEASE | 1–3 |
| C01 | C | Canonical initial queue-issuance acknowledgment | Q0_FRONTEND_FILES_RELEASED | 1–3 |
| C02 | C | Typed retained-authority facts behind existing browser storage adapter | C01_ACK_REVIEWED, Q0_FRONTEND_FILES_RELEASED, OWNER_C02_SCOPE_RELEASED | 3–6 |
| C03 | C | Separate factory import from default browser composition | C02_AUTHORITY_FACTS_REVIEWED, OWNER_C03_SCOPE_RELEASED | 2–5 |
| D01 | D | Remove dead games-summary/endgame workspace adapters and rebind retained tests | Q0_FRONTEND_FILES_RELEASED | 1–3 |
| D02 | D | Classify and repair retained authored-exercise compatibility | Q0_FRONTEND_FILES_RELEASED | 3–6 |
| D03 | D | Versioned TS/Python retained grader parity or demonstrated retirement | D02_COMPATIBILITY_CLASSIFIED, D02_OFFLINE_FILES_RELEASED, OWNER_RETAINED_GRADER_SCOPE_RELEASED | 3–6 |
| F01 | F | Delete unused Rust UCI validator duplicate | OWNER_ASSIGNED | 0.75–2 |
| F02 | F | Share exact migration witness policy in existing owner | OWNER_F02_SCOPE_RELEASED | 0.75–2 |

Estimates exclude resource waits and any newly discovered gate; several tasks are conditional or read-only. Do not add all rows to estimate elapsed time. File claims are in `ownership.csv`; raw source analyses are under `reference/`.
