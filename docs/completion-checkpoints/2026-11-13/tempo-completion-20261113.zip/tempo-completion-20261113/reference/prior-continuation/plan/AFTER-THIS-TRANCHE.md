# Subsequent work: keep choosing the next small supported boundary

The current packet authorizes the enumerated tasks and their explicit conditional branches. This file is the ordered recommendation for work left afterward. It does not silently dispatch all remaining audit findings. The owner records what the actual tranche changed, then uses the source and original acceptance to choose the next finite assignment.

## 1. Close the gaps exposed by the delivered slices

Complete a concrete failed acceptance before polishing unrelated architecture. Likely examples are a supported frozen-exercise public-owner gap found by D02, a native fixture that E proved belongs to a retained journey, or an installed capability handoff that blocked the qualified release. Keep the exact original records and behavior while resolving it. A new product-support choice needs a concise decision; an ordinary in-scope implementation choice does not need renewed authorization.

## 2. Prefer demonstrated deletions and one real consumer

Use B04's reachability evidence for BE001 bulk queue entrypoints and BE013 unused position Protocol declarations. A truly unused alternate entrypoint can be deleted without moving the shared eligibility/reset helpers that active workers still use. A dead Protocol can be removed as a truthful declaration cleanup, but that does not prove a substitutable actual interface. The next interface task should name one production consumer, one semantic result and one independent fake plus the applicable adapter conformance proof.

Follow BE005's remaining private imports by migrating one live capability at a time, with all real tests/monkeypatch consumers accounted for. Renaming a SQL fragment public does not fix its ownership. ST002/ST005 source preparation, introduction and grade results need sealed/semantic values without leaking cursors, rows or forgeable authority. Prefer an existing owner and a small callable/data contract.

## 3. Resolve browser composition in consumer order

After C's authority port/factory work, choose a concrete dependency edge from FE003/FE004/FE006/FE010 or ST003/ST004. The likely sequence is explicit adapter composition, semantic retained-work facts, then one delivery/journal contract. Keep distinct durable business journals. Request success and transaction commit are different; real IndexedDB retention/reload proof belongs to the touched transaction boundary. Avoid a new global facade or a single universal workflow store.

FE002's two live board renderers require behavior-preserving migration of actual consumers, including drag, drawing, keyboard, hints, orientation and sound. A type alias or a renderer swap is insufficient. It can become a separate frontend task once shared UI ownership is free; it is not a dependency of calendar or storage work.

## 4. Move policy only with its real transaction contract

BE007/BE008 domain errors and opaque review results should expose named conflict/hold/unavailable outcomes while preserving the current wire and durable receipt contract. BE009 explicit command registration must account for persisted names and recovery consumers and keep optional startup independent. BE010 Tactics effects and the remaining BE011 purge authority need Study-owned semantic capabilities plus native atomic/replay proof. BE012 reset/preserve/split behavior, BE018 retained Coverage inputs, ST006 driver-dependent behavior and ST014 abandonment are distinct stateful contracts, not import cleanup.

For each, name the one transition, writer, preserved identity/lock order, current consumer and finite negative case. Do not combine unrelated transaction migrations or introduce a generic repository framework to hide the current concrete APIs. BE019 legality/own-response consolidation should first compare actual accepted inputs and deterministic results; legitimate implementations in separate runtimes do not automatically become one service.

## 5. Make enforcement reflect owners that actually exist

RT002/RT003/RT004 should follow defended current interfaces. Extend the existing owner/build/export map and import controls for one current component, prove a real forbidden edge is rejected while legitimate composition still works, then narrow qualification selection for genuinely pure changes. Do not flip manifest labels or remove native gates to make the architecture appear complete. Unknown ownership remains explicit.

## Explicit decisions that stay visible

BE015 lower-level review support, FE012 offline/demo projection support, FE013 the scheduling public abstraction and ST011 independent Rust fixture packaging are still decision candidates. Resolve them from current product intent and actual consumers first. Retaining an intentional boundary is a valid outcome when its contract and rationale are explicit. These are not four automatically required rewrites.

Every subsequent assignment should state: observable outcome, exact owner/consumers, released paths, preservation rules, finite proof, merge/install authority and stop condition. Use the existing ledger rather than accumulating competing plans.
