# Explicit authority for this continuation

This is the execution authority Andy requested on November 12, 2026 for the coordinated qualification and substantial next tranche in this packet. It applies when an agent receives this packet as its assignment. It supplies the user authorization that older generic repository instructions require for consequential delivery; it does not manufacture credentials, host access, or platform approvals.

## All assigned Creators

You are authorized to inspect the current source and PRs; create isolated task branches/worktrees; implement the released scope and its necessary bounded repairs; install normal project development dependencies in the task environment; run the selected component/native/browser checks on verified disposable resources; commit; push your scoped branch to `aaweaver-actuary/tempo`; open or update its PR; publish the technical PR review/evidence comments required for this delivery; and address review findings. Assigned reviewers may submit those scoped reviews. Publish a useful draft with an honest blocker when acceptance is incomplete. Do not stop to ask whether you may push.

Use the existing authenticated GitHub tool or CLI that actually works. In the preparing cloud environment, Git reads worked, shell push lacked credentials, and the GitHub connector could publish and merge. That observation is not a promise about your host. Use an available supported authenticated route; do not expose or invent credentials, weaken an access restriction, or rewrite another owner's branch. Use expected-head/reference guards and ordinary non-force pushes.

You may merge your scoped PR only when its applicable acceptance and review are complete **and the integration owner releases that exact PR/head for merge**. This release is coordination of the already-authorized action, not another request for Andy's permission. The owner may delegate the merge to you or perform it. A draft, reported test count, absent CI run, or clean conflict status alone is insufficient.

You may install on the registered local machine only when the integration owner explicitly assigns you the local-operator role for an accepted release checkpoint. At that point the installation authority below applies directly; do not ask Andy to approve the same installation again. Otherwise hand off the scoped result without operating the live installation.

## Integration owner

You are authorized to start first; dispatch and resume A–G or narrower workers; assign a reviewer; choose ready work within the task graph; reserve and release shared files/resources; make bounded integration and proof-fixture repairs; push integration/support branches; open or update PRs; mark accepted drafts ready; and merge accepted scoped PRs into `main` in dependency order. Use independent technical review proportionately and include the architecture look in that same review. No extra universal Guardian receipt is required.

You may merge a coherent accepted subset while other independent work is blocked. You may reorder independent slices or combine very small compatible slices when this reduces coordination cost without obscuring their acceptance. A change to the actual product behavior or a newly discovered dependency must be explicit in the existing ledger and relevant PR. You may not quietly transform a conditional probe into a large new architecture programme.

You are also authorized to update the existing root audit HTML/workbook and the existing progress records after accepted changes. Record completed, partial and still-pending acceptance separately. Do not replace historical audit facts or mark an unmerged branch as fixed on main.

## Registered-Mac installation operator

The integration owner or its explicitly designated operator is authorized, once the applicable acceptance and merge are complete, to install the exact accepted merged release on Andy's verified registered local Tempo installation. This includes the ordinary supported CLI update/install workflow, building and selecting immutable images, the necessary scoped service stop/restart, and supported required forward migrations with normal backup and recovery safeguards. Use `--no-ci` when hosted CI remains unavailable, as already approved; record that state honestly. This option selects current main, so coordinate a short merge freeze and verify the accepted full main SHA immediately before starting and the actually installed SHA afterward. An arbitrary accepted but unmerged branch is not this release checkpoint.

Quiesce gracefully when necessary while retaining every active issued attempt, unsent/sent journal and durable receipt. Do not force abandonment or forge completion to obtain a clean maintenance window.

Verify the registration, checkout, Docker context/daemon, persistent volume identity, browser origin, installed schema, source/image identities, worker configuration and active modes before changing the live target. `/Users/andy/tempo` is a historical location, not a target-discovery shortcut. Never install into the preparing cloud checkout and call that the local installation.

Current source requires schema 65. Read the actual installed schema and current runner policy. The historical `current63` lifecycle profile does not prove a transition to 65. If a new transition is needed, qualify the actual supported transition through the bounded lifecycle task before installation. If the target is already on the required schema and the selected release does not change lifecycle behavior, apply the ordinary relevant update gates; do not invent a migration campaign. Changes to the lifecycle implementation itself may require additional lifecycle proof even without a schema bump.

Keep current modes and retained data. This authority does not include purging live volumes, deleting uncertain retained rows/journals, resetting learning history, fabricating human reviews, enabling retired/optional features, force-pushing main, bypassing repository checks, or using an older image as an assumed database rollback. Disposable synthetic tests must never target the live database. On the installed product, use non-mutating health/identity/queue checks and genuine user interaction for any human review evidence; report a remaining human acceptance step honestly.

## Capability failures and genuine decisions

Do all safe available work. A missing Docker daemon, Mac connection, token scope, browser capability, or denied host execution is an execution blocker, not missing user consent and not a product-test failure. Name the exact blocked command/action, observed error, missing capability and next capable operator. Continue independent ready work. Request only a real credential/host handoff or newly out-of-scope decision if it cannot be resolved from current instructions. Do not ask a broad “may I push/merge/install?” question when this authority already covers it.

If a platform approval is actually required, use its supported approval process. If automatic approval review rejects an action, report the rejected action and reason; try only a materially safer supported alternative. This document does not override system/tool controls. Never claim a pass, merge or installation merely because the permission exists.
