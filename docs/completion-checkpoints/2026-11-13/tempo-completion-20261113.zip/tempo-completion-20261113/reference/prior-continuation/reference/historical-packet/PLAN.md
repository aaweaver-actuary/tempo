# Tempo: low-hanging-fruit implementation plan

Prepared November 12, 2026. Status: **planning complete; implementation not started by this packet author.**

## Recommendation

Start four independent Creator streams: **A — Current catalog, guards and guides; B — Small backend consolidations; C — Browser keys and receipt handling; D — Game Review and UI dependencies.** Give each a separate worktree and a finite packet. Add **E — Maintained proof restoration** when a worker slot is available; E can investigate and fix its own selected lane immediately. **F — Isolated duplicate helpers** is optional. **G — Study calendar** is a queued follow-up, not part of the initial quick batch.

Use one integration owner for shared files, combined proof and audit updates. This is an additional responsibility, not a reason to keep another full agent hierarchy running. An existing Creator can assume it after finishing its initial slice. Creators are independent launch points; they do not launch one another or overwrite another stream's work.

The easiest complete fix is **RT006**, a stale component guide: approximately 20–45 focused minutes. The best first executable fix is **BE020**, the current contract catalog's deleted-package references: an existing checker supplies a concrete failing baseline. The smallest useful source deletions are **BE017** and **ST008**, approximately 30–90 minutes each after confirming current callers. The smallest complete frontend seam is **ST009**, approximately 45–90 minutes while preserving all existing key bytes.

My planning range for the first bounded batch is **6–10 fully closed families**, plus partial receipt, dependency and proof improvements. Ten plausible initial closures comprise A's five families, B's first three, ST009 and FE011. This is an estimate, not a promised pass count: repaired guards can expose real violations, artifact runtimes may be unavailable, and current test fixtures may fail for independent reasons. FE007 may add another closure if current reachability supports removing its obsolete adapter. BE006, BE016 and full FE001 require their complete applicable proof before closure.

## Verified starting point

- The audit's source baseline is [40172873fdf5d134a35b872b24858917287cb81e](https://github.com/aaweaver-actuary/tempo/tree/40172873fdf5d134a35b872b24858917287cb81e).
- Published `main` was checked at [a2e877d908309544eafee908c7e537149c22d169](https://github.com/aaweaver-actuary/tempo/commit/a2e877d908309544eafee908c7e537149c22d169). Its only changes from the audit are the root `tempo-architecture-audit.html` and `tempo-architecture-registry.xlsx`.
- Both committed artifacts match the audited local files byte for byte. The product source is unchanged.
- The complete registry has 55 families: 51 confirmed source mismatches and four decisions. The plan maps all 55 to an immediate, optional, partial, queued or deferred disposition.
- This packet does not establish installed recovery. No product source edit, product test, merge, restart, migration or installation occurred during planning.

Reconcile against actual current main and active local work at launch. Earlier PRs and audit claims are evidence, not automatic assignments. The latest published PR scan did not establish whether any unpublished local cleanup is active.

## Packets and first assignments

| Creator | First task | Continue within the packet | Closure expectation | Planning effort |
| --- | --- | --- | --- | --- |
| **A** | A0: correct the component guide; A1 is the first executable priority | Contract catalog/consumer qualification; scheduling import guard; current backend/database guides | Up to five complete families: RT006, BE020, RT001, BE022, ST010 | 4–12 focused worker/review hours across the stream |
| **B** | B01: remove unused duplicate request envelopes, keeping `studies.py` ownership | B02 prune uncalled authoring SQL; B03 pure snapshot exception; B05 shared maturity augmentation; B06 pure receipt codec | First three can close independently. BE006 and BE016 retain their integrated-proof obligations | First three 2–6 h combined; B05 1–3 h; B06 2–4 h plus qualification |
| **C** | C0: move physical browser key encoding into existing adapters | C1 four early-clear receipt consumers; C2 seven ordinary consumers; C3 specialized PGN/integrity/annotation paths | ST009 can close first. FE001 stays partial until every relevant interpreter is resolved | C0 45–90 min; C1 1.5–3 h; remaining batches 4–8 h plus transport/browser proof |
| **D** | D1: independently importable current Game Review decoder, or D2 for the fastest type-only change | Public board value types; conditional obsolete adapter removal; optional orphan evidence fetch removal | FE011 complete; FE007 conditional complete; FE008 partial only | D1 2–4 h; D2 30–60 min; D3 45–120 min; D4 45–90 min |
| **E** | E0/E1: restore one currently selected retained Study proof lane | E1b position codec native proof after B06; E2 current minimal Game Review proof | Partial BE021/ST012/ST013. A working lane is the result; clearing all static rows is a different project | Roughly 5–14 h for initial selected source/fixture work, plus native execution; low confidence |
| **F — optional** | F01: delete unused Rust validation body | F02: one shared migration witness rule, unchanged semantics | ST007 and RT005 may close separately | 30–90 min each to edit/review; toolchain/lifecycle qualification extra |
| **G — queued** | Define one captured Study-day context after affected B files are released | Active Study/tactic entrypoints, mutations, startup and replay compatibility | BE003, only after complete caller adoption and day/replay proof | Approximately 1–2 focused engineering days plus native/assembled availability |

Estimates assume compatible dependencies and a prepared worktree. They are active engineering/review effort, not elapsed time, model benchmarks or promised completion times. Do not add them and divide by creator count: shared qualification, integration and unknown baseline failures limit parallel speedup.

### Fast first checkpoint

Ask A to finish A0/A1, B to finish B01/B02/B03, C to finish C0/C1, and D to finish D1/D2. These are stopping checkpoints, not new approval gates. Review the completed slices and continue the packet's remaining bounded tasks when they are ready. If a later task is blocked, finish and hand off independent earlier work rather than enlarging scope.

## What can actually run in parallel

**A, B, C and D have separate product/test write ownership.** Their exact path reservations are in `ownership.csv` and the individual prompts. Do not treat shared read access as a write conflict. The plan explicitly reserves B's contract-identity test and Python snapshot package, C's receipt protocol and journals, D's Game Review/board-value tests, and A's scheduling guard and current documentation.

E's source triage, selected fixture corrections and supported native execution do **not** have a blanket dependency on A. A catalog correction is a prerequisite only if the particular selected build/gate actually consumes it. `make preflight` checks environment capabilities; it does not itself depend on the public contract catalog.

| Relationship | Type | Practical rule |
| --- | --- | --- |
| A1 catalog → A0 contract-example verification | Conditional verification dependency | Use existing scheduling/chess-line examples immediately, or verify contract examples after the relevant catalog correction. A0 prose need not wait. |
| C1 → C2 → C3 | Real implementation/adoption dependency | Establish one decoder-adoption pattern before migrating the next consumers. C0 is independently useful and only recommended first. |
| D2 + D3 → full FE007 closure | Coverage dependency | Type import repair alone is partial; the reverse analysis-adapter edge must also be retired or corrected. |
| B06 → E1b | Real released-capability dependency | Native grade/replay proof adopts B's actual codec; a plan or empty facade is insufficient. E0/E1/E2 can proceed independently. |
| B06 consumer proof + E1b + position browser journey → full BE016 qualification | Evidence dependency | Pure codec tests cannot prove the actual issued-plan/grade path. Earlier B tasks remain independently deliverable. |
| B05 → G's reconciliation edits | File handoff | Wait for the specific reconciliation patch to land/release ownership; G need not wait for unrelated B tasks. |
| B01 → a later FE009 grading task | File/contract dependency | Both touch the Python exercise contract. FE009 also needs the retained-feature support decision. It is deferred here. |
| C authoring receipts → later BE018 retirement | File handoff | `analysis-paste-command.ts` and `branch-command.ts` belong to C while receipt adoption is in progress. |
| C3 + D4 → combined integrity UI proof | Integration ordering | Separate files can be edited concurrently; check the combined UI/outbox behavior after adoption. |
| All native/browser/lifecycle runs | Shared resource constraint | Use one heavy-run owner on the shared host unless genuinely independent capacity is verified. This is not a source dependency. |
| Every accepted slice → root audit refresh | Shared artifact constraint | Only the integration owner writes the common report/workbook. Other creators submit deltas. |

F has no product-source dependency on A–D. Its lifecycle-sensitive files can still trigger costly current qualification. Skip or queue F when proof cost makes it a poor immediate return; do not weaken the classifier to manufacture a cheap pass.

## Several creators without several competing managers

Each Creator owns one packet and its worktree/branch. It performs the Manager responsibility itself or delegates to one Manager when useful; add a Coordinator only when the work actually warrants another layer. A bounded worker plus a reviewer reused at a later checkpoint is usually enough. Preserve the current Creator/Manager/Coordinator/Worker terminology without keeping every role resident for a one-file change.

The integration owner controls shared-file adoption, integration order, the combined user journey and registry updates. It does not take over all implementation. Use the existing PR/work ledger for branch and review facts; the audit registry tracks architectural status. No new service, lease system, governance database or mandatory Guardian receipt is needed.

Actual concurrency limits apply across whatever scope the host enforces. Four packets being independent does not grant four full worker teams. If the available environment has four total active-agent slots, budget the active Creators/workers/reviewer within four, or run fewer Creators at once. A Creator may perform a bounded task directly when spawning is unavailable. Separate worktrees must not share mutable package `dist`, generated WASM or build-output directories. Shared caches are safe only when their actual tools support concurrent use.

Recommended launch choices:

- **Two implementation slots:** A and B first; replace the first finished slot with C, then D.
- **Four genuinely available independent slots:** A, B, C and D. Add E by reusing the first finished slot, or earlier if capacity exists.
- **One admitted heavy-run slot:** reserve it through the existing delivery owner. Component work continues while the heavy run is occupied.
- **Quota-sensitive option:** A0/A1, B01/B02, C0 and D2 are the smallest useful checkpoints. Do not launch the whole 55-finding backlog.

Creators should finish in reviewable commits or PRs under the authority of their actual session. This plan creates no merge/install authority. Honor any valid existing explicit authority for the actual selected changes; do not re-ask for routine reversible actions already authorized. A scoped launch is not permission to absorb unrelated historical PRs or operate the live installation.

## Keep the audit current without losing its provenance

The original finding evidence remains pinned to `40172873`. New completion evidence records the actual implementation and verification revision separately. Never rewrite every baseline source link to a newer SHA merely because one finding was fixed.

Use the **existing JSON embedded in the root HTML** as the current structured registry unless the integration owner deliberately extracts it once into `tempo-architecture-registry.json`. If extracted, that single JSON becomes authoritative and the HTML/workbook become generated views. Do not maintain two independently editable structured masters.

Each Creator submits a small proposed progress delta in its own branch at `tempo-low-fruit-20261112/progress/<CREATOR>.json`. The integration owner reviews and incorporates it when the corresponding change is accepted. These files are handoffs, not separate authoritative trackers. A schema/example is in `progress/TEMPLATE.json`.

For every finding update retain: finding ID, scoped task, actual code revision, observed checks and results, implementation stage, full versus partial scope, remaining files/conditions, and requested registry status. A partial receipt migration cannot close FE001; one fixed native file cannot close ST012/ST013; type-only board imports do not close FE002; a new interface declaration does not close BE013.

At each accepted integration checkpoint the single updater:

1. Applies the accepted status/assignee/evidence fields to the authoritative structured record, preserving original evidence and acceptance text.
2. Updates the root HTML finding statuses and the workbook's matching Findings rows. Preserve file/coverage evidence sheets. Align the workbook Status dropdown with the chosen shared vocabulary; the original dropdown has only Open, Needs decision, Planned, In progress, Deferred and Resolved. Regenerate the reports or patch the actual named fields using appropriate file tools; never manually reconcile binary workbooks from multiple branches.
3. Labels the old 55-family/51-confirmed counts and architectural verdict as the **audit baseline**, and shows a separate current progress summary with its reviewed-through revision. Closed findings remain in the historical registry.
4. Records full closures, partial progress, pending verification and decisions separately. “Implemented”, “component-tested”, “assembled-demonstrated”, “merge-qualified” and “installed” remain distinct. A main-branch registry must not call a finding closed based solely on an unmerged branch; record that as verified on branch until the corresponding implementation is integrated at the revision the registry describes.

This small update loop is sufficient. Do not build a dashboard or audit automation framework before the first correction. The integration packet includes the exact extraction entry point and column names, so workers do not need to reverse-engineer the files.

## Qualification and stop conditions

Use the focused commands in each packet. Discovery (`--list`), collection, syntax checking, mocked tests, native tests and browser journeys are different evidence. The author ran source/plan checks only, not the listed product tests.

For code changes, include the proportional Guardian-like diff review already described by current `AGENTS.md`. Reuse the independent technical reviewer for it. Documentation-only changes need no automatic architecture ceremony. The point is to catch new coupling or changed semantics, not create a universal approval receipt.

E1b specifically uses `database/tests/position_study/test_position_grade_effects.py::test_native_two_decisions_and_late_failure_rollback` after B06. It needs a real task-owned `TEMPO_POSITION_TEST_DSN` and a non-skipped pass. B owns the narrowly affected issued-plan consumer test. The supported position browser journey is `make ui-file FILE=position-study-acceptance.spec.ts`; its retained first-wrong/reload/offline case is the relevant integrated behavior. These proof requirements do not hold unrelated A/B/C/D changes hostage.

Current lifecycle classification can make a tiny `scripts/` or `database/` change expensive to merge. Report that cost honestly and reuse valid evidence only when its actual source/dependency/fixture/environment inputs permit reuse. Do not rewrite qualification policy inside the cleanup to avoid its own requirements.

## Deliberately outside the quick batch

The following remain important but need a separate cohesive design/adoption slice: whole Study facade/store composition (FE003–FE006), raw storage APIs across 60 modules (ST005), real position ports (BE013), active board lifecycle consolidation (FE002), retained bulk queue retirement (BE001), producer-to-Study write ownership, command registration/startup, and complete owner-map/CI selection repair (RT002–RT004).

The four original candidates remain explicit decisions: BE015 retained direct-review support, FE012 offline/demo projection support, FE013 intended scheduling abstraction level, and ST011 package-fixture independence. FE009's grading mismatch also needs the retained authored-Study support/recovery decision before changing accepted saved inputs. This packet does not restore removed features to satisfy obsolete tests.

G's calendar work is a useful next project, but approximately forty callsites, replay semantics, timezone/DST and daily-admission behavior make it a poor “just replace date.today” task. Its queued prompt names the boundaries and dependencies without automatically starting it.

## Packet use

Extract this bundle as `tempo-low-fruit-20261112/` under the Tempo repository root. Launch one Creator with its matching file under `prompts/`. Every prompt embeds the common constraints and its actual tasks, files, proof and closure rules; there is no dependency on access to the original chat or a personal planning application.

`00-integration-owner.txt` is the shared role. `A-current-contracts.txt`, `B-backend-seams.txt`, `C-browser-receipts.txt`, and `D-game-review-ui.txt` are ready starting scopes. `E-maintained-proofs.txt` is a bounded proof stream with a B06-dependent subtask. `F-isolated-duplicates.txt` is optional. `G-study-calendar-queued.txt` is a queued follow-up.

The detailed task inventory, exact path reservations, original-source references and all-family dispositions follow in the accompanying CSV/JSON files and prompts. New source findings are recorded as residual work rather than silently added to this finite assignment.

## All 55 finding dispositions

| ID | Packet | Disposition | Finding |
| --- | --- | --- | --- |
| BE001 | Later / decision owner | Deferred | Retained bulk queue materialization competes with the active phased refresh implementation |
| BE002 | Later / decision owner | Deferred | Next-exercise boundary is callback-injected but its important data and capabilities remain implicit |
| BE003 | G | Queued domain project | Study calendar and day selection still have multiple active authorities |
| BE004 | Later / decision owner | Deferred | Application modules still own native SQL and PostgreSQL transaction introspection |
| BE005 | Later / decision owner | Deferred | Private storage implementation names remain a cross-owner API |
| BE006 | B | Immediate bounded task | Opening baseline maturity augmentation is duplicated in normal review and chronological replay |
| BE007 | Later / decision owner | Deferred | Domain errors and policy modules still depend on HTTP transport semantics |
| BE008 | Later / decision owner | Deferred | Learning review port exists, but its main results and schedule capabilities are still opaque dictionaries |
| BE009 | Later / decision owner | Deferred | Worker command availability still depends on eager imports and a mutable global registry |
| BE010 | Later / decision owner | Deferred | Standalone tactic attempts still write Study scheduling and queue effects directly |
| BE011 | Later / decision owner | Deferred | Repertoire deletion owns Study purge and reimplements evidence aggregation |
| BE012 | Later / decision owner | Deferred | Authored content changes clone physical card rows and independently reset or transfer learning state |
| BE013 | Later / decision owner | Deferred | Declared position-learning ports are unused and do not describe the actual implementation APIs |
| BE014 | B | Immediate bounded task | Public pure repertoire facade imports concrete storage through its snapshot exception |
| BE015 | Later / decision owner | Decision | Retained direct review entrypoint bypasses the complete submission boundary |
| BE016 | B | Prepare now; native/assembled qualification dependent | Position receipt codec is embedded in the checkpoint transaction/HTTP module, creating reverse cycles |
| BE017 | B | Immediate bounded task | Study exercise envelopes are still defined independently in two contract modules |
| BE018 | Later / decision owner | Deferred | Retained repertoire edit commands still accept Coverage inputs and query retired feature state |
| BE019 | Later / decision owner | Deferred | Repertoire own-response and legality rules have several independently maintained implementations |
| BE020 | A | Immediate bounded task | Contract catalog and qualification still require the deleted analysis-jobs package |
| BE021 | E | Partial selected scope | Backend regression and fixture files still import deleted implementations |
| BE022 | A | Immediate bounded task | Owner documentation still advertises removed public interfaces and assemblies |
| FE001 | C | Staged migration; early batches partial | Operation-receipt semantics have many live browser implementations |
| FE002 | Later / decision owner | Deferred | Two live board renderers own the same Chessground lifecycle |
| FE003 | Later / decision owner | Deferred | The Study facade still requires concrete global stores and outbox records |
| FE004 | Later / decision owner | Deferred | Study composition and queue acquisition retain domain and persistence workflows |
| FE005 | Later / decision owner | Deferred | Study client authority policy depends on concrete browser database layouts |
| FE006 | Later / decision owner | Deferred | Study delivery adapters are installed through hidden module side effects |
| FE007 | D | Immediate bounded task | Frontend domain types and an adapter depend outward on UI implementation |
| FE008 | D | Partial selected scope | Retired backend capabilities still have browser consumers and recovery paths |
| FE009 | Later / decision owner | Deferred | The retained version-1 grading contract accepts different answers across browser and server |
| FE010 | Later / decision owner | Deferred | Build mode selects separate durability lifecycles for the same Study commands |
| FE011 | D | Immediate bounded task | Game Review's wire contract is embedded in the view and unchecked at runtime |
| FE012 | Later / decision owner | Decision | Legacy offline and demo queue repetition still maintain local scheduling projections |
| FE013 | Later / decision owner | Decision | Decide whether scheduling's FSRS-shaped public API is the intended abstraction level |
| RT001 | A | Immediate bounded task | The import-linter contract still targets removed storage and feedback owners |
| RT002 | Later / decision owner | Deferred | The active selected boundary map cannot enforce the stated whole-component interface standard |
| RT003 | Later / decision owner | Deferred | There is no complete current owner/build/public-interface registry for the assembled product |
| RT004 | Later / decision owner | Deferred | Qualification selection still couples leaf presentation and package changes to broad runtime proof |
| RT005 | F | Optional isolated task | Migration-cut witness policy has two separately maintained implementations |
| RT006 | A | Immediate bounded task | Current component instructions still advertise retired contract targets |
| ST001 | Later / decision owner | Deferred | Position introduction creates scheduling state inside the persistence implementation |
| ST002 | Later / decision owner | Deferred | Position source and introduction contracts are defined by concrete storage modules |
| ST003 | Later / decision owner | Deferred | Browser persistence imports application implementations and their global runtime |
| ST004 | Later / decision owner | Deferred | Opening journal policy code receives raw IndexedDB connections |
| ST005 | Later / decision owner | Deferred | Storage extraction leaves public APIs as native rows, cursors and physical parameter shapes |
| ST006 | Later / decision owner | Deferred | Driver identity changes the semantics exercised by replacement connections and tests |
| ST007 | F | Optional isolated task | Rust retains two independent implementations of UCI line validation |
| ST008 | B | Immediate bounded task | The retired HTTP-composition authoring helpers retain competing SQL implementations |
| ST009 | C | Immediate bounded task | Browser command adapters expose physical localStorage key formats |
| ST010 | A | Immediate bounded task | Current storage documentation points at retired owners and an old schema |
| ST011 | Later / decision owner | Decision | Rust package tests depend on undeclared repository-sibling fixtures |
| ST012 | E | Partial selected scope | Native and component proof sources still depend on removed implementations |
| ST013 | E | Partial selected scope | Native proof SQL still assumes the removed compatibility translator |
| ST014 | Later / decision owner | Deferred | Queue abandonment mixes operator transport, Study policy and SQL in one storage module |

The CSV includes each original closure condition and the reason for deferral/partial scope. Deferred is a planning recommendation, not a claim that the architectural gap disappeared.
