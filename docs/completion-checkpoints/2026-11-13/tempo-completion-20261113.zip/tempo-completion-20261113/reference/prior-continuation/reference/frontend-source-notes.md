# C / D / F continuation recommendation

Planning only. This work read current source and prior result files, and wrote prompts/task metadata. It did not modify Tempo product source, run product tests, push, merge or install anything.

## Recommended sequence

1. Start the integration owner, then the qualification/native-runner owner. While Q0 is waiting for the real host, F01 is a useful independent coding slot: one demonstrably uncalled Rust duplicate, no recovery/UI dependency. Other available slots can serve A/B/G preparation rather than racing Q0's receipt tests.
2. Once Q0 releases the frontend files, C01 and D01 can run in parallel. C01 finishes the initial queue acknowledgment boundary; D01 removes unused endpoint adapter branches and preserves mixed test obligations. Their production/test reservations are disjoint. C01 needs the coordinated assembled journey because it changes queue issuance; D01 alone does not need a fresh native stack.
3. After C01, release C02 only if a short map confirms the retained-authority port is finite. C03 is a separate optional factory boundary slice, not a mandatory rewrite. These are known concrete coupling repairs, but they should not delay qualification/install of already accepted work.
4. D02 is a bounded compatibility investigation with conditional implementation. Do not blanket-retire authored Study: frozen published study_exercise cards remain selected by current queue producers. D03 grader parity is useful only if the retained support decision proves a continuing dual-runtime contract. Otherwise positive-reachability-backed retirement is simpler.
5. F02 may be implemented/reviewed/pushed independently, but its lifecycle-sensitive merge waits for the exact applicable lifecycle acceptance. Keep it off F01 and Q0's critical path.

These are workstreams, not seven concurrent teams. Current host capacity is four active agents including the owner; reviewers consume those slots. The owner must release a completed slot for review or run an explicit serial second pass if the actual session has no separate reviewer capacity. No prompt claims independent review occurred when it did not.

## Effort and payoff

Estimates are focused implementation plus review on a prepared checkout. They exclude dependency setup, unavailable native/browser host, queueing and installation. They are planning ranges rather than test-time promises.

| Task | Focused effort | Release condition | Likely result |
| --- | --- | --- | --- |
| F01 Rust duplicate | 0.75–2 hours | Rust toolchain, isolated output | ST007 closure candidate |
| D01 retired read adapters | 1–3 hours | Q0 frontend test release | Further FE008 reduction |
| C01 queue acknowledgment | 1–3 hours plus assembled proof | Q0 receipt release | FE001 closure candidate with complete caller/proof inventory |
| C02 authority facts | 3–6 hours after 30–45 minute map | Finite adapter boundary, no journal redesign | Meaningful FE005 partial |
| C03 factory import isolation | 2–5 hours | C02 and owner release | Remaining FE005 closure candidate |
| D02 retained capability | 45–90 minute decision map; 3–6 hours if finite implementation | Supported/retired metadata distinction | Truthful recovery/hold with original records preserved |
| D03 grader parity | 3–6 hours plus retained-record proof | Retained dual-runtime support established | FE009 candidate, or retire unused runtime path |
| F02 migration witness | 0.75–2 hours plus lifecycle proof | Applicable lifecycle qualification before merge | RT005 closure, release time uncertain |

The best counterargument to doing C01 immediately is its proof cost: a tiny queue edit still needs an assembled save-to-next journey. If the native/browser host is unavailable, F01, D01 and documentation/proof repair make more progress per occupied slot. The best counterargument to D03 is stronger: an absent public exercise surface means parity work may strengthen an intentionally retired path. D02 must settle that first.

## Concrete source anchors

Reviewed main source: `799b66234b8be386a33d980df10b8b1d9a9d8b36`, available in `/workspace/scratch/98ef0fd314f3/plan-source`.

Reviewed pending frontend source: combined #993/#995 tree at `/workspace/scratch/98ef0fd314f3/frontend-review/git-review`. The queue acknowledgment residual is unchanged by these pending PRs. Current pending heads are #993 `9b02516ae2336714710a639b23e2a107dfe9d2db` and #995 `328ef924856ce0490c2e9dab7a1e4b42ae9eae8a`.

| Observation | Source evidence | Implication |
| --- | --- | --- |
| Initial queue202 manually interprets `operation_id` and pending states; subsequent polls call the canonical decoder | `app/views/fetchAndInitializeQueue.tsx`, `pendingIssuanceStates` and `followQueueIssuance`; `app/domain/adapters/operation-result-adapter.ts` | Small FE001 continuation; no need to redo #993's command migrations |
| Authority policy knows actual database/store/column names | `app/lib/study-connection.ts`, `assertStudyAuthority`, lines144–172 in inspected source | Typed facts in existing adapter are a substantive boundary fix; moving code unchanged is insufficient |
| Factory fake repeats physical database shape | `tests/unit/study-client-factory-regressions.test.ts`; `tests/unit/operation-status-study-client-regressions.test.ts` | Existing tests provide a concrete in-memory-port acceptance target |
| Many real retention cases already exist | `tests/unit/study-learning-connection-regressions.test.ts` | Reuse resume/recovery, foreign work, schema/registry failure tests before adding a new test file |
| No current runtime consumer for exact `/api/games/summary` or `/api/endgames/templates` beyond old adapters | `app/domain/adapters/workspace-adapters.ts`, `app/lib/workspace-data.ts`; app/package source search | Narrow deletion is plausible; mixed old tests still contain retained generic obligations |
| Standalone authored Studies retired, frozen generated ordinary exercises preserved | `SPEC.md`, product cut paragraphs near lines23–41 | Do not use a single retired label for all stored authored work |
| Published study_exercise cards still seeded/eligible | `database/tempo_storage/queue_refresh/application/seeding.py`, `eligibility.py`, `admission.py`; `queue_refresh/eligibility.py` | Missing `/api/studies` route is a compatibility gap, not proof all exercise cards are unsupported |
| Browser/server graders have different schema bounds and notation acceptance | `app/domain/study-exercises.ts`; `backend/app/contracts/study_exercises.py`; `backend/app/study/policy/study_grading.py` | FE009 needs accepted/rejected contract vectors plus retained-version policy if use remains supported |
| Grader test is inside a mixed legacy/PGN suite | `backend/tests/test_studies.py`; `tests/fixtures/study-grading.json` | A pure test extraction may be appropriate, but cannot hide or delete unrelated retained PGN obligations |
| Unused same-crate Rust constructor duplicates live validator | `tempo-core/src/structs/validated_line.rs::from_uci`; `tempo-core/src/lib.rs::validate_uci_line_native` | Delete alternate implementation; do not switch live diagnostics to its different body |
| `cut62WitnessName` is identical in two live callers | `scripts/tempo-runtime.mjs`; `scripts/tempo-managed-isolation.mjs` | One body in existing deployment owner, compatible exports |
| Actual required schema is65; current lifecycle preflight rejects>=64 | `database/tempo_storage/ddl/schema_version.py:3`; `scripts/lifecycle-source-preflight.mjs:85–86` | F02 exact lifecycle acceptance remains a real gate even if its pure tests pass |

## Explicit deferred scope

FE002's live renderer migration, FE012's offline/demo scheduling decision, FE013's FSRS-shaped API decision, and ST011's fixture packaging question remain separate. C02/C03 do not close FE003/FE004/FE006/FE010 or ST003/ST004 by wrapping an interface. D02 must not remove accepted obligations, all study-command records, or frozen supported exercises; D03 must not reinterpret old attempts with a changed grader. F02 must not weaken lifecycle selection or source preflight to make a small cleanup mergeable.

## Written deliverables

- `C-browser-contracts-and-authority.txt`
- `D-retained-capability-and-grading.txt`
- `F-isolated-rust-and-lifecycle-duplicates.txt`
- `frontend-task-matrix.json`

Each prompt includes explicit push/PR authority, merge after exact acceptance and owner sequencing release, and installation authority assigned to the registered-Mac operator. No old packet wording claiming the assignment grants no authority is carried forward. The matrix includes exact file claims, shared-file handoffs, dependencies, proof commands, estimates, status and defer map.
