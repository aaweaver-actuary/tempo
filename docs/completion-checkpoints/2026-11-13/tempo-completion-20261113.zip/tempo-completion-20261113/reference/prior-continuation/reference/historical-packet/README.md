# Tempo low-hanging-fruit packets

Read PLAN.md. Extract this directory under the Tempo repository root next to the existing audit HTML and XLSX. Give each independently launched Creator one matching file in prompts/.

Start A/B/C/D within actual capacity; E restores selected proof and has one B06-dependent subtask. F is optional. G is queued. 00-integration-owner.txt assigns shared artifacts, integration and heavy proof to one owner; it need not be another permanent team.

plan.json and finding-dispositions.csv map all 55 original families. ownership.csv lists exact write reservations; proposed new files are labeled. progress/TEMPLATE.json is a proposed per-Creator handoff, not an independent registry. The original root audit remains the architectural evidence source.

The packet author changed no product source and ran no product tests. Estimates and full-closure candidates are planning judgments. Source/plan consistency checks are recorded in validation.json. The independent plan review is preserved in review/plan-review.md with corrections incorporated into the compiled prompts.
