# Source and evidence index

Prepared November 12, 2026 for `aaweaver-actuary/tempo`. The final read of remote main remained `799b66234b8be386a33d980df10b8b1d9a9d8b36`; the fresh planning worktree was clean. Source inspection and packet consistency validation are not new product acceptance execution.

## Current baseline and reviewed work

- [Current pinned main](https://github.com/aaweaver-actuary/tempo/tree/799b66234b8be386a33d980df10b8b1d9a9d8b36)
- [#996 accepted audit update](https://github.com/aaweaver-actuary/tempo/pull/996); included unchanged as the root HTML/workbook snapshot and `merge-review.json`.
- Already merged: [#988](https://github.com/aaweaver-actuary/tempo/pull/988), [#989](https://github.com/aaweaver-actuary/tempo/pull/989), [#990](https://github.com/aaweaver-actuary/tempo/pull/990), [#994](https://github.com/aaweaver-actuary/tempo/pull/994). Exact accepted heads, merge revisions and independent results are in `current-state.json` and `merge-review.json`.
- Still held at preparation: [#991](https://github.com/aaweaver-actuary/tempo/pull/991) `da457a44da68ed5aefd71c41231eb76074510034`; [#992](https://github.com/aaweaver-actuary/tempo/pull/992) `1d68597b8b8da4c61bba6b9ea91793e42475540f`; [#993](https://github.com/aaweaver-actuary/tempo/pull/993) `9b02516ae2336714710a639b23e2a107dfe9d2db`; [#995](https://github.com/aaweaver-actuary/tempo/pull/995) `328ef924856ce0490c2e9dab7a1e4b42ae9eae8a`.

The four pending patch files are diff evidence against their merge bases at these exact heads. Do not apply them blindly over advanced main, use them as proof of execution, or merge both a combined copy and its original PR. Refresh the actual branches before execution.

## Product and delivery authority

- [Current product specification, including retirement amendments and frozen generated exercises](https://github.com/aaweaver-actuary/tempo/blob/799b66234b8be386a33d980df10b8b1d9a9d8b36/SPEC.md)
- [Current agent rules](https://github.com/aaweaver-actuary/tempo/blob/799b66234b8be386a33d980df10b8b1d9a9d8b36/AGENTS.md)
- [Contribution and evidence reuse rules](https://github.com/aaweaver-actuary/tempo/blob/799b66234b8be386a33d980df10b8b1d9a9d8b36/CONTRIBUTING.md)
- [Test selection and runner limitations](https://github.com/aaweaver-actuary/tempo/blob/799b66234b8be386a33d980df10b8b1d9a9d8b36/docs/testing.md)
- [Supported Tempo CLI](https://github.com/aaweaver-actuary/tempo/blob/799b66234b8be386a33d980df10b8b1d9a9d8b36/docs/TEMPO-CLI.md)

The current user assignment supplies the scoped push, accepted merge and ready registered-Mac installation authority described in `../AUTHORITY.md`. Earlier generic documentation requiring authorization is satisfied for those actions. Actual host/tool and repository protection controls remain effective.

## Critical qualification facts

- [Current native/browser runner options](https://github.com/aaweaver-actuary/tempo/blob/799b66234b8be386a33d980df10b8b1d9a9d8b36/database/tests/postgres-test-options.mjs): the position pytest selector is not already implemented.
- [Exact native rollback test on reviewed #992](https://github.com/aaweaver-actuary/tempo/blob/1d68597b8b8da4c61bba6b9ea91793e42475540f/database/tests/position_study/test_position_grade_effects.py): needs `TEMPO_POSITION_TEST_DSN`, refuses a database outside `tempo_position_test_*`, and must genuinely execute.
- [Required source schema](https://github.com/aaweaver-actuary/tempo/blob/799b66234b8be386a33d980df10b8b1d9a9d8b36/database/tempo_storage/ddl/schema_version.py): 65 at preparation, separate from installed state.
- [Historical lifecycle source refusal](https://github.com/aaweaver-actuary/tempo/blob/799b66234b8be386a33d980df10b8b1d9a9d8b36/scripts/lifecycle-source-preflight.mjs): historical `full/current63` does not qualify the schema-65 source.
- [Current minimal Game Review acceptance](https://github.com/aaweaver-actuary/tempo/blob/799b66234b8be386a33d980df10b8b1d9a9d8b36/tests/browser/minimal-game-review-acceptance.spec.ts)
- [Current position Study browser acceptance](https://github.com/aaweaver-actuary/tempo/blob/799b66234b8be386a33d980df10b8b1d9a9d8b36/tests/browser/position-study-acceptance.spec.ts)

`../plan/QUALIFICATION-RUNBOOK.md` maps exact current commands, titles, missing assertions and new runner deliverables. `backend-task-analysis.json` and `frontend-task-analysis.json` preserve the detailed source-grounded planning analyses; the compiled `../plan/tasks.json` is the controlling cross-stream task map.

## Historical packet and audit

`historical-packet/` is the original low-fruit plan and A–G prompts, retained as supporting context. Its main pin, completed assignments, permission disclaimers and manual-launch convention are superseded by this continuation where they differ. Never treat an archived prompt as the current dispatch instruction.

The original audit remains pinned to `40172873fdf5d134a35b872b24858917287cb81e`. Its 55 families include four decision candidates. The included accepted snapshot has six Closed and one Partially addressed; the rest remain Open or Needs decision. `../plan/finding-dispositions.csv` preserves each original acceptance and states its current continuation or defer decision. A planned task is not a new status update or closure.
