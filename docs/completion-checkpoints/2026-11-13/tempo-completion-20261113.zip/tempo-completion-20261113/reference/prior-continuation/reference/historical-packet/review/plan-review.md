# Independent low-fruit plan review

Reviewed on 2026-11-12 against the audit at `40172873fdf5d134a35b872b24858917287cb81e`, the incoming tooling/frontend/backend packets, and selected actual producers, consumers, test selectors and proof files. Parent verified that observed main `a2e877d908309544eafee908c7e537149c22d169` adds only the root report/workbook. No product edits or product tests were performed by this reviewer.

## Verdict

The A/B/C/D split is defensible for parallel source work in isolated worktrees. It separates catalog/current documentation, backend pure seams, browser receipt semantics, and read-only UI contracts. E is maintained-proof repair; F is optional duplicate removal; full calendar work remains a later packet. The packets are substantially more bounded than assigning one creator per audit finding or permitting every creator to fix neighboring defects.

Use the corrections below in the compiled prompts. The largest remaining risk is overstating a cheap source edit as a cheap complete closure. Native proof, consumer adoption, compatibility and artifact qualification can outlast the implementation.

## Required corrections and clarifications

### 1. BE016 needs a named position-codec proof, not generic Study acceptance

Creator E's initially selected `check_postgres_queue_attempt_recovery.py` / `check_postgres_study_only.py` stages do not establish the new first-response codec's adopted position readers. Their ordinary queue/review receipt assertions and the obsolete opening-evidence scenario are insufficient for that claim.

Smallest concrete extra native target:

- `database/tests/position_study/test_position_grade_effects.py::test_native_two_decisions_and_late_failure_rollback`, lines 149–273.
- It creates real first-response envelopes, exercises native grade writes, injects a late failure and proves rollback, races duplicate submissions, and checks immutable replay.
- Its codec import at line 165 still uses removed `app.services.postgres_opening_evidence`. Bind this specific fixture to B's released codec; do not restore the facade.
- Assign this file explicitly to E as a narrow B06-dependent handoff. The native function requires a real task-owned `TEMPO_POSITION_TEST_DSN` and checks the database-name prefix. A skipped test does not count.
- The existing `make python-file FILE=database/tests/position_study/test_position_grade_effects.py::test_native_two_decisions_and_late_failure_rollback` entry supports the node ID. It still needs the supported backend environment and actual native resource owner.
- This is the smallest identified target, not a guarantee that the stale import is its only fixture defect. Bound any additional repair to proving these current invariants; otherwise report the named residual.

Also reserve the narrow consumer test `database/tests/position_study/test_position_issued_plans.py::test_clean_proof_requires_saved_review_and_all_first_response_receipts` to B06. At lines 161–199 it monkeypatches the decoder on the outer `position_checkpoint` module. Once issuance imports the inner codec directly, that patch no longer represents the adopted dependency. Prefer valid real envelopes and the real decoder; at minimum bind the intended dependency explicitly. Do not continue a mock that bypasses the changed interface while claiming consumer proof.

For the required assembled position journey, the existing test is `tests/browser/position-study-acceptance.spec.ts`, title **position Study keeps its server-issued suffix and first-wrong journal across reload and offline** (line 313). Its fixture seeds initial authored/position state; actual API/UI paths create plans and responses. Supported invocation is `make ui-file FILE=position-study-acceptance.spec.ts`. The current test may still expose fixture or runner failures; no current pass is asserted.

Keep B06 implemented/component-tested with integrated qualification pending until the named applicable evidence exists. B01–B03 should remain independently releasable. No need to revive the broad historical LP07 migration programme solely for a byte-preserving codec extraction.

### 2. Do not create a blanket A→E dependency

`make preflight` invokes Docker/loopback/workspace-mount capability checks. The native runner does not directly reference `contracts/check_dependencies.py` or the active contract catalog. E's source triage and selected Study proof can proceed once its actual assertions and prerequisites are ready.

A→E is conditional only when a selected gate or artifact build actually consumes A's catalog changes. A's documentation completion is never a prerequisite. Distinguish:

- source/capability dependency;
- integration/rebase dependency;
- shared native/browser resource serialization.

These do not imply the same execution order. The central runner/inventory writer and shared resource budget are more immediate constraints than catalog completion.

### 3. D1 must match actual current producer variants

`backend/app/games/review.py` POST `/compare` returns `detail()` **without a color field**. Saved GET `/games/{id}` merges stored game color into the detail. Do not make color mandatory in both response variants. Preserve caller-selected color for pasted PGN and saved-player orientation for stored games.

`covered` and `unavailable` do not carry `ply`; `departure` and `coverage_end` do. The latter two use one-based first affected move with a preceding board position. Derive their bounds from the current producer, rather than treating all results as the same optional-field bag or requiring every field on every tag.

Reusing existing chess.js/chess-line operations to validate a supplied sequence is reasonable. Do not create a second comparison or chess-legality policy engine in this wire decoder. Validation should reject malformed successful responses while preserving supported current payloads. The old `matched` fixtures and older packaged review API are not authorities for this contract.

### 4. Keep first-wave closure forecasts conservative

Ten potential complete families are identified before the more conditional work: A's five candidates, B01–B03, C0/ST009, and D1/FE011. They still depend on A's real graph/artifact checks and final reachability verification. A reasonable planning range is **6–10 complete closures in the first batch**, with additional partial receipt/FE007/FE008/proof progress. It is not fourteen guaranteed immediate closures.

Full FE007 can follow if adapter retirement is confirmed. BE006/BE016 and full FE001 have additional consumer/qualification cost. RT005 has very little code but touches lifecycle-sensitive callers. Native proof restoration can reveal obsolete scenarios and current fixture failures. Report source-ready and merge-qualified separately.

The effort estimates are active work on a prepared environment. They exclude host access, dependency setup, unrelated baseline failures, review queues and final release qualification. Do not sum parallel worker estimates into a confident elapsed-time promise.

### 5. Preserve audit baseline provenance while updating progress

Keep the audit `method.source_pin` and its original evidence anchors at `40172873`. Completion evidence needs its own current revision. Do not globally rewrite original source links or claim all files were re-audited at the new head after a few fixes.

The original 55/51 counts and verdict are baseline facts. Label them accordingly and provide a separate current progress summary as statuses change. Otherwise closed rows sit beneath an apparently current unchanged failure count.

Use one canonical structured record (the existing embedded JSON or an extracted JSON) and a derived workbook. One integration writer updates both root artifacts from accepted per-stream deltas. The deltas are review handoffs, not a competing project tracker. No new persistent governance framework or approval receipt is needed.

## Ownership collision checks

- B owns `backend/tests/test_study_contract_identity.py`; E excludes it. Current `test_studies.py` grader/support questions are not part of blanket proof cleanup.
- B03 owns `packages/game-review-contracts/README.md` and `REGRESSIONS.md`; A excludes those two during B03. Other A-owned current documentation changes requested by B/C/D are applied serially by the designated writer.
- The integration owner applies B03's `components.json` export delta, new-test inventory registrations, and D3's deleted-source inventory delta. Component implementation must not wait for the whole global ownership map, but the relevant required metadata must be integrated before final closure.
- C owns `analysis-paste-command.ts` and `branch-command.ts`; later BE018 Coverage-input retirement cannot edit them concurrently.
- B05 owns `review_reconciliation.py`; later calendar work waits for release of that file. This is a file/integration dependency, not a requirement that all backend findings close.
- D2 owns legacy board type edits; FE002 renderer migration stays deferred.
- E's runner files and F's lifecycle scripts are separate edits but share downstream qualification inputs. Reconcile their combined source before reusing native/lifecycle evidence.
- The exact B06 proof files named above must be added to the compiled reservation table; do not leave them under an undefined “all position tests” owner.

## Simplest launch order

1. Establish the existing integration owner and branch/progress conventions once. This is a role, not a permanently idle extra agent tree.
2. Start A, B, C and D on their first small task if actual host/agent capacity permits. Four scopes do not grant four full multi-agent hierarchies or independent native stacks.
3. Let A0/A1, B01/B02, C0 and D2/D1 produce small coherent reviewable changes first. Each creator can continue its finite assigned sequence without waiting for every other stream.
4. Start E's bounded case disposition independently when a worker slot is available. Serialize its real native/browser work under the existing host resource owner, not by the number of creator threads.
5. Run F only if its small deletion is worth its toolchain/lifecycle qualification cost. Do not let it become the critical path for the first batch.
6. Adopt B06's released codec in its named proof and coordinate one appropriate assembled position journey. Full calendar work follows the policy-file and relevant-proof handoffs.

The main value of parallelism here is separating actual editing ownership. More creator/manager/coordinator labels do not add throughput when all threads contend for the same mutable package outputs, native stack, shared runner files or reviewer slots.

## Checks already proportionate in the source packets

- Existing shared receipt decoder is reused; separate journals and legacy missing-identity policy remain explicit.
- ST009 preserves exact old key serialization and retained record identities.
- B01 preserves `app.contracts.studies` as the existing envelope owner.
- B02 leaves `initial_depth` and the active authoring owners unchanged.
- A avoids making every current importer legal just to green the corrected guard.
- E does not blanket-replace `?`, restore retired translators, erase mixed assertions, or label all static mismatches executed test failures.
- D4 retains the `issueIdentity`-based choice reset when its orphan optional fetch is removed.
- Candidate findings and broad state/transaction/lifecycle redesign remain decisions or later scoped projects.

## Limits

This review examined the supplied packets and selected actual source paths. It did not execute their product tests, inspect live Study, prove every dynamic caller absent, or certify all proposed commands will pass in the eventual host. Compilation of final portable prompts should retain the named ownership/dependency distinctions and corrections above.
