# Backend completion tasks

Source pin: `091ad318b1afaadcb25e5ca44ff526120a202336`. Planning only; no product changes or test runs.

## What remains from the original packet

- **B01:** Done for unused alias slice; BE005 wider encapsulation remains B09-B11.
- **B02:** Done for exact observation helper; BE011 wider purge ownership B23.
- **B03:** Done for fresh state initializer; preserve native receipt evidence separately.
- **B04:** B00 completes original probe; B04/B05/B26 are wider implementation expansion.
- **G00:** B01 complete row disposition map.
- **G01:** Done; retain recorded/current-day separation and import guards.
- **G02:** B03 missing-day disposition; no redo of captured active Study/Tactics callers.
- **G03:** B02 settings and backward-day coalescing plus B01 remaining row map.
- **G04:** B02/B03 relevant native and coordinated assembled calendar proof; one release owner.
- **D02:** B31 supplies minimal frozen runtime endpoints after frontend support/grader classification; frontend owns consumer/recovery behavior.
- **E-residue:** Proof owner P01/P02/P03 handles named PGN/admission/deletion failures; P06 prefix routes; P12 shared browser qualification.

## Complete BE finding coverage

| Finding | Tasks | Other owner |
|---|---|---|
| BE001 | B00, B04, B05 | — |
| BE002 | B12, B13 | — |
| BE003 | B01, B02, B03 | — |
| BE004 | B07, B08 | — |
| BE005 | B09, B10, B11 | — |
| BE007 | B16, B17 | — |
| BE008 | B14, B15 | — |
| BE009 | B18, B19, B20, B21 | — |
| BE010 | B22 | — |
| BE011 | B23 | — |
| BE012 | B24, B25 | — |
| BE013 | B00, B26 | — |
| BE015 | B00, B06 | — |
| BE018 | B27 | — |
| BE019 | B28, B29, B30 | — |
| BE021 | B32, B33, B34, B35, B36 | P01, P02, P03 |

## Execution rules

Keep the modular monolith and existing owner boundaries. No retired automatic feedback, authored-Studies suite, engine/provider, advanced prefix or generic persistence framework may return merely to satisfy old tests. Source and receipt history stays intact.

Pure changes receive pure proof; callers receive actual adapter/contract proof; transaction changes receive native proof. The delivery owner performs one coordinated assembled journey for the changed release. Native/browser/Docker work uses one heavy resource slot. Completed bounded B01/B02/B03/G01 work is not repeated.

No mypy/pyright configuration or locked checker was found. The plan retains literal type-check acceptance for BE002/BE008/BE013 with small proposed mypy fixtures binding real production and independent fake implementations. The integration owner provisions one pinned checker in the existing disposable environment and records actual pass/fail. Do not create a repository-wide framework or substitute runtime tests.

## B00 — Finish B04: exact bulk, direct-review and unused-port reachability map

**Scope:** BE001, BE013, BE015; milestone `original-packet`; phase `0-probes`; gate `source`.

**Prerequisites:** None.

**Read first:** backend/app/main.py:reconcile_unseen_queue,seed_queue,randomize_daily_queue,materialize_daily_queue,_apply_review,_reconcile_review; backend/app/services/queue_application.py; backend/app/services/tactical_catalog.py:seed_tactical_introductions; backend/app/study/position_learning/contracts.py:four Protocols; backend/app/services/learning_review_adapter.py:apply_legacy_review,submit_legacy_review; database/tests/frozen-order-browser-fixture.py; database/tests/native_review/test_postgres.py; backend/tests/test_next_exercise_native.py; database/tests/check_postgres_deletion.py; database/tests/games_collection/test_packaged_collection.py

**Write paths:** Read-only handoff/evidence only.

**Ordered steps**

1. Produce one symbol table with every definition, import/re-export, actual caller, fixture-only caller, runner selection, and retained recovery receiver for the three named families.
2. Trace tasks.execute_background_slice/progress_study_queue to execute_postgres_queue_refresh_slice. Separately trace bulk wrappers; do not confuse shared eligibility/requeue helpers with dead bulk orchestration.
3. Record the known live fixture calls to randomize_daily_queue and the legacy tactical-history case. Determine whether any supported callers still require bulk seed/materialize/QueueAdmissionAdapter; attach exact searches and function names.
4. For apply_legacy_review distinguish deliberately lower-level algorithm tests from user submission tests; trace mounted review/reconcile routes to full submit_legacy_review.
5. For all four unused Protocols compare declared and actual signatures. Integration owner chooses removal of obsolete declarations plus accurate actual interfaces (preferred) or adoption only where a real injection boundary needs it; release B04/B05/B06/B26.

**Acceptance and stop condition**

- Original B04 is complete when this finite evidence table and concrete dispositions exist, even though wider BE001/BE013 work remains.
- No product edit is made by this probe. Open confirmed rows stay open until the implementation tasks complete.
- A possible unknown supported consumer is a named blocker with owner and exact contract question, not a reason to retain every duplicate indefinitely.

**Selected commands (planned, not executed)**

- `rg -n '(seed_queue|materialize_daily_queue|randomize_daily_queue|seed_tactical_introductions|QueueAdmissionAdapter|PositionScheduleReadPort|IssuedPositionAttemptPort|GradeEffectWritePort|PositionOwnerEpochReadPort|apply_legacy_review|_apply_review|_reconcile_review)' backend database services` — entrypoint/options inspected; any proposed new selection is stated in acceptance

**Main risk:** Static absence alone does not settle dynamically selected or external compatibility consumers; use current advertised entrypoints and runner inventory.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## B01 — Finish G00: calendar row dispositions and two finite compatibility decisions

**Scope:** BE003; milestone `original-packet`; phase `0-probes`; gate `source`.

**Prerequisites:** None.

**Read first:** backend/app/settings_commands.py:apply_settings; backend/app/services/durable_tasks.py:_request_current_queue_in_transaction; backend/app/services/postgres_queue_refresh.py:execute_postgres_queue_refresh_slice; backend/app/services/study_calendar.py:capture_study_calendar; backend/app/study/policy/clock.py:StudyCalendar,study_calendar_at; backend/tests/test_study_calendar.py; database/tempo_storage/durable_tasks/storage.py; database/tempo_storage/lifecycle/refresh_requests.py; SPEC.md:November 10 pass 2; reference/audit-current.json:every BE003 file row

**Write paths:** Read-only handoff/evidence only.

**Ordered steps**

1. Build a row-by-row table for every BE003 audit location: current use-case clock, configured zone source, explicit/recorded/accepted day, actual caller, and retained or removed disposition.
2. Trace and record the settings case 2026-11-12T02:00Z / America/New_York: Study day 2026-11-11 while date.today returns 2026-11-12. Follow the older-day singleton early return before signal_queue_refresh_in_transaction. B02 owns the named regression; this probe makes no product edits.
3. Choose the new settings operation follow-up policy. Recommended: one observed instant and newly saved effective Study zone; an existing accepted task keeps its own day. Specify how an east-to-west zone change requests the now-earlier current day without rewriting the old task/receipt.
4. Determine supported missing-queue_date task variants from current persisted payload/history contracts and maintained fixtures; explicit accepted day always wins. If a trustworthy original acceptance fact cannot establish a day, do not infer it from the host or current zone.
5. Integration owner records one-time missing-day resolution or explicit durable hold policy, and explains how a fresh known-current request can still progress. Release B02/B03 only with these exact contracts.

**Acceptance and stop condition**

- Every original BE003 row has a disposition; compatibility wrappers with ambient defaults are explicitly unsupported for new current-day acceptance or receive an injected context.
- The backward-zone singleton behavior and supported legacy missing-day behavior have explicit choices, original IDs/receipts preserved.
- No live data inspection/migration is assumed; missing historical facts are acknowledged, not invented.

**Selected commands (planned, not executed)**

- `rg -n 'date.today|datetime.now|current_study_day|capture_study_calendar|review_day_at|queue_date' backend/app/settings_commands.py backend/app/services/durable_tasks.py backend/app/services/postgres_queue_refresh.py backend/app/services/scheduler.py backend/app/study/policy backend/app/*commands.py` — entrypoint/options inspected; any proposed new selection is stated in acceptance

**Main risk:** This is a policy/support decision, not merely replacing date.today. Keeping the max-day guard unchanged can still strand the configured current day after a timezone change.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## B02 — Fix settings follow-up and backward-day queue coalescing

**Scope:** BE003; milestone `original-packet`; phase `1-calendar`; gate `native`.

**Prerequisites:** B01

**Read first:** backend/app/settings_commands.py:SettingsRequest,apply_settings,SETTINGS_COMMAND; backend/app/services/durable_tasks.py:_request_current_queue_in_transaction; backend/app/queue_commands.py:request_queue_refresh_in_transaction; backend/tests/test_settings_descriptor.py; backend/tests/test_study_calendar.py; backend/tests/native_study_fixture.py

**Write paths:** backend/app/settings_commands.py; backend/app/services/durable_tasks.py; database/tempo_storage/durable_tasks/storage.py (only if selected durable coalescing operation needs a narrow adapter); backend/tests/test_study_calendar.py; backend/tests/test_settings_descriptor.py; backend/tests/test_settings_calendar_postgres.py (proposed)

**Ordered steps**

1. Implement only the B01 settings/day policy. Capture one aware instant and select the day from effective saved settings through study_calendar_at/capture_study_calendar; remove host date selection.
2. Make the selected current day actually durable/signaled despite an outstanding later accepted task. Preserve existing task/day and history; use current generation/refresh-epoch mechanisms rather than a second scheduler or blind deletion of the greater-day guard.
3. Repair affected settings tests to current retained Settings fields and current post-commit behavior; remove expectations of retired provider account writes, while retaining operation replay and policy-hook-before-wake assertions.
4. Add named unchanged-zone and east-to-west-zone regressions. Assert settings update/refresh obligation/operation receipt commit or roll back together, and the same completed operation replays without recomputing time.
5. Add the same boundary to an owned capped PostgreSQL fixture; integration owner executes it in the single heavy slot.

**Acceptance and stop condition**

- At 2026-11-12T02:00Z with America/New_York unchanged, new settings follow-up signals 2026-11-11, never host tomorrow.
- An east-to-west change with accepted future-day work requests the selected earlier current day and preserves original accepted payload, generation history, receipt, and issued-origin dates.
- A rollback leaves neither partial settings nor a false queue refresh; completed receipt replay causes no new follow-up.
- Required native case executes, not skipped; whole-calendar closure still waits B03 and B01 map.
- The configured current-day worker actually processes the durable request and reaches a ready/playable projection in the native case; merely signaling an epoch is insufficient.
- Lease and partially advance an accepted future-day refresh, request the earlier current day after a backward-zone change, then resume the old slice. Prove the old lease/generation cannot publish or checkpoint against the new day/generation and the fresh current-day request still reaches ready under the B01 policy.

**Selected commands (planned, not executed)**

- `make python-file FILE=backend/tests/test_study_calendar.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_settings_descriptor.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_settings_calendar_postgres.py` — Makefile:109-111; proposed test file must be added by this task

**Integration handoff**

- One coordinated release saved-review → authoritative playable-next proof on a configured non-UTC day; do not repeat a browser stack per calendar leaf.

**Main risk:** Changing singleton coalescing can drop progress or mutate an accepted day if implemented as overwrite. The native case must cover the actual durable path.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## B03 — Resolve supported historical missing-day queue tasks exactly once

**Scope:** BE003; milestone `original-packet`; phase `1-calendar`; gate `native`.

**Prerequisites:** B01, B02

**Read first:** backend/app/services/postgres_queue_refresh.py:execute_postgres_queue_refresh_slice first epoch branch; backend/app/services/durable_tasks.py:advance_task_slice_in_transaction,lock_current_slice; database/tempo_storage/durable_tasks/storage.py; backend/tests/test_study_calendar.py

**Write paths:** backend/app/services/postgres_queue_refresh.py; backend/app/services/durable_tasks.py (only selected helper); backend/tests/test_study_calendar.py; backend/tests/test_settings_calendar_postgres.py (proposed by B02; serialized ownership)

**Ordered steps**

1. Apply only B01 supported historical variants. Remove unconditional date.today fallback from accepted task execution.
2. For a recoverable original day, persist its one-time resolution while holding existing task lease/generation fences before any queue phase runs. For an unrecoverable accepted record, retain exact identity/payload and truthful durable disposition selected in B01.
3. Do not recapture a different current zone/date on subsequent slices/restarts. Keep explicit queue_date byte value authoritative, including an older valid accepted day.
4. Exercise missing day with and without existing _refresh_cycle_epoch, stale lease, interrupted first normalization, timezone change, and replay. Verify a hold does not veto unrelated valid current-day work.
5. Update B01 callsite table to final symbols and hand calendar closure to the integration owner.

**Acceptance and stop condition**

- No accepted task chooses host day. Each supported missing-day shape reaches the documented one-time result or explicit hold, and never fabricates a historical clock.
- Atomic effect/checkpoint and original task identity/generation/receipt are retained; failed normalization writes nothing.
- All BE003 supported rows and new-task boundaries are accounted for before requesting closure.

**Selected commands (planned, not executed)**

- `make python-file FILE=backend/tests/test_study_calendar.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_settings_calendar_postgres.py` — Makefile:109-111; proposed test file must be added by this task

**Integration handoff**

- Use B02 current-day PostgreSQL fixture and final calendar assembled journey; no separate full suite.

**Main risk:** Original day may be unrecoverable. Stop at a missing B01 policy rather than silently treating today as historical truth.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## B04 — Remove unreachable bulk seeding and duplicate admission writers

**Scope:** BE001; milestone `whole-audit`; phase `2-queue`; gate `native`.

**Prerequisites:** B00

**Read first:** backend/app/services/queue_application.py:seed_queue,materialize_daily_queue,reconcile_unseen_queue,admit_prioritized_opening_cards; backend/app/services/tactical_catalog.py:seed_tactical_introductions; backend/app/services/queue_admission.py; backend/app/services/queue_admission_adapter.py; database/tempo_storage/queue_refresh/application/seeding.py; database/tempo_storage/queue_refresh/application/admission.py; backend/app/services/postgres_queue_refresh.py:_prepare_tactical_introduction,_publish_tactical_introduction,_admit_one_prioritized_opening,_admit_one_study_card

**Write paths:** backend/app/services/queue_application.py (only bulk seed/materialize/admission regions); backend/app/services/tactical_catalog.py (bulk seeder only); backend/app/services/queue_admission.py and queue_admission_adapter.py (only B00-proven obsolete writers/ports); database/tempo_storage/queue_refresh/application/seeding.py and admission.py (only unreferenced statements); backend/app/main.py (compatibility bulk wrappers; integration-owned merge); backend/tests/test_queue_application_database_split.py; backend/tests/test_queue_admission.py; backend/tests/test_tactic_introduction_history_postgres.py; database/tests/queue_admission/test_postgres.py (coordinate proof owner)

**Ordered steps**

1. Use B00 consumer map; for a genuinely supported consumer, first migrate it to the existing phased owner or its semantic public operation. Do not simulate all phases inside a foreground writer transaction.
2. Remove seed/materialize wrappers and bulk tactic seeder if all remaining callers are obsolete fixtures. Retire duplicate-only tests; port daily limits, generated-card exclusions, tactic introduction history, and rollback assertions to active phased owner tests.
3. Remove only orphan bulk admission/seeding SQL and adapter APIs. Preserve live shared eligibility/reset/unlock, requeue, queue placement, and priority pure policy still used by the worker.
4. Keep unique tactic_introductions claim before card/progress/queue effects; existing rollback and concurrent cross-day tests continue to exercise active writer.
5. Search again for every deleted symbol and update current owner guide/drawing only for changed authority.

**Acceptance and stop condition**

- One active implementation owns tactic and Study introduction policy. No retained callable bulk seeder can write a competing queue.
- Removed interfaces have no supported caller; retained claims/exclusions/rotation and once-only history are covered through active worker operations.
- Native tactic history, rollback, and cross-day claim cases pass; shared helpers and issued work remain unchanged.

**Selected commands (planned, not executed)**

- `make python-file FILE=backend/tests/test_queue_application_database_split.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_tactic_introduction_history_postgres.py` — Makefile:109-111; existing file

**Integration handoff**

- Release owner combines active queue refresh and saved-review/next-card acceptance once after B05.

**Required small worker batches**

- B04-1: Remove proven-unreachable seed/materialize and migrate legacy tactic-history test to active publisher; preserve active helpers. Files: backend/app/services/queue_application.py, backend/app/services/tactical_catalog.py, backend/tests/test_tactic_introduction_history_postgres.py, backend/tests/test_queue_application_database_split.py.
- B04-2: Remove B00-proven unused admission writers only after invariant tests reach active owner. Files: backend/app/services/queue_admission.py, backend/app/services/queue_admission_adapter.py, database/tempo_storage/queue_refresh/application/seeding.py, database/tempo_storage/queue_refresh/application/admission.py, backend/tests/test_queue_admission.py, database/tests/queue_admission/test_postgres.py.
- B04-3: Integration owner deletes only now-unreferenced compatibility wrappers. Files: backend/app/main.py.

**Main risk:** Generated-card exclusion predicates differ between old and active counts. Preserve the active intended frozen-card behavior explicitly; no blanket deletion of application/eligibility.py.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## B05 — Migrate fixture ordering to active publication and delete bulk presentation writes

**Scope:** BE001; milestone `whole-audit`; phase `2-queue`; gate `native`.

**Prerequisites:** B00, B04

**Read first:** backend/app/services/queue_application.py:randomize_daily_queue,_quarantine_malformed_opening_cards; backend/app/services/postgres_queue_refresh.py:_prepare_queue_randomization,_publish_queue_randomization,_quarantine_one_opening; database/tempo_storage/queue_refresh/application/publication.py; database/tempo_storage/queue_refresh/presentation.py; database/tests/frozen-order-browser-fixture.py; database/tests/native_review/test_postgres.py; backend/tests/test_next_exercise_native.py

**Write paths:** backend/app/services/postgres_queue_refresh.py (narrow public active publication callable if needed); backend/app/services/queue_application.py (remaining duplicate presentation only); database/tempo_storage/queue_refresh/application/publication.py; backend/app/main.py (remaining bulk wrappers); database/tests/frozen-order-browser-fixture.py; database/tests/native_review/test_postgres.py; backend/tests/test_next_exercise_native.py; backend/tests/test_queue_randomization_noop_protection.py

**Ordered steps**

1. For each B00 fixture consumer, use actual active preparation/publication operations with the same membership/identity/source revalidation and caller locks. A narrow fixture adapter may orchestrate existing capabilities; it may not implement ordering again.
2. Preserve frozen introduction ranks, same seed/order fingerprint, protected issued pointers, invalidation retries and current queue membership checks.
3. Delete orphan bulk randomization/quarantine/ready-marking statements and wrappers after fixture migration. Keep queue ordering pure policy as the single reusable policy.
4. Run current no-op protection and native next-exercise cases, including changed membership between preparation and publish and failure rollback.
5. Attach final definition/caller map proving bulk writers are gone and fixtures now prove the production phase owner.

**Acceptance and stop condition**

- No alternate projection-ready UPDATE, quarantine writer, or per-entry bulk ordering survives merely for test convenience.
- Stale membership/proposal is refused without moving protected attempts; retry converges with stable input.
- BE001 is eligible for closure only after B04 and this task.

**Selected commands (planned, not executed)**

- `make python-file FILE=backend/tests/test_queue_randomization_noop_protection.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_next_exercise_native.py` — Makefile:109-111; existing file

**Integration handoff**

- Final queue/position browser selection consumes the migrated frozen fixture; retain original immutable order evidence.

**Required small worker batches**

- B05-1: Move every fixture to the existing active ordering/publication capability; verify stale membership/rollback. Files: backend/app/services/postgres_queue_refresh.py, database/tests/frozen-order-browser-fixture.py, database/tests/native_review/test_postgres.py, backend/tests/test_next_exercise_native.py.
- B05-2: Remove only orphan alternate presentation writers and complete final caller map. Files: backend/app/services/queue_application.py, database/tempo_storage/queue_refresh/application/publication.py, backend/app/main.py, backend/tests/test_queue_randomization_noop_protection.py.

**Main risk:** A fixture that writes equivalent-looking rows directly would hide the original competing-owner problem. Use active publisher, not copied SQL.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## B06 — Retire or explicitly constrain direct review compatibility entrypoints

**Scope:** BE015; milestone `whole-audit`; phase `2-queue`; gate `caller`.

**Prerequisites:** B00

**Read first:** backend/app/main.py:_apply_review,_reconcile_review; backend/app/services/learning_review_adapter.py:apply_legacy_review,submit_legacy_review; services/learning/application/src/tempo_learning_review/application.py:apply_review,submit_review; database/tests/check_postgres_deletion.py; database/tests/games_collection/test_packaged_collection.py; backend/tests/test_opening_evidence_contracts.py

**Write paths:** backend/app/main.py (direct compatibility wrappers); backend/app/services/learning_review_adapter.py (compatibility entrypoint only); database/tests/check_postgres_deletion.py (coordinate proof owner); database/tests/games_collection/test_packaged_collection.py (only retained disposition if still selected); backend/tests/test_opening_evidence_contracts.py; services/learning/application/README.md

**Ordered steps**

1. Implement B00 decision: route supported user-review callers through submit_legacy_review/submit_review; remove main convenience bypass wrappers once caller migration is complete.
2. Keep pure apply_review only as an internal algorithm boundary with explicit already-fenced preconditions and tests intentionally named for that scope; it must not be advertised as user submission.
3. For retained deletion/replay proof, replace synthetic direct grade calls with current full submission fixture or explicit lower-level algorithm test according to the assertion actually needed.
4. Prove actual HTTP review/reconcile and worker recovery use full locks/evidence/continuation sequencing; demonstrate original payload binding conflicts still reject.
5. If B00 positively establishes no supported bypass and an intentional constrained internal interface, document that decision with reachability and actual wrapper removal/constraint evidence.

**Acceptance and stop condition**

- No supported API/fixture accidentally selects a review submission path lacking complete owner guarantees.
- No second scheduler is introduced; low-level apply_review remains internal, if retained.
- Candidate can close by explicit supported-interface disposition; absence of a reproduced HTTP defect is recorded.

**Selected commands (planned, not executed)**

- `make python-file FILE=backend/tests/test_opening_evidence_contracts.py` — Makefile:109-111; existing file
- `python services/learning/application/run_suite.py application` — entrypoint/options inspected; any proposed new selection is stated in acceptance

**Integration handoff**

- Reuses final native review receipt/replay and assembled review journey; no extra browser run for removing wrappers.

**Main risk:** Do not make old receipt/evidence tests impossible by deleting the shared pure algorithm; constrain only the bypassable submission facade.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## B07 — Move position admission owner reads and admission proof SQL to storage

**Scope:** BE004; milestone `whole-audit`; phase `2-storage`; gate `native`.

**Prerequisites:** P02

**Read first:** backend/app/services/position_queue_admission.py:prepare_due,prepare_opening_introduction,admit_targeted_position_introduction; database/tempo_storage/study/position_owner_epoch.py; database/tempo_storage/study/position_introductions.py; backend/tests/test_position_queue_admission.py; backend/tests/test_position_introductions.py

**Write paths:** backend/app/services/position_queue_admission.py; database/tempo_storage/study/position_owner_epoch.py; database/tempo_storage/study/position_introductions.py; backend/tests/test_position_queue_admission.py; backend/tests/test_position_introductions.py

**Ordered steps**

1. Add narrowly named storage operations for next active owner after repertoire, exact active/current owner facts, and canonical admitted card/queue proof. Return explicit semantic immutable facts, not cursor/physical row leakage.
2. Move the four exact SQL statements from the three named application functions without changing predicates, ordering, limits, borrowed transaction, or introduced-card proof.
3. Application keeps source preparation, carrier choice, hold interpretation, and injecting initial_position_state. Storage imports no application policy.
4. Extend existing tests for owner missing/changed, epoch/digest mismatch, legacy/shadow/held owner, and canonical admission absent despite an introduced claim.
5. Release these modules to ST002/ST005 after signatures settle.

**Acceptance and stop condition**

- No execute/execute_native SQL remains in these three application functions.
- The active preparation caller and independent storage fake use same typed facts; current hold reasons unchanged.
- Native admission and introduction cases preserve rollback, history and busy/stale fences.

**Selected commands (planned, not executed)**

- `make python-file FILE=backend/tests/test_position_queue_admission.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_position_introductions.py` — Makefile:109-111; existing file

**Integration handoff**

- Existing --native-check position-queue-admission and position-introductions, coordinated once by heavy owner; exact registered nodes in database/tests/position-native-pytest.py.

**Main risk:** ST002/ST005 overlap: do not simultaneously change sealed proposal representation or all storage return types.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## B08 — Move checkpoint writer capability check and shared owner lock into storage

**Scope:** BE004; milestone `whole-audit`; phase `2-storage`; gate `native`.

**Prerequisites:** B07

**Read first:** backend/app/study/position_checkpoint.py:begin_position_checkpoint; database/tempo_storage/study/position_first_responses.py; database/tempo_storage/study/position_owner_epoch.py:owner_lock_key; database/tests/position_study/test_position_first_responses.py; backend/tests/test_opening_checkpoint_preparation.py; database/tests/position_study/test_position_grade_effects.py

**Write paths:** backend/app/study/position_checkpoint.py (begin_position_checkpoint only); database/tempo_storage/study/position_owner_epoch.py (reuse internal _writer and shared owner-lock implementation); backend/tests/test_opening_checkpoint_preparation.py; database/tests/position_study/test_position_first_responses.py

**Ordered steps**

1. Add the narrow public shared-owner-fence capability to position_owner_epoch.py, reusing its existing _writer check and shared advisory lock. It returns semantic writer/busy outcome without checking current source when original checkpoint replay does not require that.
2. Keep application replay/plan/manifest scope checks in their current order; call the storage capability at the exact old lock location.
3. Translate storage capability outcomes to existing evidence hold/conflict semantics; do not let storage import FastAPI or the checkpoint application.
4. Add reader/no-transaction/busy/invalid connection tests and a sequence assertion that original replay/scope validation precedes owner lock and card/day/queue locks follow it.
5. Execute actual PostgreSQL lock/rollback proof through the existing grade/checkpoint owner fixture.

**Acceptance and stop condition**

- No raw.info.transaction_status or advisory SQL remains in checkpoint application.
- Malformed/forged preparation, changed issued record and unavailable writer retain exact refusal semantics.
- Failed checkpoint/grade after lock rolls back first-response effect and checkpoint together; public contract import is inert.

**Selected commands (planned, not executed)**

- `make python-file FILE=backend/tests/test_opening_checkpoint_preparation.py` — Makefile:109-111; existing file
- `make python-file FILE=database/tests/position_study/test_position_first_responses.py` — Makefile:109-111; existing file

**Integration handoff**

- Existing native grade-effects case plus a focused shared-lock native assertion in that owner, not a separate browser gate.

**Main risk:** The seal is an authority, not a data shape. Do not weaken validation to hasattr or a boolean writer flag.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## B09 — Finish private queue, bounded-read and source-token capability cleanup

**Scope:** BE005; milestone `whole-audit`; phase `3-public-interfaces`; gate `caller`.

**Prerequisites:** B04, B05, B07, B34

**Read first:** backend/app/queue_commands.py:_lock_attempt_card,available_attempt_sql; backend/app/services/postgres_queue_refresh.py:_prepare_queue_randomization; backend/app/services/queue_application.py:eligibility aliases; backend/app/services/repertoire_move_verification.py:_source_token; database/tempo_storage/commands/queue.py; database/tempo_storage/queue_refresh/reads.py; database/tempo_storage/queue_refresh/application/eligibility.py; database/tempo_storage/repertoire_scope/move_verification.py:_source_token

**Write paths:** backend/app/queue_commands.py; backend/app/services/queue_application.py; backend/app/services/postgres_queue_refresh.py; backend/app/services/durable_tasks.py (remaining constant re-exports only); backend/app/services/repertoire_move_verification.py; database/tempo_storage/commands/queue.py; database/tempo_storage/queue_refresh/reads.py; database/tempo_storage/queue_refresh/application/eligibility.py; database/tempo_storage/repertoire_scope/move_verification.py; affected storage-boundary tests

**Ordered steps**

1. Inventory remaining cross-owner private names at current head; original B01 removed some aliases already. Delete only consumer-free remaining re-exports after migrating test-only SQL assertions.
2. Expose semantic queue attempt lock/availability operations, source-token operation, and bounded presentation-read capability from existing owners; caller supplies facts rather than choosing SQL fragments/private reader internals.
3. Move the live shared eligibility/reset calls to a narrow public storage surface while retaining SQL and exact lock/order semantics. Do not rename every internal constant public.
4. Rewrite affected boundary tests to assert semantic outcomes and sequencing; retain exact SQL tests within storage owner where meaningful.
5. Attach final allowlist/caller search, including changed aliases and intentionally private names used solely within an owner.

**Acceptance and stop condition**

- Backend no longer imports storage underscore names for these seams or passes private SQL fragments to substitute a store.
- Current active eligibility, queue attempt, and bounded reads preserve behavior; shared live helpers survive bulk cleanup.
- BE005 still waits Redis tasks B10/B11; no claim that removing imports alone encapsulates active capabilities.

**Selected commands (planned, not executed)**

- `make python-file FILE=backend/tests/test_queue_command_database_split.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_queue_refresh_read_database_split.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_queue_application_database_split.py` — Makefile:109-111; existing file

**Integration handoff**

- Reuse relevant native queue proof when lock predicates or read semantics change; no new browser requirement for source-equivalent adapter exposure.

**Required small worker batches**

- B09-1: Encapsulate actual card lock/availability capability; migrate private SQL test seams. Files: backend/app/queue_commands.py, database/tempo_storage/commands/queue.py, backend/tests/test_queue_command_database_split.py.
- B09-2: Public active eligibility and bounded-read APIs; preserve actual SQL/order. Files: backend/app/services/queue_application.py, backend/app/services/postgres_queue_refresh.py, database/tempo_storage/queue_refresh/reads.py, database/tempo_storage/queue_refresh/application/eligibility.py, backend/tests/test_queue_refresh_read_database_split.py, backend/tests/test_queue_application_database_split.py.
- B09-3: Expose source token semantic operation and remove only proven dead residual SQL re-exports. Files: backend/app/services/repertoire_move_verification.py, database/tempo_storage/repertoire_scope/move_verification.py, backend/app/services/durable_tasks.py.

**Main risk:** Exact source-token module must be located first; path is not guessed as an implemented target.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## B10 — Encapsulate Redis admission keys and lease policy in current storage owner

**Scope:** BE005; milestone `whole-audit`; phase `3-public-interfaces`; gate `native`.

**Prerequisites:** None.

**Read first:** backend/app/services/redis_admission_gate.py; backend/app/services/study_priority.py:control_snapshot; database/tempo_storage/redis_control/admission.py; backend/tests/test_legacy_redis_control_database_split.py; backend/tests/test_redis_admission_fixture.py

**Write paths:** backend/app/services/redis_admission_gate.py; backend/app/services/study_priority.py; database/tempo_storage/redis_control/admission.py; backend/tests/test_legacy_redis_control_database_split.py; backend/tests/test_redis_admission_fixture.py

**Ordered steps**

1. Give existing admission storage named acquire/renew/release/presence/telemetry operations that own keys, Lua scripts and fixed lease durations.
2. Keep async/thread lifetime, request timing and BackgroundAdmissionDeferred policy in application. If renewal cadence needs a value, expose a documented semantic lease contract rather than private key constants.
3. Replace study_priority direct foreground-key use with public telemetry/presence capability; preserve fail-closed admission and actual foreground_wait distinction.
4. Remove now-unused private script re-exports only after their tests migrate inside storage.
5. Use current deterministic Redis call-order tests and owned Redis fixture for expiry/renewal/release interference.

**Acceptance and stop condition**

- Application sees no _FOREGROUND_KEY/_BACKGROUND_KEY/private Lua source. Storage owns namespace and lease values.
- Failed Redis admission remains an unavailable/deferred boundary, never new success; browser activity lease and unrelated tokens remain intact.
- Required Redis isolation proof executes on an owned fixture with original resource caps.

**Selected commands (planned, not executed)**

- `make python-file FILE=backend/tests/test_legacy_redis_control_database_split.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_redis_admission_fixture.py` — Makefile:109-111; existing file

**Integration handoff**

- Existing --native-check redis-fixture-isolation can be batched with final native selection.

**Main risk:** Do not turn this encapsulation into a concurrency increase, new lease protocol, or unified application/storage runtime.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## B11 — Encapsulate wake ownership keys without changing broker protocol

**Scope:** BE005; milestone `whole-audit`; phase `3-public-interfaces`; gate `caller`.

**Prerequisites:** None.

**Read first:** backend/app/services/background_wakes.py:ownership_keys,consume_wake,CoalescedWakeTask; database/tempo_storage/redis_control/wake_runtime/wakes.py; backend/app/services/background_runtime.py; backend/tests/test_background_wakes.py; backend/tests/test_legacy_wake_runtime_database_split.py

**Write paths:** backend/app/services/background_wakes.py; database/tempo_storage/redis_control/wake_runtime/wakes.py; backend/tests/test_background_wakes.py; backend/tests/test_legacy_wake_runtime_database_split.py

**Ordered steps**

1. Move prefix selection into public storage ownership_keys(task_name); preserve exact persisted Redis key bytes.
2. Keep broker message/channel publishing at its current owner. Remove remaining private _RESERVE/_ABORT aliases only after migrating their legitimate tests to storage.
3. Verify current background_runtime already uses its public diagnostic capability; record no-change disposition for previously removed aliases instead of rewriting it.
4. Test reserve/publish/consume/abort and latest-token fences with stale token, lost ack, upgrade-marked queue refresh and unrelated tasks.
5. Record every remaining BE005 audit row as removed, public capability, or legitimate within-owner implementation.

**Acceptance and stop condition**

- No cross-owner use of storage private wake keys/scripts remains.
- Original headers/key names and tokenless historical message semantics unchanged; latest owner token cannot be removed by stale delivery.
- B09/B10/B11 together cover BE005 including original partial cleanup.

**Selected commands (planned, not executed)**

- `make python-file FILE=backend/tests/test_background_wakes.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_legacy_wake_runtime_database_split.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_queue_refresh_wakeup.py` — Makefile:109-111; existing file

**Integration handoff**

- Use existing Redis native wake proof only if script/publication behavior changes; byte-identical wrapper encapsulation requires caller proof.

**Main risk:** Do not classify Kombu implementation overrides as storage private APIs merely because their names start with underscore.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## B12 — Type next-exercise facts, head identity and issuance variants

**Scope:** BE002; milestone `whole-audit`; phase `3-public-interfaces`; gate `pure`.

**Prerequisites:** None.

**Read first:** backend/app/study/next_exercise.py:QueueReadSnapshot,issue_returned_head,next_exercise; backend/app/contracts/queue_issuance.py:NextExerciseOutcome; backend/app/services/queue_next_card.py:PreparedQueueHead; backend/tests/test_next_exercise_application.py; backend/tests/test_next_exercise_issuance.py

**Write paths:** backend/app/study/next_exercise.py; backend/app/contracts/queue_issuance.py; backend/app/services/queue_next_card.py (PreparedQueueHead shape only); backend/tests/test_next_exercise_application.py; backend/tests/test_next_exercise_issuance.py; backend/tests/test_next_exercise_import_boundary.py; backend/tests/typing/next_exercise_contract.py (proposed scoped typing fixture)

**Ordered steps**

1. Define exact immutable identity/projection/diagnostic and issued/replay/hold variants for fields the application actually reads. Reuse issued-plan contract types; keep optional transport extension data at edge.
2. Replace unrestricted mode strings and object proposal with accurate discriminated variants. Do not turn a dataclass wrapping Any into a claimed typed boundary.
3. Type each injected capability and its return, including current-head and replay. Make mutation/finalization responsibilities explicit or return fresh values while preserving old wire behavior.
4. Update existing independent in-memory fixture to implement same interface and test missing identity/revision, invalid mode, held plan, and changed day/head.
5. Leave concrete HTTP conversion to B13 and mark temporary adapters clearly until that task lands.
6. After behavior is correct, run the scoped typing fixture with real production and independent fake bindings. Inspect errors and fix contract annotations/adapters; do not suppress errors to manufacture substitutability.

**Acceptance and stop condition**

- Core next_exercise imports neither FastAPI nor storage nor composition; actual production caller and independent fake use the same annotated capabilities.
- Malformed required facts cannot produce ready; head/current-day revalidation and immutable conflict distinctions unchanged.
- No claim of compiler type-check pass unless a real checker ran; current repository has no configured mypy/pyright gate.
- Actual production binding and independent fake pass the scoped static typing check; deliberate incompatible implementation fails it. Checker/version/command/error output are retained. Runtime tests alone do not satisfy this criterion.

**Selected commands (planned, not executed)**

- `make python-file FILE=backend/tests/test_next_exercise_application.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_next_exercise_issuance.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_next_exercise_import_boundary.py` — Makefile:109-111; existing file
- `python -m mypy --strict --follow-imports=silent --no-incremental backend/app/contracts/queue_issuance.py backend/app/study/next_exercise.py backend/tests/typing/next_exercise_contract.py` — PROPOSED acceptance command, not an existing configured repository runner; targets inspected and fixture proposed; pinned checker must be provisioned by owner first.

**Main risk:** Do not type every flat HTTP field by rebuilding the whole API. Type the domain facts and translate at the edge.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## B13 — Use typed next-exercise capabilities and remove HTTP closure side channel

**Scope:** BE002; milestone `whole-audit`; phase `3-public-interfaces`; gate `caller`.

**Prerequisites:** B12, B05

**Read first:** backend/app/product_composition/study.py:_issue_facts,_render_outcome,queue_next_exercise; backend/app/study/queue_serving.py; backend/app/services/queue_next_card.py; backend/tests/test_next_exercise_http.py; backend/tests/test_next_exercise_snapshot.py

**Write paths:** backend/app/product_composition/study.py; backend/app/study/queue_serving.py (translation only); backend/app/services/queue_next_card.py (adapter output); backend/tests/test_next_exercise_http.py; backend/tests/test_next_exercise_snapshot.py; backend/tests/test_next_exercise_native.py; backend/tests/typing/next_exercise_contract.py (proposed scoped typing fixture)

**Ordered steps**

1. Translate detached storage facts into B12 typed values before policy; convert typed outcome back to existing flat queue at render boundary.
2. Replace nonlocal JSONResponse transport storage with an explicit typed edge dispatch outcome carrying operation identity and required transport metadata; domain receives only semantic pending/unavailable facts.
3. Preserve original 202 operation id, response body/headers and non-202 dispatcher failures; do not reinterpret arbitrary failures as foreground denial.
4. Exercise all ready/empty/held/unavailable/pending branches with real composition callbacks and exact current wire snapshots.
5. Run owned next-exercise native replay/rollback test after fixture changes; integration owner schedules final saved-review to playable-next once.
6. After behavior is correct, run the scoped typing fixture with real production and independent fake bindings. Inspect errors and fix contract annotations/adapters; do not suppress errors to manufacture substitutability.

**Acceptance and stop condition**

- No hidden HTTP response side channel crosses the application boundary.
- Current three queue routes retain flat envelopes and header/operation recovery behavior; no absent field masquerades as success.
- Original issued position plan replays without source reconstruction; held/missing manifest remains held.
- Actual production binding and independent fake pass the scoped static typing check; deliberate incompatible implementation fails it. Checker/version/command/error output are retained. Runtime tests alone do not satisfy this criterion.

**Selected commands (planned, not executed)**

- `make python-file FILE=backend/tests/test_next_exercise_http.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_next_exercise_snapshot.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_next_exercise_native.py` — Makefile:109-111; existing file
- `python -m mypy --strict --follow-imports=silent --no-incremental backend/app/contracts/queue_issuance.py backend/app/study/next_exercise.py backend/app/product_composition/study.py backend/tests/typing/next_exercise_contract.py` — PROPOSED acceptance command, not an existing configured repository runner; targets inspected and fixture proposed; pinned checker must be provisioned by owner first.

**Integration handoff**

- Native original-plan rollback/replay and one release queue browser journey because assembly/issuance is touched.

**Main risk:** A pending transport is not an empty queue; an immutable hold is not a fresh operation.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## B14 — Type Learning schedule and reconciliation port values

**Scope:** BE008; milestone `whole-audit`; phase `3-public-interfaces`; gate `pure`.

**Prerequisites:** B06

**Read first:** services/learning/application/src/tempo_learning_review/models.py; services/learning/application/src/tempo_learning_review/ports.py; services/learning/application/src/tempo_learning_review/application.py:apply_review; backend/app/services/learning_review_adapter.py:schedule,record_position_review,schedule_snapshot,reconcile_completed; backend/app/study/policy/scheduling_review_contracts.py:SchedulingReviewResult,CardState

**Write paths:** services/learning/application/src/tempo_learning_review/models.py; services/learning/application/src/tempo_learning_review/ports.py; services/learning/application/src/tempo_learning_review/application.py (schedule/reconciliation use only); backend/app/services/learning_review_adapter.py (schedule/reconciliation adapters); services/learning/application/tests/test_application.py; services/learning/application/tests/typing/review_store_contract.py (proposed scoped typing fixture)

**Ordered steps**

1. List exact schedule/reconciliation fields read by apply_review: state,requeue_today,requeue_after_cards,review_id,identity,due and recorded result metadata.
2. Define narrow immutable values in independent Learning package; reuse existing same-owner shapes where possible, but never import backend scheduling contracts into independent library.
3. Translate existing scheduling owner result at backend adapter. Explicitly distinguish position human-review recording from physical scheduling; preserve snapshot/receipt wire bytes.
4. Update ReviewStore and independent memory store, then actual adapter. Use paired tests for ordinary schedule, position schedule-noop, queue-origin reconciliation and recorded receipt replay.
5. Do not broaden scheduling math, calendar capture or grade-effect policy while typing results.
6. After behavior is correct, run the scoped typing fixture with real production and independent fake bindings. Inspect errors and fix contract annotations/adapters; do not suppress errors to manufacture substitutability.

**Acceptance and stop condition**

- Learning policy no longer relies on opaque schedule/reconciliation dictionaries or implicit required keys.
- Alternative store supplies same annotated capabilities without importing backend/storage; missing required value fails at boundary.
- Recorded review remains distinct from current day and existing receipt raw bytes roundtrip unchanged.
- Actual production binding and independent fake pass the scoped static typing check; deliberate incompatible implementation fails it. Checker/version/command/error output are retained. Runtime tests alone do not satisfy this criterion.

**Selected commands (planned, not executed)**

- `python services/learning/application/run_suite.py application` — entrypoint/options inspected; any proposed new selection is stated in acceptance
- `make python-file FILE=backend/tests/test_position_review_reconciliation.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_scheduling_review_application.py` — Makefile:109-111; existing file
- `python -m mypy --strict --follow-imports=silent --no-incremental services/learning/application/tests/typing/review_store_contract.py` — PROPOSED acceptance command, not an existing configured repository runner; targets inspected and fixture proposed; pinned checker must be provisioned by owner first.

**Main risk:** A second SchedulingReviewResult authority would duplicate policy. Independent package owns its port value and adapters translate from actual scheduling owner.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## B15 — Type Learning submission, completion and final result contracts

**Scope:** BE008; milestone `whole-audit`; phase `3-public-interfaces`; gate `caller`.

**Prerequisites:** B14

**Read first:** services/learning/application/src/tempo_learning_review/application.py:submit_review; services/learning/application/src/tempo_learning_review/models.py:ReviewResult,EvidenceCompletion; services/learning/application/src/tempo_learning_review/ports.py:ReviewSubmissionStore; backend/app/services/learning_review_adapter.py:completion/continuation methods

**Write paths:** services/learning/application/src/tempo_learning_review/models.py; services/learning/application/src/tempo_learning_review/ports.py; services/learning/application/src/tempo_learning_review/application.py (submission/result paths); backend/app/services/learning_review_adapter.py; services/learning/application/tests/test_application.py; backend/tests/test_opening_evidence_contracts.py; services/learning/application/tests/typing/review_store_contract.py (proposed scoped typing fixture)

**Ordered steps**

1. Replace ReviewResult-as-arbitrary-JSON with explicit current result/completion/continuation values and an explicit opaque original-receipt representation for replay.
2. Type competing review, completion callbacks, receipt save and continuation facts; remove mixed booleans/implicit dictionaries where variants have materially different authority.
3. Preserve exact original payload/result JSON for idempotency binding; only current newly created results use declared serialization. Unknown retained receipt fields are preserved at replay edge rather than silently dropped.
4. Update backend adapter and independent memory submission store together. Test evidence mismatch, retired original attempt, pending continuation, same operation replay and different payload conflict.
5. Run installed Learning tooling/library check only for relevant changed package inputs; final native review/assembled proof belongs to integration.
6. After behavior is correct, run the scoped typing fixture with real production and independent fake bindings. Inspect errors and fix contract annotations/adapters; do not suppress errors to manufacture substitutability.

**Acceptance and stop condition**

- Port and policy have explicit final result and completion/continuation requirements; opaque historical bytes are isolated and named.
- A missing or incomplete evidence result cannot authorize grade, receipt or prepared continuation.
- Existing wire field presence/defaults and exact stored receipts are preserved; no discarded unknown historical fields.
- Actual production binding and independent fake pass the scoped static typing check; deliberate incompatible implementation fails it. Checker/version/command/error output are retained. Runtime tests alone do not satisfy this criterion.

**Selected commands (planned, not executed)**

- `python services/learning/application/run_suite.py application` — entrypoint/options inspected; any proposed new selection is stated in acceptance
- `python services/learning/application/run_suite.py tooling` — entrypoint/options inspected; any proposed new selection is stated in acceptance
- `make python-file FILE=backend/tests/test_opening_evidence_contracts.py` — Makefile:109-111; existing file
- `python -m mypy --strict --follow-imports=silent --no-incremental services/learning/application/src/tempo_learning_review/models.py services/learning/application/src/tempo_learning_review/ports.py backend/app/services/learning_review_adapter.py services/learning/application/tests/typing/review_store_contract.py` — PROPOSED acceptance command, not an existing configured repository runner; targets inspected and fixture proposed; pinned checker must be provisioned by owner first.

**Integration handoff**

- Coordinate original grade/receipt/continuation native cases and single release saved-review journey; no full browser qualification for pure model declaration alone.

**Main risk:** Typed parsing must not rewrite historical result JSON, JSON ordering/digest bindings, or receipt identity.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## B16 — Make review failures transport-neutral and preserve durable wire errors

**Scope:** BE007; milestone `whole-audit`; phase `3-public-interfaces`; gate `caller`.

**Prerequisites:** B15, B08

**Read first:** backend/app/contracts/review_conflicts.py; services/learning/application/src/tempo_learning_review/errors.py; backend/app/services/learning_review_adapter.py:translate_failure; backend/app/command_gateway.py:execute_command error serialization; backend/app/command_dispatch.py:dispatch_command; backend/app/study/policy/review_reconciliation.py; backend/app/study/position_checkpoint.py:evidence_error

**Write paths:** backend/app/contracts/review_conflicts.py; services/learning/application/src/tempo_learning_review/errors.py; services/learning/application/src/tempo_learning_review/application.py (error constructors); backend/app/services/learning_review_adapter.py (error adapter); backend/app/command_gateway.py; backend/app/command_dispatch.py; backend/app/study/policy/review_reconciliation.py; backend/app/study/position_checkpoint.py (only error construction); backend/tests/test_legacy_control_database_split.py; backend/tests/test_study_attempt_guard.py; backend/tests/test_opening_evidence_contracts.py; backend/tests/test_queue_head_issuance_coalescing.py

**Ordered steps**

1. Use one review error declaration owner in the independent Learning package and identity-preserving backend aliases; do not introduce two parallel transport-neutral ReviewConflict classes.
2. Define stable semantic failure categories/codes with message/details and retryability; ReviewConflict no longer inherits HTTPException and Learning errors no longer require status numbers.
3. Central transport/command receipt edge maps these exact categories to existing HTTP status/detail/code/retryable values. Preserve old receipt decoding including numeric status_code.
4. Replace review reconciliation/checkpoint domain raises with semantic errors; retain scope-specific messages and structured evidence detail.
5. Update non-HTTP worker tests and cold import test blocking FastAPI; verify command rollback saves a definitive original failure receipt.
6. Run current queue issuance retry selection against mapped errors so only the same retryable head-change family increments generation.

**Acceptance and stop condition**

- Public domain contracts import with FastAPI blocked; semantic conflict/hold/unavailable distinctions are usable without HTTP integers.
- Existing completed/failed operation JSON and browser recovery observe same status/code/message/retryable shape.
- No error becomes generic success or accidental infinitely retryable task.

**Selected commands (planned, not executed)**

- `python services/learning/application/run_suite.py application` — entrypoint/options inspected; any proposed new selection is stated in acceptance
- `make python-file FILE=backend/tests/test_queue_head_issuance_coalescing.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_opening_evidence_contracts.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_command_registry_contract.py` — Makefile:109-111; existing file

**Integration handoff**

- Affected browser failure/operation recovery cases already owned by final assembled qualification; only rerun for changed actual wire outcomes.

**Required small worker batches**

- B16-1: One neutral review failure owner and compatibility aliases; map through existing adapter. Files: services/learning/application/src/tempo_learning_review/errors.py, services/learning/application/src/tempo_learning_review/application.py, backend/app/contracts/review_conflicts.py, backend/app/services/learning_review_adapter.py.
- B16-2: Preserve durable old status/code/detail/retry serialization and only intended retry families. Files: backend/app/command_gateway.py, backend/app/command_dispatch.py, backend/tests/test_legacy_control_database_split.py, backend/tests/test_queue_head_issuance_coalescing.py.
- B16-3: Convert exact domain raise sites to neutral errors with old wire mapping; retain atomic receipt/rollback. Files: backend/app/study/policy/review_reconciliation.py, backend/app/study/position_checkpoint.py, backend/tests/test_opening_evidence_contracts.py, backend/tests/test_study_attempt_guard.py.

**Main risk:** Gateway catches HTTPException today. Domain change must ship with edge mapping atomically or errors become 500/unclassified.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## B17 — Remove HTTP errors from remaining retained authoring and Study policies

**Scope:** BE007; milestone `whole-audit`; phase `3-public-interfaces`; gate `caller`.

**Prerequisites:** B16, B27, B29

**Read first:** backend/app/pgn_import_validation.py:validate_sources; backend/app/services/canonical_prefix.py:ensure_line_in_scope,ensure_batch_lines_in_scope; backend/app/services/repertoire_move_verification.py:verify_repertoire_move; backend/app/services/study_attempts.py:finish_study_attempt; backend/app/services/study_mode.py:study_only_enabled

**Write paths:** backend/app/pgn_import_validation.py; backend/app/services/canonical_prefix.py; backend/app/services/repertoire_move_verification.py; backend/app/services/study_attempts.py; backend/app/services/study_mode.py; backend/app/main.py:repertoire_move_membership (edge mapping only); backend/app/command_gateway.py (reuse semantic failure mapping); backend/app/tasks.py (Study mode failure boundary only); backend/tests/test_repertoire_import_boundary.py; backend/tests/test_canonical_repertoire_prefix.py; backend/tests/test_study_calendar.py

**Ordered steps**

1. For each named raise, use B16 neutral failure values and map only at current command/HTTP entrypoint. Keep validation/location diagnostics and structured repertoire conflict data intact.
2. Do not remove FastAPI from genuine transport/command request decoders merely to satisfy a filename heuristic; scope is domain/application policy listed in BE007.
3. Preserve bounded replay deadline, absent policy fail-closed behavior, missing exercise/card distinction and canonical-scope guard.
4. Add one non-HTTP consumer test per failure family and parameterized mapper assertions for current HTTP 409/422/404/503 shapes.
5. Import pure policy/contracts with transport blocked and attach residual scan with justified transport-layer exceptions.

**Acceptance and stop condition**

- Every BE007 nontransport raise has neutral semantics; supported transport callers maintain original response/retry contracts.
- No stale source or unavailable policy is converted to empty/valid data.
- No change in source validation or exercise grading policy beyond the separately approved tasks.

**Selected commands (planned, not executed)**

- `make python-file FILE=backend/tests/test_repertoire_import_boundary.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_canonical_repertoire_prefix.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_study_calendar.py` — Makefile:109-111; existing file

**Required small worker batches**

- B17-1: Neutral errors only after shared kernel and retired Coverage decision. Files: backend/app/pgn_import_validation.py, backend/app/services/canonical_prefix.py, backend/tests/test_repertoire_import_boundary.py, backend/tests/test_canonical_repertoire_prefix.py.
- B17-2: Keep worker unavailable-policy and completion semantics without HTTP dependency. Files: backend/app/services/study_attempts.py, backend/app/services/study_mode.py, backend/app/tasks.py, backend/tests/test_study_calendar.py.
- B17-3: Preserve foreground deadline/source-currentness errors at actual transport edge. Files: backend/app/services/repertoire_move_verification.py, backend/app/main.py, backend/app/command_gateway.py.

**Main risk:** Error neutralization must not absorb legality semantics changes from B28–30; consume released kernel/mapper first.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## B18 — Export explicit core Study and Tactics command descriptors

**Scope:** BE009; milestone `whole-audit`; phase `4-registration`; gate `caller`.

**Prerequisites:** B02, B03, B16, B22, B31, B09

**Read first:** backend/app/contracts/command_registry.py:CommandDescriptor,CommandRegistry; backend/app/queue_commands.py; backend/app/review_commands.py; backend/app/study_attempt_commands.py; backend/app/tactic_commands.py; backend/app/tasks.py:opening_evidence.checkpoint registration

**Write paths:** backend/app/queue_commands.py; backend/app/review_commands.py; backend/app/study_attempt_commands.py; backend/app/tactic_commands.py; backend/app/contracts/command_registry.py (only typed descriptor helper if needed); backend/tests/test_command_registry_contract.py

**Ordered steps**

1. Represent existing core commands as immutable descriptor tuples or explicit register_into(registry) functions owned by each module; preserve names, preparers, original payload decoding, and after_commit behavior.
2. Move standalone checkpoint descriptor to its current Study composition, not an implicit statement in tasks.py.
3. Do not register on import in the final candidate. Stage source changes with B21 assembly so an intermediate missing registry is never shipped.
4. Use two fresh registries in tests; importing each owner does not mutate either, explicit registration installs exactly expected commands, duplicate names still fail.
5. Trace recovery for persisted core names and any registered decoder/preparer from existing command registry tests.

**Acceptance and stop condition**

- Core command import is inert; explicit registry registration is sufficient for queue/review/checkpoint/Tactics/frozen-exercise commands.
- Original names, operation digest and after-commit wake semantics unchanged.
- Do not merge this partial switch alone if production composition has not adopted it.

**Selected commands (planned, not executed)**

- `make python-file FILE=backend/tests/test_command_registry_contract.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_opening_evidence_command_registration.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_http_command_registration_boundary.py` — Makefile:109-111; existing file

**Main risk:** Deleting eager imports before explicit registration would strand durable queued commands; B21 is the integration commit.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## B19 — Export explicit authoring mutation command descriptors

**Scope:** BE009; milestone `whole-audit`; phase `4-registration`; gate `caller`.

**Prerequisites:** B24, B25, B27, B30, B17

**Read first:** backend/app/analysis_paste_commands.py; backend/app/branch_commands.py; backend/app/pgn_import_commands.py; backend/app/prefix_split_commands.py; backend/app/card_commands.py; backend/app/integrity_repair_commands.py

**Write paths:** backend/app/analysis_paste_commands.py; backend/app/branch_commands.py; backend/app/pgn_import_commands.py; backend/app/prefix_split_commands.py; backend/app/card_commands.py; backend/app/integrity_repair_commands.py; backend/tests/test_http_command_registration_boundary.py

**Ordered steps**

1. For exactly these six modules, replace import-time registration statements with explicit owner descriptors using existing registry API.
2. Preserve preparer/apply pairs for imports, repairs and card changes; immutable command names and old payload decoders remain selected for supported commands.
3. Keep retired Coverage fields handled by B27 rejection and retired commands in RETIRED_COMMANDS; do not revive retired handlers to fill a name table.
4. Test import leaves a fresh registry unchanged, explicit registration has exact names and duplicate rejection, and decode/preparation errors still reach the same owner boundary.
5. Hand descriptors and exact name list to B21; no shared tasks.py/main.py edits in this leaf.

**Acceptance and stop condition**

- Six authoring modules have no import-time global registry mutation in final integrated tree.
- Their current executable descriptor behavior matches prior handlers and preserved preparers.
- Core Study assembly need not import this family to recover an essential review.

**Selected commands (planned, not executed)**

- `make python-file FILE=backend/tests/test_http_command_registration_boundary.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_command_registry_contract.py` — Makefile:109-111; existing file

**Main risk:** Do not merge side-effect removal before B21. Independent worker only owns descriptor declarations and tests.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## B20 — Export remaining retained control command descriptors

**Scope:** BE009; milestone `whole-audit`; phase `4-registration`; gate `caller`.

**Prerequisites:** B02, B23

**Read first:** backend/app/activity_commands.py; backend/app/annotation_commands.py; backend/app/teaching_commands.py; backend/app/repertoire_commands.py; backend/app/settings_commands.py

**Write paths:** backend/app/activity_commands.py; backend/app/annotation_commands.py; backend/app/teaching_commands.py; backend/app/repertoire_commands.py; backend/app/settings_commands.py; backend/tests/test_settings_descriptor.py

**Ordered steps**

1. Use existing Settings CommandDescriptor unchanged as template; expose it without auto-registering.
2. Convert exactly other four modules to explicit descriptors/register_into function. Preserve settings post-commit policy hook and retained activity/teaching/annotation payload names.
3. Keep repertoire deletion composition pointed to B23 Study-owned retirement capability.
4. Test independent registry import/registration and settings completed receipt replay; no retired provider side effects.
5. Release the control name list to B21; do not touch process assembly here.

**Acceptance and stop condition**

- Control owner imports do not mutate default gateway registry.
- Explicit current controls register once and preserve command names/hook behavior.
- No implicit source-to-composition import is introduced.

**Selected commands (planned, not executed)**

- `make python-file FILE=backend/tests/test_settings_descriptor.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_command_registry_contract.py` — Makefile:109-111; existing file

**Main risk:** Settings hook ordering is consequential even when registration looks like a structural edit.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## B21 — Compose explicit supported command sets and isolate essential startup

**Scope:** BE009; milestone `whole-audit`; phase `4-registration`; gate `assembled`.

**Prerequisites:** B18, B19, B20, B31, P06

**Read first:** backend/app/tasks.py:imports and command registration; backend/app/command_gateway.py:_registry,_handlers,_preparers; backend/app/main.py:router imports and app construction; backend/app/product_composition/README.md; backend/app/contracts/command_registry.py

**Write paths:** backend/app/tasks.py; backend/app/command_gateway.py (composition injection only); backend/app/main.py (integration-owned imports/mounts); backend/app/product_composition/command_registration.py (proposed); backend/tests/test_worker_command_registration_boundary.py; backend/tests/test_http_command_registration_boundary.py; backend/tests/test_explicit_product_composition.py; backend/app/product_composition/README.md; docs/architecture/diagrams/study-games.md

**Ordered steps**

1. Compose fixed essential Study, retained controls/authoring and minimal Game Review route sets through existing root; do not add a plugin discovery framework or dynamic import-by-user-name.
2. Make actual essential worker/API startup avoid optional Games and unused authoring imports. Existing worker command dispatch/recovery resolves a command only through the fixed declared family/name table; it loads that retained family at its dispatch boundary, after retired/unknown rejection. Preserve all retained UI/recovery commands without requiring all authoring families before the first essential review. No new process, queue, mode, plugin discovery or import-by-user-string.
3. Remove import-time register calls from released descriptor families and replace worker checkpoint statement. Keep compatibility registry maps only as private executor implementation, not domain imports.
4. Cold subprocess tests block optional provider/retired Games imports and prove essential Study registration/recovery. Duplicate/unknown/retired names have their existing outcomes.
5. Run a current assembled queue/save/recovery test once with optional family absent; attach exact command inventory and update current assembly drawing.

**Acceptance and stop condition**

- Domain/contract/command owner imports are inert. Essential registration supplies review/queue/checkpoint recovery without optional imports.
- Production root still supplies every supported current name, including frozen attempts and prefix split; persisted names do not change.
- No broker/provider/database startup occurs from importing public contract/descriptor modules.

**Selected commands (planned, not executed)**

- `make python-file FILE=backend/tests/test_worker_command_registration_boundary.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_http_command_registration_boundary.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_explicit_product_composition.py` — Makefile:109-111; existing file

**Integration handoff**

- Single combined startup/isolation/review-to-next proof for the release; do not spawn extra services or parallel native stacks.

**Main risk:** Core descriptors can still import authoring through helper modules. Trace transitive startup imports; do not mistake renamed eager imports for isolation.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## B22 — Move standalone tactic schedule and queue transitions behind Study capability

**Scope:** BE010; milestone `whole-audit`; phase `2-study-ownership`; gate `native`.

**Prerequisites:** B03

**Read first:** backend/app/tactic_commands.py:submit_tactic_attempt; backend/app/study/interfaces/captured_tactic.py; backend/app/product_composition/tactic_capture.py; database/tempo_storage/tactics/attempts.py; backend/app/study/queue_placement.py:ensure_card_queued_after; backend/tests/test_study_calendar.py:test_tactic_attempt_lock_due_and_queue_share_capture_and_replay_retains_receipt

**Write paths:** backend/app/tactic_commands.py; backend/app/study/interfaces/tactic_attempt.py (proposed); backend/app/study/tactic_attempt_admission.py (proposed); backend/app/product_composition/tactic_attempt.py (proposed focused borrowed adapter); database/tempo_storage/tactics/attempts.py; database/tempo_storage/study/tactic_attempts.py (proposed); backend/tests/test_study_calendar.py; backend/tests/test_tactic_attempt_admission.py (proposed)

**Ordered steps**

1. Define validated immutable attempt facts and result; producer owns puzzle/source validation, progress/source receipt identity, Study owns scheduling/card creation/reopen/queue decision.
2. Preserve lock order daily tactic admission → puzzle attempt replay → card → queue day. Receipt replay returns before new scheduling effect.
3. Move exact light first due, nonclean reopen and failed guided-after-four behavior into Study owner; move card/queue SQL into Study storage with caller-owned transaction.
4. Keep progress/admission-mode/source receipt updates on same transaction, using actual Study result. Do not reinterpret clean/correct or regenerate IDs.
5. Test clean first pass, correct assisted, incorrect, existing light/normal card, exact retry/different attempt, and injected receipt failure rollback.

**Acceptance and stop condition**

- No Tactics producer chooses Study schedule columns or queues directly; both capture and packaged/historical attempts consume declared Study capabilities.
- Captured day/instant and original receipt byte behavior unchanged; one logical attempt has one effect.
- Owned native rollback and concurrent/replayed attempt proof executes; Tactics remains usable when optional Games is absent.

**Selected commands (planned, not executed)**

- `make python-file FILE=backend/tests/test_study_calendar.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_tactic_capture_boundary.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_tactic_attempt_admission.py` — Makefile:109-111; proposed test file must be added by this task

**Integration handoff**

- One final Tactics attempt → saved result → guided/playable queue path, batched with release qualification.

**Main risk:** Tactic progress and source receipt are producer-owned; moving all Tactics persistence into Study would invert ownership again.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## B23 — Give Study the transaction-bound card retirement and evidence purge capability

**Scope:** BE011; milestone `whole-audit`; phase `2-study-ownership`; gate `native`.

**Prerequisites:** P03

**Read first:** backend/app/card_deletion.py:purge_card_data,_purge_opening_evidence,delete_repertoire_data,permanent_delete_card; backend/app/study/policy/observation_summary.py:observation_counts; database/tempo_storage/authored_repertoires/card_deletion/storage.py; backend/tests/test_card_deletion_storage_boundary.py; database/tests/check_postgres_deletion.py

**Write paths:** backend/app/card_deletion.py (purge delegation only); backend/app/study/card_retirement.py (proposed); database/tempo_storage/authored_repertoires/card_deletion/storage.py; database/tempo_storage/study/card_retirement.py (proposed); backend/tests/test_card_deletion_storage_boundary.py; backend/tests/test_observation_summary.py; database/tests/check_postgres_deletion.py (coordinate proof owner)

**Ordered steps**

1. Separate content disposition from training purge. Repertoire retains which cards lose final membership, learned keep/delete choice, retained/shared ownership, graph reparenting and task cancellation.
2. Expose Study removal command accepting explicit card IDs/disposition and captured clock on borrowed transaction. Move training/evidence/queue retirement orchestration and associated exact SQL under Study owner.
3. Keep Tactics source-specific attempt cleanup behind its existing narrow adapter if ownership warrants; Study calls producer cleanup capability rather than becoming owner of puzzle source semantics. Preserve current stored data behavior.
4. Reuse existing observation_counts with identical count order, int conversion, surviving observations and distinct clean-day sets; do not rewrite already-correct B02 helper.
5. Preserve immutable review/admission/operation receipts and tombstones. Native deletion proof checks keep/shared/delete, exact-match cancellation, stale recreate rejection, surviving evidence and injected failure rollback in one transaction.

**Acceptance and stop condition**

- Content deletion submits semantic identities/disposition; Study controls training/evidence/queue cleanup, not a renamed Repertoire module.
- Incremental and rebuild counters remain equal; shared/retained cards and original review/receipt history survive exactly as before.
- No schema migration/data cleanup beyond explicit deletion use case; current tombstone/replay contracts preserved.

**Selected commands (planned, not executed)**

- `make python-file FILE=backend/tests/test_card_deletion_storage_boundary.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_observation_summary.py` — Makefile:109-111; existing file

**Integration handoff**

- Use maintained check_postgres_deletion cases under proof owner; no separate full browser suite for pure purge extraction.

**Main risk:** Physical cards bridge content and training. Keep identity/content selection separate from Study lifecycle; no blanket transfer of all deletion SQL.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## B24 — Centralize authored reset/preserve learning transitions with explicit columns

**Scope:** BE012; milestone `whole-audit`; phase `2-study-ownership`; gate `native`.

**Prerequisites:** B33

**Read first:** backend/app/card_commands.py:revise_card; backend/app/repertoire/changes/retained_mutations.py:rewrite_card; backend/app/integrity_repair_commands.py:resolve_integrity_issue; database/tempo_storage/authored_repertoires/card_edits/storage.py; database/tempo_storage/connections.py:card_columns; SPEC.md:S05

**Write paths:** backend/app/card_commands.py (learning transition delegation); backend/app/repertoire/changes/retained_mutations.py:rewrite_card; backend/app/study/card_revision.py (proposed); database/tempo_storage/study/card_revision.py (proposed); database/tempo_storage/authored_repertoires/card_edits/storage.py; backend/tests/test_card_revision_lifecycle.py (proposed)

**Ordered steps**

1. Before editing, list complete current reset/preserve field policies for explicit revision and integrity rewrite. Integration owner resolves any reset-intent discrepancy against SPEC S05; do not simply copy the longer list.
2. Add Study-owned typed reset/preserve transition taking content identity/revision and captured context. Repertoire continues legal move/content/membership selection.
3. Translate explicit declared lifecycle values to fixed storage columns. Remove information_schema/SELECT-star clone behavior from these two callers; unknown future columns cannot silently inherit state.
4. Keep original review transfer, active attempt completion/rebinding, old/new revision history and queue-origin semantics distinct for reset versus preserve.
5. Paired fixtures show equivalent reset intent yields same complete state and preserve retains actual history without fabricated reviews; inject failure after effect to prove rollback.

**Acceptance and stop condition**

- Revision and repair no longer own independent schedule reset lists or copy all physical card fields.
- Reset policy includes explicit FSRS/due/introduction/history-related values with documented intent; preserved histories stay exact.
- A newly added irrelevant storage column cannot alter lifecycle cloning behavior; current native source/revision fencing remains.

**Selected commands (planned, not executed)**

- `make python-file FILE=backend/tests/test_study_calendar.py` — Makefile:109-111; existing file
- `backend/tests/test_retained_mutations_boundary.py (replace retired alias assertions with current owner behavior)` — entrypoint/options inspected; any proposed new selection is stated in acceptance
- `make python-file FILE=backend/tests/test_card_revision_lifecycle.py` — Makefile:109-111; proposed test file must be added by this task

**Integration handoff**

- Existing native card revision/deletion/receipt fixture extended only for changed lifecycle boundary; final user journey once.

**Main risk:** Source reveals inconsistent reset lists but does not alone authorize a policy change. The complete reset choice is finite owner decision before implementation.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## B25 — Move prefix split learning state and queue/history transfer to Study

**Scope:** BE012; milestone `whole-audit`; phase `2-study-ownership`; gate `native`.

**Prerequisites:** B24, P06

**Read first:** backend/app/services/prefix_split.py:apply_prefix_split,_copy_card,_queue_split_followups; database/tempo_storage/authored_repertoires/opening_mutations/prefix_splits.py:copy_card,reassign_reviews,complete_queue_entry,reassign_queue_entry; backend/app/prefix_split_commands.py; database/tests/native-split-pytest.py

**Write paths:** backend/app/services/prefix_split.py; backend/app/study/card_revision.py (B24 owner released); database/tempo_storage/study/card_revision.py; database/tempo_storage/authored_repertoires/opening_mutations/prefix_splits.py; backend/tests/test_prefix_split_lifecycle.py (proposed); database/tests/native_review/test_postgres.py:test_native_split_then_refresh_retains_verified_after_four_placement

**Ordered steps**

1. Keep legal split geometry, content identities, memberships and split receipt in current Repertoire path.
2. Express shortened-preserve and continuation-initial-state as distinct Study transitions built on B24 value/storage boundary; do not treat continuation as equivalent to new never-introduced revision reset.
3. Move review transfer and source queue completion/rebinding/follow-up placement to Study capability preserving captured calendar and existing issued-origin days.
4. Replace copy_card dynamic full-row cloning with explicit content projection plus explicit Study state; remove card_columns if no supported callers remain.
5. Exercise retained source receipt replay, existing continuation collision, protected queued attempt, short-card state/history and rollback on late failure.

**Acceptance and stop condition**

- Prefix authoring does not choose schedule/history/queue state directly; Study owns exact split lifecycle.
- Original split id/revision/reviews/queue origin replay unchanged; no new automatic recombination.
- Exact native prefix-split-placement proof passes and browser route task remains separate from lifecycle policy.

**Selected commands (planned, not executed)**

- `make python-file FILE=backend/tests/test_study_calendar.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_prefix_split_lifecycle.py` — Makefile:109-111; proposed test file must be added by this task

**Integration handoff**

- Existing --native-check prefix-split-placement; one manual prefix-split browser proof owned by P06/P12.

**Main risk:** Continuation is intentionally introduced learning state, unlike a reset to new; preserve that distinction.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## B26 — Remove fictitious position ports and bind accurate current capability surfaces

**Scope:** BE013; milestone `whole-audit`; phase `3-public-interfaces`; gate `caller`.

**Prerequisites:** B00, B07, B08, S01, S02, B12, B14

**Read first:** backend/app/study/position_learning/contracts.py:PositionScheduleReadPort,IssuedPositionAttemptPort,GradeEffectWritePort,PositionOwnerEpochReadPort; backend/app/study/position_learning/issuance.py:issue_in_borrowed_transaction,replay_exact_attempt; backend/app/study/position_learning/grade_effects.py:apply_in_borrowed_transaction; database/tempo_storage/study/position_due_candidates.py:PositionDueCandidateReader; backend/app/queue_commands.py; backend/app/services/queue_next_card.py

**Write paths:** backend/app/study/position_learning/contracts.py; backend/app/study/position_learning/README.md; backend/app/study/interfaces/README.md; actual narrow consumer annotation/adapter locations from B00; backend/tests/test_position_ports.py (proposed); backend/tests/typing/position_ports_contract.py (proposed scoped typing fixture)

**Ordered steps**

1. Delete the four declaration-only misleading Protocols if B00 confirms no supported references; retain shared immutable evidence value re-exports by identity.
2. Document actual current borrowed functions and S01/S02 prepared/fence types. Where a production consumer is injected, use one accurate narrow Protocol/Callable with actual argument/result variants rather than four unused aspirational APIs.
3. Type concrete binding at composition and independent fake at one real consuming application test; no raw database object passed merely by undocumented convention.
4. Test source/owner/queue fence requirements, correct no-commit capability and forbidden import direction through current boundary suite.
5. Attach positive producer/fake/consumer trace showing which real interface replaced each removed promise.
6. After behavior is correct, run the scoped typing fixture with real production and independent fake bindings. Inspect errors and fix contract annotations/adapters; do not suppress errors to manufacture substitutability.

**Acceptance and stop condition**

- No inaccurate unused port remains advertised as implementation-independent API.
- Each retained capability has real production binding and independent consumer proof; opaque seals remain authoritative.
- No new service/repository or generic unit-of-work layer; closure is structural with caller proof.
- Actual production binding and independent fake pass the scoped static typing check; deliberate incompatible implementation fails it. Checker/version/command/error output are retained. Runtime tests alone do not satisfy this criterion.

**Selected commands (planned, not executed)**

- `make python-file FILE=backend/tests/test_position_ports.py` — Makefile:109-111; proposed test file must be added by this task
- `make python-file FILE=backend/tests/test_next_exercise_import_boundary.py` — Makefile:109-111; existing file
- `python -m mypy --strict --follow-imports=silent --no-incremental backend/app/study/position_learning/contracts.py backend/tests/typing/position_ports_contract.py` — PROPOSED acceptance command, not an existing configured repository runner; targets inspected and fixture proposed; pinned checker must be provisioned by owner first.

**Main risk:** Removing stale Protocols is valid only with truthful actual public interface evidence; renaming them unused is not closure.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## B27 — Reject retired Coverage inputs before authoring and remove their storage branch

**Scope:** BE018; milestone `whole-audit`; phase `1-retirement`; gate `caller`.

**Prerequisites:** None.

**Read first:** backend/app/contracts/transport/authored_lines.py:source_gap_id; backend/app/analysis_paste_commands.py:commit_analysis_paste; backend/app/branch_commands.py:add_repertoire_branch; backend/app/services/analysis_paste.py:build_paste_preview,commit_pasted_lines,_resolves_gap; database/tempo_storage/authored_repertoires/analysis_paste.py:coverage_gap,cover_gap; database/tempo_storage/authored_repertoires/branches.py:lock_source_gap,mark_gap_covered

**Write paths:** backend/app/contracts/transport/authored_lines.py; backend/app/analysis_paste_commands.py; backend/app/branch_commands.py; backend/app/services/analysis_paste.py; database/tempo_storage/authored_repertoires/analysis_paste.py; database/tempo_storage/authored_repertoires/branches.py; backend/app/main.py (preview/commit input adapter only; coordinate owner); backend/tests/test_retired_coverage_inputs.py (proposed)

**Ordered steps**

1. Keep accepted terminal operation replay at gateway before fresh decode. For new requests or unfinished legacy gap-bearing commands, return one deterministic retired-feature response before any source/content/storage write.
2. Retain source_gap_id only as an explicitly rejected compatibility input where necessary to recognize old bytes; do not silently ignore it or reinterpret the operation as gap-free.
3. Apply same guard to preview, paste commit and branch add; verify payload original identity remains retained on failed operation.
4. Remove _resolves_gap and now-unreferenced Coverage SELECT/UPDATE operations from authoring storage; ordinary content paths no longer require Coverage tables.
5. Test missing/null gap normal behavior, valid-looking old gap, malformed old gap, completed old receipt replay, and zero partial writes for rejection.

**Acceptance and stop condition**

- No retained edit/import path accesses retired Coverage state.
- Gap-bearing pending operation receives documented terminal/held retirement disposition with original id/payload; no silent new operation.
- Gap-free import/correction behavior and current guards preserved.

**Selected commands (planned, not executed)**

- `make python-file FILE=backend/tests/test_retired_coverage_inputs.py` — Makefile:109-111; proposed test file must be added by this task
- `make python-file FILE=backend/tests/test_explicit_product_composition.py` — Makefile:109-111; existing file

**Integration handoff**

- Consumer pending/recovery check for original failed command; no full native/browser stack solely to delete unreachable SQL.

**Required small worker batches**

- B27-1: Reject new/unfinished gap-bearing requests before writes while gateway replays existing terminal receipt. Files: backend/app/contracts/transport/authored_lines.py, backend/app/analysis_paste_commands.py, backend/app/branch_commands.py, backend/app/main.py, backend/tests/test_retired_coverage_inputs.py.
- B27-2: Delete unused Coverage behavior and verify gap-free path. Files: backend/app/services/analysis_paste.py, database/tempo_storage/authored_repertoires/analysis_paste.py, database/tempo_storage/authored_repertoires/branches.py.

**Main risk:** Pydantic field deletion alone may change old replay/failed payload interpretation. Explicit boundary recognition is needed.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## B28 — Extract one pure legal source interpretation kernel from current position index

**Scope:** BE019; milestone `whole-audit`; phase `2-repertoire`; gate `pure`.

**Prerequisites:** None.

**Read first:** backend/app/repertoire/position_index.py:_build_validated_index,position_key; backend/app/studies/repertoire_conflicts.py:trained_move_index_from_snapshot; backend/app/services/repertoire_integrity.py:_scan_source; backend/app/services/analysis_paste.py:_position_moves,_parsed_existing_lines; backend/app/repertoire/changes/application.py:_source_rows_report

**Write paths:** backend/app/repertoire/source_interpretation.py (proposed); backend/app/repertoire/position_index.py (route traversal only); backend/tests/test_repertoire_source_interpretation.py (proposed); backend/tests/test_product_repertoire_changes.py

**Ordered steps**

1. Write a compact matrix of existing normalization/invalid-source behavior before edits: invalid FEN, unknown trained color, illegal move after prefix, empty move list, mixed colors, transpositions and terminal boundary.
2. Extract bounded pure route interpretation into immutable frames/own-response facts and diagnostics using existing canonical position identity. Preserve legal prefix plus incomplete diagnostic without certifying it complete.
3. Make position index first real consumer. Keep mapping/binding/currentness/reentry authority and snapshot completeness in index owner, not generic kernel.
4. Do not silently reconcile contradictory old scanner policy; integration owner records chosen shared semantic invalidity and explicit consumer presentation differences.
5. Pure fixtures cover castling/legal en-passant, FEN clocks, same-response aliases, opponent branches and illegal tail; no database needed.

**Acceptance and stop condition**

- One kernel owns parsing/legal traversal/own-turn interpretation; index consumes it with unchanged identity and mapping invariants.
- Invalid/incomplete input cannot produce complete certificate or fabricated own response.
- Kernel is pure, bounded and independent of HTTP/storage; no new chess/parser framework.

**Selected commands (planned, not executed)**

- `make python-file FILE=backend/tests/test_repertoire_source_interpretation.py` — Makefile:109-111; proposed test file must be added by this task
- `make python-file FILE=backend/tests/test_product_repertoire_changes.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_repertoire_conflicts.py` — Makefile:109-111; existing file

**Main risk:** Integrity currently records a candidate before checking legality, while older conflict scan silently truncates. Explicit chosen diagnostic semantics required.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## B29 — Use source kernel for conflict listing and strict import/change validation

**Scope:** BE019; milestone `whole-audit`; phase `2-repertoire`; gate `pure`.

**Prerequisites:** B28

**Read first:** backend/app/studies/repertoire_conflicts.py; backend/app/services/repertoire_conflicts.py; backend/app/pgn_import_validation.py:validate_sources; backend/app/repertoire/changes/application.py:_source_rows_report,validate_source_rows

**Write paths:** backend/app/studies/repertoire_conflicts.py; backend/app/pgn_import_validation.py; backend/app/repertoire/changes/application.py (translation only); backend/tests/test_repertoire_conflicts.py; backend/tests/test_repertoire_import_boundary.py; backend/tests/test_repertoire_source_interpretation.py

**Ordered steps**

1. Replace repeated chess traversal/own-response set construction in old snapshot conflicts and strict import validation with B28 kernel.
2. Retain conflict payload ordering/route IDs/diagnostic byte bounds and strict pre-write import rejection.
3. Keep source/repertoire mixed-color rules explicit; same legal sources produce same semantic response sets through index/change guard/listing/import.
4. Use one common parameterized fixture corpus; assert raw inputs remain unmutated and invalid legal prefixes are never accepted as complete.
5. Remove obsolete parsing duplicate only after all callers map; leave transport error conversion for B17.

**Acceptance and stop condition**

- Conflict listing/import/edit guard consume one interpretation owner.
- Own-response alternatives conflict, opponent branches remain legal and transposition identity consistent.
- Existing current wire presentation differences are documented and tested, not hidden by forced equal JSON.

**Selected commands (planned, not executed)**

- `make python-file FILE=backend/tests/test_repertoire_conflicts.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_repertoire_import_boundary.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_product_repertoire_changes.py` — Makefile:109-111; existing file

**Main risk:** Import strictness and read diagnostics differ legitimately; preserve difference while sharing facts.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## B30 — Use source kernel for integrity scans and paste preview response comparison

**Scope:** BE019; milestone `whole-audit`; phase `2-repertoire`; gate `pure`.

**Prerequisites:** B28, B29, B27

**Read first:** backend/app/services/repertoire_integrity.py:_scan_source,_record_position; backend/app/services/analysis_paste.py:_position_moves,_parsed_existing_lines,_destination_options; backend/tests/test_product_position_index.py; backend/tests/test_repertoire_import_boundary.py

**Write paths:** backend/app/services/repertoire_integrity.py (source interpretation only); backend/app/services/analysis_paste.py (source interpretation/comparison only); backend/tests/test_repertoire_source_interpretation.py; backend/tests/test_repertoire_integrity.py (if current; otherwise focused proposed same name); backend/tests/test_analysis_paste.py (if current; otherwise focused proposed same name)

**Ordered steps**

1. Translate authored lines and relevant card sources to B28 input; integrity retains source labels/issue IDs/digest formatting and existing scoped publication.
2. Replace preview cached traversal and own-response comparison with kernel facts; retain cache bound, duplicate detection, target scoring and proposed-vs-existing scope.
3. Invalid FEN/illegal tail/mixed colors must not be silently dropped in a way that manufactures a unique safe target; use documented diagnostic outcome.
4. Run cross-consumer corpus for common sources, asserting semantic agreement and explicitly expected presentation differences.
5. Attach final BE019 consumer table proving all listed traversals now use common interpretation or are justified unrelated presentation logic.

**Acceptance and stop condition**

- All BE019 current semantic consumers share one legal/own-response kernel.
- Integrity cards-plus-lines and preview proposed-versus-existing scopes remain distinct and bounded.
- No provider/engine computation or new full repertoire replay on review save is introduced.

**Selected commands (planned, not executed)**

- `make python-file FILE=backend/tests/test_repertoire_source_interpretation.py` — Makefile:109-111; proposed test file must be added by this task
- `make python-file FILE=backend/tests/test_analysis_paste.py` — Makefile:109-111; proposed test file must be added by this task
- `make python-file FILE=backend/tests/test_repertoire_integrity.py` — Makefile:109-111; proposed test file must be added by this task

**Main risk:** Issue identity or preview signature changes would invalidate pending operations; preserve serialization and detect any necessary compatibility explicitly.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## B31 — Restore exactly four frozen ordinary exercise runtime endpoints

**Scope:** FE008; milestone `original-packet`; phase `1-frozen-runtime`; gate `native`.

**Prerequisites:** C20, P06

**Read first:** SPEC.md:November 10 pass 2 frozen ordinary exercises; app/views/study_exercise_runner.tsx:present,attempt,self-assess,feedback consumers; app/lib/offline-training.ts:retained study attempts; backend/app/study_attempt_commands.py:submit_study_attempt,self_assess_study_attempt; backend/app/services/study_attempts.py:finish_study_attempt; database/tempo_storage/study_attempts/storage.py; backend/app/contracts/studies.py:StudyAttemptRequest,StudySelfAssessmentRequest; backend/app/contracts/command_registry.py:retired authored commands

**Write paths:** backend/app/study_exercise_routes.py (proposed); backend/app/main.py (one router import/mount only); database/tempo_storage/study_attempts/storage.py (narrow read helper if needed); backend/tests/test_frozen_study_routes.py (proposed); backend/tests/test_frozen_study_attempts_postgres.py (proposed)

**Ordered steps**

1. Consume C20 server-v1 support/response contract handoff only. Later grader C22-C24 must not block these runtime routes. Retain GRADER_VERSION=1 and original request model_dump hash; do not add default provenance fields.
2. Mount GET /api/studies/{study_id}/exercises/{exercise_id}/present; POST same prefix /attempts; POST /attempts/{attempt_id}/self-assess; GET /attempts/{attempt_id}/feedback. No other /studies APIs.
3. Present reads retained existing exercise/current revision/position on reader connection, enforces same study/exercise owner and supported current status, and projects only prompt-visible fields. Omit accepted lines/reference sets/correct-option IDs/rubric.
4. Submission routes dispatch existing studies.attempts.submit and studies.attempts.self_assess with original Idempotency-Key and precise current payload envelopes; route never writes scheduling tables.
5. Feedback requires an existing attempt bound to the same study/exercise and reads its persisted exercise revision, not a newer current revision. Unknown/mismatched attempt cannot reveal answers.
6. Test ordinary queued exercise, correct/again, explanation self-assess, pending/reload/lost acknowledgment replay, original receipt, old revision feedback, and retired payload hold. Native fixture seeds retained rows only; no authoring restoration.

**Acceptance and stop condition**

- Actual frozen queue card can present, submit, self-assess when required and reveal its bound feedback; response agrees with frontend contract and retained server-v1 grading baseline. Keep GRADER_VERSION=1 and original model_dump request hash shape; add no default provenance fields.
- One answer/replay creates exactly one attempt/schedule effect; review context requires queue identity and practice cannot name queue.
- Creation/import/chapter/bundle/enroll/proposal/automatic-feedback routes remain retired; retained journal data unchanged.
- Four route tests and real owned native completion run; final browser journey owned by frontend/P12.

**Selected commands (planned, not executed)**

- `make python-file FILE=backend/tests/test_frozen_study_routes.py` — Makefile:109-111; proposed test file must be added by this task
- `make python-file FILE=backend/tests/test_frozen_study_attempts_postgres.py` — Makefile:109-111; proposed test file must be added by this task

**Integration handoff**

- Coordinate frontend FE008 test: queued frozen exercise → answer receipt → reload/offline replay → authoritative playable successor; one shared browser run.

**Main risk:** Backend source exists but routes are absent. Reintroducing old study_routes.py wholesale would resurrect retired authoring; add focused runtime router only.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## B32 — Retire executable tests exclusive to removed authoring/producer systems

**Scope:** BE021; milestone `whole-audit`; phase `1-proof-repair`; gate `source`.

**Prerequisites:** None.

**Read first:** SPEC.md:November 10 amendments; backend/tests/test_study_command_database_split.py; backend/tests/test_study_portable_storage_boundary.py; backend/tests/test_stalemate_swindles.py; backend/tests/test_tactics_asset_archive.py; backend/tests/test_tactics_asset_generation.py; backend/tests/test_tactics_asset_inventory.py; backend/tests/test_study_priority_interface.py; backend/tests/fixtures/product_game_worker_process.py; backend/tests/test_regressions.py

**Write paths:** backend/tests/test_study_command_database_split.py; backend/tests/test_study_portable_storage_boundary.py; backend/tests/test_stalemate_swindles.py; backend/tests/test_tactics_asset_archive.py; backend/tests/test_tactics_asset_generation.py; backend/tests/test_tactics_asset_inventory.py; backend/tests/test_study_priority_interface.py; backend/tests/fixtures/product_game_worker_process.py; backend/tests/test_regressions.py; only current runner/index references to deleted tests

**Ordered steps**

1. For each named file, classify exact assertions against current SPEC: removed authored chapters/bundles, removed portable storage, removed miner/assets generation tooling, removed automatic Games priority/worker.
2. Delete exclusive executable tests and orphan fixtures after tracing actual runner references. In test_regressions.py remove only test_game_mistakes_respect_arbitrary_fen_side_to_move importing retired app.chess.evaluation; retain both Python/Rust parity cases. Preserve historical evidence/receipts and actual frozen corpora.
3. Retain frozen corpus/grader support through current test_study_contract_identity.py and frontend grader suite; retain current packaged Tactics reader behavior through test_tactical_catalog.py rather than resurrecting removed asset tool modules.
4. Keep retired-command/payload rejection coverage in current command catalog/recovery tests; remove tests expecting optional automatic feedback execution.
5. Update current selections to avoid zero-selection success; report each removed node with SPEC rationale and retained replacement where an invariant still matters.

**Acceptance and stop condition**

- No active test imports a deleted subsystem solely to exercise a retired feature from these files.
- Removed tests have explicit retirement classifications; no broad skip, importorskip, fake old package, or weakened assertions.
- Current retained corpora and packaged puzzle activation/progress still have discoverable real tests.

**Selected commands (planned, not executed)**

- `make python-file FILE=backend/tests/test_study_contract_identity.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_tactical_catalog.py` — Makefile:109-111; existing file
- `rg -n '(test_study_command_database_split|test_study_portable_storage_boundary|test_stalemate_swindles|test_tactics_asset_archive|test_tactics_asset_generation|test_tactics_asset_inventory|test_study_priority_interface|product_game_worker_process)' backend database scripts tools components.json` — entrypoint/options inspected; any proposed new selection is stated in acceptance

**Required small worker batches**

- B32-1: Remove exclusive old authored/portable/miner tests; retained corpus proof stays in current contract suite. Files: backend/tests/test_study_command_database_split.py, backend/tests/test_study_portable_storage_boundary.py, backend/tests/test_stalemate_swindles.py.
- B32-2: Remove old generation/archive/inventory tool tests only after proving no supported tool caller; keep current pack loader proof. Files: backend/tests/test_tactics_asset_archive.py, backend/tests/test_tactics_asset_generation.py, backend/tests/test_tactics_asset_inventory.py.
- B32-3: Retire feedback-worker/priority test fixtures and only old evaluation case; retained chess parity survives. Files: backend/tests/test_study_priority_interface.py, backend/tests/fixtures/product_game_worker_process.py, backend/tests/test_regressions.py.

**Main risk:** Pack assets are retained, but their removed generator is not automatically required. Verify consumers before deleting a fixture; no history rewrite.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## B33 — Rebind retained review and scheduling regressions to current owners

**Scope:** BE021; milestone `whole-audit`; phase `1-proof-repair`; gate `caller`.

**Prerequisites:** None.

**Read first:** backend/tests/test_legacy_review_storage_separation.py; backend/tests/test_scheduling_review_store.py; backend/tests/test_prepared_review_continuation.py; backend/tests/test_retained_borrowed_store.py; backend/tests/test_retained_mutations_boundary.py; backend/app/services/learning_review_adapter.py; backend/app/services/review_service.py; backend/app/repertoire/changes/retained_mutations.py

**Write paths:** backend/tests/test_legacy_review_storage_separation.py; backend/tests/test_scheduling_review_store.py; backend/tests/test_prepared_review_continuation.py; backend/tests/test_retained_borrowed_store.py; backend/tests/test_retained_mutations_boundary.py

**Ordered steps**

1. Remove legacy_study_remediation mock/assertion from receipt sequencing test while preserving receipt-write/current-revision/rollback behavior actually supported.
2. Rebind three real_game_feedback_adapter-dependent scheduling wrapper tests to current review_service/scheduling owner and keep history clock, source replay, error, rollback, maturity and follow-up ordering assertions.
3. Keep prepared identity omission/request digest test; retire two optional queue.prepare_next/automatic-feedback expectations under current SPEC.
4. Classify old retained factory/alias-identity tests: port real borrowed transaction/source mutation safeguards to current retained_mutations owner; delete alias-only or retired proposal-store assertions with explicit rationale.
5. Run the complete changed files; document retained case inventory so no former failure disappears through empty collection.

**Acceptance and stop condition**

- Five files collect against current source and each retained assertion executes; no reintroduced old modules.
- Actual transaction/effect/receipt safety assertions survive; obsolete optional feedback/proposal execution is removed.
- No database/native pass is inferred from fake orchestration tests.

**Selected commands (planned, not executed)**

- `make python-file FILE=backend/tests/test_legacy_review_storage_separation.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_scheduling_review_store.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_prepared_review_continuation.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_retained_mutations_boundary.py` — Makefile:109-111; existing file

**Main risk:** Mocking a different function without preserving the same observable boundary would create false green evidence.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## B34 — Repair retained queue timing/read probes and mixed route tests

**Scope:** BE021; milestone `whole-audit`; phase `1-proof-repair`; gate `caller`.

**Prerequisites:** P02

**Read first:** backend/tests/test_queue_head_preparation_timing.py; backend/tests/test_queue_issue_writer_timing.py; backend/tests/test_queue_refresh_read_database_split.py; backend/tests/test_explicit_product_composition.py; backend/tests/test_study_route_database_split.py; backend/tests/test_studies.py; backend/app/services/queue_next_card.py; backend/app/queue_commands.py; backend/app/services/queue_presentation.py

**Write paths:** backend/tests/test_queue_head_preparation_timing.py; backend/tests/test_queue_issue_writer_timing.py; backend/tests/test_queue_refresh_read_database_split.py; backend/tests/test_explicit_product_composition.py; backend/tests/test_study_route_database_split.py; backend/tests/test_studies.py

**Ordered steps**

1. Update timing fakes to current position preparation/issuance dependencies; remove deleted game_feedback/legacy_study_remediation setup while preserving emitted timing stages, original proposal and busy/source-hold results.
2. Retire only automatic game-priority presentation/SQL translation cases; keep current bounded presentation, row protection, closed-reader and ordinary nonpriority behavior tests.
3. Remove old chapter router/storage callback tests; B31 adds explicit four runtime-route tests. Keep cold lifespan/provider isolation and retained branch add/remove checks.
4. In test_studies.py retain grader golden corpus test and remove deleted app.studies.pgn preview test exclusive to retired annotated-Studies import.
5. Execute each surviving file and list node inventory before/after, pointing ordinary frozen route/review coverage to B31.

**Acceptance and stop condition**

- Timing/read/current composition tests no longer import deleted subsystems and still assert meaningful retained behavior.
- No blanket skip of files containing both retained and retired cases.
- Pure/caller claims stay distinct from native reader/issuance qualification.

**Selected commands (planned, not executed)**

- `make python-file FILE=backend/tests/test_queue_head_preparation_timing.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_queue_issue_writer_timing.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_queue_refresh_read_database_split.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_explicit_product_composition.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_studies.py` — Makefile:109-111; existing file

**Required small worker batches**

- B34-1: Rebind current timing/read assertions; retire exclusive feedback/translator expectations. Files: backend/tests/test_queue_head_preparation_timing.py, backend/tests/test_queue_issue_writer_timing.py, backend/tests/test_queue_refresh_read_database_split.py.
- B34-2: Retain current lifespan/branch/grader assertions; B31 owns frozen runtime routes, old chapter route/import assertions retire. Files: backend/tests/test_explicit_product_composition.py, backend/tests/test_study_route_database_split.py, backend/tests/test_studies.py.

**Main risk:** Timing probes may expose real current field/fence changes; fix fixtures narrowly, not production guards to satisfy stale fake shape.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## B35 — Finish backend recovery and diagnostic fixture disposition

**Scope:** BE021; milestone `whole-audit`; phase `1-proof-repair`; gate `caller`.

**Prerequisites:** None.

**Read first:** backend/tests/test_study_recovery_acceptance.py; backend/tests/fixtures/capture_unit_diagnostic.py; backend/tests/test_worker_command_registration_boundary.py; backend/tests/fixtures/study_recovery_content.py; database/tests/games_collection/study_recovery_acceptance.py; backend/tests/native_study_fixture.py

**Write paths:** backend/tests/test_study_recovery_acceptance.py; backend/tests/fixtures/capture_unit_diagnostic.py; backend/tests/test_worker_command_registration_boundary.py; database/tests/games_collection/study_recovery_acceptance.py (coordinate P owner; helper consumers only)

**Ordered steps**

1. Classify still-stale first-boundary/real game feedback/opening-frontier checks as retired; preserve bounded legal publication/shape, original retry deadline, original review manifest, timeout/partial-marker and diagnostic cleanup tests.
2. Where current recovery test needs graph/source geometry, use existing legal current fixture source preparation rather than importing retired frontier/producers.
3. Remove feedback coordinator/runner section from capture_unit_diagnostic if exclusively retired; keep actual current product snapshot/latency observer functionality and bounded artifact capture.
4. Replace worker_game_commands lazy-resolution test with explicit retired-name rejection and no optional import assertion; coordinate final registration expectations with B21.
5. Link supported packaged recovery tests to current helper owner (proof/storage P tasks) rather than recreating test_packaged_collection in backend.

**Acceptance and stop condition**

- All current backend recovery/diagnostic selections import supported modules and execute nonempty tests.
- Retry identity/deadline, timeout failure propagation, exact manifest binding and cleanup assertions remain.
- No automatic Games worker, advanced frontier, or old proposal framework is restored.

**Selected commands (planned, not executed)**

- `make python-file FILE=backend/tests/test_study_recovery_acceptance.py` — Makefile:109-111; existing file
- `make python-file FILE=backend/tests/test_worker_command_registration_boundary.py` — Makefile:109-111; existing file

**Main risk:** Some historical review artifacts reference absent fixture modules by design; leave immutable evidence unchanged and fix only active executable paths.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## B36 — Reconcile every BE021 reference and final backend finding coverage

**Scope:** BE021; milestone `whole-audit`; phase `5-closure`; gate `source`.

**Prerequisites:** P01, P02, P03, B32, B33, B34, B35, B31, B21. Integration owner supplies the exact current changed backend test inventory and relevant advertised selection receipts before this closure pass; tests/REGRESSIONS.md is the existing inventory entrypoint.

**Read first:** reference/audit-current.json:BE021 files/proof_details; backend/tests/test_product_snapshot_postgres.py; backend/tests/test_regressions.py; backend/tests/test_study_contract_identity.py; tests/REGRESSIONS.md

**Write paths:** Read-only handoff/evidence only.

**Ordered steps**

1. Create exact table for all 27 original BE021 files/66 references: current-existing/corrected before packet, repaired task/node, retired with SPEC reason, or still blocked.
2. Positively verify already-corrected test_product_snapshot_postgres exception export and test_study_contract_identity removed portable import. B32 retires still-stale test_regressions evaluation case while retaining Rust/Python parity; do not report it already fixed.
3. Include P01 PGN proof, P02 five admission failures and P03 four deletion failures as separate owner evidence; their prior stale failures are not erased.
4. Use current advertised selection/collection, not a blanket all-backend run per leaf. If full backend suite is integration-selected, inspect real failures and collection counts, never mark planned native tests green.
5. Close BE021 only if no active unresolved missing implementation import remains in scoped inventory and retained invariants have named current proof.

**Acceptance and stop condition**

- Every original reference has executable disposition and actual current evidence.
- No resurrected retired subsystem, broad skip/ignore, empty selected suite, or synthetic old facade used to get green.
- Final packet original milestone and wider-audit milestone reported separately.

**Selected commands (planned, not executed)**

- `rg -n '(legacy_study_remediation|real_game_feedback_adapter|app.study_routes|app.study_commands|app.studies.pgn|app.services.study_portable|app.study.qualify_priority|worker_game_commands|app.games.feedback|tactics_asset_)' backend/tests` — entrypoint/options inspected; any proposed new selection is stated in acceptance

**Main risk:** A source scan proves reference absence; execution/selection receipts separately prove advertised tests work.

**Excludes:** No new service, database, event bus, generic repository, scheduler, or retired producer restoration. No changes to historical migration checksums, persisted command names, accepted operation identities, or original receipt bytes.

## Source-verified runner cautions

- make python-file FILE=<path> exists at Makefile:109-111; resolved TEMPO_PYTHON must satisfy >=3.12,<3.15 and package sources must be bound correctly.
- backend/tests/native_study_fixture.py owns its capped Docker PostgreSQL fixture. Tests importing owned_postgres are heavy even if invoked by python-file; schedule under same single heavy slot.
- Current runner accepts --native-check position-grade-effects,position-introductions,position-queue-admission,prefix-split-placement,redis-fixture-isolation,game-review-reader only (repeated flag, not comma-delimited).
- Native checks require --mode browser or --mode study. Study mode also requires explicit --browser-grep. --skip-browser is invalid with either. --maintained-study-proof forbids added native checks and is partial evidence.
- An existing valid combined example after relevant changes is: node database/tests/test-postgres-docker.mjs --mode browser --browser-file position-study-acceptance.spec.ts --native-check position-grade-effects --native-check position-introductions --native-check position-queue-admission. This runs a browser stack too; not a leaf pure test.
- Run make preflight once for chosen owner runner prerequisites. Extend existing supported native owner registration only if a new exact case is necessary; do not invent CLI flags.
- No current native runner selection for settings historical-day case is claimed; B02 uses owned_postgres fixture or proof owner adds exact case to existing runner, with real pass required.
