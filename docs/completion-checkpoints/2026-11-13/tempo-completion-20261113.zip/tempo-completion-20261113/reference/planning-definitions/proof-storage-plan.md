# Tempo finish packet: proof, storage and tooling plan

**Planning only.** Source `091ad318b1afaadcb25e5ca44ff526120a202336`, tree `e727a9d8580122b215f9f7f941b32129ea1a8249`. No product edits, remote changes, installation, heavy tests or live actions were performed.

## Completion boundaries

Checkpoint 1 completes the earlier packet plus its concrete review residue. Checkpoint 2 closes the fixed audit criteria after the wider owner-contract work. Installation and a genuine user saved-review → playable-next interaction are separate observations. A partial suite, a successful health response or a prior unrelated receipt cannot satisfy any later state.

The known reported installation is `d79ae4fcc4b006985114d85b5fb9a5aca8becbf1`, schema 65, five images, at 2026-11-12 19:31:39 UTC. This planning task did not inspect that live target. Source 091ad differs from that installed product only in test/harness/audit inputs according to the prior independent source review; do not force a test-only reinstall.

## Exact earlier-packet residue

| Residue | Required disposition | Tasks |
| --- | --- | --- |
| E01 three weak SQL tests | Wrong projection/relation/advisory lock must fail | P01 |
| Five admission + four deletion stale tests | Rebind current invariants; explicit producer-only retirement | P02, P03 |
| E02 real-game obligation queue case | Paused accepted identity/history + ordinary Study proof, no retired producer | P04 |
| E02 opening evidence reconciliation queue case | Current checkpoint/review recovery with exact atomicity and replay | P05 |
| E02 manual prefix split | Three actual HTTP routes + real durable/browser journey | P06, P07, P12 |
| E02 historical 49→48→49 rollback | Finite historical proof or positive supported-retirement decision | P08 |
| Browser restart replay | Successful original receipt + playable final successor | P16, P12 |
| F02 / E04 | One exact witness policy + actual schema65 lifecycle | T01, P13 |
| Current proof records | Current E00/E01/E03 accepted scope and E02 residuals | P17 |

## Native/browser/lifecycle sequence

1. Finish pure/component task proofs and exact source/case discovery. Keep proposed test targets explicitly proposed until authored and registered.
2. Release T01 reviewed source to P13 before T01 merges. P13 adds and proves the current65 profile; historical full/current63 refusal stays valid. Existing `lifecycle-current` does not qualify65 today.
3. Acquire the single heavy slot. Capture exact clean source tree and test/fixture/product hashes, resolve supported Python and WASM inputs, then run `make preflight`.
4. Run current65 lifecycle only when changed lifecycle/install behavior requires it. A64→65 forward proof is conditional on an actual supported starting64 target; no older-image downgrade claim.
5. Run the P14 current Study/native/HTTP cohort with P12 exact browser cases in one stack where supported. Existing native selectors only accept study/browser modes; there is no native-only flag.
6. Preserve raw failures. A locator-only retry may reuse native evidence only after exact unchanged-input proof. Every selected case needs zero skips/retries/duplicates and owned cleanup.
7. After wider audit changes, run the final affected cohort; reuse only demonstrably identical evidence. Pure leaf changes do not cause broad native/browser reruns.

## Normal installation and real user observation

The current supported commands below come from `tempo`, `scripts/tempo-cli.mjs:parseArguments`, and `docs/TEMPO-CLI.md`. They are instructions for the later authorized delivery phase, not actions performed by this packet. `./tempo install` registers the management command only and is needed only when absent. Normal deployment uses `tempo start`; the approved hosted-CI workaround is `tempo start --no-ci --no-open`, truthfully recorded as CI disabled. A read-only plan can still report a gate and is not an accepted installation.

~~~sh
# Read-only inspection and plan on the registered operator target.
tempo status
tempo doctor --verbose
tempo start --plan

# Later, only for an exact qualified source and authorized installation.
tempo start --no-ci --no-open
tempo doctor --verbose
~~~

Check immutable image IDs, configuration, source SHA, complete schema ledger, active modes/workers and backup/recovery state after the normal updater. Never delete a migration guard to force startup. A new main after planning needs actual reconciliation. Do not call `--no-ci` a CI pass. Exact candidate-ref/candidate-sha is the documented reviewed offline-rehearsal option, not an invented general release bypass.

A real user’s own review and subsequent legal move on the next card supply live usability/cadence evidence. Do not create synthetic reviews on live data. If that interaction has not happened, state installed and live interaction pending. Disposable scripted acceptance remains useful and is labeled accordingly.

## Audit coverage and limits

This plan maps all 13 nonclosed ST/RT findings, preserves all 264 original ST005 function rows and all 758 original proof rows in the JSON. 54 proof rows are explicitly assigned to backend/frontend companion plans; the others are owned here. Historical source URLs/lines remain intact, with separate current source hashes/definition/caller observations.

The storage ledger is not a264-function rewrite mandate. Every row gets a positive current ownership/reachability disposition: actual public physical leaks need semantic types and adopted consumers; legitimate private adapter details need proof of their enclosing public contract; already semantic values need exact type/caller evidence; retired-only helpers need positive registration/import/recovery absence before removal. No blanket no-change, generic defer, type-alias-only façade or restored SQL translator closes the finding.

The native proof ledger uses the same rule. Current selected cases must resolve current imports and native parameter syntax. Mixed files retain their supported safety assertions. Retired producer/cutover fixtures are not restored just to turn an obsolete test green. Old text missing from current source is only a reconciliation observation, not an automatic pass.

## Nonclosed finding map

| Finding | Baseline state | Tasks |
| --- | --- | --- |
| RT002 | Open | T03 |
| RT003 | Open | T02 |
| RT004 | Open | P07, T04 |
| RT005 | Open | T01, P13 |
| ST002 | Open | S01, S02, P14 |
| ST003 | Open | S03, S04, P12 |
| ST004 | Open | S05, P12 |
| ST005 | Open | P14, S08, S09, S10, S11, S12, S13, S14, S15, S16, S17, S18, S19, S20, S21, S22, S23, S24, S25, S26, S27, S28, S29, S30, S31, S34 |
| ST006 | Open | P02, S06, P14 |
| ST011 | Needs decision | T05 |
| ST012 | Open | P01, P02, P03, P04, P05, P06, P07, P08, P16, P17, P13, P12, P14, P09, P10, P11, P18, P19, P20, P21, P22, P24 |
| ST013 | Open | P01, P04, P05, P06, P07, P08, P17, P13, P12, P14, P09, P10, P11, P18, P19, P20, P21, P22, P24 |
| ST014 | Open | S07, P14 |

## Task index

| ID | Phase | Task |
| --- | --- | --- |
| P01 | original-packet-residue | Make the three rebound E01 SQL tests reject wrong queries and missing locks |
| P02 | finish-proof-debt | Dispose all five stale position-admission tests against current owners |
| P03 | finish-proof-debt | Repair the four current card-deletion borrowed-connection test failures |
| P04 | original-packet-residue | Replace the obsolete real-game queue case with paused-history preservation |
| P05 | original-packet-residue | Rebind the retired opening-reconciliation queue case to retained review recovery |
| P06 | original-packet-residue | Restore the three retained manual prefix-split HTTP routes |
| P07 | original-packet-residue | Restore truthful HTTP coverage and acceptance scope in every shared runner mode |
| P08 | original-packet-residue | Give the historical 49→48→49 rollback case a finite, explicit supported disposition |
| P16 | original-packet-residue | Require successful original-review replay and a playable final successor |
| P17 | original-packet-residue | Reconcile E00/E01/E03/E02 evidence descriptions with actual current proof |
| S01 | audit-expansion | Separate typed position source values from the concrete sealed SQL capability |
| S02 | audit-expansion | Type introduction and owner-fence contracts without weakening their seals |
| S03 | audit-expansion | Inject workspace and IndexedDB dependencies into the offline storage instance |
| S04 | audit-expansion | Inject intent-store validation and portable-backup diagnostics at composition |
| S05 | audit-expansion | Make the opening journal own IndexedDB lifetime and commit-boundary results |
| S06 | audit-expansion | Use explicit supported transaction capabilities for eligibility and frozen-order locks |
| S07 | audit-expansion | Separate queue-abandonment request/policy from SQL and operator transport |
| T01 | original-packet-residue | Share the exact cut62 witness policy and qualify its current lifecycle use |
| T02 | audit-expansion | Make the existing component registry describe every current executable owner |
| T03 | audit-expansion | Enforce the actual public boundaries through the existing parser and registry |
| T04 | audit-expansion | Select proof by changed owner and effect instead of blanket Study filenames |
| T05 | audit-expansion | Declare and prove the Rust component fixture input contract |
| P13 | original-packet-residue | Qualify the actual schema65 installation lifecycle and recovery path |
| P12 | integration-checkpoint | Declare and demonstrate the exact assembled browser journeys |
| P14 | integration-checkpoint | Run one coordinated exact native and HTTP qualification cohort |
| P15 | installation-and-user-acceptance | Use the normal CLI for authorized installation and observe genuine live Study |
| S08 | audit-expansion | Settle and adopt typed storage boundary: Position issuance identity and lock facts |
| S09 | audit-expansion | Settle and adopt typed storage boundary: Position issuance attempt and completion evidence facts |
| S10 | audit-expansion | Settle and adopt typed storage boundary: Position grading and checkpoint receipt contracts |
| S11 | audit-expansion | Settle and adopt typed storage boundary: Learning review and reconciliation snapshots |
| S12 | audit-expansion | Settle and adopt typed storage boundary: Queue command and operation receipt facts |
| S13 | audit-expansion | Settle and adopt typed storage boundary: Queue application seeding, eligibility and publication projections |
| S14 | audit-expansion | Settle and adopt typed storage boundary: Opening, tactic and capacity admission facts |
| S15 | audit-expansion | Settle and adopt typed storage boundary: Queue refresh and HTTP head projection contracts |
| S16 | audit-expansion | Settle and adopt typed storage boundary: Queue placement, retained origins and frozen-order state facts |
| S17 | audit-expansion | Settle and adopt typed storage boundary: PGN import and card-edit storage projections |
| S18 | audit-expansion | Settle and adopt typed storage boundary: Card and repertoire deletion retention facts |
| S19 | audit-expansion | Settle and adopt typed storage boundary: Integrity scan and publication adapter facts |
| S20 | audit-expansion | Settle and adopt typed storage boundary: Integrity read and repair command contracts |
| S21 | audit-expansion | Settle and adopt typed storage boundary: Repertoire branch, paste, canonical-prefix and move-membership facts |
| S22 | audit-expansion | Settle and adopt typed storage boundary: Manual prefix split command and lineage facts |
| S23 | audit-expansion | Settle and adopt typed storage boundary: Opening graph worker persistence facts |
| S24 | audit-expansion | Settle and adopt typed storage boundary: Durable task identity and read models |
| S25 | audit-expansion | Settle and adopt typed storage boundary: Durable task claim and transition facts |
| S26 | audit-expansion | Settle and adopt typed storage boundary: Settings and current mode facts |
| S27 | audit-expansion | Settle and adopt typed storage boundary: Background activity, refresh and readiness facts |
| S28 | audit-expansion | Settle and adopt typed storage boundary: Tactics catalog, capture and attempt facts |
| S29 | audit-expansion | Settle and adopt typed storage boundary: Retained exercise attempt facts after route restoration |
| S30 | audit-expansion | Settle and adopt typed storage boundary: Retained HTTP read projections and command lock facts |
| S31 | audit-expansion | Settle and adopt typed storage boundary: Read-only Game Review storage values |
| S34 | audit-expansion | Settle and adopt typed storage boundary: Bounded published repertoire source facts |
| P09 | audit-expansion-proof | Reconcile current proof contract: Background diagnostic and admission proofs |
| P10 | audit-expansion-proof | Reconcile current proof contract: Current opening checkpoint, original evidence and immutability proofs |
| P11 | audit-expansion-proof | Reconcile current proof contract: Deletion and repertoire allowance native proofs |
| P18 | audit-expansion-proof | Reconcile current proof contract: Historical position seed/operator/source-fixture support decisions |
| P19 | audit-expansion-proof | Reconcile current proof contract: Frozen order proof inputs and native SQL |
| P20 | audit-expansion-proof | Reconcile current proof contract: Tactic capture and retained corpus/history native proofs |
| P21 | audit-expansion-proof | Reconcile current proof contract: Current queue dispatch, opening admission and capacity proof closures |
| P22 | audit-expansion-proof | Reconcile current proof contract: Historical schema and retired packaged collection proof decisions |
| P24 | audit-expansion-proof | Reconcile current proof contract: Mixed native review suite after retained split and receipt repairs |

## Concrete task cards

### P01 — Make the three rebound E01 SQL tests reject wrong queries and missing locks

**Scope:** original-packet-residue. Findings: ST012, ST013, BE021. Prior tasks: E01.

**Prerequisites (reviewed source/capability unless explicitly stronger):** Independent bounded source task; reserve listed paths.

**Owner/resource conditions:** Apply the shared path lease and exact candidate rules.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `backend/tests/test_pgn_import_storage_boundary.py` (Borrowed, test_retained_import_storage_preserves_full_receipt_tuple_and_raw_json, test_current_import_card_identity_projections_preserve_empty_and_existing_rows); `database/tempo_storage/authored_repertoires/pgn_import/storage.py` (existing_card_ids, deleted_card_ids); `database/tempo_storage/commands/receipts/storage.py` (operation_status); `tests/REGRESSIONS.md`.

**Write scope:** `backend/tests/test_pgn_import_storage_boundary.py` [existing]; `tests/REGRESSIONS.md` [existing].

**Steps:**

1. Keep the existing 20-case file and original request/result/transaction assertions. Strengthen only the three QF-04 projection/lock cases.
2. Assert the receipt projection selects its twelve named fields from operation_receipts with the exact operation predicate; compare unchanged raw payload/error bytes as before.
3. Give existing_card_ids and deleted_card_ids nonempty distinct replies plus an empty case. Reject reversed relation/column projections while preserving input order parameters and caller-owned lifecycle.
4. Assert the receipt lock uses the actual advisory transaction lock with its exact key and parameters. A plain SELECT %s must fail the regression.
5. Run bounded mutation controls against wrong receipt projection, wrong deleted-card table and missing advisory lock; retain the expected failures in the handoff, then restore source.

**Acceptance:**

- All three known in-process mutations are detected; the complete owning file passes without -k exclusions.
- No assertion treats preloaded fake replies as native SQL, locking or migration acceptance.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_pgn_import_storage_boundary.py` — cwd `.`; focused; current.

**Integration:** No additional heavy proof for this isolated pure change.

**Material risks:** Overly textual SQL assertions may reject harmless formatting; normalize whitespace and assert selected semantics plus parameters, not a copied whole implementation.

**Exclusions:** Native stack for this pure borrowed-boundary repair; Restoring retired approval facade/preview APIs

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### P02 — Dispose all five stale position-admission tests against current owners

**Scope:** finish-proof-debt. Findings: ST012, BE021, ST006. Prior tasks: E02.

**Prerequisites (reviewed source/capability unless explicitly stronger):** Independent bounded source task; reserve listed paths.

**Owner/resource conditions:** Reserve the admission test file first; release it to B07/S06/S02 before their later assertions.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `backend/tests/test_position_queue_admission.py` (test_due_consumers_apply_position_ownership_only_when_schema_present, test_refresh_consumes_prepared_due_before_advancing, test_new_position_issue_fences_source_before_existing_queue_locks_and_rolls_back_stale_head, test_urgent_game_target_is_selected_when_natural_due_is_false, test_changed_urgency_rolls_back_inserted_position_plan); `database/tempo_storage/queue_refresh/eligibility.py` (position_due_exclusion); `backend/app/services/position_queue_admission.py`; `SPEC.md`.

**Write scope:** `backend/tests/test_position_queue_admission.py` [existing]; `tests/REGRESSIONS.md` [existing].

**Steps:**

1. Replace the absent conflicts/native_configured/is_postgres_connection seams in the first three tests with the current eligibility, preparation and writer-capability boundary. Retain source-before-queue lock order and stale-head rollback assertions.
2. The two game_feedback cases describe a retired active producer. Preserve their useful rollback/current-owner protection assertion under an actual retained source/owner invalidation; move only exclusively retired urgency expectations to an explicitly historical record, backed by SPEC November 10 pass 2 and P04 pause-preservation proof.
3. Do not restore game_feedback imports, add compatibility stubs, or suppress failures with a global not-native/name filter. Record each old nodeid → current nodeid or evidenced retirement.
4. Run every pure case in the file with the one current native nodeid explicitly deselected: test_native_refresh_admits_due_carrier_and_reuses_pending. P14 runs that exact pending case through the supported native bridge. The second native node from the earlier combined report belongs to test_position_introductions.py, not this file.

**Acceptance:**

- All five named pre-existing failures have a source-linked disposition and retained assertions still execute.
- Pure cases pass; native deselections/skips are reported separately and are never counted as native passes.

**Commands (planned, not executed):**

- `PYTEST_ADDOPTS='--deselect=backend/tests/test_position_queue_admission.py::test_native_refresh_admits_due_carrier_and_reuses_pending' make python-file FILE=backend/tests/test_position_queue_admission.py` — cwd `.`; focused; current.
- `node database/tests/test-postgres-docker.mjs --mode browser --browser-grep "study_only_mode_preserves_foreground_review_and_queue_progression across reload and resumption$" --native-check position-queue-admission --list` — cwd `.`; discovery; current.

**Integration:** P14: exact current position-queue-admission native selector on the assembled candidate.

**Material risks:** Retiring the two historical producer tests without replacement current owner invalidation proof would weaken rollback protection.

**Exclusions:** No neighboring cleanup or unrelated feature restoration.

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### P03 — Repair the four current card-deletion borrowed-connection test failures

**Scope:** finish-proof-debt. Findings: ST012, BE021. Prior tasks: E02.

**Prerequisites (reviewed source/capability unless explicitly stronger):** Independent bounded source task; reserve listed paths.

**Owner/resource conditions:** Reserve deletion test file first; release corrected fixture to B23/S18.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `backend/tests/test_card_deletion_storage_boundary.py` (Compatible, test_cancellation_queries_then_clocks_fetches_and_rechecks_only_exact_matches, test_purge_preserves_identifier_reads_clock_points_fixed_targets_and_tombstones, test_repertoire_delete_keeps_shared_owner_retention_policy_and_refresh_after_writes); `database/tempo_storage/authored_repertoires/card_deletion/storage.py`; `backend/app/card_deletion.py`.

**Write scope:** `backend/tests/test_card_deletion_storage_boundary.py` [existing]; `tests/REGRESSIONS.md` [existing].

**Steps:**

1. Update Compatible to model the current native execution capability rather than intentionally rejecting execute_native. Do not make unknown SQL succeed.
2. Keep exact cancellation identity/recheck ordering, monotonic clock points, fixed tombstone targets, shared membership keep/delete behavior and post-write refresh/calendar assertions.
3. Add a negative for unexpected connection/commit/close and for a wrong cancellation predicate so a broadly permissive fake cannot hide a regression.
4. Execute the complete file before its sequential handoff to backend BE011 and the ST005 deletion cluster.

**Acceptance:**

- All four named parameterized failures pass for their intended assertions; no task-owned production change was needed only to satisfy the obsolete fixture.
- Retained cancellation/retention identities and transaction ownership remain enforced.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_card_deletion_storage_boundary.py` — cwd `.`; focused; current.

**Integration:** No additional heavy proof for this isolated pure change.

**Material risks:** A fake that simply accepts every native query would reproduce the QF-04 blind spot.

**Exclusions:** No neighboring cleanup or unrelated feature restoration.

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### P04 — Replace the obsolete real-game queue case with paused-history preservation

**Scope:** original-packet-residue. Findings: ST012, ST013, BE021. Prior tasks: E02.

**Prerequisites (reviewed source/capability unless explicitly stronger):** Independent bounded source task; reserve listed paths.

**Owner/resource conditions:** Integration owner reserves queue proof and runner paths; a P07 lease is not a P07 dependency.

**Shared-file sequence:** P04 → P05 on check_postgres_queue_attempt_recovery.py; P07 runner integration follows both.

**Read first:** `database/tests/check_postgres_queue_attempt_recovery.py` (test_postgres_real_game_obligation_admission_restart_publication_and_remediation, _QUEUE_RECOVERY_UNRESOLVED, queue_recovery_main); `database/tempo_storage/ddl/migrations/064_retire_optional_study_producers.sql`; `database/tests/check_postgres_background_workloads.py`; `backend/app/contracts/command_registry.py`; `SPEC.md`.

**Write scope:** `database/tests/check_postgres_queue_attempt_recovery.py` [existing]; `database/tests/postgres-test-plan.mjs` [existing]; `tests/runner/postgres-test-speedups.test.mjs` [existing]; `tests/REGRESSIONS.md` [existing].

**Steps:**

1. Record the exact old case identity and the superseding SPEC decision: automatic provider feedback is retired; already accepted optional operations/effects are paused with original identity, and generated exercises remain ordinary Study.
2. Reuse the current stale-delivery/retirement fixture primitives to seed a bounded accepted historical effect, its original operation/task/delivery, and one unrelated ordinary card on an owned schema65 database. Do not import or run removed real_game_feedback producers.
3. Snapshot exact source rows, request bytes/digests, effect/operation IDs, clocks, dispositions, retry history and existing grades; prove stale delivery/restart creates no new optional work, no duplicate grade or receipt, and no loss of paused history.
4. Exercise ordinary queue issuance/save while that paused history exists; retain the issued head and protected position assertions from the old case where they remain applicable.
5. Replace the old current-runner case registration with the new named retained-invariant case and update the exact expected inventory. Keep the historical case explanation; a removed invocation alone is not completion.

**Acceptance:**

- The old unresolved real-game case has a positive current retention disposition with a real native replacement pass.
- No old producer is resurrected and no accepted history is deleted or fabricated.

**Commands (planned, not executed):**

- `node --test --test-concurrency=1 tests/runner/postgres-test-speedups.test.mjs` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_queue_attempt_recovery.py` — cwd `.`; focused; current.

**Integration:** P14: current Study queue receipt stage executes the replacement with exact receipt inventory, worker restart and owned cleanup.

**Material risks:** Assuming pending/held/applied historical feedback is disposable would violate the retirement ledger and retained history.

**Exclusions:** Provider intake; Automatic Games scheduling/admission; Schema64 migration on a live target

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### P05 — Rebind the retired opening-reconciliation queue case to retained review recovery

**Scope:** original-packet-residue. Findings: ST012, ST013, BE021. Prior tasks: E02.

**Prerequisites (reviewed source/capability unless explicitly stronger):** P04; C11; B00

**Owner/resource conditions:** Apply the shared path lease and exact candidate rules.

**Shared-file sequence:** P10 follows the retained opening helper release; shared opening proof changes serialized.

**Read first:** `database/tests/check_postgres_queue_attempt_recovery.py` (test_postgres_retired_opening_evidence_reconciliation_is_atomic_and_replay_safe); `backend/app/study/position_checkpoint.py`; `backend/app/review_commands.py` (submit_review); `backend/app/services/learning_review_adapter.py`; `database/tests/check_postgres_opening_evidence.py`.

**Write scope:** `database/tests/check_postgres_queue_attempt_recovery.py` [existing]; `database/tests/check_postgres_opening_evidence.py` [existing]; `database/tests/postgres-test-plan.mjs` [existing]; `tests/REGRESSIONS.md` [existing].

**Steps:**

1. Map each old assertion separately: valid/guided save, changed revision, unprovable origin, original failed transport, separate reconciliation identity, exact receipt replay, immutable learned color and no partial scheduling/evidence write.
2. Use current position_checkpoint/review submission and current fixture shapes. Keep historical accepted non-position review replay where current source supports it; otherwise assert its truthful retained hold without changing original failure/result.
3. Replace all actual psycopg parameter markers in the selected path with %s and use current first-response/receipt codecs. Never revive removed postgres_opening_evidence or obsolete color fixture APIs as a facade.
4. Run the current replacement in the owned queue stage with exact inventory. Use failed-write injection to prove effect + receipt + checkpoint roll back together.

**Acceptance:**

- Every retained assertion is exercised through current source; retired-only shadow fields are explicitly mapped to preserved history or evidenced retirement.
- Original failed transport receipt is unchanged; a successful reconciliation has its correct original logical attempt and one scheduling effect; conflict cases commit none.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_queue_attempt_recovery.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_position_review_reconciliation.py` — cwd `.`; focused; current.
- `node --test --test-concurrency=1 tests/runner/postgres-test-speedups.test.mjs` — cwd `.`; focused; current.

**Integration:** P14: replacement current queue case; P12 real browser replay/receipt acceptance.

**Material risks:** A historical hold is not successful recovery. Report that disposition explicitly and do not count it as a completed current review.

**Exclusions:** No neighboring cleanup or unrelated feature restoration.

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### P06 — Restore the three retained manual prefix-split HTTP routes

**Scope:** original-packet-residue. Findings: ST012, ST013. Prior tasks: E02.

**Prerequisites (reviewed source/capability unless explicitly stronger):** Independent bounded source task; reserve listed paths.

**Owner/resource conditions:** main.py path sequence: P06 → B31 → B04/B05 → B06 → B27 → B21. Reserve proposed router/test paths.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `SPEC.md`; `backend/app/prefix_split_commands.py` (accept_prefix_split, reject_prefix_split); `backend/app/services/prefix_split.py` (preview_prefix_split, apply_prefix_split); `backend/app/main.py`; `backend/app/contracts/transport/content.py` (PrefixSplitRequest); `app/lib/prefix-split-command.ts`; `app/views/card_editor.tsx`; `app/views/training_view.tsx`.

**Write scope:** `backend/app/prefix_split_routes.py` [proposed; reserve before creation]; `backend/app/main.py` [existing]; `backend/tests/test_prefix_split_http.py` [proposed; reserve before creation]; `tests/REGRESSIONS.md` [existing].

**Steps:**

1. Add a small router using GET /api/cards/{identifier}/prefix-split for the existing read-only preview and POST on that path plus /reject for the existing registered commands. Mount it once in main.py.
2. Follow current command_dispatch and operation response semantics exactly: original Idempotency-Key, expected revision, 202 original operation polling, immutable payload conflict, completed/failed/blocked distinctions.
3. Keep SQL and split policy in their existing owners. Preserve actual source/currentness, integrity, original membership, active-attempt and queue-order protections; add a route-level negative wherever transport must carry the authoritative revision/identity.
4. Use a real assembled FastAPI route inventory to prove the routes mount; route tests exercise read/writer dispatch, not mocked product responses. Send P07/P12 the supported endpoints and exact result schema.

**Acceptance:**

- Exactly one GET and two POST routes mount on the normal packaged app and invoke existing owners.
- Preview is read-only; accept/reject use the original operation and revision; stale/illegal/conflicting requests fail truthfully.
- P12 proves actual UI→HTTP→writer→receipt→playable successor, so route-source success alone is component-tested only.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_prefix_split_http.py` — cwd `.`; focused; proposed test path; execute only after the named owning task creates and registers it.
- `npm run test:frontend -- prefix-split-pending-regressions` — cwd `.`; focused; current.
- `npm run test:frontend -- prefix-split-training-regressions` — cwd `.`; focused; current.

**Integration:** P07 restores real durability HTTP checks; P12 adds the real prefix-split browser case using existing owned fixtures.

**Material risks:** The native command currently succeeds while the HTTP surface is absent; mocks of these endpoints cannot close the gap.

**Exclusions:** Advanced prefix transition/evaluation; Automatic recombination; New scheduler or new split algorithm

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### P07 — Restore truthful HTTP coverage and acceptance scope in every shared runner mode

**Scope:** original-packet-residue. Findings: ST012, ST013, RT004. Prior tasks: E02.

**Prerequisites (reviewed source/capability unless explicitly stronger):** P04; P05; P06

**Owner/resource conditions:** One owner serializes runner/CI-validator edits after P04/P05/P06 source releases; P08 historical proof may proceed independently.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `database/tests/test-postgres-docker.mjs` (verifyForegroundAndStudyDurability); `database/tests/postgres-test-plan.mjs` (postgresTestStages, verifyMaintainedQueueReceipt); `tests/fixtures/postgres-study-prefix-split.py`; `scripts/ci-run-layer.mjs` (validatePostgresScenarios); `scripts/ci-fast-lane.mjs`.

**Write scope:** `database/tests/test-postgres-docker.mjs` [existing]; `database/tests/postgres-test-plan.mjs` [existing]; `tests/fixtures/postgres-study-prefix-split.py` [existing]; `scripts/ci-run-layer.mjs` [existing]; `scripts/ci-fast-lane.mjs` [existing]; `tests/runner/postgres-test-speedups.test.mjs` [existing]; `tests/runner/ci-fast-lane.test.mjs` [existing]; `tests/runner/ci-reliability.test.mjs` [existing].

**Steps:**

1. Until P06 is accepted, emit the explicit unresolved prefix HTTP limitation in full, durability, study and maintained selections, or keep the normal HTTP assertion failing outside the explicitly partial lane. Do not let a mode label imply the previous HTTP coverage.
2. After P06, restore real HTTP GET preview + POST accept through API and original operation receipt settlement, exact split rows and replay. The Python helper may remain a native invariant check, but cannot substitute for HTTP evidence.
3. Update current queue inventory only after P04/P05 actual dispositions. Keep historical rollback P08 separately visible until executed or explicitly removed from current support with evidence.
4. Extend existing report validators and negative controls to reject a pass with missing HTTP/replay proof, wrong acceptance scope, unresolved required cases, zero selection, skip/retry, duplicate cases or incomplete cleanup. Do not invent a second report format.
5. Publish exact --list output before the one integration run; every selected mode reports its real scope and raw case set.

**Acceptance:**

- All consumers of study_durability preserve HTTP proof or visibly carry its unresolved limitation.
- A successful maintained subset cannot be relabeled full E02/full-system qualification; final E02 closure requires P04/P05/P06/P08 and P14/P12 evidence.

**Commands (planned, not executed):**

- `node --test --test-concurrency=1 tests/runner/postgres-test-speedups.test.mjs tests/runner/ci-fast-lane.test.mjs tests/runner/ci-reliability.test.mjs` — cwd `.`; focused; current.
- `node database/tests/test-postgres-docker.mjs --mode study --maintained-study-proof --list` — cwd `.`; discovery; current.
- `node database/tests/test-postgres-docker.mjs --mode durability --list` — cwd `.`; discovery; current.

**Integration:** P14 current native/HTTP stage; P12 exact real browser cases.

**Material risks:** An exit-zero stage without exact source and HTTP evidence can silently preserve the current claim hazard.

**Exclusions:** No neighboring cleanup or unrelated feature restoration.

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### P08 — Give the historical 49→48→49 rollback case a finite, explicit supported disposition

**Scope:** original-packet-residue. Findings: ST012, ST013. Prior tasks: E02.

**Prerequisites (reviewed source/capability unless explicitly stronger):** Independent bounded source task; reserve listed paths.

**Owner/resource conditions:** Reserve shared runner paths independently of P07 completion; recheck exact historical/current schema sources.

**Shared-file sequence:** P07/P14 own the same runner/options/plan files; one integration owner applies each reviewed patch sequentially.

**Read first:** `database/tests/check_postgres_study_priority.py` (historical_migration_sources, require_copy_contract, historical_rollback_proof, run_proof, main); `database/tempo_storage/ddl/migrations/049_study_priority_recovery.sql`; `database/tempo_storage/ddl/rollbacks/049_study_priority_recovery.sql`; `database/tests/postgres-test-plan.mjs`.

**Write scope:** `database/tests/check_postgres_study_priority.py` [existing]; `database/tests/postgres-test-options.mjs` [existing]; `database/tests/postgres-test-plan.mjs` [existing]; `database/tests/test-postgres-docker.mjs` [existing]; `tests/runner/postgres-test-speedups.test.mjs` [existing]; `tests/REGRESSIONS.md` [existing].

**Steps:**

1. Recommended disposition: retain the index-only historical rollback safety case because the rollback SQL remains supported historical source; keep it separate from current65 lifecycle.
2. Inspect whether exact current→historical table-copy contracts actually match. If they do not, do not weaken require_copy_contract or project away new history: seed the exact schema49 fixture directly on its owned historical database with an explicit historically accepted request/receipt fixture and preserve a separate current65 sentinel unchanged.
3. Expose one fixed historical-rollback selection in the existing runner (or reuse the existing full six-case current runner if its exact inputs are already valid). A new selector must have exact cases/refusal/cleanup tests before it is advertised.
4. Prove exact ledger1..49 →1..48→1..49, only the two intended priority indexes change, all 60 historical accepted review/receipt rows remain byte-equivalent, and the original current65 database, ledger and sentinel history never change.
5. If the integration owner instead retires this historical operation, first prove no supported CLI/upgrade/rollback command calls it, update the actual support documentation/registration, retain source history, and record the owner decision. Do not merely mark it not required because the installed database is65.

**Acceptance:**

- One executable retained historical proof or one positively evidenced retired-support decision accounts for the old sixth case; no generic defer.
- No claim that a 65→48 live downgrade is safe; no current65 schema/image rollback is attempted.

**Commands (planned, not executed):**

- `PYTHONPATH=backend:database backend/.venv/bin/python database/tests/check_postgres_study_priority.py --list` — cwd `.`; discovery; current.
- `PYTHONPATH=backend:database backend/.venv/bin/python database/tests/check_postgres_study_priority.py --current-only --list` — cwd `.`; discovery; current.
- `node --test --test-concurrency=1 tests/runner/postgres-test-speedups.test.mjs` — cwd `.`; focused; current.

**Integration:** P14 runs the delivered single-case selector on one owned native slot; exact command must be copied from reviewed --list and parser, not guessed.

**Material risks:** The current proof requires exact source/destination table contracts; a silent reduced projection could make an unsafe historical copy appear equal.

**Exclusions:** No neighboring cleanup or unrelated feature restoration.

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### P16 — Require successful original-review replay and a playable final successor

**Scope:** original-packet-residue. Findings: ST012. Prior tasks: E02.

**Prerequisites (reviewed source/capability unless explicitly stronger):** C11; P07

**Owner/resource conditions:** Apply the shared path lease and exact candidate rules.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `tests/browser/study-only-mode.spec.ts`; `database/tests/check_postgres_training_transition.py`; `tests/browser/recovery.spec.ts`.

**Write scope:** `tests/browser/study-only-mode.spec.ts` [existing]; `database/tests/check_postgres_training_transition.py` [existing]; `tests/REGRESSIONS.md` [existing].

**Steps:**

1. Capture the first real review response and original idempotency key/body. After worker restart, validate the resend response; if202, poll the same original operation to a successful authoritative receipt.
2. Compare original and replay attempt/card/revision/review/result identity, retain exactly three committed human reviews and exactly-once complete evidence.
3. Assert the fourth authoritative queue entry renders with input enabled and play one legal move; do not click Correct or create a fourth completed review just to prove playability.
4. Add/refine negative test logic so 4xx/5xx resend or foreign/malformed receipt fails even if review count remains3. Preserve settings restoration and owned fixture cleanup.

**Acceptance:**

- A rejected resend cannot pass. Three completed review→successor transitions have observed playable successors if that claim is made.
- No stage duration is described as user review cadence or end-to-end interaction latency.

**Commands (planned, not executed):**

- `node database/tests/test-postgres-docker.mjs --mode browser --browser-grep "study_only_mode_preserves_foreground_review_and_queue_progression across reload and resumption$" --list` — cwd `.`; discovery; current.

**Integration:** P12 runs this exact case once on the assembled candidate.

**Material risks:** Counting rows proves no observed duplicate, not successful replay or a usable successor.

**Exclusions:** No neighboring cleanup or unrelated feature restoration.

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### P17 — Reconcile E00/E01/E03/E02 evidence descriptions with actual current proof

**Scope:** original-packet-residue. Findings: ST012, ST013. Prior tasks: E00, E01, E02, E03.

**Prerequisites (reviewed source/capability unless explicitly stronger):** P01; P04; P05; P06; P07; P08; P16

**Owner/resource conditions:** Integration owner serializes shared guides/progress record; accepted qualification provenance is appended only when earned.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `database/tests/README.md`; `docs/testing.md`; `tests/REGRESSIONS.md`; `tempo-low-fruit-20261112/progress/merge-review.json`; `database/tests/check_postgres_game_review_reader.py`.

**Write scope:** `database/tests/README.md` [existing]; `docs/testing.md` [existing]; `tests/REGRESSIONS.md` [existing]; `tempo-low-fruit-20261112/progress/merge-review.json` [existing].

**Steps:**

1. Describe accepted E00 exact-case bridge and E01 current borrowed-owner cases; keep P01 semantic limitations until repaired.
2. Replace obsolete pending E03/ten-relation statements with the current three-relation read-only proof, real saved/pasted HTTP producer, source/image identity and no Study-write assertions.
3. Record #1004 merged partial E02 as historical evidence with its actual qualification source, four residuals and QF-02/QF-03 limits; update only with new raw accepted evidence when earned.
4. Keep reported installed d79/schema65 and current source091ad distinct. Documentation-only changes do not require reinstalling identical product code.

**Acceptance:**

- Current owner guides and regression descriptions match executable source and exact evidence; no prior report is relabeled as a current pass.
- ST010 stays closed; this is finite proof-record alignment, not another documentation audit.

**Commands (planned, not executed):**

- `git diff --check` — cwd `.`; source; current.

**Integration:** No additional heavy proof for this isolated pure change.

**Material risks:** Overwriting old qualification provenance destroys the distinction between reported and independently observed evidence.

**Exclusions:** No neighboring cleanup or unrelated feature restoration.

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### S01 — Separate typed position source values from the concrete sealed SQL capability

**Scope:** audit-expansion. Findings: ST002. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** B00

**Owner/resource conditions:** B00 releases the actual port decision; B26 later adopts S01/S02, so do not depend on B26 here. Co-design S34 shape without a reverse dependency.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `database/tempo_storage/authored_repertoires/position_study_source.py` (AuthoredSourceToken, PreparedPositionSource, PreparedPositionSourceWithFacts, prepared_source, fence_position_source); `backend/app/repertoire/position_study_source.py` (prepare_position_source, prepare_position_source_with_facts); `backend/app/contracts/product_v02/repertoire.py` (RepertoireSnapshot, DecisionPresentation); `packages/evidence-math/src/tempo_evidence_math/position_learning.py`; `backend/app/repertoire/snapshot.py` (PreparedPublishedRepertoire).

**Write scope:** `packages/evidence-math/src/tempo_evidence_math/position_learning.py` [existing]; `database/tempo_storage/authored_repertoires/position_study_source.py` [existing]; `backend/app/repertoire/position_study_source.py` [existing]; `backend/app/study/position_learning/contracts.py` [existing]; `backend/tests/test_position_learning_contract_values.py` [existing]; `database/tests/position_study/test_position_source_authority.py` [existing].

**Steps:**

1. Choose the smallest existing pure position contract surface and add narrow typed source/membership/decision-binding/publication fact views. Do not import backend, SQL, or full Repertoire implementation into evidence-math.
2. Replace snapshot: object, routes: tuple and untyped publication-fact dictionaries at the public boundary with those semantic types and existing RouteOption/PositionDefinition/SourceCertificate values.
3. Keep the actual capability seal private to the storage/preparation implementation. Public clients depend on the pure view/port; a value with matching fields or digest alone is never sufficient authority.
4. Update every current import of the public prepared classes to the contract surface. One fake preparation+fence pair may substitute the boundary for policy tests; the real writer still rejects its foreign/forged ticket.
5. Preserve original full snapshot provenance versus current authored digest, exact header/integrity comparison, bounded source read, graph lock and currentness fences.

**Acceptance:**

- Importing public values does not import tempo_storage, psycopg, application composition or start I/O.
- No public snapshot/routes/bindings/facts field remains object/unparameterized tuple/Any.
- Foreign/forged preparation and stale source still fail closed; native source/currentness proof retains lock order and limits.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_position_learning_contract_values.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_position_schedule_occurrences.py` — cwd `.`; focused; current.
- `PYTEST_ADDOPTS='--deselect=database/tests/position_study/test_position_source_authority.py::test_native_id_only_edit_and_busy_row_cannot_cross_fence' make python-file FILE=database/tests/position_study/test_position_source_authority.py` — cwd `.`; focused; current.

**Integration:** One current source-authority native case on P14 or the final changed-storage integration checkpoint; a new fixed bridge selector must be implemented/reviewed before execution if the existing selector does not reach the fence.

**Material risks:** Replacing sealed implementation checks with structural typing at runtime would let constructed data bypass preparation authority.

**Exclusions:** New service/package/repository framework; Moving graph traversal into a writer transaction; Changing supported source bounds

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### S02 — Type introduction and owner-fence contracts without weakening their seals

**Scope:** audit-expansion. Findings: ST002. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** S01; P02; B07

**Owner/resource conditions:** Apply the shared path lease and exact candidate rules.

**Shared-file sequence:** position_introductions.py and position_owner_epoch.py after B07, then S08/S10 as applicable.

**Read first:** `database/tempo_storage/study/position_introductions.py` (PreparedIntroduction, IntroductionFence, prepare_introduction, fence_introduction, initialize_introduction); `database/tempo_storage/study/position_owner_epoch.py` (OwnerDecision, fence_position_owner_in_writer); `backend/app/services/position_queue_admission.py`; `backend/tests/test_position_introductions.py`.

**Write scope:** `database/tempo_storage/study/position_introductions.py` [existing]; `database/tempo_storage/study/position_owner_epoch.py` [existing]; `backend/app/services/position_queue_admission.py` [existing]; `packages/evidence-math/src/tempo_evidence_math/position_learning.py` [existing]; `backend/tests/test_position_introductions.py` [existing].

**Steps:**

1. Consume S01 typed source and introduce named typed definition/binding/manifest/owner-epoch fields for preparation and fence results.
2. Keep source, owner, allocator namespace, completed seed manifest, unseen alias/history, card locks and exact prepared-object identity in their existing order; preserve the private preparation and fence capabilities.
3. Keep initial FSRS state construction in the scheduling owner and the allocated-ID callback contract from accepted ST001. Do not reintroduce fsrs.Card into storage.
4. Update actual admission callers and fake boundaries together; use injected failures before and after allocation to preserve atomic insertion and historical hold recording.

**Acceptance:**

- Public imports are SQL-independent and exact fields are semantically typed.
- Fresh introduction only writes after real admission; forged/mismatched fence, changed owner/source/history or failing initialization leaves no partial state.
- ST001 remains closed with its scheduling/storage ownership intact.

**Commands (planned, not executed):**

- `PYTEST_ADDOPTS='--deselect=backend/tests/test_position_introductions.py::test_native_authorized_introduction_writes_fresh_state_only_after_admission' make python-file FILE=backend/tests/test_position_introductions.py` — cwd `.`; focused; current.
- `PYTEST_ADDOPTS='--deselect=backend/tests/test_position_queue_admission.py::test_native_refresh_admits_due_carrier_and_reuses_pending' make python-file FILE=backend/tests/test_position_queue_admission.py` — cwd `.`; focused; current.

**Integration:** P14 existing --native-check position-introductions and position-queue-admission prove changed introduction/currentness transaction boundary.

**Material risks:** Merely renaming tuples without current consumer adoption leaves the same coupling; generalized token serialization would destroy ephemeral authority.

**Exclusions:** No neighboring cleanup or unrelated feature restoration.

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### S03 — Inject workspace and IndexedDB dependencies into the offline storage instance

**Scope:** audit-expansion. Findings: ST003. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** FE06; FE08

**Owner/resource conditions:** Frontend FE06 releases authority-adapter contract; reserve app/lib/study-connection.ts.

**Shared-file sequence:** app/lib/study-connection.ts after FE06, before S04/S05.

**Read first:** `database/browser/offline-training-storage.ts` (offlineTrainingDatabase); `database/browser/prepared-training-storage.ts`; `app/lib/study-connection.ts`; `app/domain/study-authority.ts`; `database/browser/study-connection-storage.ts`.

**Write scope:** `database/browser/offline-training-storage.ts` [existing]; `database/browser/prepared-training-storage.ts` [existing]; `app/lib/study-connection.ts` [existing]; `app/lib/offline-training.ts` [existing]; `tests/unit/study-storage-boundary-regressions.test.tsx` [existing]; `tests/unit/offline-training-regressions.test.ts` [existing].

**Steps:**

1. Consume the frontend FE005 authority-adapter contract; create a storage instance with workspace/database name, IDBFactory and failure notification supplied by browser composition.
2. Remove the storage→app/lib/study-connection import and global singleton ownership. Preserve the exact workspace-derived database naming and existing version2 stores/indexes.
3. Keep one promise/cache per instance with explicit close/versionchange handling. Reject blocked upgrade without losing retained records or using another workspace.
4. Adopt the instance through the existing Study composition/connection owner and prepared-queue adapter; retain a compatibility re-export only if current consumers still need it and it delegates to that composition.

**Acceptance:**

- Storage can be imported/instantiated with two isolated factories/workspaces without importing the application Study singleton.
- Mixed-version blocked/versionchange/retry cases preserve raw stores and original queue/attempt IDs.

**Commands (planned, not executed):**

- `npm run test:frontend -- study-storage-boundary-regressions` — cwd `.`; focused; current.
- `npm run test:frontend -- offline-training-regressions` — cwd `.`; focused; current.

**Integration:** P12 final browser offline reload and saved-review replay if this task is included; no native PostgreSQL solely for this factory refactor.

**Material risks:** A new default name or cache shared across instances can silently bind one workspace to another.

**Exclusions:** No neighboring cleanup or unrelated feature restoration.

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### S04 — Inject intent-store validation and portable-backup diagnostics at composition

**Scope:** audit-expansion. Findings: ST003. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** S03; FE08; FE24

**Owner/resource conditions:** Apply the shared path lease and exact candidate rules.

**Shared-file sequence:** study-intent-store.ts after FE24; pure parser is FE08, do not duplicate it.

**Read first:** `database/browser/study-intent-storage.ts` (initializeStudyIntentStorage, migrate, closeStudyIntentStorage); `database/browser/tempo-db.ts` (getRecords, putRecords, openTempoDatabase); `database/browser/encrypted-backup.ts`; `app/lib/study-legacy-validation.ts`; `app/lib/validated-data.ts`; `app/lib/data-validation.ts`.

**Write scope:** `database/browser/study-intent-storage.ts` [existing]; `database/browser/tempo-db.ts` [existing]; `database/browser/encrypted-backup.ts` [existing]; `app/lib/study-legacy-validation.ts` [existing]; `app/lib/study-intent-store.ts` [proposed; reserve before creation]; `tests/unit/study-storage-boundary-regressions.test.tsx` [existing]; `tests/unit/validated-data-regressions.test.ts` [existing].

**Steps:**

1. Consume frontend FE08 pure parsing contract; storage accepts pure schemas/validators and an injected diagnostic reporter, without importing validated-data/debug-reporting or application review implementations.
2. Inject workspace, intent-store opener/factory, Web Storage and notifications into an explicit intent storage instance. Move window storage-listener registration to lifecycle composition with unsubscribe.
3. Keep all legacy source keys, cutover acknowledgement semantics, source rereads, frozen payload bytes, generation cancellation, teaching facts and conflict states unchanged.
4. Adopt these dependencies through the existing Study intent/session composition after FE006. Portable export/import retains its version/encryption envelope and tombstone/order semantics; do not redesign backup format.
5. Prove malformed legacy bytes remain retained, failed/aborted hydration cannot publish ready, an older tab invalidates the same gate, and stale generation callbacks cannot overwrite a newer workspace.

**Acceptance:**

- No database/browser production import targets app/lib implementation modules.
- Storage instance tests supply workspace/factory/validation/diagnostics/notifications without application singleton startup.
- Original durable IDs, byte-preserved payloads and mixed-version recovery behave identically.

**Commands (planned, not executed):**

- `npm run test:frontend -- study-storage-boundary-regressions` — cwd `.`; focused; current.
- `npm run test:frontend -- validated-data-regressions` — cwd `.`; focused; current.
- `npm run test:frontend -- pending-review-recovery-regressions` — cwd `.`; focused; current.

**Integration:** P12 real reload/acknowledgment recovery and offline retained journal acceptance on the assembled browser.

**Material risks:** Moving event registration without lifecycle cleanup may double-notify or leave old workspace listeners active.

**Exclusions:** Merging distinct review, opening-event and teaching authorities into one global store

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### S05 — Make the opening journal own IndexedDB lifetime and commit-boundary results

**Scope:** audit-expansion. Findings: ST004. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** S03; S04; C11

**Owner/resource conditions:** Apply the shared path lease and exact candidate rules.

**Shared-file sequence:** opening-evidence-journal.ts after C11 original-identity change.

**Read first:** `database/browser/opening-evidence-journal-storage.ts` (appendOpeningAttempt, readSavedOpeningJournal, removeAcknowledgedOpeningAttempt, confirmOpeningDelivery, readRecoveryAttempt, readGuardedOpeningAttempts); `app/lib/opening-evidence-journal.ts` (reconcileRecoveryGuards, recoveryCandidate, pendingAggregateAttempts, recoverySchedule); `app/domain/opening-evidence-journal.ts`.

**Write scope:** `database/browser/opening-evidence-journal-storage.ts` [existing]; `app/lib/opening-evidence-journal.ts` [existing]; `app/domain/opening-evidence-journal.ts` [existing]; `tests/unit/opening-evidence-regressions.test.ts` [existing]; `tests/unit/opening-evidence-offline-quota.test.ts` [existing]; `tests/unit/opening-evidence-recovery-policy.test.tsx` [existing].

**Steps:**

1. Expose a typed journal instance/factory bound to the S03 storage provider. Public journal methods accept semantic attempt/checkpoint/receipt values, not IDBDatabase.
2. Move opening/closing/transaction wiring behind that adapter. Keep capture, retry/lease/recovery policy and transport in app/lib/opening-evidence-journal.ts.
3. Define each method result at transaction completion. Replace callbacks invoked on request success before commit with committed results; application notification follows resolved success.
4. Add the concrete abort-after-request-success case for acknowledgment/removal and write failure. An aborted transaction must preserve retained records and emit no confirmed/removal signal.
5. Preserve complete position-plan first responses through partial checkpoint acknowledgments, quota retention, original operation identity from FE001, bounded event limits, reload and cross-tab signaling.

**Acceptance:**

- No raw IDBDatabase parameter/local variable remains in application journal policy.
- Request failure and transaction abort cannot acknowledge/remove authority or publish success; committed retries preserve original event/operation IDs.
- Real browser quota/reload/acknowledgment/position-plan recovery is accepted in P12.

**Commands (planned, not executed):**

- `npm run test:frontend -- opening-evidence-regressions` — cwd `.`; focused; current.
- `npm run test:frontend -- opening-evidence-offline-quota` — cwd `.`; focused; current.
- `npm run test:frontend -- opening-evidence-recovery-policy` — cwd `.`; focused; current.

**Integration:** P12 browser recovery and offline journal cases once, with actual IndexedDB and real server receipt traffic.

**Material risks:** Resolving a read/write promise or notifying at request success can still precede transaction abort; tests must inject the abort at that exact boundary.

**Exclusions:** Global journal unification; Changing persisted keys or discarding retained quota records

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### S06 — Use explicit supported transaction capabilities for eligibility and frozen-order locks

**Scope:** audit-expansion. Findings: ST006. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** P02; B07

**Owner/resource conditions:** S06 releases the explicit capability semantics before S16; shared frozen_order.py edits are serialized, never a reverse task dependency.

**Shared-file sequence:** test_position_queue_admission.py after P02/B07; frozen_order.py before S16.

**Read first:** `database/tempo_storage/queue_refresh/eligibility.py` (position_due_exclusion); `database/tempo_storage/frozen_order.py` (activation, activate_run, restore_queue_changes); `database/tempo_storage/queue_refresh/application/seeding.py` (due_cards); `database/tempo_storage/queue_refresh/application/admission.py` (has_missing_due_card); `database/tempo_storage/postgres.py` (PostgresConnection).

**Write scope:** `database/tempo_storage/queue_refresh/eligibility.py` [existing]; `database/tempo_storage/frozen_order.py` [existing]; `database/tempo_storage/postgres.py` [existing]; `backend/tests/test_position_queue_admission.py` [existing]; `backend/tests/test_frozen_opening_order.py` [existing]; `backend/tests/test_frozen_queue_refresh_regression.py` [existing].

**Steps:**

1. Remove behavior choices based solely on isinstance(raw, psycopg.Connection) or isinstance(database, PostgresConnection). Use the existing borrowed transaction capability plus an explicit schema-read/lock capability or fail clearly.
2. Equivalent supported wrappers must execute the same to_regclass ownership check, due exclusion and FOR SHARE/FOR UPDATE clauses. A replacement incapable of those semantics must refuse, never omit a guard.
3. Keep missing-table behavior only for explicitly supported pre-migration reads; current schema65 cannot silently claim no position owner because the wrapper type differs.
4. Add spy/fake conformance tests that inspect the requested schema/lock queries and a native two-connection contention case for activation/restoration; preserve original queue occupants and protected attempts.

**Acceptance:**

- Equivalent supported capabilities choose identical eligibility and locking semantics.
- Unsupported adapter fails with an actionable error before writes; no fallback to unlocked/legacy eligibility.
- Native lock/concurrency proof remains separate from the passing fake conformance tests.

**Commands (planned, not executed):**

- `PYTEST_ADDOPTS='--deselect=backend/tests/test_position_queue_admission.py::test_native_refresh_admits_due_carrier_and_reuses_pending' make python-file FILE=backend/tests/test_position_queue_admission.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_frozen_opening_order.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_frozen_queue_refresh_regression.py` — cwd `.`; focused; current.

**Integration:** P14 exact admission native case plus bounded frozen-order native lock case selected through the existing owning native runner.

**Material risks:** A generic capability bool supplied by arbitrary callers can recreate the guard bypass; supported adapters must actually implement the declared semantics.

**Exclusions:** No neighboring cleanup or unrelated feature restoration.

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### S07 — Separate queue-abandonment request/policy from SQL and operator transport

**Scope:** audit-expansion. Findings: ST014. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** T02

**Owner/resource conditions:** P13 harness is needed only for applicable later CLI qualification, not to start pure contract/policy work.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `database/tempo_storage/lifecycle/queue_attempt_abandonment.py` (validate_request, origin_fingerprint, plan_in_writer, abandon_in_writer, _locked_origin, _check_unaccepted, main); `scripts/position-study/abandon-queue-attempt.mjs`; `backend/tests/test_queue_attempt_abandonment_postgres.py`; `database/tests/check_postgres_cli_lifecycle.py` (abandon_fixture).

**Write scope:** `backend/app/contracts/queue_attempt_abandonment.py` [proposed; reserve before creation]; `backend/app/study/queue_attempt_abandonment.py` [proposed; reserve before creation]; `backend/app/queue_attempt_abandonment_cli.py` [proposed; reserve before creation]; `database/tempo_storage/lifecycle/queue_attempt_abandonment.py` [existing]; `scripts/position-study/abandon-queue-attempt.mjs` [existing]; `backend/tests/test_queue_attempt_abandonment_postgres.py` [existing]; `tests/runner/tempo-cli.test.mjs` [existing].

**Steps:**

1. Add pure typed PlanRequest/ApplyRequest/OriginFacts/PlanResult/AbandonmentReceipt values under the existing backend contract owner; request/origin fingerprints keep exact encoding and UTC rules.
2. Move the unfinished-issued-legacy-opening eligibility decision to one Study application owner. Storage supplies locked semantic origin/queue/accepted-review/position-plan facts and persists the exact receipt under its existing locks/savepoint.
3. Move argparse/base64 transport to a thin backend CLI composition module; update the registered target-checked Node operator to call it. Keep target lock, installed immutable image/config verification and default-plan/apply distinction.
4. Preserve original queue/card/revision/operation/digest/actor/reason and exact replay/conflict behavior. Keep missing pre-migration receipt lookup safe where actually supported.
5. Use existing native abandonment fixture to prove concurrent review wins safely, changed origin holds, duplicate apply returns the same receipt, and unrelated origins/reviews/cards/grades remain byte-identical.

**Acceptance:**

- Public request/result contract imports without SQL or CLI startup.
- Exactly one Study policy owner and one SQL writer remain; operator and Study lookup call the same contract.
- Native concurrency/replay/rollback and target-isolation acceptance pass; no actual user attempt is abandoned.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_queue_attempt_abandonment_postgres.py` — cwd `.`; native; current wrapper; run only inside the admitted owned native fixture with exact non-skipping case execution.
- `node --test --test-concurrency=1 --test-name-pattern="abandon" tests/runner/tempo-cli.test.mjs` — cwd `.`; focused; current.

**Integration:** P14 bounded native abandonment test through the existing fixture; P13 registered disposable operator plan/apply/replay, never live apply.

**Material risks:** Moving savepoint/lock orchestration can race review acceptance. Keep card lock → queue day → origin lock order and atomic receipt boundary.

**Exclusions:** Changing abandonment eligibility; Abandoning any live attempt; Adding a new recovery state machine

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### T01 — Share the exact cut62 witness policy and qualify its current lifecycle use

**Scope:** original-packet-residue. Findings: RT005. Prior tasks: F02, E04.

**Prerequisites (reviewed source/capability unless explicitly stronger):** Independent bounded source task; reserve listed paths.

**Owner/resource conditions:** Integration owner records current65 lifecycle applicability before source implementation; this is a decision, not P13 completion. T01 reviewed source feeds P13; P13 accepted native lifecycle gates T01 merge.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `scripts/tempo-runtime.mjs` (cut62WitnessName, validateCut62Preflight); `scripts/tempo-managed-isolation.mjs` (cut62WitnessName); `scripts/tempo-deployment.mjs`; `tests/runner/tempo-cli.test.mjs`.

**Write scope:** `scripts/tempo-runtime.mjs` [existing]; `scripts/tempo-managed-isolation.mjs` [existing]; `scripts/tempo-deployment.mjs` [existing]; `tests/runner/tempo-cli.test.mjs` [existing].

**Steps:**

1. Put the one pure witness-name policy in the existing shared deployment owner, or a single dependency-safe module already owned by that CLI component. Both current runtime and managed-isolation callers import it; preserve any verified public re-export.
2. Preserve exact rule: no crossing returns null; legal crossings are only starting59 or61 to intended62 with the existing UUID acceptance/filename; unsupported crossings keep the exact fail-closed error. Do not generalize this historical safety rule to64/65.
3. Run exact old/new equivalence matrix for lower/upper/malformed/missing schemas, UUIDs, same-schema and illegal63/64/65 intended targets; retain private-file, witness identity, original backup/retry and interrupted-capture controls.
4. Release the reviewed source to P13 before merge. Use its current65 disposable lifecycle acceptance and unchanged-input historical policy controls; do not require obsolete current63 reconstruction merely because that old harness refuses65.

**Acceptance:**

- One cut62WitnessName body; two real callers; no import cycle or changed witness/error/legal-crossing outcome.
- Focused comparator/witness controls plus applicable actual current lifecycle proof pass before merge. Source-only extraction is not itself merge-qualified.

**Commands (planned, not executed):**

- `node --test --test-concurrency=1 --test-name-pattern='schema 62 comparator accepts only the exact guarded crossing' tests/runner/tempo-cli.test.mjs` — cwd `.`; focused; current.
- `node --test --test-concurrency=1 --test-name-pattern='schema 62 (retry requires|bind source|runtime preserves|rejects a different|interrupted capture)' tests/runner/tempo-cli.test.mjs` — cwd `.`; focused; current.
- `node --test --test-concurrency=1 --test-name-pattern='schema 6[345]' tests/runner/tempo-cli.test.mjs` — cwd `.`; focused; current.

**Integration:** P13 current65→candidate65 registered disposable lifecycle with exact immutable images/config and recovery; add64→65 only if a real supported starting64 path is in scope.

**Material risks:** This tiny extraction sits on migration safety. A lower source line count does not waive lifecycle-sensitive acceptance.

**Exclusions:** New historical migration support; Weakening current63/full refusal; Live installation in this planning stage

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. T01 source-reviewed release + P13 actual applicable lifecycle acceptance + exact candidate review; P13 consumes T01 source before merge.

### T02 — Make the existing component registry describe every current executable owner

**Scope:** audit-expansion. Findings: RT003. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** Independent bounded source task; reserve listed paths.

**Owner/resource conditions:** Reserve components.json. Apply reviewed current owner declarations in finite batches; no blanket dependency on every downstream typed implementation.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `components.json`; `components.schema.json`; `tools/component-build/selection.mjs`; `tools/component-build/check-components.mjs`; `tools/component-build/affected.mjs`; `tools/component-build/README.md`.

**Write scope:** `components.json` [existing]; `components.schema.json` [existing]; `tools/component-build/selection.mjs` [existing]; `tools/component-build/check-components.mjs` [existing]; `tools/component-build/README.md` [existing]; `tools/component-build/tests/boundaries.test.mjs` [existing]; `tools/component-build/tests/integration.test.mjs` [existing].

**Steps:**

1. Reconcile exact tracked runtime paths against current owners. Classify each as one production owner, pure public contract, explicit composition, fixture/test, or tooling role; retain a source-linked zero-unowned/zero-overlap report.
2. Register existing board-ui and evidence-math public exports/local proof commands as implemented from their actual package manifests/README. Replace study-web/tempo-cli/integration placeholder roots with truthful current app/static/scripts/tempo ownership; do not pretend they are new independently deployable services.
3. Adopt backend/storage subowner boundaries and current public interfaces from accepted BE/S/FE releases, with explicit side-effect/SQL/table owner and composition exceptions. Keep one authoritative mapping; the selected guard map becomes a projection/input consumer, not a second hand-maintained policy.
4. Decide and record the existing affected planner role: recommended use its pure graph projection only if it can consume this same registry without a second source mapping; otherwise explicitly retire its unadopted production-planner claim and keep only reusable tested utility. No new planner.
5. Split publication into small owner batches (pure packages; browser/CLI composition; backend+storage). Each batch validates actual files/exports/test selection and a deliberate unowned/duplicate-path failure.

**Acceptance:**

- Every current executable source has one explicit owner/role and current public surface; implemented packages select through supported component commands.
- Current owner, API, dependencies, effect ownership and finite proof can be found without reading private implementation.
- No package is marked implemented based only on a README claim or a source-only test.

**Commands (planned, not executed):**

- `node tools/component-build/check-components.mjs --list` — cwd `.`; discovery; current.
- `node tools/component-build/test-lane.mjs frontend --list` — cwd `.`; discovery; current.
- `node tools/component-build/test-lane.mjs runners --list` — cwd `.`; discovery; current.
- `node tools/component-build/check-components.mjs` — cwd `.`; focused; current.
- `node --test --test-concurrency=1 tools/component-build/tests/boundaries.test.mjs tools/component-build/tests/integration.test.mjs` — cwd `.`; focused; current.

**Integration:** Package-local installed/source-removed proof only for newly registered implemented artifacts; no PostgreSQL/browser for metadata-only adoption unless its claimed command requires it.

**Material risks:** A giant owner root or blanket composition exception can hide private coupling while producing a false zero-unowned report.

**Exclusions:** No neighboring cleanup or unrelated feature restoration.

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### T03 — Enforce the actual public boundaries through the existing parser and registry

**Scope:** audit-expansion. Findings: RT002. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** T02; FE09; S01; S03; S04

**Owner/resource conditions:** FE09 source releases adopted pure domain imports; FE10 plus this guard supply full FE007 closure. Guard can develop from reviewed contract releases before downstream task merge.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `tools/component-build/check-interface-boundaries.mjs`; `tools/component-build/check-components.mjs`; `tools/component-build/selected-interface-owners.json`; `tools/component-build/tests/interface-boundaries.test.mjs`; `eslint.config.mjs`.

**Write scope:** `tools/component-build/check-interface-boundaries.mjs` [existing]; `tools/component-build/check-components.mjs` [existing]; `tools/component-build/selected-interface-owners.json` [existing]; `tools/component-build/tests/interface-boundaries.test.mjs` [existing]; `tools/component-build/REGRESSIONS.md` [existing].

**Steps:**

1. Consume T02 current owner map and actual public exports. Cover all current participating consumers, including new/unregistered source under owner roots; selected12files cannot stand in for whole-owner enforcement.
2. Resolve relevant relative, @/, bare workspace package, re-export, type-only, lazy/dynamic-literal and node: imports. Report type dependencies separately from emitted runtime reachability; do not claim an erased type import starts runtime I/O.
3. Add negative controls: optional Game Review→Study journal; public facade→SQL/infrastructure; previously unregistered consumer→private implementation; app/domain→app/components/effectful app/lib even through import type.
4. Retain positive controls for approved composition, internal private calls, own-module re-exports and neutral @tempo/board-ui type-only contracts. Enforce public import closure without wrapping private implementation as a fake facade.
5. Wire the real current guard through the existing component suite/CI selection. No parallel lint/policy framework.

**Acceptance:**

- Every named negative mutation fails for the intended boundary and every approved composition case passes.
- A new source consumer cannot silently escape the declared owner scope; missing/unknown imports are visible and conservative.
- Static guard is never described as native SQL, lifecycle or whole-program effect proof.

**Commands (planned, not executed):**

- `node tools/component-build/check-interface-boundaries.mjs tools/component-build/selected-interface-owners.json` — cwd `.`; focused; current.
- `node --test --test-concurrency=1 tools/component-build/tests/interface-boundaries.test.mjs` — cwd `.`; focused; current.
- `node tools/component-build/check-components.mjs` — cwd `.`; focused; current.

**Integration:** No additional heavy proof for this isolated pure change.

**Material risks:** Banning all bare imports or treating type-only imports as runtime would break legitimate package/public composition and overstate risk.

**Exclusions:** No neighboring cleanup or unrelated feature restoration.

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### T04 — Select proof by changed owner and effect instead of blanket Study filenames

**Scope:** audit-expansion. Findings: RT004. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** T02; T03; P07

**Owner/resource conditions:** Integration owner reserves shared CI selector/validator paths.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `scripts/ci-fast-lane.mjs` (selectFastLane, validateFastGate); `scripts/ci-fast-lane-inventory.json`; `scripts/ci-fast-commands.mjs`; `scripts/ci-verification-plan.mjs`; `scripts/ci-quality.mjs`; `.github/workflows/pages.yml`; `tools/component-build/affected.mjs`.

**Write scope:** `scripts/ci-fast-lane.mjs` [existing]; `scripts/ci-fast-lane-inventory.json` [existing]; `scripts/ci-fast-commands.mjs` [existing]; `scripts/ci-verification-plan.mjs` [existing]; `scripts/ci-quality.mjs` [existing]; `tests/runner/ci-fast-lane.test.mjs` [existing]; `tests/runner/ci-reliability.test.mjs` [existing]; `.github/workflows/pages.yml` [existing].

**Steps:**

1. Use T02 owner/proof/effect declarations as selection authority; remove duplicated hand-maintained path decisions only after equivalent selection tests exist.
2. For pure MoveNumberDisplay, OpeningTitle, board-ui geometry, chess-line and evidence-math implementation changes, select the relevant local/unit/contract consumers without PostgreSQL or unrelated browser suites.
3. For Study facade/session transport, review/receipt/journal behavior, SQL/locking or lifecycle changes, select the exact required current native/browser/CLI cases, including P07 truthful scope validation.
4. Keep unknown/ambiguous/deleted ownership conservative and explicit. Test rename/delete/package-public-interface changes, combined paths, missing files and stale source/case/report identities.
5. Preserve current exact-case/zero-skip/zero-retry validators and build-input/source binding. Reuse affected.mjs only according to T02 decision; no third planner or broad FAST exemption.

**Acceptance:**

- The original eleven path probes plus pure-vs-persistence mutations select proportional proof for the actual reason.
- A pure leaf does not require native/browser by name alone; changed durable behavior still selects its applicable real proof.
- Hosted CI unavailable remains ci-disabled; changing selection code does not claim hosted execution.

**Commands (planned, not executed):**

- `node --test --test-concurrency=1 tests/runner/ci-fast-lane.test.mjs tests/runner/ci-reliability.test.mjs` — cwd `.`; focused; current.
- `node --test --test-concurrency=1 tools/component-build/tests/affected.test.mjs` — cwd `.`; focused; current.

**Integration:** No additional heavy proof for this isolated pure change.

**Material risks:** Over-narrow selection can silently omit consumer breakage; retain unknown fallback and boundary-change consumer closure.

**Exclusions:** Enabling hosted CI; Running full-system suites for each pure leaf; Changing product resource limits

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### T05 — Declare and prove the Rust component fixture input contract

**Scope:** audit-expansion. Findings: ST011. Prior tasks: F01.

**Prerequisites (reviewed source/capability unless explicitly stronger):** T02

**Owner/resource conditions:** Integration owner records supported Rust component input-set decision before staging implementation.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `tempo-core/Cargo.toml`; `tempo-core/src/lib.rs`; `tests/fixtures/README.md`; `tests/fixtures/card-id-parity.json`; `tests/fixtures/position-distance-parity.json`; `tests/fixtures/core-parity.json`; `components.json`.

**Write scope:** `components.json` [existing]; `tempo-core/README.md` [existing]; `tests/fixtures/README.md` [existing]; `tools/component-build/tests/integration.test.mjs` [existing].

**Steps:**

1. Recommended current support decision: tempo-core is an independently testable repository component with an explicitly declared crate + three governed fixture input set; standalone published Cargo-package testing is not a current product promise.
2. Declare those exact files as fixture inputs in the existing component registry and README. Do not create parallel mutable fixture authority or alter parity bytes.
3. Add a source-restricted staging proof which copies only declared crate/workspace lock inputs and the three fixture paths into an owned temporary root, removes access to the source repository, and executes the documented Rust component tests.
4. Prove omitted fixture fails selection/staging before cargo. Reconcile Rust, backend/test_regressions.py and TypeScript parity consumers with the same governed fixture authority.
5. If the integration owner explicitly chooses independently publishable Cargo artifact support instead, put one governed fixture authority inside the packaged crate and update exact Python/TS consumers; verify cargo package contents and unpacked-crate tests. Do not claim package independence while relying on undeclared siblings.

**Acceptance:**

- The declared supported independent component test works from only its input set.
- One fixture authority remains and parity consumers use it; supported-scope decision is explicit and source-linked.
- ST007 stays closed; no replay algorithm is reintroduced.

**Commands (planned, not executed):**

- `cargo test --manifest-path tempo-core/Cargo.toml --locked` — cwd `.`; component; current.
- `cargo fmt --manifest-path tempo-core/Cargo.toml --check` — cwd `.`; component; current.

**Integration:** No native PostgreSQL or browser required for declared Rust fixture packaging with unchanged WASM API.

**Material risks:** Credible counterargument: future crate distribution benefits from self-contained fixtures. That is a different artifact promise; choose it explicitly rather than adding accidental sibling dependencies.

**Exclusions:** No neighboring cleanup or unrelated feature restoration.

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### P13 — Qualify the actual schema65 installation lifecycle and recovery path

**Scope:** original-packet-residue. Findings: RT005, ST012, ST013. Prior tasks: E04, F02.

**Prerequisites (reviewed source/capability unless explicitly stronger):** T01

**Owner/resource conditions:** One heavy-slot lease; independently observed actual target/schema applicability; clean exact candidate. T01 prerequisite means reviewed source only.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `scripts/lifecycle-source-preflight.mjs` (checkLifecycleSource); `scripts/check-tempo-cli.mjs` (validateLifecycleProfile, verifyTempoCliLifecycle); `database/tests/test-postgres-docker.mjs` (deployment_lifecycle_current); `database/tests/postgres-test-options.mjs`; `database/tests/postgres-test-plan.mjs`; `scripts/tempo-runtime.mjs` (validateCut62Preflight, assessMigrationRecovery, executeLifecycle); `tests/runner/lifecycle-current-profile.test.mjs`; `docs/TEMPO-CLI.md`; `Makefile`.

**Write scope:** `scripts/lifecycle-source-preflight.mjs` [existing]; `scripts/check-tempo-cli.mjs` [existing]; `database/tests/check_postgres_cli_lifecycle.py` [existing]; `database/tests/postgres-test-options.mjs` [existing]; `database/tests/postgres-test-plan.mjs` [existing]; `database/tests/test-postgres-docker.mjs` [existing]; `tests/runner/lifecycle-current-profile.test.mjs` [existing]; `tests/runner/lifecycle-source-preflight.test.mjs` [existing]; `tests/runner/postgres-test-speedups.test.mjs` [existing]; `Makefile` [existing]; `docs/testing.md` [existing].

**Steps:**

1. Applicability first: bind current installed evidence to actual schema/ledger/images/config. The known reported baseline is d79/schema65; independently inspect the authorized target before using it. Same-schema65→candidate65 is the default required lifecycle for T01 and later product deployment;64→65 is conditional on an actually supported target needing that forward transition.
2. Add an explicit current65 profile to the existing lifecycle owner and route existing lifecycle-current mode to the exact declared current profile. Do not merely delete the >=64 guard or reuse current63/historical assertions under a new label.
3. A current65 fixture is an owned fresh schema65 database with populated retained Study/Tactics/history/receipts and current immutable images. Exercise the same registered CLI/runtime path, matching target/context/daemon/volumes/ports/config and binding candidate source/image hashes.
4. Verify normal same-schema start/recreate, original receipt after no-op, failure before any write, injected interruption/retry at an applicable image/service transition, unknown/mismatched guard refusal, and no automatic start after unresolved migration verification. Preserve exact current history and only clean invocation-owned resources.
5. If64→65 is genuinely in scope, add a separately labeled stopped-writer forward proof with restore-verified backup, exact1..64→1..65 ledger, new introduction-hold schema and unchanged retained rows. Reinstalling an older image must not be called a database rollback; incompatible lower-schema code refuses and recovery fixes forward from original evidence.
6. Preserve historical full/current63 refusal and unit tests as correct scoped guards. Their inability to qualify65 is not a reason to rebuild obsolete schema16/59/61/62 stacks for this task.
7. Release the supported command and exact expected stages/cases only after parser/source/refusal tests. Run real current65 lifecycle once with T01 reviewed source; report component-tested, lifecycle-qualified and merge-ready separately.

**Acceptance:**

- Current65 profile executes genuine CLI/runtime operations on an owned disposable target and records exact images/config/schema/history/recovery evidence.
- Historical guard behavior remains intact; wrong schema/profile/overrides fail before resource acquisition.
- Applicable lifecycle pass gates T01 merge, not its reviewed source release. No dependency cycle and no live operation in this task.

**Commands (planned, not executed):**

- `node --test --test-concurrency=1 tests/runner/lifecycle-source-preflight.test.mjs tests/runner/lifecycle-current-profile.test.mjs tests/runner/postgres-test-speedups.test.mjs` — cwd `.`; focused; current.
- `make preflight` — cwd `.`; capability; current.
- `node database/tests/test-postgres-docker.mjs --mode lifecycle-current --list` — cwd `.`; discovery; current parser; current source only lists historical63, updated current65 inventory required.
- `node database/tests/test-postgres-docker.mjs --mode lifecycle-current` — cwd `.`; native-lifecycle; proposed current65 behavior; currently rejects schema65; do not run as current65 until this task releases it.

**Integration:** One heavy slot; lifecycle image receipt may feed P14/P12 only with exact existing source/image/config reuse validation.

**Material risks:** Blanket accepting schema65 would convert the old guard into a false safety claim. Current65 no-migration lifecycle and64→65 forward migration are different proofs.

**Exclusions:** Live maintenance; New historical migration matrix; Destructive history cleanup; Treating current63 refusal as a permanent release blocker

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### P12 — Declare and demonstrate the exact assembled browser journeys

**Scope:** integration-checkpoint. Findings: ST003, ST004, ST012, ST013. Prior tasks: Q0, E02, E03.

**Prerequisites (reviewed source/capability unless explicitly stronger):** P06; P07; P16

**Owner/resource conditions:** Release exact browser inventory before P14 execution; P12 acceptance can share the P14 run. Heavy-slot lease and all actually changed cohort inputs are required.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `tests/browser/study-only-mode.spec.ts`; `tests/browser/prefix-split-training.spec.ts`; `tests/browser/recovery.spec.ts`; `tests/browser/opening-progression.spec.ts`; `tests/browser/position-study-acceptance.spec.ts`; `tests/browser/minimal-game-review-acceptance.spec.ts`; `database/tests/postgres-test-options.mjs`; `docs/testing.md`.

**Write scope:** `tests/browser/prefix-split-training.spec.ts` [existing]; `tests/browser/manual-prefix-split-http.spec.ts` [proposed; reserve before creation]; `tests/fixtures/postgres-study-prefix-split.py` [existing]; `tests/REGRESSIONS.md` [existing].

**Steps:**

1. Before execution, collect exact browser identities from existing runner --list and current Playwright inventory. Keep each viewport/project/title explicit; zero selection, skip, retry or intercepted essential result cannot count as pass.
2. Add one normal-build real manual prefix-split browser case using an owned multi-decision opening. Preview through the real GET, accept through UI/real POST, observe original operation receipt and exact split/lineage/queue rows, reload and resend same operation without a second split, then play the authoritative successor. Verify reject through a real endpoint assertion and existing local UI contract.
3. Run P16 successful restart replay plus the existing relevant opening/position recovery and minimal Game Review saved/pasted comparison cases. Real Game Review must leave Study/receipt/queue snapshots unchanged.
4. When S03–S05 or FE journal/session changes are in the cohort, include the applicable actual browser offline reload/quota/acknowledgment/position-plan recovery cases. Pure presentation/registry tasks do not independently require this matrix.
5. Prefer one combined P14 runner invocation that includes these exact cases and applicable native checks. If a locator-only retry is needed, preserve failed evidence and rerun only the failed identities after proving native/product/fixture hashes unchanged.
6. Checkpoint1 covers original packet + review residual candidate. Checkpoint2 reruns only journeys whose inputs/owner contracts changed during wider audit completion; reuse unchanged raw evidence with exact source comparisons.

**Acceptance:**

- Saved review has an authoritative successful receipt, exact-once durable effect and a rendered successor accepting a legal move.
- Prefix preview/accept/reject use real HTTP, no route interception or direct Python command substitutes.
- Browser reports bind clean source tree, images, schema, build target, cases and cleanup; no synthetic session is described as the user’s live Study.

**Commands (planned, not executed):**

- `make preflight` — cwd `.`; capability; current.
- `node database/tests/test-postgres-docker.mjs --mode browser --browser-file study-only-mode.spec.ts --list` — cwd `.`; discovery; current.
- `node database/tests/test-postgres-docker.mjs --mode browser --browser-file manual-prefix-split-http.spec.ts --list` — cwd `.`; discovery; proposed spec; only after P06/P12 authoring release.

**Integration:** P14 runs the selected native+HTTP+browser stack once when possible; exact final regex/identity list is an output of discovery, never a guessed pass.

**Material risks:** A healthy container, queue JSON identity or mocked response is insufficient to prove a playable next card.

**Exclusions:** Synthetic reviews against live user history; Latency/cadence claim from stage duration; Browser proof for unrelated pure changes

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### P14 — Run one coordinated exact native and HTTP qualification cohort

**Scope:** integration-checkpoint. Findings: ST002, ST005, ST006, ST012, ST013, ST014. Prior tasks: E00, E02, E03, E04, Q0.

**Prerequisites (reviewed source/capability unless explicitly stronger):** P01; P02; P03; P04; P05; P06; P07; P08; P16; P12

**Owner/resource conditions:** P12 prerequisite is exact reviewed browser inventory, not completed browser qualification. P13 acceptance is required if lifecycle behavior/images changed. Checkpoint2 consumes every changed applicable owner input; do not add unrelated native work.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `database/tests/postgres-test-options.mjs`; `database/tests/postgres-test-plan.mjs`; `database/tests/position-native-pytest.py` (NODEIDS, ExactCase); `database/tests/native-split-pytest.py`; `scripts/release-candidate-artifacts.mjs`; `docs/testing.md`.

**Write scope:** `database/tests/postgres-test-options.mjs` [existing]; `database/tests/postgres-test-plan.mjs` [existing]; `database/tests/position-native-pytest.py` [existing]; `database/tests/test-postgres-docker.mjs` [existing]; `tests/runner/postgres-test-speedups.test.mjs` [existing].

**Steps:**

1. Reserve exactly one native/Docker/browser heavy slot. Resolve supported Python from backend/pyproject.toml, compatible Node dependencies and digest-verified WASM inputs; run make preflight before the native runner. No bypass of admission/traffic/resource accounting.
2. Use a clean committed assembled candidate and capture git SHA/tree/status plus selected product/test/harness/fixture hashes. The ordinary native receipt’s HEAD field alone does not prove mounted bytes equal the commit.
3. For checkpoint1, list and run current Study receipt/recovery, nine Study-only assertions, opening admission/restart, current priority plus P08 historical disposition, real prefix HTTP, current packaged reader, and the existing exact position grade/introduction/admission/split selectors needed by changed code. Include P12 exact browser set in that same stack when possible.
4. Existing supported native-check names are redis-fixture-isolation, position-grade-effects, position-introductions, position-queue-admission, prefix-split-placement and game-review-reader. Native checks accept only study/browser modes; do not invent --native-only or combine --skip-browser with them.
5. Any new conformance case required by S01/S05/S06/S07 or ST005 SQL changes gets one fixed reviewed selector in the existing bridge with exact collection/setup/call/teardown, owned fresh database, refusal and cleanup; no new generic qualification framework.
6. Require native atomic failure, contention, stale source/owner, original operation replay, queue preservation and history retention only where applicable. Pure contract/metadata leaves use their pure tests; they do not add unrelated native/browser obligations.
7. Checkpoint2 follows the final wider-audit candidate. Rerun changed inputs/consumer boundaries and preserve valid unchanged evidence with explicit comparisons; do not promote prior candidate results without that proof.
8. Stop on first concrete failure, keep all diagnostics and cleanup results, repair its owning task, then rerun only invalidated evidence. Report executed/passed/failed/skipped/blocked separately.

**Acceptance:**

- Every selected native case truly executes exact expected identity with zero skips, retries, duplicates or zero-selection; all selected stages and cleanup complete.
- SQL/locks/migrations/rollback are proved on native PostgreSQL; fake-boundary passes are not substituted.
- E02 full current scope closes only after its four residual categories are accounted; no whole-repository/full lane health claim unless that actual lane ran and passed.

**Commands (planned, not executed):**

- `git rev-parse HEAD` — cwd `.`; source; current.
- `git rev-parse HEAD^{tree}` — cwd `.`; source; current.
- `git --no-optional-locks status --porcelain --untracked-files=all` — cwd `.`; source; current.
- `make preflight` — cwd `.`; capability; current.
- `node database/tests/test-postgres-docker.mjs --mode study --browser-grep "study_only_mode_preserves_foreground_review_and_queue_progression across reload and resumption$" --native-check position-grade-effects --native-check position-introductions --native-check position-queue-admission --native-check prefix-split-placement --native-check game-review-reader --list` — cwd `.`; discovery; current.
- `node database/tests/test-postgres-docker.mjs --mode study --browser-grep "study_only_mode_preserves_foreground_review_and_queue_progression across reload and resumption$" --native-check position-grade-effects --native-check position-introductions --native-check position-queue-admission --native-check prefix-split-placement --native-check game-review-reader` — cwd `.`; native-browser; current syntax; executable full current Study stages require P04–P08; expand browser grep only from P12 exact inventory.

**Integration:** One heavy slot; current65 lifecycle first if needed, then one current Study/native/browser assembly, then only separately selected historical or ownership conformance cases not covered by that assembly.

**Material risks:** Source mounted from a dirty checkout can disagree with image/HEAD receipt; provenance must include actual clean/tree/input equality.

**Exclusions:** Repeated full suites per worker; Installation; Live review generation

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### P15 — Use the normal CLI for authorized installation and observe genuine live Study

**Scope:** installation-and-user-acceptance. Findings: installation/user acceptance only. Prior tasks: Q0, E04.

**Prerequisites (reviewed source/capability unless explicitly stronger):** Independent bounded source task; reserve listed paths.

**Owner/resource conditions:** Later-phase source merge/installation authorization and actual target inspection. Applicable P13 lifecycle plus P14/P12 current affected acceptance gate installation. Genuine user interaction remains separately pending until observed.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `tempo`; `scripts/tempo-cli.mjs` (parseArguments); `scripts/tempo-runtime.mjs`; `docs/TEMPO-CLI.md`; `AGENTS.md`.

**Write scope:** .

**Steps:**

1. No action in the planning phase. In the later authorized delivery phase, independently inspect the registered target and current receipt before choosing the normal operation; existing authorization remains effective.
2. If the management command is not installed, ./tempo install only registers the existing target/CLI. It is not deployment, migration or acceptance. Normally use the already installed tempo command.
3. Capture tempo status, tempo doctor --verbose and tempo start --plan. The plan is read-only and may report hosted CI unavailable; that is neither a successful qualification nor proof that installation will be accepted.
4. After the exact candidate is merge-qualified and installation is authorized, use tempo start --no-ci --no-open while the repository-approved hosted-CI workaround applies. Normal tempo start remains supported when hosted checks are available. Do not use invented tempo update/install-release commands or call --no-ci a CI pass.
5. The normal updater rechecks actual main/source/target/schema/backup/recovery conditions. If the head changed, qualify/reconcile it or stop at that precise gate; do not silently install an unreviewed main. Candidate-ref/candidate-sha is documented for exact reviewed offline maintenance rehearsal and requires --no-ci, not a blanket alternate deploy path.
6. After success, inspect normal deployment.json and running immutable image IDs/config fingerprints, exact source revision, schema ledger65, active modes, workers and health. Preserve original backup/guard and fix-forward semantics on failure; never remove a guard to force startup.
7. Observe a real user-initiated saved review and next playable card, with the user’s actual interaction and consent. Capture original attempt/operation/review IDs and timing only as observed. Do not generate synthetic reviews on live data or describe disposable scripted traffic as live cadence.
8. If the user has not performed a real review, record installed/source-qualified and live interaction pending; do not declare that final live usability/cadence gate complete. A test-only/docs-only delta from the same installed product needs no forced reinstall.

**Acceptance:**

- Installation evidence distinguishes source, qualified candidate, installed image set/schema/modes and actual functional observation.
- Genuine user interaction is the only live review→next-card evidence; unavailable interaction remains pending.
- No unsupported command or historical downgrade path is suggested to a fresh operator.

**Commands (planned, not executed):**

- `tempo status` — cwd `.`; read-only-operator; current.
- `tempo doctor --verbose` — cwd `.`; read-only-operator; current.
- `tempo start --plan` — cwd `.`; read-only-operator; current.
- `./tempo install` — cwd `.`; management-registration; current; only if command is absent and registration is needed.
- `tempo start --no-ci --no-open` — cwd `.`; authorized-installation; current.
- `tempo doctor --verbose` — cwd `.`; read-only-post-install; current.

**Integration:** Real user interaction after installation is observed separately from all disposable acceptance.

**Material risks:** A newer main can appear between plan and update; the normal CLI rechecks it. Existing schema65 does not waive proof for changed lifecycle code.

**Exclusions:** No installation before candidate applicable qualification and merge; Synthetic live reviews; Live history cleanup; Routine reinstallation for test-only changes

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### S08 — Settle and adopt typed storage boundary: Position issuance identity and lock facts

**Scope:** audit-expansion. Findings: ST005. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** S01; S02; B07

**Owner/resource conditions:** Shared typing environment prerequisite: integration owner selects and records one exact mypy version and Python interpreter, provisions it once in the shared task environment during execution, and reuses the B12/B14/B26 convention. No blanket ignore-missing-imports, casts to Any, per-worker installation or repository-wide typing campaign.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `database/tempo_storage/study/position_issued_plans.py` (issued_plan, lock_card, locked_card, locked_day, locked_queue, origin_index_exists, issued_for_entry, origin_count, locked_origins); `backend/app/study/position_learning/issuance.py`.

**Write scope:** `database/tempo_storage/study/position_issued_plans.py` [existing]; `backend/app/study/position_learning/issuance.py` [existing]; `backend/tests/test_position_issued_plan_contracts.py` [existing]; `backend/tests/test_queue_attempt_issuance.py` [existing]; `backend/tests/typing/storage_contract_s08.py` [proposed scoped type-check fixture; create only for the applicable owner/public contract after row classification].

**Steps:**

1. Use the exact row ledger for this cluster. For every listed function, trace current supported callers and public owner reachability; classify as public physical leak, private owner implementation, retired/no supported caller, or already semantic/typed. Record concrete caller/public-export/source evidence, never a blanket no-change disposition.
2. Use explicit attempt/card/day/entry/revision arguments; return IssuedPlanRecord/LockedCard/QueueOrigin/lock-success/unique-index-present facts. Zero, one and ambiguous two origins remain distinct; preserve SKIP LOCKED and source→owner→card/day/queue order.
3. For confirmed public/application representation leaks, define the smallest pure typed value/operation contract in the existing owner surface, map SQL rows inside the adapter and adopt every actual listed consumer in the same change. No generic repository, new service or one-function-per-file layer.
4. If a cursor is legitimately private, prove its enclosing public owner returns typed semantic values and prohibit direct cross-owner access with T03. If unreachable, prove registration/import/retained recovery absence before deleting the exclusive helper and its exclusive tests. If already typed, name the exact type and passing current caller contract.
5. Add focused conformance assertions for present/absent/ambiguous/error values, exact IDs/ordering/nullability, immutable original JSON where required, and no new connect/commit/close. A semantic in-memory fake drives policy; an adapter spy rejects wrong predicates/projections. Use native proof only for actually changed SQL/mapping/lock/transaction semantics.
6. Update local owner guidance and T02 ownership/proof metadata for this boundary only. Work in one bounded symbol subset at a time, using a sequential path lease for shared adapters/callers.
7. Use the same scoped pinned checker convention as B12/B14/B26. In backend/tests/typing/storage_contract_s08.py, bind the actual production adapter and an independently implemented in-memory semantic fake to the real consumed interface, and check actual consumer result use. Include an intentional wrong result/argument implementation as a negative fixture and retain its expected checker errors. Imported Any or a cast cannot stand in for the production binding.

**Acceptance:**

- Every exact row assigned to this task has a source-linked current disposition; no unresolved public physical contract is closed by labeling it private.
- Required public result/argument conversions have real production consumer adoption; no caller .fetchone/.fetchall/.rowcount/physical column order remains at the migrated interface.
- Focused semantic fake/adapter contract and applicable native consumer proof pass; one final P14/P12 cohort supplies shared integration evidence rather than a full run per helper.
- The applicable listed caller contracts actually pass a scoped static type check with real production and independent fake bindings, and the deliberate incompatible implementation fails. Runtime fake tests alone do not satisfy the original type-checkable criterion. Private/already-typed dispositions name and check their enclosing public contract; no forced rewrite of private SQL helpers.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_position_issued_plan_contracts.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_queue_attempt_issuance.py` — cwd `.`; focused; current.
- `python -m mypy --strict --follow-imports=silent --no-incremental backend/tests/typing/storage_contract_s08.py` — cwd `.`; static-typing; PROPOSED scoped acceptance command; no configured checker gate currently exists; integration owner pins/provisions shared checker first and includes any actual changed contract module targets needed to prevent an Any import escape.

**Integration:** At checkpoint2, include only native owner/concurrency/replay cases affected by this cluster; reuse accepted identical inputs. P14 exact selector release is required if the current runner cannot execute the necessary case.

**Material risks:** A typed dictionary alias or wrapper around a cursor is not a semantic boundary; conversely, forcing a new value class around every private/scalar helper adds cost without removing coupling.; Shared backend/app/main.py/service callers may move during BE ownership repairs: rebind the ledger to the released owner, do not edit stale entrypoints or create competing writers.

**Exclusions:** Blind rewrite of all264 historical rows; New storage/repository framework; Changing persistence schema only for typing; Unrelated historical feature restoration

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### S09 — Settle and adopt typed storage boundary: Position issuance attempt and completion evidence facts

**Scope:** audit-expansion. Findings: ST005. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** S08; B00

**Owner/resource conditions:** Shared typing environment prerequisite: integration owner selects and records one exact mypy version and Python interpreter, provisions it once in the shared task environment during execution, and reuses the B12/B14/B26 convention. No blanket ignore-missing-imports, casts to Any, per-worker installation or repository-wide typing campaign.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `database/tempo_storage/study/position_issued_plans.py` (lock_attempt, attempt_count, locked_attempt, review_receipt, good_today, insert_plan, saved_completion, first_responses, again_index_exists, again_after_review); `backend/app/study/position_learning/issuance.py`.

**Write scope:** `database/tempo_storage/study/position_issued_plans.py` [existing]; `backend/app/study/position_learning/issuance.py` [existing]; `backend/tests/test_position_issued_plan_contracts.py` [existing]; `backend/tests/test_position_prefix_eligibility.py` [existing]; `backend/tests/typing/storage_contract_s09.py` [proposed scoped type-check fixture; create only for the applicable owner/public contract after row classification].

**Steps:**

1. Use the exact row ledger for this cluster. For every listed function, trace current supported callers and public owner reachability; classify as public physical leak, private owner implementation, retired/no supported caller, or already semantic/typed. Record concrete caller/public-export/source evidence, never a blanket no-change disposition.
2. Remove caller fetchone/fetchall/rowcount from these functions. Explicit PlanInsertResult distinguishes inserted/conflict; completion/first-response facts retain original IDs and bounded21-row ambiguity sentinel, source_kind, invalidation and accepted_at timestamp meaning. Preserve accepted_at > completed_at::timestamptz regression.
3. For confirmed public/application representation leaks, define the smallest pure typed value/operation contract in the existing owner surface, map SQL rows inside the adapter and adopt every actual listed consumer in the same change. No generic repository, new service or one-function-per-file layer.
4. If a cursor is legitimately private, prove its enclosing public owner returns typed semantic values and prohibit direct cross-owner access with T03. If unreachable, prove registration/import/retained recovery absence before deleting the exclusive helper and its exclusive tests. If already typed, name the exact type and passing current caller contract.
5. Add focused conformance assertions for present/absent/ambiguous/error values, exact IDs/ordering/nullability, immutable original JSON where required, and no new connect/commit/close. A semantic in-memory fake drives policy; an adapter spy rejects wrong predicates/projections. Use native proof only for actually changed SQL/mapping/lock/transaction semantics.
6. Update local owner guidance and T02 ownership/proof metadata for this boundary only. Work in one bounded symbol subset at a time, using a sequential path lease for shared adapters/callers.
7. Use the same scoped pinned checker convention as B12/B14/B26. In backend/tests/typing/storage_contract_s09.py, bind the actual production adapter and an independently implemented in-memory semantic fake to the real consumed interface, and check actual consumer result use. Include an intentional wrong result/argument implementation as a negative fixture and retain its expected checker errors. Imported Any or a cast cannot stand in for the production binding.

**Acceptance:**

- Every exact row assigned to this task has a source-linked current disposition; no unresolved public physical contract is closed by labeling it private.
- Required public result/argument conversions have real production consumer adoption; no caller .fetchone/.fetchall/.rowcount/physical column order remains at the migrated interface.
- Focused semantic fake/adapter contract and applicable native consumer proof pass; one final P14/P12 cohort supplies shared integration evidence rather than a full run per helper.
- The applicable listed caller contracts actually pass a scoped static type check with real production and independent fake bindings, and the deliberate incompatible implementation fails. Runtime fake tests alone do not satisfy the original type-checkable criterion. Private/already-typed dispositions name and check their enclosing public contract; no forced rewrite of private SQL helpers.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_position_issued_plan_contracts.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_position_prefix_eligibility.py` — cwd `.`; focused; current.
- `python -m mypy --strict --follow-imports=silent --no-incremental backend/tests/typing/storage_contract_s09.py` — cwd `.`; static-typing; PROPOSED scoped acceptance command; no configured checker gate currently exists; integration owner pins/provisions shared checker first and includes any actual changed contract module targets needed to prevent an Any import escape.

**Integration:** At checkpoint2, include only native owner/concurrency/replay cases affected by this cluster; reuse accepted identical inputs. P14 exact selector release is required if the current runner cannot execute the necessary case.

**Material risks:** A typed dictionary alias or wrapper around a cursor is not a semantic boundary; conversely, forcing a new value class around every private/scalar helper adds cost without removing coupling.; Shared backend/app/main.py/service callers may move during BE ownership repairs: rebind the ledger to the released owner, do not edit stale entrypoints or create competing writers.

**Exclusions:** Blind rewrite of all264 historical rows; New storage/repository framework; Changing persistence schema only for typing; Unrelated historical feature restoration

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### S10 — Settle and adopt typed storage boundary: Position grading and checkpoint receipt contracts

**Scope:** audit-expansion. Findings: ST005. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** S01; S02; B08; B26

**Owner/resource conditions:** Shared typing environment prerequisite: integration owner selects and records one exact mypy version and Python interpreter, provisions it once in the shared task environment during execution, and reuses the B12/B14/B26 convention. No blanket ignore-missing-imports, casts to Any, per-worker installation or repository-wide typing campaign.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `database/tempo_storage/study/position_grade_effects.py` (locked_owner, locked_state, issued_plan, first_response, saved_completion, prior_grade, daily_good_grades, update_schedule); `database/tempo_storage/study/position_first_responses.py` (receipt, insert); `backend/app/study/position_checkpoint.py`; `backend/app/study/position_learning/grade_effects.py`.

**Write scope:** `database/tempo_storage/study/position_grade_effects.py` [existing]; `database/tempo_storage/study/position_first_responses.py` [existing]; `backend/app/study/position_checkpoint.py` [existing]; `backend/app/study/position_learning/grade_effects.py` [existing]; `backend/tests/test_position_first_response_codec.py` [existing]; `backend/tests/test_position_review_integration.py` [existing]; `backend/tests/typing/storage_contract_s10.py` [proposed scoped type-check fixture; create only for the applicable owner/public contract after row classification].

**Steps:**

1. Use the exact row ledger for this cluster. For every listed function, trace current supported callers and public owner reachability; classify as public physical leak, private owner implementation, retired/no supported caller, or already semantic/typed. Record concrete caller/public-export/source evidence, never a blanket no-change disposition.
2. Name locked owner/state/evidence/grade arguments and semantic results; update_schedule returns an explicit optimistic-write outcome instead of a cursor rowcount. Preserve immutable first response bytes/digest and original event conflict. Grade insertion, schedule update and receipt remain in one borrowed transaction; late failure rolls all back.
3. For confirmed public/application representation leaks, define the smallest pure typed value/operation contract in the existing owner surface, map SQL rows inside the adapter and adopt every actual listed consumer in the same change. No generic repository, new service or one-function-per-file layer.
4. If a cursor is legitimately private, prove its enclosing public owner returns typed semantic values and prohibit direct cross-owner access with T03. If unreachable, prove registration/import/retained recovery absence before deleting the exclusive helper and its exclusive tests. If already typed, name the exact type and passing current caller contract.
5. Add focused conformance assertions for present/absent/ambiguous/error values, exact IDs/ordering/nullability, immutable original JSON where required, and no new connect/commit/close. A semantic in-memory fake drives policy; an adapter spy rejects wrong predicates/projections. Use native proof only for actually changed SQL/mapping/lock/transaction semantics.
6. Update local owner guidance and T02 ownership/proof metadata for this boundary only. Work in one bounded symbol subset at a time, using a sequential path lease for shared adapters/callers.
7. Use the same scoped pinned checker convention as B12/B14/B26. In backend/tests/typing/storage_contract_s10.py, bind the actual production adapter and an independently implemented in-memory semantic fake to the real consumed interface, and check actual consumer result use. Include an intentional wrong result/argument implementation as a negative fixture and retain its expected checker errors. Imported Any or a cast cannot stand in for the production binding.

**Acceptance:**

- Every exact row assigned to this task has a source-linked current disposition; no unresolved public physical contract is closed by labeling it private.
- Required public result/argument conversions have real production consumer adoption; no caller .fetchone/.fetchall/.rowcount/physical column order remains at the migrated interface.
- Focused semantic fake/adapter contract and applicable native consumer proof pass; one final P14/P12 cohort supplies shared integration evidence rather than a full run per helper.
- The applicable listed caller contracts actually pass a scoped static type check with real production and independent fake bindings, and the deliberate incompatible implementation fails. Runtime fake tests alone do not satisfy the original type-checkable criterion. Private/already-typed dispositions name and check their enclosing public contract; no forced rewrite of private SQL helpers.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_position_first_response_codec.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_position_review_integration.py` — cwd `.`; focused; current.
- `python -m mypy --strict --follow-imports=silent --no-incremental backend/tests/typing/storage_contract_s10.py` — cwd `.`; static-typing; PROPOSED scoped acceptance command; no configured checker gate currently exists; integration owner pins/provisions shared checker first and includes any actual changed contract module targets needed to prevent an Any import escape.

**Integration:** At checkpoint2, include only native owner/concurrency/replay cases affected by this cluster; reuse accepted identical inputs. P14 exact selector release is required if the current runner cannot execute the necessary case.

**Material risks:** A typed dictionary alias or wrapper around a cursor is not a semantic boundary; conversely, forcing a new value class around every private/scalar helper adds cost without removing coupling.; Shared backend/app/main.py/service callers may move during BE ownership repairs: rebind the ledger to the released owner, do not edit stale entrypoints or create competing writers.

**Exclusions:** Blind rewrite of all264 historical rows; New storage/repository framework; Changing persistence schema only for typing; Unrelated historical feature restoration

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### S11 — Settle and adopt typed storage boundary: Learning review and reconciliation snapshots

**Scope:** audit-expansion. Findings: ST005. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** B14; B15; B06

**Owner/resource conditions:** Shared typing environment prerequisite: integration owner selects and records one exact mypy version and Python interpreter, provisions it once in the shared task environment during execution, and reuses the B12/B14/B26 convention. No blanket ignore-missing-imports, casts to Any, per-worker installation or repository-wide typing campaign.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `database/tempo_storage/learning_bridge/review.py` (policy_settings, receipt, card, card_owners, card_integrity, attempt_by_id, first_queued_attempt, current_revision, queue_date, evidence_state, entry_status, continuation_facts); `database/tempo_storage/review_reconciliation.py` (light_interval_setting, baseline_schedule_seed, review_attempt_receipt, card_revision, review_snapshot); `backend/app/services/learning_review_adapter.py`; `backend/app/study/policy/review_reconciliation.py`.

**Write scope:** `database/tempo_storage/learning_bridge/review.py` [existing]; `database/tempo_storage/review_reconciliation.py` [existing]; `backend/app/services/learning_review_adapter.py` [existing]; `backend/app/study/policy/review_reconciliation.py` [existing]; `backend/tests/test_scheduling_review_application.py` [existing]; `backend/tests/test_position_review_reconciliation.py` [existing]; `backend/tests/test_review_service_storage_boundary.py` [existing]; `backend/tests/typing/storage_contract_s11.py` [proposed scoped type-check fixture; create only for the applicable owner/public contract after row classification].

**Steps:**

1. Use the exact row ledger for this cluster. For every listed function, trace current supported callers and public owner reachability; classify as public physical leak, private owner implementation, retired/no supported caller, or already semantic/typed. Record concrete caller/public-export/source evidence, never a blanket no-change disposition.
2. Adapt SQL results to existing tempo_learning_review CardFacts/QueueAttempt/AttemptReceipt/ContinuationFacts wherever they fit. Add only missing named facts for current revision/evidence/policy. Absence, unresolved attempt, invalidated review, historical scheduling snapshot and original recorded_at remain separate; do not rewrite raw accepted request bytes during mapping.
3. For confirmed public/application representation leaks, define the smallest pure typed value/operation contract in the existing owner surface, map SQL rows inside the adapter and adopt every actual listed consumer in the same change. No generic repository, new service or one-function-per-file layer.
4. If a cursor is legitimately private, prove its enclosing public owner returns typed semantic values and prohibit direct cross-owner access with T03. If unreachable, prove registration/import/retained recovery absence before deleting the exclusive helper and its exclusive tests. If already typed, name the exact type and passing current caller contract.
5. Add focused conformance assertions for present/absent/ambiguous/error values, exact IDs/ordering/nullability, immutable original JSON where required, and no new connect/commit/close. A semantic in-memory fake drives policy; an adapter spy rejects wrong predicates/projections. Use native proof only for actually changed SQL/mapping/lock/transaction semantics.
6. Update local owner guidance and T02 ownership/proof metadata for this boundary only. Work in one bounded symbol subset at a time, using a sequential path lease for shared adapters/callers.
7. Use the same scoped pinned checker convention as B12/B14/B26. In backend/tests/typing/storage_contract_s11.py, bind the actual production adapter and an independently implemented in-memory semantic fake to the real consumed interface, and check actual consumer result use. Include an intentional wrong result/argument implementation as a negative fixture and retain its expected checker errors. Imported Any or a cast cannot stand in for the production binding.

**Acceptance:**

- Every exact row assigned to this task has a source-linked current disposition; no unresolved public physical contract is closed by labeling it private.
- Required public result/argument conversions have real production consumer adoption; no caller .fetchone/.fetchall/.rowcount/physical column order remains at the migrated interface.
- Focused semantic fake/adapter contract and applicable native consumer proof pass; one final P14/P12 cohort supplies shared integration evidence rather than a full run per helper.
- The applicable listed caller contracts actually pass a scoped static type check with real production and independent fake bindings, and the deliberate incompatible implementation fails. Runtime fake tests alone do not satisfy the original type-checkable criterion. Private/already-typed dispositions name and check their enclosing public contract; no forced rewrite of private SQL helpers.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_scheduling_review_application.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_position_review_reconciliation.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_review_service_storage_boundary.py` — cwd `.`; focused; current.
- `python -m mypy --strict --follow-imports=silent --no-incremental backend/tests/typing/storage_contract_s11.py` — cwd `.`; static-typing; PROPOSED scoped acceptance command; no configured checker gate currently exists; integration owner pins/provisions shared checker first and includes any actual changed contract module targets needed to prevent an Any import escape.

**Integration:** At checkpoint2, include only native owner/concurrency/replay cases affected by this cluster; reuse accepted identical inputs. P14 exact selector release is required if the current runner cannot execute the necessary case.

**Material risks:** A typed dictionary alias or wrapper around a cursor is not a semantic boundary; conversely, forcing a new value class around every private/scalar helper adds cost without removing coupling.; Shared backend/app/main.py/service callers may move during BE ownership repairs: rebind the ledger to the released owner, do not edit stale entrypoints or create competing writers.

**Exclusions:** Blind rewrite of all264 historical rows; New storage/repository framework; Changing persistence schema only for typing; Unrelated historical feature restoration

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### S12 — Settle and adopt typed storage boundary: Queue command and operation receipt facts

**Scope:** audit-expansion. Findings: ST005. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** P01; B18

**Owner/resource conditions:** Shared typing environment prerequisite: integration owner selects and records one exact mypy version and Python interpreter, provisions it once in the shared task environment during execution, and reuses the B12/B14/B26 convention. No blanket ignore-missing-imports, casts to Any, per-worker installation or repository-wide typing campaign.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `database/tempo_storage/commands/queue.py` (prepare_available_attempt, prepare_queue_head, issued_origin, lock_current_queue_task, current_projection, issuance_owner_repertoires); `database/tempo_storage/commands/receipts/storage.py` (locked_attempt, blocked_operation, locked_retry, recoverable_receipt, locked_publication, operation_status, latest_queue_issuance); `backend/app/command_gateway.py`; `backend/app/queue_commands.py`; `backend/app/services/queue_application.py`.

**Write scope:** `database/tempo_storage/commands/queue.py` [existing]; `database/tempo_storage/commands/receipts/storage.py` [existing]; `backend/app/command_gateway.py` [existing]; `backend/app/queue_commands.py` [existing]; `backend/app/services/queue_application.py` [existing]; `backend/tests/test_queue_command_database_split.py` [existing]; `backend/tests/test_command_receipt_storage_boundary.py` [existing]; `backend/tests/typing/storage_contract_s12.py` [proposed scoped type-check fixture; create only for the applicable owner/public contract after row classification].

**Steps:**

1. Use the exact row ledger for this cluster. For every listed function, trace current supported callers and public owner reachability; classify as public physical leak, private owner implementation, retired/no supported caller, or already semantic/typed. Record concrete caller/public-export/source evidence, never a blanket no-change disposition.
2. Use semantic operation/attempt/projection results with named original operation, request hash, payload/result/error bytes, retry generation and lease facts. Preserve immutable conflicts, pending versus completed hold, exact retry key, active head identity and no extra issuance. Keep receipt lock ownership inside SQL adapter.
3. For confirmed public/application representation leaks, define the smallest pure typed value/operation contract in the existing owner surface, map SQL rows inside the adapter and adopt every actual listed consumer in the same change. No generic repository, new service or one-function-per-file layer.
4. If a cursor is legitimately private, prove its enclosing public owner returns typed semantic values and prohibit direct cross-owner access with T03. If unreachable, prove registration/import/retained recovery absence before deleting the exclusive helper and its exclusive tests. If already typed, name the exact type and passing current caller contract.
5. Add focused conformance assertions for present/absent/ambiguous/error values, exact IDs/ordering/nullability, immutable original JSON where required, and no new connect/commit/close. A semantic in-memory fake drives policy; an adapter spy rejects wrong predicates/projections. Use native proof only for actually changed SQL/mapping/lock/transaction semantics.
6. Update local owner guidance and T02 ownership/proof metadata for this boundary only. Work in one bounded symbol subset at a time, using a sequential path lease for shared adapters/callers.
7. Use the same scoped pinned checker convention as B12/B14/B26. In backend/tests/typing/storage_contract_s12.py, bind the actual production adapter and an independently implemented in-memory semantic fake to the real consumed interface, and check actual consumer result use. Include an intentional wrong result/argument implementation as a negative fixture and retain its expected checker errors. Imported Any or a cast cannot stand in for the production binding.

**Acceptance:**

- Every exact row assigned to this task has a source-linked current disposition; no unresolved public physical contract is closed by labeling it private.
- Required public result/argument conversions have real production consumer adoption; no caller .fetchone/.fetchall/.rowcount/physical column order remains at the migrated interface.
- Focused semantic fake/adapter contract and applicable native consumer proof pass; one final P14/P12 cohort supplies shared integration evidence rather than a full run per helper.
- The applicable listed caller contracts actually pass a scoped static type check with real production and independent fake bindings, and the deliberate incompatible implementation fails. Runtime fake tests alone do not satisfy the original type-checkable criterion. Private/already-typed dispositions name and check their enclosing public contract; no forced rewrite of private SQL helpers.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_queue_command_database_split.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_command_receipt_storage_boundary.py` — cwd `.`; focused; current.
- `python -m mypy --strict --follow-imports=silent --no-incremental backend/tests/typing/storage_contract_s12.py` — cwd `.`; static-typing; PROPOSED scoped acceptance command; no configured checker gate currently exists; integration owner pins/provisions shared checker first and includes any actual changed contract module targets needed to prevent an Any import escape.

**Integration:** At checkpoint2, include only native owner/concurrency/replay cases affected by this cluster; reuse accepted identical inputs. P14 exact selector release is required if the current runner cannot execute the necessary case.

**Material risks:** A typed dictionary alias or wrapper around a cursor is not a semantic boundary; conversely, forcing a new value class around every private/scalar helper adds cost without removing coupling.; Shared backend/app/main.py/service callers may move during BE ownership repairs: rebind the ledger to the released owner, do not edit stale entrypoints or create competing writers.

**Exclusions:** Blind rewrite of all264 historical rows; New storage/repository framework; Changing persistence schema only for typing; Unrelated historical feature restoration

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### S13 — Settle and adopt typed storage boundary: Queue application seeding, eligibility and publication projections

**Scope:** audit-expansion. Findings: ST005. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** S06; B07

**Owner/resource conditions:** Shared typing environment prerequisite: integration owner selects and records one exact mypy version and Python interpreter, provisions it once in the shared task environment during execution, and reuses the B12/B14/B26 convention. No blanket ignore-missing-imports, casts to Any, per-worker installation or repository-wide typing campaign.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `database/tempo_storage/queue_refresh/application/requeue.py` (position_at_offset); `database/tempo_storage/queue_refresh/application/seeding.py` (due_cards, new_study_cards); `database/tempo_storage/queue_refresh/application/admission.py` (unseen_opening_page, introduction_count_rows, priority_rows, candidate_identifiers, repertoire_identifiers, current_limit); `database/tempo_storage/queue_refresh/application/publication.py` (quarantine_candidates); `database/tempo_storage/queue_refresh/application/eligibility.py` (locked_opening_page, ready_unlock_candidates); `backend/app/services/queue_admission_adapter.py`; `backend/app/services/queue_application.py`.

**Write scope:** `database/tempo_storage/queue_refresh/application/requeue.py` [existing]; `database/tempo_storage/queue_refresh/application/seeding.py` [existing]; `database/tempo_storage/queue_refresh/application/admission.py` [existing]; `database/tempo_storage/queue_refresh/application/publication.py` [existing]; `database/tempo_storage/queue_refresh/application/eligibility.py` [existing]; `backend/app/services/queue_admission_adapter.py` [existing]; `backend/app/services/queue_application.py` [existing]; `backend/tests/test_queue_application_database_split.py` [existing]; `backend/tests/test_queue_refresh_admission_database_split.py` [existing]; `backend/tests/test_queue_refresh_publication_database_split.py` [existing]; `backend/tests/typing/storage_contract_s13.py` [proposed scoped type-check fixture; create only for the applicable owner/public contract after row classification].

**Steps:**

1. Use the exact row ledger for this cluster. For every listed function, trace current supported callers and public owner reachability; classify as public physical leak, private owner implementation, retired/no supported caller, or already semantic/typed. Record concrete caller/public-export/source evidence, never a blanket no-change disposition.
2. Type queue-page positions/card IDs/counts/limits and quarantine/eligibility results at the owner interface. Preserve paging cursor ordering, already-queued exclusion, current-day budget, frozen generated exercise exclusion and inactive/active position-owner behavior. Numeric scalar helpers need annotations only if already semantic; do not wrap every integer in a new class.
3. For confirmed public/application representation leaks, define the smallest pure typed value/operation contract in the existing owner surface, map SQL rows inside the adapter and adopt every actual listed consumer in the same change. No generic repository, new service or one-function-per-file layer.
4. If a cursor is legitimately private, prove its enclosing public owner returns typed semantic values and prohibit direct cross-owner access with T03. If unreachable, prove registration/import/retained recovery absence before deleting the exclusive helper and its exclusive tests. If already typed, name the exact type and passing current caller contract.
5. Add focused conformance assertions for present/absent/ambiguous/error values, exact IDs/ordering/nullability, immutable original JSON where required, and no new connect/commit/close. A semantic in-memory fake drives policy; an adapter spy rejects wrong predicates/projections. Use native proof only for actually changed SQL/mapping/lock/transaction semantics.
6. Update local owner guidance and T02 ownership/proof metadata for this boundary only. Work in one bounded symbol subset at a time, using a sequential path lease for shared adapters/callers.
7. Use the same scoped pinned checker convention as B12/B14/B26. In backend/tests/typing/storage_contract_s13.py, bind the actual production adapter and an independently implemented in-memory semantic fake to the real consumed interface, and check actual consumer result use. Include an intentional wrong result/argument implementation as a negative fixture and retain its expected checker errors. Imported Any or a cast cannot stand in for the production binding.

**Acceptance:**

- Every exact row assigned to this task has a source-linked current disposition; no unresolved public physical contract is closed by labeling it private.
- Required public result/argument conversions have real production consumer adoption; no caller .fetchone/.fetchall/.rowcount/physical column order remains at the migrated interface.
- Focused semantic fake/adapter contract and applicable native consumer proof pass; one final P14/P12 cohort supplies shared integration evidence rather than a full run per helper.
- The applicable listed caller contracts actually pass a scoped static type check with real production and independent fake bindings, and the deliberate incompatible implementation fails. Runtime fake tests alone do not satisfy the original type-checkable criterion. Private/already-typed dispositions name and check their enclosing public contract; no forced rewrite of private SQL helpers.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_queue_application_database_split.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_queue_refresh_admission_database_split.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_queue_refresh_publication_database_split.py` — cwd `.`; focused; current.
- `python -m mypy --strict --follow-imports=silent --no-incremental backend/tests/typing/storage_contract_s13.py` — cwd `.`; static-typing; PROPOSED scoped acceptance command; no configured checker gate currently exists; integration owner pins/provisions shared checker first and includes any actual changed contract module targets needed to prevent an Any import escape.

**Integration:** At checkpoint2, include only native owner/concurrency/replay cases affected by this cluster; reuse accepted identical inputs. P14 exact selector release is required if the current runner cannot execute the necessary case.

**Material risks:** A typed dictionary alias or wrapper around a cursor is not a semantic boundary; conversely, forcing a new value class around every private/scalar helper adds cost without removing coupling.; Shared backend/app/main.py/service callers may move during BE ownership repairs: rebind the ledger to the released owner, do not edit stale entrypoints or create competing writers.

**Exclusions:** Blind rewrite of all264 historical rows; New storage/repository framework; Changing persistence schema only for typing; Unrelated historical feature restoration

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### S14 — Settle and adopt typed storage boundary: Opening, tactic and capacity admission facts

**Scope:** audit-expansion. Findings: ST005. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** P02; B07; B22; S06

**Owner/resource conditions:** Shared typing environment prerequisite: integration owner selects and records one exact mypy version and Python interpreter, provisions it once in the shared task environment during execution, and reuses the B12/B14/B26 convention. No blanket ignore-missing-imports, casts to Any, per-worker installation or repository-wide typing campaign.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `database/tempo_storage/queue_refresh/openings.py` (route_occurrence, parent_study_review, remaining_allowance, opening_limit, locked_opening_card, safe_route); `database/tempo_storage/queue_refresh/admissions.py` (pack_activation, locked_puzzle_progress, queued_card, locked_unseen_entry, locked_card, due_card_eligibility, study_card_eligibility, position_carrier_eligible); `database/tempo_storage/queue_refresh/capacity.py` (queued_capacity_card, current_capacity_priority, published_capacity_route); `backend/app/services/opening_capacity_admission.py`; `backend/app/services/position_queue_admission.py`; `backend/app/services/postgres_queue_refresh.py`.

**Write scope:** `database/tempo_storage/queue_refresh/openings.py` [existing]; `database/tempo_storage/queue_refresh/admissions.py` [existing]; `database/tempo_storage/queue_refresh/capacity.py` [existing]; `backend/app/services/opening_capacity_admission.py` [existing]; `backend/app/services/position_queue_admission.py` [existing]; `backend/app/services/postgres_queue_refresh.py` [existing]; `backend/tests/test_queue_admission_database_split.py` [existing]; `backend/tests/test_study_opening_admission.py` [existing]; `backend/tests/test_opening_capacity_admission.py` [existing]; `backend/tests/typing/storage_contract_s14.py` [proposed scoped type-check fixture; create only for the applicable owner/public contract after row classification].

**Steps:**

1. Use the exact row ledger for this cluster. For every listed function, trace current supported callers and public owner reachability; classify as public physical leak, private owner implementation, retired/no supported caller, or already semantic/typed. Record concrete caller/public-export/source evidence, never a blanket no-change disposition.
2. Use named route/parent-review/allowance/card-eligibility/pack/progress/capacity facts. Preserve exact membership and published generation, absence versus held source, active attempts, parent review qualification and original daily allowance. Keep capacity graph and physical rows private and currentness checks in the existing owner.
3. For confirmed public/application representation leaks, define the smallest pure typed value/operation contract in the existing owner surface, map SQL rows inside the adapter and adopt every actual listed consumer in the same change. No generic repository, new service or one-function-per-file layer.
4. If a cursor is legitimately private, prove its enclosing public owner returns typed semantic values and prohibit direct cross-owner access with T03. If unreachable, prove registration/import/retained recovery absence before deleting the exclusive helper and its exclusive tests. If already typed, name the exact type and passing current caller contract.
5. Add focused conformance assertions for present/absent/ambiguous/error values, exact IDs/ordering/nullability, immutable original JSON where required, and no new connect/commit/close. A semantic in-memory fake drives policy; an adapter spy rejects wrong predicates/projections. Use native proof only for actually changed SQL/mapping/lock/transaction semantics.
6. Update local owner guidance and T02 ownership/proof metadata for this boundary only. Work in one bounded symbol subset at a time, using a sequential path lease for shared adapters/callers.
7. Use the same scoped pinned checker convention as B12/B14/B26. In backend/tests/typing/storage_contract_s14.py, bind the actual production adapter and an independently implemented in-memory semantic fake to the real consumed interface, and check actual consumer result use. Include an intentional wrong result/argument implementation as a negative fixture and retain its expected checker errors. Imported Any or a cast cannot stand in for the production binding.

**Acceptance:**

- Every exact row assigned to this task has a source-linked current disposition; no unresolved public physical contract is closed by labeling it private.
- Required public result/argument conversions have real production consumer adoption; no caller .fetchone/.fetchall/.rowcount/physical column order remains at the migrated interface.
- Focused semantic fake/adapter contract and applicable native consumer proof pass; one final P14/P12 cohort supplies shared integration evidence rather than a full run per helper.
- The applicable listed caller contracts actually pass a scoped static type check with real production and independent fake bindings, and the deliberate incompatible implementation fails. Runtime fake tests alone do not satisfy the original type-checkable criterion. Private/already-typed dispositions name and check their enclosing public contract; no forced rewrite of private SQL helpers.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_queue_admission_database_split.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_study_opening_admission.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_opening_capacity_admission.py` — cwd `.`; focused; current.
- `python -m mypy --strict --follow-imports=silent --no-incremental backend/tests/typing/storage_contract_s14.py` — cwd `.`; static-typing; PROPOSED scoped acceptance command; no configured checker gate currently exists; integration owner pins/provisions shared checker first and includes any actual changed contract module targets needed to prevent an Any import escape.

**Integration:** At checkpoint2, include only native owner/concurrency/replay cases affected by this cluster; reuse accepted identical inputs. P14 exact selector release is required if the current runner cannot execute the necessary case.

**Material risks:** A typed dictionary alias or wrapper around a cursor is not a semantic boundary; conversely, forcing a new value class around every private/scalar helper adds cost without removing coupling.; Shared backend/app/main.py/service callers may move during BE ownership repairs: rebind the ledger to the released owner, do not edit stale entrypoints or create competing writers.

**Exclusions:** Blind rewrite of all264 historical rows; New storage/repository framework; Changing persistence schema only for typing; Unrelated historical feature restoration

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### S15 — Settle and adopt typed storage boundary: Queue refresh and HTTP head projection contracts

**Scope:** audit-expansion. Findings: ST005. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** B12; B13

**Owner/resource conditions:** Shared typing environment prerequisite: integration owner selects and records one exact mypy version and Python interpreter, provisions it once in the shared task environment during execution, and reuses the B12/B14/B26 convention. No blanket ignore-missing-imports, casts to Any, per-worker installation or repository-wide typing campaign.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `database/tempo_storage/queue_refresh/reads.py` (study_opening_queries); `database/tempo_storage/queue_refresh/foreground.py` (lock_refresh_epochs); `database/tempo_storage/queue_refresh/presentation.py` (saved_plan, current_membership, locked_membership_hash, locked_quarantine_card); `database/tempo_storage/http_composition/queue_projection.py` (entry_state, available_head, retained_entry_issued, position_source_revision); `backend/app/main.py`; `backend/app/services/postgres_queue_refresh.py`; `backend/app/services/queue_application.py`; `backend/app/services/queue_next_card.py`.

**Write scope:** `database/tempo_storage/queue_refresh/reads.py` [existing]; `database/tempo_storage/queue_refresh/foreground.py` [existing]; `database/tempo_storage/queue_refresh/presentation.py` [existing]; `database/tempo_storage/http_composition/queue_projection.py` [existing]; `backend/app/main.py` [existing]; `backend/app/services/postgres_queue_refresh.py` [existing]; `backend/app/services/queue_application.py` [existing]; `backend/app/services/queue_next_card.py` [existing]; `backend/tests/test_queue_refresh_read_database_split.py` [existing]; `backend/tests/test_queue_refresh_position_source_profile.py` [existing]; `backend/tests/test_queue_serving_projection.py` [existing]; `backend/tests/typing/storage_contract_s15.py` [proposed scoped type-check fixture; create only for the applicable owner/public contract after row classification].

**Steps:**

1. Use the exact row ledger for this cluster. For every listed function, trace current supported callers and public owner reachability; classify as public physical leak, private owner implementation, retired/no supported caller, or already semantic/typed. Record concrete caller/public-export/source evidence, never a blanket no-change disposition.
2. Return typed refresh epoch/membership/presentation/head facts instead of native rows. Preserve stale membership detection, quarantine, retained issued identity, read-only preparation and owner revision. Projection cannot imply issuance; only authoritative existing issuance result can enable the browser.
3. For confirmed public/application representation leaks, define the smallest pure typed value/operation contract in the existing owner surface, map SQL rows inside the adapter and adopt every actual listed consumer in the same change. No generic repository, new service or one-function-per-file layer.
4. If a cursor is legitimately private, prove its enclosing public owner returns typed semantic values and prohibit direct cross-owner access with T03. If unreachable, prove registration/import/retained recovery absence before deleting the exclusive helper and its exclusive tests. If already typed, name the exact type and passing current caller contract.
5. Add focused conformance assertions for present/absent/ambiguous/error values, exact IDs/ordering/nullability, immutable original JSON where required, and no new connect/commit/close. A semantic in-memory fake drives policy; an adapter spy rejects wrong predicates/projections. Use native proof only for actually changed SQL/mapping/lock/transaction semantics.
6. Update local owner guidance and T02 ownership/proof metadata for this boundary only. Work in one bounded symbol subset at a time, using a sequential path lease for shared adapters/callers.
7. Use the same scoped pinned checker convention as B12/B14/B26. In backend/tests/typing/storage_contract_s15.py, bind the actual production adapter and an independently implemented in-memory semantic fake to the real consumed interface, and check actual consumer result use. Include an intentional wrong result/argument implementation as a negative fixture and retain its expected checker errors. Imported Any or a cast cannot stand in for the production binding.

**Acceptance:**

- Every exact row assigned to this task has a source-linked current disposition; no unresolved public physical contract is closed by labeling it private.
- Required public result/argument conversions have real production consumer adoption; no caller .fetchone/.fetchall/.rowcount/physical column order remains at the migrated interface.
- Focused semantic fake/adapter contract and applicable native consumer proof pass; one final P14/P12 cohort supplies shared integration evidence rather than a full run per helper.
- The applicable listed caller contracts actually pass a scoped static type check with real production and independent fake bindings, and the deliberate incompatible implementation fails. Runtime fake tests alone do not satisfy the original type-checkable criterion. Private/already-typed dispositions name and check their enclosing public contract; no forced rewrite of private SQL helpers.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_queue_refresh_read_database_split.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_queue_refresh_position_source_profile.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_queue_serving_projection.py` — cwd `.`; focused; current.
- `python -m mypy --strict --follow-imports=silent --no-incremental backend/tests/typing/storage_contract_s15.py` — cwd `.`; static-typing; PROPOSED scoped acceptance command; no configured checker gate currently exists; integration owner pins/provisions shared checker first and includes any actual changed contract module targets needed to prevent an Any import escape.

**Integration:** At checkpoint2, include only native owner/concurrency/replay cases affected by this cluster; reuse accepted identical inputs. P14 exact selector release is required if the current runner cannot execute the necessary case.

**Material risks:** A typed dictionary alias or wrapper around a cursor is not a semantic boundary; conversely, forcing a new value class around every private/scalar helper adds cost without removing coupling.; Shared backend/app/main.py/service callers may move during BE ownership repairs: rebind the ledger to the released owner, do not edit stale entrypoints or create competing writers.

**Exclusions:** Blind rewrite of all264 historical rows; New storage/repository framework; Changing persistence schema only for typing; Unrelated historical feature restoration

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### S16 — Settle and adopt typed storage boundary: Queue placement, retained origins and frozen-order state facts

**Scope:** audit-expansion. Findings: ST005. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** S06

**Owner/resource conditions:** Shared typing environment prerequisite: integration owner selects and records one exact mypy version and Python interpreter, provisions it once in the shared task environment during execution, and reuses the B12/B14/B26 convention. No blanket ignore-missing-imports, casts to Any, per-worker installation or repository-wide typing campaign.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `database/tempo_storage/study/review/storage.py` (queued_order_entries, queue_membership_receipt, queued_entry, insert_entry, other_queued_entries); `database/tempo_storage/lifecycle/queue_attempt_origins.py` (attempt_contexts, current_card_identity, entry_contexts, current_queue_card_identity); `database/tempo_storage/frozen_order.py` (queue_state_rows); `backend/app/queue_attempt_origins.py`; `backend/app/services/frozen_opening_order.py`; `backend/app/services/learning_review_adapter.py`; `backend/app/study/queue_order.py`; `backend/app/study/queue_placement.py`.

**Write scope:** `database/tempo_storage/study/review/storage.py` [existing]; `database/tempo_storage/lifecycle/queue_attempt_origins.py` [existing]; `database/tempo_storage/frozen_order.py` [existing]; `backend/app/queue_attempt_origins.py` [existing]; `backend/app/services/frozen_opening_order.py` [existing]; `backend/app/services/learning_review_adapter.py` [existing]; `backend/app/study/queue_order.py` [existing]; `backend/app/study/queue_placement.py` [existing]; `backend/tests/test_queue_order_owner.py` [existing]; `backend/tests/test_queue_application_extraction.py` [existing]; `backend/tests/test_frozen_opening_order.py` [existing]; `backend/tests/typing/storage_contract_s16.py` [proposed scoped type-check fixture; create only for the applicable owner/public contract after row classification].

**Steps:**

1. Use the exact row ledger for this cluster. For every listed function, trace current supported callers and public owner reachability; classify as public physical leak, private owner implementation, retired/no supported caller, or already semantic/typed. Record concrete caller/public-export/source evidence, never a blanket no-change disposition.
2. Type queue order/membership/inserted-entry/origin/frozen exposure facts. Preserve exact queue/card/revision/cycle and nullable history, both same-card retry and issued-head protection, stable ties and unrelated occupant positions. Internal cursor use remains private; the application no longer decodes positional physical rows at its exposed boundary.
3. For confirmed public/application representation leaks, define the smallest pure typed value/operation contract in the existing owner surface, map SQL rows inside the adapter and adopt every actual listed consumer in the same change. No generic repository, new service or one-function-per-file layer.
4. If a cursor is legitimately private, prove its enclosing public owner returns typed semantic values and prohibit direct cross-owner access with T03. If unreachable, prove registration/import/retained recovery absence before deleting the exclusive helper and its exclusive tests. If already typed, name the exact type and passing current caller contract.
5. Add focused conformance assertions for present/absent/ambiguous/error values, exact IDs/ordering/nullability, immutable original JSON where required, and no new connect/commit/close. A semantic in-memory fake drives policy; an adapter spy rejects wrong predicates/projections. Use native proof only for actually changed SQL/mapping/lock/transaction semantics.
6. Update local owner guidance and T02 ownership/proof metadata for this boundary only. Work in one bounded symbol subset at a time, using a sequential path lease for shared adapters/callers.
7. Use the same scoped pinned checker convention as B12/B14/B26. In backend/tests/typing/storage_contract_s16.py, bind the actual production adapter and an independently implemented in-memory semantic fake to the real consumed interface, and check actual consumer result use. Include an intentional wrong result/argument implementation as a negative fixture and retain its expected checker errors. Imported Any or a cast cannot stand in for the production binding.

**Acceptance:**

- Every exact row assigned to this task has a source-linked current disposition; no unresolved public physical contract is closed by labeling it private.
- Required public result/argument conversions have real production consumer adoption; no caller .fetchone/.fetchall/.rowcount/physical column order remains at the migrated interface.
- Focused semantic fake/adapter contract and applicable native consumer proof pass; one final P14/P12 cohort supplies shared integration evidence rather than a full run per helper.
- The applicable listed caller contracts actually pass a scoped static type check with real production and independent fake bindings, and the deliberate incompatible implementation fails. Runtime fake tests alone do not satisfy the original type-checkable criterion. Private/already-typed dispositions name and check their enclosing public contract; no forced rewrite of private SQL helpers.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_queue_order_owner.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_queue_application_extraction.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_frozen_opening_order.py` — cwd `.`; focused; current.
- `python -m mypy --strict --follow-imports=silent --no-incremental backend/tests/typing/storage_contract_s16.py` — cwd `.`; static-typing; PROPOSED scoped acceptance command; no configured checker gate currently exists; integration owner pins/provisions shared checker first and includes any actual changed contract module targets needed to prevent an Any import escape.

**Integration:** At checkpoint2, include only native owner/concurrency/replay cases affected by this cluster; reuse accepted identical inputs. P14 exact selector release is required if the current runner cannot execute the necessary case.

**Material risks:** A typed dictionary alias or wrapper around a cursor is not a semantic boundary; conversely, forcing a new value class around every private/scalar helper adds cost without removing coupling.; Shared backend/app/main.py/service callers may move during BE ownership repairs: rebind the ledger to the released owner, do not edit stale entrypoints or create competing writers.

**Exclusions:** Blind rewrite of all264 historical rows; New storage/repository framework; Changing persistence schema only for typing; Unrelated historical feature restoration

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### S17 — Settle and adopt typed storage boundary: PGN import and card-edit storage projections

**Scope:** audit-expansion. Findings: ST005. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** P01; B19

**Owner/resource conditions:** Shared typing environment prerequisite: integration owner selects and records one exact mypy version and Python interpreter, provisions it once in the shared task environment during execution, and reuses the B12/B14/B26 convention. No blanket ignore-missing-imports, casts to Any, per-worker installation or repository-wide typing campaign.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `database/tempo_storage/authored_repertoires/pgn_import/preparation.py` (delivery); `database/tempo_storage/authored_repertoires/pgn_import/storage.py` (matching_repertoire, current_sources, existing_lines, existing_card_ids, deleted_card_ids, discard_receipt); `database/tempo_storage/authored_repertoires/card_edits/storage.py` (current_publication, graph_task, card_scope, locked_card, locked_replacement, card_repertoires, locked_archive_identity); `backend/app/card_commands.py`; `backend/app/pgn_import_commands.py`; `backend/app/repertoire/changes/retained_mutations.py`; `backend/app/services/explicit_repertoire_import.py`.

**Write scope:** `database/tempo_storage/authored_repertoires/pgn_import/preparation.py` [existing]; `database/tempo_storage/authored_repertoires/pgn_import/storage.py` [existing]; `database/tempo_storage/authored_repertoires/card_edits/storage.py` [existing]; `backend/app/card_commands.py` [existing]; `backend/app/pgn_import_commands.py` [existing]; `backend/app/repertoire/changes/retained_mutations.py` [existing]; `backend/app/services/explicit_repertoire_import.py` [existing]; `backend/tests/test_pgn_import_storage_boundary.py` [existing]; `backend/tests/test_card_edits_storage_boundary.py` [existing]; `backend/tests/test_repertoire_import_boundary.py` [existing]; `backend/tests/typing/storage_contract_s17.py` [proposed scoped type-check fixture; create only for the applicable owner/public contract after row classification].

**Steps:**

1. Use the exact row ledger for this cluster. For every listed function, trace current supported callers and public owner reachability; classify as public physical leak, private owner implementation, retired/no supported caller, or already semantic/typed. Record concrete caller/public-export/source evidence, never a blanket no-change disposition.
2. Type matching repertoire/source/line/card/deleted-card/discard and revision/publication/archive facts. IDs are semantic strings/sets rather than single-column row tuples; preserve batch returning sets, opaque original delivery, discard byte identity and exact current publication/revision checks. Adopt actual PGN and edit callers; do not resurrect approval previews.
3. For confirmed public/application representation leaks, define the smallest pure typed value/operation contract in the existing owner surface, map SQL rows inside the adapter and adopt every actual listed consumer in the same change. No generic repository, new service or one-function-per-file layer.
4. If a cursor is legitimately private, prove its enclosing public owner returns typed semantic values and prohibit direct cross-owner access with T03. If unreachable, prove registration/import/retained recovery absence before deleting the exclusive helper and its exclusive tests. If already typed, name the exact type and passing current caller contract.
5. Add focused conformance assertions for present/absent/ambiguous/error values, exact IDs/ordering/nullability, immutable original JSON where required, and no new connect/commit/close. A semantic in-memory fake drives policy; an adapter spy rejects wrong predicates/projections. Use native proof only for actually changed SQL/mapping/lock/transaction semantics.
6. Update local owner guidance and T02 ownership/proof metadata for this boundary only. Work in one bounded symbol subset at a time, using a sequential path lease for shared adapters/callers.
7. Use the same scoped pinned checker convention as B12/B14/B26. In backend/tests/typing/storage_contract_s17.py, bind the actual production adapter and an independently implemented in-memory semantic fake to the real consumed interface, and check actual consumer result use. Include an intentional wrong result/argument implementation as a negative fixture and retain its expected checker errors. Imported Any or a cast cannot stand in for the production binding.

**Acceptance:**

- Every exact row assigned to this task has a source-linked current disposition; no unresolved public physical contract is closed by labeling it private.
- Required public result/argument conversions have real production consumer adoption; no caller .fetchone/.fetchall/.rowcount/physical column order remains at the migrated interface.
- Focused semantic fake/adapter contract and applicable native consumer proof pass; one final P14/P12 cohort supplies shared integration evidence rather than a full run per helper.
- The applicable listed caller contracts actually pass a scoped static type check with real production and independent fake bindings, and the deliberate incompatible implementation fails. Runtime fake tests alone do not satisfy the original type-checkable criterion. Private/already-typed dispositions name and check their enclosing public contract; no forced rewrite of private SQL helpers.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_pgn_import_storage_boundary.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_card_edits_storage_boundary.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_repertoire_import_boundary.py` — cwd `.`; focused; current.
- `python -m mypy --strict --follow-imports=silent --no-incremental backend/tests/typing/storage_contract_s17.py` — cwd `.`; static-typing; PROPOSED scoped acceptance command; no configured checker gate currently exists; integration owner pins/provisions shared checker first and includes any actual changed contract module targets needed to prevent an Any import escape.

**Integration:** At checkpoint2, include only native owner/concurrency/replay cases affected by this cluster; reuse accepted identical inputs. P14 exact selector release is required if the current runner cannot execute the necessary case.

**Material risks:** A typed dictionary alias or wrapper around a cursor is not a semantic boundary; conversely, forcing a new value class around every private/scalar helper adds cost without removing coupling.; Shared backend/app/main.py/service callers may move during BE ownership repairs: rebind the ledger to the released owner, do not edit stale entrypoints or create competing writers.

**Exclusions:** Blind rewrite of all264 historical rows; New storage/repository framework; Changing persistence schema only for typing; Unrelated historical feature restoration

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### S18 — Settle and adopt typed storage boundary: Card and repertoire deletion retention facts

**Scope:** audit-expansion. Findings: ST005. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** P03; B23

**Owner/resource conditions:** Shared typing environment prerequisite: integration owner selects and records one exact mypy version and Python interpreter, provisions it once in the shared task environment during execution, and reuses the B12/B14/B26 convention. No blanket ignore-missing-imports, casts to Any, per-worker installation or repository-wide typing campaign.

**Shared-file sequence:** card_deletion/storage.py and corrected test after B23 Study purge extraction.

**Read first:** `database/tempo_storage/authored_repertoires/card_deletion/storage.py` (cancellation_candidates, locked_cancellation_candidate, remaining_evidence_observations, locked_repertoire, owned_cards, replacement_main, preview_card, preview_repertoires, locked_revision, graph_routes, graph_dependencies); `backend/app/card_deletion.py`.

**Write scope:** `database/tempo_storage/authored_repertoires/card_deletion/storage.py` [existing]; `backend/app/card_deletion.py` [existing]; `backend/tests/test_card_deletion_storage_boundary.py` [existing]; `backend/tests/typing/storage_contract_s18.py` [proposed scoped type-check fixture; create only for the applicable owner/public contract after row classification].

**Steps:**

1. Use the exact row ledger for this cluster. For every listed function, trace current supported callers and public owner reachability; classify as public physical leak, private owner implementation, retired/no supported caller, or already semantic/typed. Record concrete caller/public-export/source evidence, never a blanket no-change disposition.
2. After BE011 separates Study-owned purge, type content-owned cancellation, membership, graph and revision facts and adopt only remaining current callers. Preserve locked cancellation recheck, shared-card retention choice, tombstone identities and observed clock points. Do not put Study scheduling or grade deletion back in the authoring adapter.
3. For confirmed public/application representation leaks, define the smallest pure typed value/operation contract in the existing owner surface, map SQL rows inside the adapter and adopt every actual listed consumer in the same change. No generic repository, new service or one-function-per-file layer.
4. If a cursor is legitimately private, prove its enclosing public owner returns typed semantic values and prohibit direct cross-owner access with T03. If unreachable, prove registration/import/retained recovery absence before deleting the exclusive helper and its exclusive tests. If already typed, name the exact type and passing current caller contract.
5. Add focused conformance assertions for present/absent/ambiguous/error values, exact IDs/ordering/nullability, immutable original JSON where required, and no new connect/commit/close. A semantic in-memory fake drives policy; an adapter spy rejects wrong predicates/projections. Use native proof only for actually changed SQL/mapping/lock/transaction semantics.
6. Update local owner guidance and T02 ownership/proof metadata for this boundary only. Work in one bounded symbol subset at a time, using a sequential path lease for shared adapters/callers.
7. Use the same scoped pinned checker convention as B12/B14/B26. In backend/tests/typing/storage_contract_s18.py, bind the actual production adapter and an independently implemented in-memory semantic fake to the real consumed interface, and check actual consumer result use. Include an intentional wrong result/argument implementation as a negative fixture and retain its expected checker errors. Imported Any or a cast cannot stand in for the production binding.

**Acceptance:**

- Every exact row assigned to this task has a source-linked current disposition; no unresolved public physical contract is closed by labeling it private.
- Required public result/argument conversions have real production consumer adoption; no caller .fetchone/.fetchall/.rowcount/physical column order remains at the migrated interface.
- Focused semantic fake/adapter contract and applicable native consumer proof pass; one final P14/P12 cohort supplies shared integration evidence rather than a full run per helper.
- The applicable listed caller contracts actually pass a scoped static type check with real production and independent fake bindings, and the deliberate incompatible implementation fails. Runtime fake tests alone do not satisfy the original type-checkable criterion. Private/already-typed dispositions name and check their enclosing public contract; no forced rewrite of private SQL helpers.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_card_deletion_storage_boundary.py` — cwd `.`; focused; current.
- `python -m mypy --strict --follow-imports=silent --no-incremental backend/tests/typing/storage_contract_s18.py` — cwd `.`; static-typing; PROPOSED scoped acceptance command; no configured checker gate currently exists; integration owner pins/provisions shared checker first and includes any actual changed contract module targets needed to prevent an Any import escape.

**Integration:** At checkpoint2, include only native owner/concurrency/replay cases affected by this cluster; reuse accepted identical inputs. P14 exact selector release is required if the current runner cannot execute the necessary case.

**Material risks:** A typed dictionary alias or wrapper around a cursor is not a semantic boundary; conversely, forcing a new value class around every private/scalar helper adds cost without removing coupling.; Shared backend/app/main.py/service callers may move during BE ownership repairs: rebind the ledger to the released owner, do not edit stale entrypoints or create competing writers.

**Exclusions:** Blind rewrite of all264 historical rows; New storage/repository framework; Changing persistence schema only for typing; Unrelated historical feature restoration

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### S19 — Settle and adopt typed storage boundary: Integrity scan and publication adapter facts

**Scope:** audit-expansion. Findings: ST005. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** B30

**Owner/resource conditions:** Shared typing environment prerequisite: integration owner selects and records one exact mypy version and Python interpreter, provisions it once in the shared task environment during execution, and reuses the B12/B14/B26 convention. No blanket ignore-missing-imports, casts to Any, per-worker installation or repository-wide typing campaign.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `database/tempo_storage/authored_repertoires/integrity/native.py` (certificate_facts, feedback_prerequisite_facts, first_source_color, next_line_source, next_card_source, staged_source, next_accumulated_position, graph_task, graph_publication, next_cards_to_validate, has_published_issue); `backend/app/services/postgres_integrity.py`.

**Write scope:** `database/tempo_storage/authored_repertoires/integrity/native.py` [existing]; `backend/app/services/postgres_integrity.py` [existing]; `backend/tests/test_repertoire_conflicts.py` [existing]; `backend/tests/test_product_position_index.py` [existing]; `backend/tests/typing/storage_contract_s19.py` [proposed scoped type-check fixture; create only for the applicable owner/public contract after row classification].

**Steps:**

1. Use the exact row ledger for this cluster. For every listed function, trace current supported callers and public owner reachability; classify as public physical leak, private owner implementation, retired/no supported caller, or already semantic/typed. Record concrete caller/public-export/source evidence, never a blanket no-change disposition.
2. Type certificate/current-task/generation/source-page/card-validation/issue-presence facts; distinguish incomplete/oversized source, held integrity and missing data. Preserve exact scan generation/publication completeness and stable paging. A physical row from a private scan helper may remain private only when its public scan outcome is typed and exercised.
3. For confirmed public/application representation leaks, define the smallest pure typed value/operation contract in the existing owner surface, map SQL rows inside the adapter and adopt every actual listed consumer in the same change. No generic repository, new service or one-function-per-file layer.
4. If a cursor is legitimately private, prove its enclosing public owner returns typed semantic values and prohibit direct cross-owner access with T03. If unreachable, prove registration/import/retained recovery absence before deleting the exclusive helper and its exclusive tests. If already typed, name the exact type and passing current caller contract.
5. Add focused conformance assertions for present/absent/ambiguous/error values, exact IDs/ordering/nullability, immutable original JSON where required, and no new connect/commit/close. A semantic in-memory fake drives policy; an adapter spy rejects wrong predicates/projections. Use native proof only for actually changed SQL/mapping/lock/transaction semantics.
6. Update local owner guidance and T02 ownership/proof metadata for this boundary only. Work in one bounded symbol subset at a time, using a sequential path lease for shared adapters/callers.
7. Use the same scoped pinned checker convention as B12/B14/B26. In backend/tests/typing/storage_contract_s19.py, bind the actual production adapter and an independently implemented in-memory semantic fake to the real consumed interface, and check actual consumer result use. Include an intentional wrong result/argument implementation as a negative fixture and retain its expected checker errors. Imported Any or a cast cannot stand in for the production binding.

**Acceptance:**

- Every exact row assigned to this task has a source-linked current disposition; no unresolved public physical contract is closed by labeling it private.
- Required public result/argument conversions have real production consumer adoption; no caller .fetchone/.fetchall/.rowcount/physical column order remains at the migrated interface.
- Focused semantic fake/adapter contract and applicable native consumer proof pass; one final P14/P12 cohort supplies shared integration evidence rather than a full run per helper.
- The applicable listed caller contracts actually pass a scoped static type check with real production and independent fake bindings, and the deliberate incompatible implementation fails. Runtime fake tests alone do not satisfy the original type-checkable criterion. Private/already-typed dispositions name and check their enclosing public contract; no forced rewrite of private SQL helpers.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_repertoire_conflicts.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_product_position_index.py` — cwd `.`; focused; current.
- `python -m mypy --strict --follow-imports=silent --no-incremental backend/tests/typing/storage_contract_s19.py` — cwd `.`; static-typing; PROPOSED scoped acceptance command; no configured checker gate currently exists; integration owner pins/provisions shared checker first and includes any actual changed contract module targets needed to prevent an Any import escape.

**Integration:** At checkpoint2, include only native owner/concurrency/replay cases affected by this cluster; reuse accepted identical inputs. P14 exact selector release is required if the current runner cannot execute the necessary case.

**Material risks:** A typed dictionary alias or wrapper around a cursor is not a semantic boundary; conversely, forcing a new value class around every private/scalar helper adds cost without removing coupling.; Shared backend/app/main.py/service callers may move during BE ownership repairs: rebind the ledger to the released owner, do not edit stale entrypoints or create competing writers.

**Exclusions:** Blind rewrite of all264 historical rows; New storage/repository framework; Changing persistence schema only for typing; Unrelated historical feature restoration

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### S20 — Settle and adopt typed storage boundary: Integrity read and repair command contracts

**Scope:** audit-expansion. Findings: ST005. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** S19; B19

**Owner/resource conditions:** Shared typing environment prerequisite: integration owner selects and records one exact mypy version and Python interpreter, provisions it once in the shared task environment during execution, and reuses the B12/B14/B26 convention. No blanket ignore-missing-imports, casts to Any, per-worker installation or repository-wide typing campaign.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `database/tempo_storage/authored_repertoires/integrity/storage.py` (summary_state, first_issue, issue_details, active_card_authority, membership_authority, remaining_membership, issue, prepared_lines, prepared_cards); `database/tempo_storage/authored_repertoires/integrity_commands.py` (locked_issue_signature, locked_source_line, locked_source_card, repertoire_card_link); `backend/app/integrity_repair_commands.py`; `backend/app/repertoire/changes/retained_mutations.py`; `backend/app/services/repertoire_integrity.py`.

**Write scope:** `database/tempo_storage/authored_repertoires/integrity/storage.py` [existing]; `database/tempo_storage/authored_repertoires/integrity_commands.py` [existing]; `backend/app/integrity_repair_commands.py` [existing]; `backend/app/repertoire/changes/retained_mutations.py` [existing]; `backend/app/services/repertoire_integrity.py` [existing]; `backend/tests/test_repertoire_conflicts.py` [existing]; `backend/tests/test_retained_mutations_boundary.py` [existing]; `backend/tests/typing/storage_contract_s20.py` [proposed scoped type-check fixture; create only for the applicable owner/public contract after row classification].

**Steps:**

1. Use the exact row ledger for this cluster. For every listed function, trace current supported callers and public owner reachability; classify as public physical leak, private owner implementation, retired/no supported caller, or already semantic/typed. Record concrete caller/public-export/source evidence, never a blanket no-change disposition.
2. Define semantic issue/summary/active-card/membership/prepared-line facts and locked repair identity. Preserve exact issue signature, source revision and remaining membership checks; lock refusal cannot become absence/success. No application consumer should infer physical column order or mutate SQL-shaped dictionaries.
3. For confirmed public/application representation leaks, define the smallest pure typed value/operation contract in the existing owner surface, map SQL rows inside the adapter and adopt every actual listed consumer in the same change. No generic repository, new service or one-function-per-file layer.
4. If a cursor is legitimately private, prove its enclosing public owner returns typed semantic values and prohibit direct cross-owner access with T03. If unreachable, prove registration/import/retained recovery absence before deleting the exclusive helper and its exclusive tests. If already typed, name the exact type and passing current caller contract.
5. Add focused conformance assertions for present/absent/ambiguous/error values, exact IDs/ordering/nullability, immutable original JSON where required, and no new connect/commit/close. A semantic in-memory fake drives policy; an adapter spy rejects wrong predicates/projections. Use native proof only for actually changed SQL/mapping/lock/transaction semantics.
6. Update local owner guidance and T02 ownership/proof metadata for this boundary only. Work in one bounded symbol subset at a time, using a sequential path lease for shared adapters/callers.
7. Use the same scoped pinned checker convention as B12/B14/B26. In backend/tests/typing/storage_contract_s20.py, bind the actual production adapter and an independently implemented in-memory semantic fake to the real consumed interface, and check actual consumer result use. Include an intentional wrong result/argument implementation as a negative fixture and retain its expected checker errors. Imported Any or a cast cannot stand in for the production binding.

**Acceptance:**

- Every exact row assigned to this task has a source-linked current disposition; no unresolved public physical contract is closed by labeling it private.
- Required public result/argument conversions have real production consumer adoption; no caller .fetchone/.fetchall/.rowcount/physical column order remains at the migrated interface.
- Focused semantic fake/adapter contract and applicable native consumer proof pass; one final P14/P12 cohort supplies shared integration evidence rather than a full run per helper.
- The applicable listed caller contracts actually pass a scoped static type check with real production and independent fake bindings, and the deliberate incompatible implementation fails. Runtime fake tests alone do not satisfy the original type-checkable criterion. Private/already-typed dispositions name and check their enclosing public contract; no forced rewrite of private SQL helpers.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_repertoire_conflicts.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_retained_mutations_boundary.py` — cwd `.`; focused; current.
- `python -m mypy --strict --follow-imports=silent --no-incremental backend/tests/typing/storage_contract_s20.py` — cwd `.`; static-typing; PROPOSED scoped acceptance command; no configured checker gate currently exists; integration owner pins/provisions shared checker first and includes any actual changed contract module targets needed to prevent an Any import escape.

**Integration:** At checkpoint2, include only native owner/concurrency/replay cases affected by this cluster; reuse accepted identical inputs. P14 exact selector release is required if the current runner cannot execute the necessary case.

**Material risks:** A typed dictionary alias or wrapper around a cursor is not a semantic boundary; conversely, forcing a new value class around every private/scalar helper adds cost without removing coupling.; Shared backend/app/main.py/service callers may move during BE ownership repairs: rebind the ledger to the released owner, do not edit stale entrypoints or create competing writers.

**Exclusions:** Blind rewrite of all264 historical rows; New storage/repository framework; Changing persistence schema only for typing; Unrelated historical feature restoration

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### S21 — Settle and adopt typed storage boundary: Repertoire branch, paste, canonical-prefix and move-membership facts

**Scope:** audit-expansion. Findings: ST005. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** B19; B27; B28; B29

**Owner/resource conditions:** Shared typing environment prerequisite: integration owner selects and records one exact mypy version and Python interpreter, provisions it once in the shared task environment during execution, and reuses the B12/B14/B26 convention. No blanket ignore-missing-imports, casts to Any, per-worker installation or repository-wide typing campaign.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `database/tempo_storage/authored_repertoires/branches.py` (lock_repertoire_for_add, insert_line_values, lock_source_gap, lock_repertoire_for_remove, stored_repertoire_lines); `database/tempo_storage/authored_repertoires/analysis_paste.py` (repertoires, lines, coverage_gap); `database/tempo_storage/authored_repertoires/canonical_prefix/scope.py` (prefix_row, line_anchor); `database/tempo_storage/repertoire_scope/move_verification.py` (source_line_page); `backend/app/branch_commands.py`; `backend/app/services/analysis_paste.py`; `backend/app/services/canonical_prefix.py`; `backend/app/services/repertoire_move_verification.py`.

**Write scope:** `database/tempo_storage/authored_repertoires/branches.py` [existing]; `database/tempo_storage/authored_repertoires/analysis_paste.py` [existing]; `database/tempo_storage/authored_repertoires/canonical_prefix/scope.py` [existing]; `database/tempo_storage/repertoire_scope/move_verification.py` [existing]; `backend/app/branch_commands.py` [existing]; `backend/app/services/analysis_paste.py` [existing]; `backend/app/services/canonical_prefix.py` [existing]; `backend/app/services/repertoire_move_verification.py` [existing]; `backend/tests/test_canonical_repertoire_prefix.py` [existing]; `backend/tests/test_retained_mutations_boundary.py` [existing]; `backend/tests/test_repertoire_import_boundary.py` [existing]; `backend/tests/typing/storage_contract_s21.py` [proposed scoped type-check fixture; create only for the applicable owner/public contract after row classification].

**Steps:**

1. Use the exact row ledger for this cluster. For every listed function, trace current supported callers and public owner reachability; classify as public physical leak, private owner implementation, retired/no supported caller, or already semantic/typed. Record concrete caller/public-export/source evidence, never a blanket no-change disposition.
2. Type retained branch locks/line values, read-only paste preview, canonical prefix and bounded source-line page facts. Positively classify coverage_gap and source-gap paths against SPEC; delete only exclusive retired workflow with current caller proof, retain basic repertoire paste/branch behavior and source/currentness checks.
3. For confirmed public/application representation leaks, define the smallest pure typed value/operation contract in the existing owner surface, map SQL rows inside the adapter and adopt every actual listed consumer in the same change. No generic repository, new service or one-function-per-file layer.
4. If a cursor is legitimately private, prove its enclosing public owner returns typed semantic values and prohibit direct cross-owner access with T03. If unreachable, prove registration/import/retained recovery absence before deleting the exclusive helper and its exclusive tests. If already typed, name the exact type and passing current caller contract.
5. Add focused conformance assertions for present/absent/ambiguous/error values, exact IDs/ordering/nullability, immutable original JSON where required, and no new connect/commit/close. A semantic in-memory fake drives policy; an adapter spy rejects wrong predicates/projections. Use native proof only for actually changed SQL/mapping/lock/transaction semantics.
6. Update local owner guidance and T02 ownership/proof metadata for this boundary only. Work in one bounded symbol subset at a time, using a sequential path lease for shared adapters/callers.
7. Use the same scoped pinned checker convention as B12/B14/B26. In backend/tests/typing/storage_contract_s21.py, bind the actual production adapter and an independently implemented in-memory semantic fake to the real consumed interface, and check actual consumer result use. Include an intentional wrong result/argument implementation as a negative fixture and retain its expected checker errors. Imported Any or a cast cannot stand in for the production binding.

**Acceptance:**

- Every exact row assigned to this task has a source-linked current disposition; no unresolved public physical contract is closed by labeling it private.
- Required public result/argument conversions have real production consumer adoption; no caller .fetchone/.fetchall/.rowcount/physical column order remains at the migrated interface.
- Focused semantic fake/adapter contract and applicable native consumer proof pass; one final P14/P12 cohort supplies shared integration evidence rather than a full run per helper.
- The applicable listed caller contracts actually pass a scoped static type check with real production and independent fake bindings, and the deliberate incompatible implementation fails. Runtime fake tests alone do not satisfy the original type-checkable criterion. Private/already-typed dispositions name and check their enclosing public contract; no forced rewrite of private SQL helpers.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_canonical_repertoire_prefix.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_retained_mutations_boundary.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_repertoire_import_boundary.py` — cwd `.`; focused; current.
- `python -m mypy --strict --follow-imports=silent --no-incremental backend/tests/typing/storage_contract_s21.py` — cwd `.`; static-typing; PROPOSED scoped acceptance command; no configured checker gate currently exists; integration owner pins/provisions shared checker first and includes any actual changed contract module targets needed to prevent an Any import escape.

**Integration:** At checkpoint2, include only native owner/concurrency/replay cases affected by this cluster; reuse accepted identical inputs. P14 exact selector release is required if the current runner cannot execute the necessary case.

**Material risks:** A typed dictionary alias or wrapper around a cursor is not a semantic boundary; conversely, forcing a new value class around every private/scalar helper adds cost without removing coupling.; Shared backend/app/main.py/service callers may move during BE ownership repairs: rebind the ledger to the released owner, do not edit stale entrypoints or create competing writers.

**Exclusions:** Blind rewrite of all264 historical rows; New storage/repository framework; Changing persistence schema only for typing; Unrelated historical feature restoration

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### S22 — Settle and adopt typed storage boundary: Manual prefix split command and lineage facts

**Scope:** audit-expansion. Findings: ST005. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** P06; P07; B25

**Owner/resource conditions:** Shared typing environment prerequisite: integration owner selects and records one exact mypy version and Python interpreter, provisions it once in the shared task environment during execution, and reuses the B12/B14/B26 convention. No blanket ignore-missing-imports, casts to Any, per-worker installation or repository-wide typing campaign.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `database/tempo_storage/authored_repertoires/opening_mutations/prefix_splits.py` (first_line_color, card_row, queued_positions, prior_split, source_queue_entries, card_present, queued_followup, membership_rows, queue_collision, insert_followup); `database/tempo_storage/foreground_controls/prefix_splits.py` (locked_prefix_card, published_usage, linked_repertoire_rows); `backend/app/prefix_split_commands.py`; `backend/app/services/prefix_split.py`.

**Write scope:** `database/tempo_storage/authored_repertoires/opening_mutations/prefix_splits.py` [existing]; `database/tempo_storage/foreground_controls/prefix_splits.py` [existing]; `backend/app/prefix_split_commands.py` [existing]; `backend/app/services/prefix_split.py` [existing]; `backend/tests/test_queue_order_owner.py` [existing]; `backend/tests/test_retained_mutations_boundary.py` [existing]; `backend/tests/test_prefix_split_http.py` [proposed; reserve before creation]; `backend/tests/typing/storage_contract_s22.py` [proposed scoped type-check fixture; create only for the applicable owner/public contract after row classification].

**Steps:**

1. Use the exact row ledger for this cluster. For every listed function, trace current supported callers and public owner reachability; classify as public physical leak, private owner implementation, retired/no supported caller, or already semantic/typed. Record concrete caller/public-export/source evidence, never a blanket no-change disposition.
2. Type exact source card/first line color, prior split, memberships, queue collision/followup and published usage facts; use named queue insertion args/result. Keep historical source review association, lineage, canonical membership, preserved parent/continuation IDs and after-four queue placement. Real HTTP consumer uses the same existing command; no second split implementation.
3. For confirmed public/application representation leaks, define the smallest pure typed value/operation contract in the existing owner surface, map SQL rows inside the adapter and adopt every actual listed consumer in the same change. No generic repository, new service or one-function-per-file layer.
4. If a cursor is legitimately private, prove its enclosing public owner returns typed semantic values and prohibit direct cross-owner access with T03. If unreachable, prove registration/import/retained recovery absence before deleting the exclusive helper and its exclusive tests. If already typed, name the exact type and passing current caller contract.
5. Add focused conformance assertions for present/absent/ambiguous/error values, exact IDs/ordering/nullability, immutable original JSON where required, and no new connect/commit/close. A semantic in-memory fake drives policy; an adapter spy rejects wrong predicates/projections. Use native proof only for actually changed SQL/mapping/lock/transaction semantics.
6. Update local owner guidance and T02 ownership/proof metadata for this boundary only. Work in one bounded symbol subset at a time, using a sequential path lease for shared adapters/callers.
7. Use the same scoped pinned checker convention as B12/B14/B26. In backend/tests/typing/storage_contract_s22.py, bind the actual production adapter and an independently implemented in-memory semantic fake to the real consumed interface, and check actual consumer result use. Include an intentional wrong result/argument implementation as a negative fixture and retain its expected checker errors. Imported Any or a cast cannot stand in for the production binding.

**Acceptance:**

- Every exact row assigned to this task has a source-linked current disposition; no unresolved public physical contract is closed by labeling it private.
- Required public result/argument conversions have real production consumer adoption; no caller .fetchone/.fetchall/.rowcount/physical column order remains at the migrated interface.
- Focused semantic fake/adapter contract and applicable native consumer proof pass; one final P14/P12 cohort supplies shared integration evidence rather than a full run per helper.
- The applicable listed caller contracts actually pass a scoped static type check with real production and independent fake bindings, and the deliberate incompatible implementation fails. Runtime fake tests alone do not satisfy the original type-checkable criterion. Private/already-typed dispositions name and check their enclosing public contract; no forced rewrite of private SQL helpers.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_queue_order_owner.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_retained_mutations_boundary.py` — cwd `.`; focused; current.
- `python -m mypy --strict --follow-imports=silent --no-incremental backend/tests/typing/storage_contract_s22.py` — cwd `.`; static-typing; PROPOSED scoped acceptance command; no configured checker gate currently exists; integration owner pins/provisions shared checker first and includes any actual changed contract module targets needed to prevent an Any import escape.

**Integration:** At checkpoint2, include only native owner/concurrency/replay cases affected by this cluster; reuse accepted identical inputs. P14 exact selector release is required if the current runner cannot execute the necessary case.

**Material risks:** A typed dictionary alias or wrapper around a cursor is not a semantic boundary; conversely, forcing a new value class around every private/scalar helper adds cost without removing coupling.; Shared backend/app/main.py/service callers may move during BE ownership repairs: rebind the ledger to the released owner, do not edit stale entrypoints or create competing writers.

**Exclusions:** Blind rewrite of all264 historical rows; New storage/repository framework; Changing persistence schema only for typing; Unrelated historical feature restoration

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### S23 — Settle and adopt typed storage boundary: Opening graph worker persistence facts

**Scope:** audit-expansion. Findings: ST005. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** B28

**Owner/resource conditions:** Shared typing environment prerequisite: integration owner selects and records one exact mypy version and Python interpreter, provisions it once in the shared task environment during execution, and reuses the B12/B14/B26 convention. No blanket ignore-missing-imports, casts to Any, per-worker installation or repository-wide typing campaign.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `database/tempo_storage/opening_graph/worker.py` (latest_staged_generation, published_generation, deleted_card_rows, missing_link, next_source_line, staged_card_ids, classification, cleanup_candidates, prefix_override_rows, protected_card, eligible_cleanup_cards); `backend/app/services/postgres_opening_graph.py`.

**Write scope:** `database/tempo_storage/opening_graph/worker.py` [existing]; `backend/app/services/postgres_opening_graph.py` [existing]; `backend/tests/test_postgres_opening_graph.py` [existing]; `backend/tests/test_opening_graph.py` [existing]; `backend/tests/test_opening_graph_cleanup_postgres.py` [existing]; `backend/tests/typing/storage_contract_s23.py` [proposed scoped type-check fixture; create only for the applicable owner/public contract after row classification].

**Steps:**

1. Use the exact row ledger for this cluster. For every listed function, trace current supported callers and public owner reachability; classify as public physical leak, private owner implementation, retired/no supported caller, or already semantic/typed. Record concrete caller/public-export/source evidence, never a blanket no-change disposition.
2. Type current/staged generation, next source page, classification/cleanup candidate and protected-card results. Preserve bounded paging, stale-generation refusal, source/currentness and protected active/retained history. Keep graph algorithm in its current application owner and SQL/locks in storage.
3. For confirmed public/application representation leaks, define the smallest pure typed value/operation contract in the existing owner surface, map SQL rows inside the adapter and adopt every actual listed consumer in the same change. No generic repository, new service or one-function-per-file layer.
4. If a cursor is legitimately private, prove its enclosing public owner returns typed semantic values and prohibit direct cross-owner access with T03. If unreachable, prove registration/import/retained recovery absence before deleting the exclusive helper and its exclusive tests. If already typed, name the exact type and passing current caller contract.
5. Add focused conformance assertions for present/absent/ambiguous/error values, exact IDs/ordering/nullability, immutable original JSON where required, and no new connect/commit/close. A semantic in-memory fake drives policy; an adapter spy rejects wrong predicates/projections. Use native proof only for actually changed SQL/mapping/lock/transaction semantics.
6. Update local owner guidance and T02 ownership/proof metadata for this boundary only. Work in one bounded symbol subset at a time, using a sequential path lease for shared adapters/callers.
7. Use the same scoped pinned checker convention as B12/B14/B26. In backend/tests/typing/storage_contract_s23.py, bind the actual production adapter and an independently implemented in-memory semantic fake to the real consumed interface, and check actual consumer result use. Include an intentional wrong result/argument implementation as a negative fixture and retain its expected checker errors. Imported Any or a cast cannot stand in for the production binding.

**Acceptance:**

- Every exact row assigned to this task has a source-linked current disposition; no unresolved public physical contract is closed by labeling it private.
- Required public result/argument conversions have real production consumer adoption; no caller .fetchone/.fetchall/.rowcount/physical column order remains at the migrated interface.
- Focused semantic fake/adapter contract and applicable native consumer proof pass; one final P14/P12 cohort supplies shared integration evidence rather than a full run per helper.
- The applicable listed caller contracts actually pass a scoped static type check with real production and independent fake bindings, and the deliberate incompatible implementation fails. Runtime fake tests alone do not satisfy the original type-checkable criterion. Private/already-typed dispositions name and check their enclosing public contract; no forced rewrite of private SQL helpers.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_postgres_opening_graph.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_opening_graph.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_opening_graph_cleanup_postgres.py` — cwd `.`; native; current wrapper; requires admitted invocation-owned native fixture and exact zero-skip execution, not a pure local check.
- `python -m mypy --strict --follow-imports=silent --no-incremental backend/tests/typing/storage_contract_s23.py` — cwd `.`; static-typing; PROPOSED scoped acceptance command; no configured checker gate currently exists; integration owner pins/provisions shared checker first and includes any actual changed contract module targets needed to prevent an Any import escape.

**Integration:** At checkpoint2, include only native owner/concurrency/replay cases affected by this cluster; reuse accepted identical inputs. P14 exact selector release is required if the current runner cannot execute the necessary case.

**Material risks:** A typed dictionary alias or wrapper around a cursor is not a semantic boundary; conversely, forcing a new value class around every private/scalar helper adds cost without removing coupling.; Shared backend/app/main.py/service callers may move during BE ownership repairs: rebind the ledger to the released owner, do not edit stale entrypoints or create competing writers.

**Exclusions:** Blind rewrite of all264 historical rows; New storage/repository framework; Changing persistence schema only for typing; Unrelated historical feature restoration

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### S24 — Settle and adopt typed storage boundary: Durable task identity and read models

**Scope:** audit-expansion. Findings: ST005. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** B02; B03

**Owner/resource conditions:** Shared typing environment prerequisite: integration owner selects and records one exact mypy version and Python interpreter, provisions it once in the shared task environment during execution, and reuses the B12/B14/B26 convention. No blanket ignore-missing-imports, casts to Any, per-worker installation or repository-wide typing campaign.

**Shared-file sequence:** durable_tasks/storage.py S24 read-model slice before S25 transition slice.

**Read first:** `database/tempo_storage/durable_tasks/storage.py` (task_by_id, task_by_kind, read_task, failure_budget, failed_task, interrupted_tasks, visible_tasks, task_exists, task_kind); `backend/app/main.py`; `backend/app/services/durable_tasks.py`.

**Write scope:** `database/tempo_storage/durable_tasks/storage.py` [existing]; `backend/app/main.py` [existing]; `backend/app/services/durable_tasks.py` [existing]; `backend/tests/test_durable_task_enqueue_identity.py` [existing]; `backend/tests/test_background_diagnostics.py` [existing]; `backend/tests/typing/storage_contract_s24.py` [proposed scoped type-check fixture; create only for the applicable owner/public contract after row classification].

**Steps:**

1. Use the exact row ledger for this cluster. For every listed function, trace current supported callers and public owner reachability; classify as public physical leak, private owner implementation, retired/no supported caller, or already semantic/typed. Record concrete caller/public-export/source evidence, never a blanket no-change disposition.
2. Return typed Task/TaskSummary/RetryBudget and semantic presence/kind results, preserving payload bytes, attempt/generation/lease/deadline and stored failure distinctions. JSON decoded application tasks must not change original command bytes or silently reset next-retry scheduling.
3. For confirmed public/application representation leaks, define the smallest pure typed value/operation contract in the existing owner surface, map SQL rows inside the adapter and adopt every actual listed consumer in the same change. No generic repository, new service or one-function-per-file layer.
4. If a cursor is legitimately private, prove its enclosing public owner returns typed semantic values and prohibit direct cross-owner access with T03. If unreachable, prove registration/import/retained recovery absence before deleting the exclusive helper and its exclusive tests. If already typed, name the exact type and passing current caller contract.
5. Add focused conformance assertions for present/absent/ambiguous/error values, exact IDs/ordering/nullability, immutable original JSON where required, and no new connect/commit/close. A semantic in-memory fake drives policy; an adapter spy rejects wrong predicates/projections. Use native proof only for actually changed SQL/mapping/lock/transaction semantics.
6. Update local owner guidance and T02 ownership/proof metadata for this boundary only. Work in one bounded symbol subset at a time, using a sequential path lease for shared adapters/callers.
7. Use the same scoped pinned checker convention as B12/B14/B26. In backend/tests/typing/storage_contract_s24.py, bind the actual production adapter and an independently implemented in-memory semantic fake to the real consumed interface, and check actual consumer result use. Include an intentional wrong result/argument implementation as a negative fixture and retain its expected checker errors. Imported Any or a cast cannot stand in for the production binding.

**Acceptance:**

- Every exact row assigned to this task has a source-linked current disposition; no unresolved public physical contract is closed by labeling it private.
- Required public result/argument conversions have real production consumer adoption; no caller .fetchone/.fetchall/.rowcount/physical column order remains at the migrated interface.
- Focused semantic fake/adapter contract and applicable native consumer proof pass; one final P14/P12 cohort supplies shared integration evidence rather than a full run per helper.
- The applicable listed caller contracts actually pass a scoped static type check with real production and independent fake bindings, and the deliberate incompatible implementation fails. Runtime fake tests alone do not satisfy the original type-checkable criterion. Private/already-typed dispositions name and check their enclosing public contract; no forced rewrite of private SQL helpers.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_durable_task_enqueue_identity.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_background_diagnostics.py` — cwd `.`; focused; current.
- `python -m mypy --strict --follow-imports=silent --no-incremental backend/tests/typing/storage_contract_s24.py` — cwd `.`; static-typing; PROPOSED scoped acceptance command; no configured checker gate currently exists; integration owner pins/provisions shared checker first and includes any actual changed contract module targets needed to prevent an Any import escape.

**Integration:** At checkpoint2, include only native owner/concurrency/replay cases affected by this cluster; reuse accepted identical inputs. P14 exact selector release is required if the current runner cannot execute the necessary case.

**Material risks:** A typed dictionary alias or wrapper around a cursor is not a semantic boundary; conversely, forcing a new value class around every private/scalar helper adds cost without removing coupling.; Shared backend/app/main.py/service callers may move during BE ownership repairs: rebind the ledger to the released owner, do not edit stale entrypoints or create competing writers.

**Exclusions:** Blind rewrite of all264 historical rows; New storage/repository framework; Changing persistence schema only for typing; Unrelated historical feature restoration

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### S25 — Settle and adopt typed storage boundary: Durable task claim and transition facts

**Scope:** audit-expansion. Findings: ST005. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** S24; B02; B03

**Owner/resource conditions:** Shared typing environment prerequisite: integration owner selects and records one exact mypy version and Python interpreter, provisions it once in the shared task environment during execution, and reuses the B12/B14/B26 convention. No blanket ignore-missing-imports, casts to Any, per-worker installation or repository-wide typing campaign.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `database/tempo_storage/durable_tasks/storage.py` (prepare_task_upsert, prepare_task_claim, prepare_manual_retry, prepare_interrupted_requeue, lock_slice, timeout_checkpoint, delivery_lease, lock_or_create_current_queue_task); `backend/app/services/durable_tasks.py`.

**Write scope:** `database/tempo_storage/durable_tasks/storage.py` [existing]; `backend/app/services/durable_tasks.py` [existing]; `backend/tests/test_durable_task_enqueue_identity.py` [existing]; `backend/tests/test_queue_refresh_wakeup.py` [existing]; `backend/tests/test_background_wakes.py` [existing]; `backend/tests/typing/storage_contract_s25.py` [proposed scoped type-check fixture; create only for the applicable owner/public contract after row classification].

**Steps:**

1. Use the exact row ledger for this cluster. For every listed function, trace current supported callers and public owner reachability; classify as public physical leak, private owner implementation, retired/no supported caller, or already semantic/typed. Record concrete caller/public-export/source evidence, never a blanket no-change disposition.
2. Expose typed upsert/claim/retry/slice/checkpoint/lease results and named args. Preserve generation/lease fencing, payload identity, immutable timeout checkpoint, one current-day task and post-commit advisory wake. Fake and native negative controls must reject stale lease and missing predicate; no transaction/connection ownership moves.
3. For confirmed public/application representation leaks, define the smallest pure typed value/operation contract in the existing owner surface, map SQL rows inside the adapter and adopt every actual listed consumer in the same change. No generic repository, new service or one-function-per-file layer.
4. If a cursor is legitimately private, prove its enclosing public owner returns typed semantic values and prohibit direct cross-owner access with T03. If unreachable, prove registration/import/retained recovery absence before deleting the exclusive helper and its exclusive tests. If already typed, name the exact type and passing current caller contract.
5. Add focused conformance assertions for present/absent/ambiguous/error values, exact IDs/ordering/nullability, immutable original JSON where required, and no new connect/commit/close. A semantic in-memory fake drives policy; an adapter spy rejects wrong predicates/projections. Use native proof only for actually changed SQL/mapping/lock/transaction semantics.
6. Update local owner guidance and T02 ownership/proof metadata for this boundary only. Work in one bounded symbol subset at a time, using a sequential path lease for shared adapters/callers.
7. Use the same scoped pinned checker convention as B12/B14/B26. In backend/tests/typing/storage_contract_s25.py, bind the actual production adapter and an independently implemented in-memory semantic fake to the real consumed interface, and check actual consumer result use. Include an intentional wrong result/argument implementation as a negative fixture and retain its expected checker errors. Imported Any or a cast cannot stand in for the production binding.

**Acceptance:**

- Every exact row assigned to this task has a source-linked current disposition; no unresolved public physical contract is closed by labeling it private.
- Required public result/argument conversions have real production consumer adoption; no caller .fetchone/.fetchall/.rowcount/physical column order remains at the migrated interface.
- Focused semantic fake/adapter contract and applicable native consumer proof pass; one final P14/P12 cohort supplies shared integration evidence rather than a full run per helper.
- The applicable listed caller contracts actually pass a scoped static type check with real production and independent fake bindings, and the deliberate incompatible implementation fails. Runtime fake tests alone do not satisfy the original type-checkable criterion. Private/already-typed dispositions name and check their enclosing public contract; no forced rewrite of private SQL helpers.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_durable_task_enqueue_identity.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_queue_refresh_wakeup.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_background_wakes.py` — cwd `.`; focused; current.
- `python -m mypy --strict --follow-imports=silent --no-incremental backend/tests/typing/storage_contract_s25.py` — cwd `.`; static-typing; PROPOSED scoped acceptance command; no configured checker gate currently exists; integration owner pins/provisions shared checker first and includes any actual changed contract module targets needed to prevent an Any import escape.

**Integration:** At checkpoint2, include only native owner/concurrency/replay cases affected by this cluster; reuse accepted identical inputs. P14 exact selector release is required if the current runner cannot execute the necessary case.

**Material risks:** A typed dictionary alias or wrapper around a cursor is not a semantic boundary; conversely, forcing a new value class around every private/scalar helper adds cost without removing coupling.; Shared backend/app/main.py/service callers may move during BE ownership repairs: rebind the ledger to the released owner, do not edit stale entrypoints or create competing writers.

**Exclusions:** Blind rewrite of all264 historical rows; New storage/repository framework; Changing persistence schema only for typing; Unrelated historical feature restoration

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### S26 — Settle and adopt typed storage boundary: Settings and current mode facts

**Scope:** audit-expansion. Findings: ST005. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** B02

**Owner/resource conditions:** Shared typing environment prerequisite: integration owner selects and records one exact mypy version and Python interpreter, provisions it once in the shared task environment during execution, and reuses the B12/B14/B26 convention. No blanket ignore-missing-imports, casts to Any, per-worker installation or repository-wide typing campaign.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `database/tempo_storage/controls/settings.py` (effective_opening_limit_rows, repertoire_limit_row, study_mode_setting); `database/tempo_storage/foreground_controls/settings.py` (locked_settings); `database/tempo_storage/http_composition/settings.py` (public_settings); `database/tempo_storage/redis_control/policy.py` (study_mode_setting); `backend/app/main.py`; `backend/app/repertoire_settings.py`; `backend/app/services/study_mode.py`; `backend/app/services/study_priority.py`; `backend/app/settings_commands.py`.

**Write scope:** `database/tempo_storage/controls/settings.py` [existing]; `database/tempo_storage/foreground_controls/settings.py` [existing]; `database/tempo_storage/http_composition/settings.py` [existing]; `database/tempo_storage/redis_control/policy.py` [existing]; `backend/app/main.py` [existing]; `backend/app/repertoire_settings.py` [existing]; `backend/app/services/study_mode.py` [existing]; `backend/app/services/study_priority.py` [existing]; `backend/app/settings_commands.py` [existing]; `backend/tests/test_settings_descriptor.py` [existing]; `backend/tests/test_repertoire_settings.py` [existing]; `backend/tests/test_study_calendar.py` [existing]; `backend/tests/typing/storage_contract_s26.py` [proposed scoped type-check fixture; create only for the applicable owner/public contract after row classification].

**Steps:**

1. Use the exact row ledger for this cluster. For every listed function, trace current supported callers and public owner reachability; classify as public physical leak, private owner implementation, retired/no supported caller, or already semantic/typed. Record concrete caller/public-export/source evidence, never a blanket no-change disposition.
2. Type public/effective/locked settings and Study mode values while preserving missing versus default/override semantics. Reuse existing descriptor or contract, strip only storage-specific representation at boundary, and keep unrelated historical retired settings untouched.
3. For confirmed public/application representation leaks, define the smallest pure typed value/operation contract in the existing owner surface, map SQL rows inside the adapter and adopt every actual listed consumer in the same change. No generic repository, new service or one-function-per-file layer.
4. If a cursor is legitimately private, prove its enclosing public owner returns typed semantic values and prohibit direct cross-owner access with T03. If unreachable, prove registration/import/retained recovery absence before deleting the exclusive helper and its exclusive tests. If already typed, name the exact type and passing current caller contract.
5. Add focused conformance assertions for present/absent/ambiguous/error values, exact IDs/ordering/nullability, immutable original JSON where required, and no new connect/commit/close. A semantic in-memory fake drives policy; an adapter spy rejects wrong predicates/projections. Use native proof only for actually changed SQL/mapping/lock/transaction semantics.
6. Update local owner guidance and T02 ownership/proof metadata for this boundary only. Work in one bounded symbol subset at a time, using a sequential path lease for shared adapters/callers.
7. Use the same scoped pinned checker convention as B12/B14/B26. In backend/tests/typing/storage_contract_s26.py, bind the actual production adapter and an independently implemented in-memory semantic fake to the real consumed interface, and check actual consumer result use. Include an intentional wrong result/argument implementation as a negative fixture and retain its expected checker errors. Imported Any or a cast cannot stand in for the production binding.

**Acceptance:**

- Every exact row assigned to this task has a source-linked current disposition; no unresolved public physical contract is closed by labeling it private.
- Required public result/argument conversions have real production consumer adoption; no caller .fetchone/.fetchall/.rowcount/physical column order remains at the migrated interface.
- Focused semantic fake/adapter contract and applicable native consumer proof pass; one final P14/P12 cohort supplies shared integration evidence rather than a full run per helper.
- The applicable listed caller contracts actually pass a scoped static type check with real production and independent fake bindings, and the deliberate incompatible implementation fails. Runtime fake tests alone do not satisfy the original type-checkable criterion. Private/already-typed dispositions name and check their enclosing public contract; no forced rewrite of private SQL helpers.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_settings_descriptor.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_repertoire_settings.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_study_calendar.py` — cwd `.`; focused; current.
- `python -m mypy --strict --follow-imports=silent --no-incremental backend/tests/typing/storage_contract_s26.py` — cwd `.`; static-typing; PROPOSED scoped acceptance command; no configured checker gate currently exists; integration owner pins/provisions shared checker first and includes any actual changed contract module targets needed to prevent an Any import escape.

**Integration:** At checkpoint2, include only native owner/concurrency/replay cases affected by this cluster; reuse accepted identical inputs. P14 exact selector release is required if the current runner cannot execute the necessary case.

**Material risks:** A typed dictionary alias or wrapper around a cursor is not a semantic boundary; conversely, forcing a new value class around every private/scalar helper adds cost without removing coupling.; Shared backend/app/main.py/service callers may move during BE ownership repairs: rebind the ledger to the released owner, do not edit stale entrypoints or create competing writers.

**Exclusions:** Blind rewrite of all264 historical rows; New storage/repository framework; Changing persistence schema only for typing; Unrelated historical feature restoration

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### S27 — Settle and adopt typed storage boundary: Background activity, refresh and readiness facts

**Scope:** audit-expansion. Findings: ST005. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** B02; B03

**Owner/resource conditions:** Shared typing environment prerequisite: integration owner selects and records one exact mypy version and Python interpreter, provisions it once in the shared task environment during execution, and reuses the B12/B14/B26 convention. No blanket ignore-missing-imports, casts to Any, per-worker installation or repository-wide typing campaign.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `database/tempo_storage/controls/activity/storage.py` (prepare_progress_read, prepare_control_read, prepare_control_update); `database/tempo_storage/commands/activity.py` (failed_task_for_update, record_manual_retry); `database/tempo_storage/lifecycle/background_metrics.py` (task_kind); `database/tempo_storage/lifecycle/refresh_requests.py` (daily_queue_projection); `database/tempo_storage/postgres_readiness.py` (read_health_facts); `backend/app/activity_commands.py`; `backend/app/operations/postgres_readiness.py`; `backend/app/services/background_activity.py`; `backend/app/services/background_metrics.py`; `backend/app/tasks.py`.

**Write scope:** `database/tempo_storage/controls/activity/storage.py` [existing]; `database/tempo_storage/commands/activity.py` [existing]; `database/tempo_storage/lifecycle/background_metrics.py` [existing]; `database/tempo_storage/lifecycle/refresh_requests.py` [existing]; `database/tempo_storage/postgres_readiness.py` [existing]; `backend/app/activity_commands.py` [existing]; `backend/app/operations/postgres_readiness.py` [existing]; `backend/app/services/background_activity.py` [existing]; `backend/app/services/background_metrics.py` [existing]; `backend/app/tasks.py` [existing]; `backend/tests/test_background_diagnostics.py` [existing]; `backend/tests/test_postgres_readiness.py` [existing]; `backend/tests/test_queue_refresh_diagnostics.py` [existing]; `backend/tests/typing/storage_contract_s27.py` [proposed scoped type-check fixture; create only for the applicable owner/public contract after row classification].

**Steps:**

1. Use the exact row ledger for this cluster. For every listed function, trace current supported callers and public owner reachability; classify as public physical leak, private owner implementation, retired/no supported caller, or already semantic/typed. Record concrete caller/public-export/source evidence, never a blanket no-change disposition.
2. Return explicit progress/control/retry/refresh-projection/readiness facts with actual unavailable/failed/pending states. Keep health a read-only observation, not full acceptance; metric/task-kind scalar results may remain scalar with precise types. No background control becomes a second scheduler.
3. For confirmed public/application representation leaks, define the smallest pure typed value/operation contract in the existing owner surface, map SQL rows inside the adapter and adopt every actual listed consumer in the same change. No generic repository, new service or one-function-per-file layer.
4. If a cursor is legitimately private, prove its enclosing public owner returns typed semantic values and prohibit direct cross-owner access with T03. If unreachable, prove registration/import/retained recovery absence before deleting the exclusive helper and its exclusive tests. If already typed, name the exact type and passing current caller contract.
5. Add focused conformance assertions for present/absent/ambiguous/error values, exact IDs/ordering/nullability, immutable original JSON where required, and no new connect/commit/close. A semantic in-memory fake drives policy; an adapter spy rejects wrong predicates/projections. Use native proof only for actually changed SQL/mapping/lock/transaction semantics.
6. Update local owner guidance and T02 ownership/proof metadata for this boundary only. Work in one bounded symbol subset at a time, using a sequential path lease for shared adapters/callers.
7. Use the same scoped pinned checker convention as B12/B14/B26. In backend/tests/typing/storage_contract_s27.py, bind the actual production adapter and an independently implemented in-memory semantic fake to the real consumed interface, and check actual consumer result use. Include an intentional wrong result/argument implementation as a negative fixture and retain its expected checker errors. Imported Any or a cast cannot stand in for the production binding.

**Acceptance:**

- Every exact row assigned to this task has a source-linked current disposition; no unresolved public physical contract is closed by labeling it private.
- Required public result/argument conversions have real production consumer adoption; no caller .fetchone/.fetchall/.rowcount/physical column order remains at the migrated interface.
- Focused semantic fake/adapter contract and applicable native consumer proof pass; one final P14/P12 cohort supplies shared integration evidence rather than a full run per helper.
- The applicable listed caller contracts actually pass a scoped static type check with real production and independent fake bindings, and the deliberate incompatible implementation fails. Runtime fake tests alone do not satisfy the original type-checkable criterion. Private/already-typed dispositions name and check their enclosing public contract; no forced rewrite of private SQL helpers.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_background_diagnostics.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_postgres_readiness.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_queue_refresh_diagnostics.py` — cwd `.`; focused; current.
- `python -m mypy --strict --follow-imports=silent --no-incremental backend/tests/typing/storage_contract_s27.py` — cwd `.`; static-typing; PROPOSED scoped acceptance command; no configured checker gate currently exists; integration owner pins/provisions shared checker first and includes any actual changed contract module targets needed to prevent an Any import escape.

**Integration:** At checkpoint2, include only native owner/concurrency/replay cases affected by this cluster; reuse accepted identical inputs. P14 exact selector release is required if the current runner cannot execute the necessary case.

**Material risks:** A typed dictionary alias or wrapper around a cursor is not a semantic boundary; conversely, forcing a new value class around every private/scalar helper adds cost without removing coupling.; Shared backend/app/main.py/service callers may move during BE ownership repairs: rebind the ledger to the released owner, do not edit stale entrypoints or create competing writers.

**Exclusions:** Blind rewrite of all264 historical rows; New storage/repository framework; Changing persistence schema only for typing; Unrelated historical feature restoration

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### S28 — Settle and adopt typed storage boundary: Tactics catalog, capture and attempt facts

**Scope:** audit-expansion. Findings: ST005. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** B22

**Owner/resource conditions:** Preserve closed ST009 typed key boundary.; Shared typing environment prerequisite: integration owner selects and records one exact mypy version and Python interpreter, provisions it once in the shared task environment during execution, and reuses the B12/B14/B26 convention. No blanket ignore-missing-imports, casts to Any, per-worker installation or repository-wide typing campaign.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `database/tempo_storage/tactics/attempts.py` (attempt_receipt, queued_attempt_card, attempt_card_schedule); `database/tempo_storage/tactics/captures.py` (capture_receipt); `database/tempo_storage/tactics/catalog.py` (active_pack_rows, progress_rows, due_tactic_rows, introduced_puzzle_rows, existing_queue_entry); `database/tempo_storage/study/captured_tactic.py` (capture_card); `backend/app/product_composition/tactic_capture.py`; `backend/app/services/tactic_capture.py`; `backend/app/services/tactical_catalog.py`; `backend/app/tactic_commands.py`.

**Write scope:** `database/tempo_storage/tactics/attempts.py` [existing]; `database/tempo_storage/tactics/captures.py` [existing]; `database/tempo_storage/tactics/catalog.py` [existing]; `database/tempo_storage/study/captured_tactic.py` [existing]; `backend/app/product_composition/tactic_capture.py` [existing]; `backend/app/services/tactic_capture.py` [existing]; `backend/app/services/tactical_catalog.py` [existing]; `backend/app/tactic_commands.py` [existing]; `backend/tests/test_tactic_capture_boundary.py` [existing]; `backend/tests/test_tactical_catalog.py` [existing]; `backend/tests/test_tactic_capture.py` [existing]; `backend/tests/typing/storage_contract_s28.py` [proposed scoped type-check fixture; create only for the applicable owner/public contract after row classification].

**Steps:**

1. Use the exact row ledger for this cluster. For every listed function, trace current supported callers and public owner reachability; classify as public physical leak, private owner implementation, retired/no supported caller, or already semantic/typed. Record concrete caller/public-export/source evidence, never a blanket no-change disposition.
2. Adapt tactic/capture/progress/active-pack/queued-attempt facts and receipts to semantic values after BE010 moves scheduling effects. Preserve catalog user progress, capture original operation/request, one activation/introduced card and reversed pack identity compatibility; avoid raw row/serialized schedule leakage to producer.
3. For confirmed public/application representation leaks, define the smallest pure typed value/operation contract in the existing owner surface, map SQL rows inside the adapter and adopt every actual listed consumer in the same change. No generic repository, new service or one-function-per-file layer.
4. If a cursor is legitimately private, prove its enclosing public owner returns typed semantic values and prohibit direct cross-owner access with T03. If unreachable, prove registration/import/retained recovery absence before deleting the exclusive helper and its exclusive tests. If already typed, name the exact type and passing current caller contract.
5. Add focused conformance assertions for present/absent/ambiguous/error values, exact IDs/ordering/nullability, immutable original JSON where required, and no new connect/commit/close. A semantic in-memory fake drives policy; an adapter spy rejects wrong predicates/projections. Use native proof only for actually changed SQL/mapping/lock/transaction semantics.
6. Update local owner guidance and T02 ownership/proof metadata for this boundary only. Work in one bounded symbol subset at a time, using a sequential path lease for shared adapters/callers.
7. Use the same scoped pinned checker convention as B12/B14/B26. In backend/tests/typing/storage_contract_s28.py, bind the actual production adapter and an independently implemented in-memory semantic fake to the real consumed interface, and check actual consumer result use. Include an intentional wrong result/argument implementation as a negative fixture and retain its expected checker errors. Imported Any or a cast cannot stand in for the production binding.

**Acceptance:**

- Every exact row assigned to this task has a source-linked current disposition; no unresolved public physical contract is closed by labeling it private.
- Required public result/argument conversions have real production consumer adoption; no caller .fetchone/.fetchall/.rowcount/physical column order remains at the migrated interface.
- Focused semantic fake/adapter contract and applicable native consumer proof pass; one final P14/P12 cohort supplies shared integration evidence rather than a full run per helper.
- The applicable listed caller contracts actually pass a scoped static type check with real production and independent fake bindings, and the deliberate incompatible implementation fails. Runtime fake tests alone do not satisfy the original type-checkable criterion. Private/already-typed dispositions name and check their enclosing public contract; no forced rewrite of private SQL helpers.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_tactic_capture_boundary.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_tactical_catalog.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_tactic_capture.py` — cwd `.`; focused; current.
- `python -m mypy --strict --follow-imports=silent --no-incremental backend/tests/typing/storage_contract_s28.py` — cwd `.`; static-typing; PROPOSED scoped acceptance command; no configured checker gate currently exists; integration owner pins/provisions shared checker first and includes any actual changed contract module targets needed to prevent an Any import escape.

**Integration:** At checkpoint2, include only native owner/concurrency/replay cases affected by this cluster; reuse accepted identical inputs. P14 exact selector release is required if the current runner cannot execute the necessary case.

**Material risks:** A typed dictionary alias or wrapper around a cursor is not a semantic boundary; conversely, forcing a new value class around every private/scalar helper adds cost without removing coupling.; Shared backend/app/main.py/service callers may move during BE ownership repairs: rebind the ledger to the released owner, do not edit stale entrypoints or create competing writers.

**Exclusions:** Blind rewrite of all264 historical rows; New storage/repository framework; Changing persistence schema only for typing; Unrelated historical feature restoration

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### S29 — Settle and adopt typed storage boundary: Retained exercise attempt facts after route restoration

**Scope:** audit-expansion. Findings: ST005. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** B31; C23

**Owner/resource conditions:** Shared typing environment prerequisite: integration owner selects and records one exact mypy version and Python interpreter, provisions it once in the shared task environment during execution, and reuses the B12/B14/B26 convention. No blanket ignore-missing-imports, casts to Any, per-worker installation or repository-wide typing campaign.

**Shared-file sequence:** study_attempts/storage.py after B31 read-helper shapes; test_studies.py remains C22/C23-owned.

**Read first:** `database/tempo_storage/study_attempts/storage.py` (active_review_card, queued_review_entry, light_interval_setting, exercise, locked_review_card, queue_day, locked_review_entry, answered_queue_entry, attempt, exercise_owner, locked_exercise, exercise_position, exercise_revision, pending_attempt, locked_attempt); `backend/app/services/study_attempts.py`; `backend/app/study_attempt_commands.py`.

**Write scope:** `database/tempo_storage/study_attempts/storage.py` [existing]; `backend/app/services/study_attempts.py` [existing]; `backend/app/study_attempt_commands.py` [existing]; `backend/tests/test_review_service_storage_boundary.py` [existing]; `backend/tests/test_study_portable_storage_boundary.py` [existing]; `backend/tests/typing/storage_contract_s29.py` [proposed scoped type-check fixture; create only for the applicable owner/public contract after row classification].

**Steps:**

1. Use the exact row ledger for this cluster. For every listed function, trace current supported callers and public owner reachability; classify as public physical leak, private owner implementation, retired/no supported caller, or already semantic/typed. Record concrete caller/public-export/source evidence, never a blanket no-change disposition.
2. Type exercise/owner/position/revision/queue/attempt/answer facts and lock outcomes consumed by current Study attempt commands. Preserve original attempt+revision, feedback visibility only after answer, human count, stale/duplicate request behavior and retained frozen content. Do not restore retired exercise authoring/bundle producers.
3. For confirmed public/application representation leaks, define the smallest pure typed value/operation contract in the existing owner surface, map SQL rows inside the adapter and adopt every actual listed consumer in the same change. No generic repository, new service or one-function-per-file layer.
4. If a cursor is legitimately private, prove its enclosing public owner returns typed semantic values and prohibit direct cross-owner access with T03. If unreachable, prove registration/import/retained recovery absence before deleting the exclusive helper and its exclusive tests. If already typed, name the exact type and passing current caller contract.
5. Add focused conformance assertions for present/absent/ambiguous/error values, exact IDs/ordering/nullability, immutable original JSON where required, and no new connect/commit/close. A semantic in-memory fake drives policy; an adapter spy rejects wrong predicates/projections. Use native proof only for actually changed SQL/mapping/lock/transaction semantics.
6. Update local owner guidance and T02 ownership/proof metadata for this boundary only. Work in one bounded symbol subset at a time, using a sequential path lease for shared adapters/callers.
7. Use the same scoped pinned checker convention as B12/B14/B26. In backend/tests/typing/storage_contract_s29.py, bind the actual production adapter and an independently implemented in-memory semantic fake to the real consumed interface, and check actual consumer result use. Include an intentional wrong result/argument implementation as a negative fixture and retain its expected checker errors. Imported Any or a cast cannot stand in for the production binding.

**Acceptance:**

- Every exact row assigned to this task has a source-linked current disposition; no unresolved public physical contract is closed by labeling it private.
- Required public result/argument conversions have real production consumer adoption; no caller .fetchone/.fetchall/.rowcount/physical column order remains at the migrated interface.
- Focused semantic fake/adapter contract and applicable native consumer proof pass; one final P14/P12 cohort supplies shared integration evidence rather than a full run per helper.
- The applicable listed caller contracts actually pass a scoped static type check with real production and independent fake bindings, and the deliberate incompatible implementation fails. Runtime fake tests alone do not satisfy the original type-checkable criterion. Private/already-typed dispositions name and check their enclosing public contract; no forced rewrite of private SQL helpers.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_review_service_storage_boundary.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_study_portable_storage_boundary.py` — cwd `.`; focused; current.
- `python -m mypy --strict --follow-imports=silent --no-incremental backend/tests/typing/storage_contract_s29.py` — cwd `.`; static-typing; PROPOSED scoped acceptance command; no configured checker gate currently exists; integration owner pins/provisions shared checker first and includes any actual changed contract module targets needed to prevent an Any import escape.

**Integration:** At checkpoint2, include only native owner/concurrency/replay cases affected by this cluster; reuse accepted identical inputs. P14 exact selector release is required if the current runner cannot execute the necessary case.

**Material risks:** A typed dictionary alias or wrapper around a cursor is not a semantic boundary; conversely, forcing a new value class around every private/scalar helper adds cost without removing coupling.; Shared backend/app/main.py/service callers may move during BE ownership repairs: rebind the ledger to the released owner, do not edit stale entrypoints or create competing writers.

**Exclusions:** Blind rewrite of all264 historical rows; New storage/repository framework; Changing persistence schema only for typing; Unrelated historical feature restoration

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### S30 — Settle and adopt typed storage boundary: Retained HTTP read projections and command lock facts

**Scope:** audit-expansion. Findings: ST005. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** B18; B19; B20

**Owner/resource conditions:** Shared typing environment prerequisite: integration owner selects and records one exact mypy version and Python interpreter, provisions it once in the shared task environment during execution, and reuses the B12/B14/B26 convention. No blanket ignore-missing-imports, casts to Any, per-worker installation or repository-wide typing campaign.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `database/tempo_storage/http_composition/repertoires.py` (repertoire_rows, line_rows, position_annotation_rows, annotation_rows, teaching_rows, export_line_rows, export_annotation_rows); `database/tempo_storage/http_composition/practice.py` (tactic_progress_rows); `database/tempo_storage/http_composition/system.py` (frozen_opening_identity); `database/tempo_storage/opening_evidence/storage.py` (attempt_status); `database/tempo_storage/repertoire_lines.py` (repertoire_presence); `database/tempo_storage/commands/teaching.py` (active_card_for_update); `database/tempo_storage/commands/annotations.py` (repertoire_for_update); `backend/app/annotation_commands.py`; `backend/app/main.py`; `backend/app/teaching_commands.py`.

**Write scope:** `database/tempo_storage/http_composition/repertoires.py` [existing]; `database/tempo_storage/http_composition/practice.py` [existing]; `database/tempo_storage/http_composition/system.py` [existing]; `database/tempo_storage/opening_evidence/storage.py` [existing]; `database/tempo_storage/repertoire_lines.py` [existing]; `database/tempo_storage/commands/teaching.py` [existing]; `database/tempo_storage/commands/annotations.py` [existing]; `backend/app/annotation_commands.py` [existing]; `backend/app/main.py` [existing]; `backend/app/teaching_commands.py` [existing]; `backend/tests/test_http_command_registration_boundary.py` [existing]; `backend/tests/test_retained_mutations_boundary.py` [existing]; `backend/tests/test_queue_serving_projection.py` [existing]; `backend/tests/typing/storage_contract_s30.py` [proposed scoped type-check fixture; create only for the applicable owner/public contract after row classification].

**Steps:**

1. Use the exact row ledger for this cluster. For every listed function, trace current supported callers and public owner reachability; classify as public physical leak, private owner implementation, retired/no supported caller, or already semantic/typed. Record concrete caller/public-export/source evidence, never a blanket no-change disposition.
2. Type retained repertoire/line/annotation/teaching/export/tactic progress/frozen identity/attempt status projections and lock facts consumed by actual routes. Reuse existing response models only when semantic and immutable; database-only field names or cursor order stay private. Preserve read-only transaction, exact revision and absence/404 distinctions.
3. For confirmed public/application representation leaks, define the smallest pure typed value/operation contract in the existing owner surface, map SQL rows inside the adapter and adopt every actual listed consumer in the same change. No generic repository, new service or one-function-per-file layer.
4. If a cursor is legitimately private, prove its enclosing public owner returns typed semantic values and prohibit direct cross-owner access with T03. If unreachable, prove registration/import/retained recovery absence before deleting the exclusive helper and its exclusive tests. If already typed, name the exact type and passing current caller contract.
5. Add focused conformance assertions for present/absent/ambiguous/error values, exact IDs/ordering/nullability, immutable original JSON where required, and no new connect/commit/close. A semantic in-memory fake drives policy; an adapter spy rejects wrong predicates/projections. Use native proof only for actually changed SQL/mapping/lock/transaction semantics.
6. Update local owner guidance and T02 ownership/proof metadata for this boundary only. Work in one bounded symbol subset at a time, using a sequential path lease for shared adapters/callers.
7. Use the same scoped pinned checker convention as B12/B14/B26. In backend/tests/typing/storage_contract_s30.py, bind the actual production adapter and an independently implemented in-memory semantic fake to the real consumed interface, and check actual consumer result use. Include an intentional wrong result/argument implementation as a negative fixture and retain its expected checker errors. Imported Any or a cast cannot stand in for the production binding.

**Acceptance:**

- Every exact row assigned to this task has a source-linked current disposition; no unresolved public physical contract is closed by labeling it private.
- Required public result/argument conversions have real production consumer adoption; no caller .fetchone/.fetchall/.rowcount/physical column order remains at the migrated interface.
- Focused semantic fake/adapter contract and applicable native consumer proof pass; one final P14/P12 cohort supplies shared integration evidence rather than a full run per helper.
- The applicable listed caller contracts actually pass a scoped static type check with real production and independent fake bindings, and the deliberate incompatible implementation fails. Runtime fake tests alone do not satisfy the original type-checkable criterion. Private/already-typed dispositions name and check their enclosing public contract; no forced rewrite of private SQL helpers.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_http_command_registration_boundary.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_retained_mutations_boundary.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_queue_serving_projection.py` — cwd `.`; focused; current.
- `python -m mypy --strict --follow-imports=silent --no-incremental backend/tests/typing/storage_contract_s30.py` — cwd `.`; static-typing; PROPOSED scoped acceptance command; no configured checker gate currently exists; integration owner pins/provisions shared checker first and includes any actual changed contract module targets needed to prevent an Any import escape.

**Integration:** At checkpoint2, include only native owner/concurrency/replay cases affected by this cluster; reuse accepted identical inputs. P14 exact selector release is required if the current runner cannot execute the necessary case.

**Material risks:** A typed dictionary alias or wrapper around a cursor is not a semantic boundary; conversely, forcing a new value class around every private/scalar helper adds cost without removing coupling.; Shared backend/app/main.py/service callers may move during BE ownership repairs: rebind the ledger to the released owner, do not edit stale entrypoints or create competing writers.

**Exclusions:** Blind rewrite of all264 historical rows; New storage/repository framework; Changing persistence schema only for typing; Unrelated historical feature restoration

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### S31 — Settle and adopt typed storage boundary: Read-only Game Review storage values

**Scope:** audit-expansion. Findings: ST005. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** Independent bounded source task; reserve listed paths.

**Owner/resource conditions:** Accepted E03 three-relation reader contract is the baseline; requalify only changed reader inputs.; Shared typing environment prerequisite: integration owner selects and records one exact mypy version and Python interpreter, provisions it once in the shared task environment during execution, and reuses the B12/B14/B26 convention. No blanket ignore-missing-imports, casts to Any, per-worker installation or repository-wide typing campaign.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `database/tempo_storage/game_review.py` (recent_games, game, authored_lines); `backend/app/games/review.py`.

**Write scope:** `database/tempo_storage/game_review.py` [existing]; `backend/app/games/review.py` [existing]; `backend/tests/test_packaged_game_review_reader_boundary.py` [existing]; `backend/tests/typing/storage_contract_s31.py` [proposed scoped type-check fixture; create only for the applicable owner/public contract after row classification].

**Steps:**

1. Use the exact row ledger for this cluster. For every listed function, trace current supported callers and public owner reachability; classify as public physical leak, private owner implementation, retired/no supported caller, or already semantic/typed. Record concrete caller/public-export/source evidence, never a blanket no-change disposition.
2. Return explicit saved-game summary/game PGN/authored-line semantic values for recent_games/game/authored_lines. Keep actual list ordering/limit100, provider/time/color/URL nullability and exact authored alternatives. Pasted PGN stays unsaved; the reader obtains no Study write capability.
3. For confirmed public/application representation leaks, define the smallest pure typed value/operation contract in the existing owner surface, map SQL rows inside the adapter and adopt every actual listed consumer in the same change. No generic repository, new service or one-function-per-file layer.
4. If a cursor is legitimately private, prove its enclosing public owner returns typed semantic values and prohibit direct cross-owner access with T03. If unreachable, prove registration/import/retained recovery absence before deleting the exclusive helper and its exclusive tests. If already typed, name the exact type and passing current caller contract.
5. Add focused conformance assertions for present/absent/ambiguous/error values, exact IDs/ordering/nullability, immutable original JSON where required, and no new connect/commit/close. A semantic in-memory fake drives policy; an adapter spy rejects wrong predicates/projections. Use native proof only for actually changed SQL/mapping/lock/transaction semantics.
6. Update local owner guidance and T02 ownership/proof metadata for this boundary only. Work in one bounded symbol subset at a time, using a sequential path lease for shared adapters/callers.
7. Use the same scoped pinned checker convention as B12/B14/B26. In backend/tests/typing/storage_contract_s31.py, bind the actual production adapter and an independently implemented in-memory semantic fake to the real consumed interface, and check actual consumer result use. Include an intentional wrong result/argument implementation as a negative fixture and retain its expected checker errors. Imported Any or a cast cannot stand in for the production binding.

**Acceptance:**

- Every exact row assigned to this task has a source-linked current disposition; no unresolved public physical contract is closed by labeling it private.
- Required public result/argument conversions have real production consumer adoption; no caller .fetchone/.fetchall/.rowcount/physical column order remains at the migrated interface.
- Focused semantic fake/adapter contract and applicable native consumer proof pass; one final P14/P12 cohort supplies shared integration evidence rather than a full run per helper.
- The applicable listed caller contracts actually pass a scoped static type check with real production and independent fake bindings, and the deliberate incompatible implementation fails. Runtime fake tests alone do not satisfy the original type-checkable criterion. Private/already-typed dispositions name and check their enclosing public contract; no forced rewrite of private SQL helpers.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_packaged_game_review_reader_boundary.py` — cwd `.`; focused; current.
- `python -m mypy --strict --follow-imports=silent --no-incremental backend/tests/typing/storage_contract_s31.py` — cwd `.`; static-typing; PROPOSED scoped acceptance command; no configured checker gate currently exists; integration owner pins/provisions shared checker first and includes any actual changed contract module targets needed to prevent an Any import escape.

**Integration:** At checkpoint2, include only native owner/concurrency/replay cases affected by this cluster; reuse accepted identical inputs. P14 exact selector release is required if the current runner cannot execute the necessary case.

**Material risks:** A typed dictionary alias or wrapper around a cursor is not a semantic boundary; conversely, forcing a new value class around every private/scalar helper adds cost without removing coupling.; Shared backend/app/main.py/service callers may move during BE ownership repairs: rebind the ledger to the released owner, do not edit stale entrypoints or create competing writers.

**Exclusions:** Blind rewrite of all264 historical rows; New storage/repository framework; Changing persistence schema only for typing; Unrelated historical feature restoration

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### S34 — Settle and adopt typed storage boundary: Bounded published repertoire source facts

**Scope:** audit-expansion. Findings: ST005. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** S01

**Owner/resource conditions:** Shared typing environment prerequisite: integration owner selects and records one exact mypy version and Python interpreter, provisions it once in the shared task environment during execution, and reuses the B12/B14/B26 convention. No blanket ignore-missing-imports, casts to Any, per-worker installation or repository-wide typing campaign.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `database/tempo_storage/authored_repertoires/product_snapshot.py` (read_repertoire); `backend/app/repertoire/position_study_source.py`; `backend/app/repertoire/snapshot.py`.

**Write scope:** `database/tempo_storage/authored_repertoires/product_snapshot.py` [existing]; `backend/app/repertoire/position_study_source.py` [existing]; `backend/app/repertoire/snapshot.py` [existing]; `backend/tests/test_product_position_index.py` [existing]; `backend/tests/test_position_schedule_occurrences.py` [existing]; `backend/tests/typing/storage_contract_s34.py` [proposed scoped type-check fixture; create only for the applicable owner/public contract after row classification].

**Steps:**

1. Use the exact row ledger for this cluster. For every listed function, trace current supported callers and public owner reachability; classify as public physical leak, private owner implementation, retired/no supported caller, or already semantic/typed. Record concrete caller/public-export/source evidence, never a blanket no-change disposition.
2. Replace the manually traced cross-owner dictionary snapshot with typed bounded published repertoire/source/line/card/membership/graph facts or a documented equivalent typed immutable public value. Keep one MVCC statement,10000 row/65536 byte bounds, ordered streamed graph rows, complete-versus-held sentinel and original provenance. Do not materialize unbounded graphs or reinterpret bounded prefixes as complete.
3. For confirmed public/application representation leaks, define the smallest pure typed value/operation contract in the existing owner surface, map SQL rows inside the adapter and adopt every actual listed consumer in the same change. No generic repository, new service or one-function-per-file layer.
4. If a cursor is legitimately private, prove its enclosing public owner returns typed semantic values and prohibit direct cross-owner access with T03. If unreachable, prove registration/import/retained recovery absence before deleting the exclusive helper and its exclusive tests. If already typed, name the exact type and passing current caller contract.
5. Add focused conformance assertions for present/absent/ambiguous/error values, exact IDs/ordering/nullability, immutable original JSON where required, and no new connect/commit/close. A semantic in-memory fake drives policy; an adapter spy rejects wrong predicates/projections. Use native proof only for actually changed SQL/mapping/lock/transaction semantics.
6. Update local owner guidance and T02 ownership/proof metadata for this boundary only. Work in one bounded symbol subset at a time, using a sequential path lease for shared adapters/callers.
7. Use the same scoped pinned checker convention as B12/B14/B26. In backend/tests/typing/storage_contract_s34.py, bind the actual production adapter and an independently implemented in-memory semantic fake to the real consumed interface, and check actual consumer result use. Include an intentional wrong result/argument implementation as a negative fixture and retain its expected checker errors. Imported Any or a cast cannot stand in for the production binding.

**Acceptance:**

- Every exact row assigned to this task has a source-linked current disposition; no unresolved public physical contract is closed by labeling it private.
- Required public result/argument conversions have real production consumer adoption; no caller .fetchone/.fetchall/.rowcount/physical column order remains at the migrated interface.
- Focused semantic fake/adapter contract and applicable native consumer proof pass; one final P14/P12 cohort supplies shared integration evidence rather than a full run per helper.
- The applicable listed caller contracts actually pass a scoped static type check with real production and independent fake bindings, and the deliberate incompatible implementation fails. Runtime fake tests alone do not satisfy the original type-checkable criterion. Private/already-typed dispositions name and check their enclosing public contract; no forced rewrite of private SQL helpers.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_product_position_index.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_position_schedule_occurrences.py` — cwd `.`; focused; current.
- `python -m mypy --strict --follow-imports=silent --no-incremental backend/tests/typing/storage_contract_s34.py` — cwd `.`; static-typing; PROPOSED scoped acceptance command; no configured checker gate currently exists; integration owner pins/provisions shared checker first and includes any actual changed contract module targets needed to prevent an Any import escape.

**Integration:** At checkpoint2, include only native owner/concurrency/replay cases affected by this cluster; reuse accepted identical inputs. P14 exact selector release is required if the current runner cannot execute the necessary case.

**Material risks:** A typed dictionary alias or wrapper around a cursor is not a semantic boundary; conversely, forcing a new value class around every private/scalar helper adds cost without removing coupling.; Shared backend/app/main.py/service callers may move during BE ownership repairs: rebind the ledger to the released owner, do not edit stale entrypoints or create competing writers.

**Exclusions:** Blind rewrite of all264 historical rows; New storage/repository framework; Changing persistence schema only for typing; Unrelated historical feature restoration

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### P09 — Reconcile current proof contract: Background diagnostic and admission proofs

**Scope:** audit-expansion-proof. Findings: ST012, ST013. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** B21

**Owner/resource conditions:** Apply the shared path lease and exact candidate rules.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `database/tests/check_postgres_background_diagnostics.py`; `database/tests/benchmark-background-diagnostics.py`; `database/tests/check_postgres_background_admission.py`; `database/tests/test-postgres-docker.mjs`; `database/tests/postgres-test-plan.mjs`; `components.json`; `SPEC.md`.

**Write scope:** `database/tests/check_postgres_background_diagnostics.py` [existing]; `database/tests/benchmark-background-diagnostics.py` [existing]; `database/tests/check_postgres_background_admission.py` [existing]; `backend/tests/test_background_diagnostics.py` [existing]; `backend/tests/test_postgres_background_timeouts.py` [existing]; `tests/REGRESSIONS.md` [existing].

**Steps:**

1. Take only the audit row indexes assigned to this task. Resolve each old reference/query against current source and actual suite/runner/function call graph. Distinguish already repaired, current selected, supported leaf awaiting registration and exclusively historical/retired.
2. Retain bounded worker/admission/metrics behavior through current durable_tasks/background_diagnostics/redis admission owners. Separate removed game_analysis/repertoire_coverage/threat producer fixture branches: rebind the generic foreground isolation claim to current accepted Study work and retire only producer-exclusive assertions after current registry/caller proof.
3. Split a mixed file by exact named case/helper families. Retained assertions get a current owner rebind and native %s semantics; historical-only cases get a source-linked support decision and current inventory removal. Remove no safety assertion merely because its old helper vanished.
4. If a row is already fixed, prove the old reference/query is absent or replaced and link the actual current case/command/result; do not count the historical finding again or fabricate a new rewrite.
5. Validate project import resolution and exact case collection before acquiring the heavy slot. Every retained native proof must have a reachable supported current runner/declared input set; proposed fixed selectors require parser/selection/refusal tests and exact operator command release.
6. Exercise only the changed native owner/consumer path in P14. Preserve real environment ownership, writer/admission isolation, transaction bounds, exact case accounting and cleanup.

**Acceptance:**

- Each assigned historical proof row has a positive, source-linked current disposition and owning executable case or positively evidenced retirement.
- No current selected proof imports a removed project implementation or uses ? with PostgresConnection/psycopg. Genuine SQL question-mark operators/literals are distinguished from parameter markers.
- Current native assertions execute through their advertised runner; historical cases cannot masquerade as current passes.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_background_diagnostics.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_postgres_background_timeouts.py` — cwd `.`; focused; current.

**Integration:** P14 checkpoint2 runs only the applicable selected native cohort. A static scan or collection result is not native execution.

**Material risks:** Old tests can mix useful retained invariants with removed products; blanket deletion or blanket resurrection both misstate support.; Current runner list names stages, not every nested executed assertion: bind the actual nested case inventory and raw native report.

**Exclusions:** Restoring retired optional products; Broad historical schema expansion; New alternate SQL translator; Claiming all native tests passed from import/compile checks

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### P10 — Reconcile current proof contract: Current opening checkpoint, original evidence and immutability proofs

**Scope:** audit-expansion-proof. Findings: ST012, ST013. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** P05; B08

**Owner/resource conditions:** Apply the shared path lease and exact candidate rules.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `database/tests/check_postgres_opening_evidence.py`; `database/tests/position_study/test_position_first_responses.py`; `database/tests/position_study/test_position_first_response_immutability.py`; `database/tests/position_study/test_original_position_evidence_postgres.py`; `database/tests/test-postgres-docker.mjs`; `database/tests/postgres-test-plan.mjs`; `components.json`; `SPEC.md`.

**Write scope:** `database/tests/check_postgres_opening_evidence.py` [existing]; `database/tests/position_study/test_position_first_responses.py` [existing]; `database/tests/position_study/test_position_first_response_immutability.py` [existing]; `database/tests/position_study/test_original_position_evidence_postgres.py` [existing]; `backend/tests/test_position_first_response_codec.py` [existing]; `backend/tests/test_opening_checkpoint_preparation.py` [existing]; `backend/tests/test_position_review_reconciliation.py` [existing]; `tests/REGRESSIONS.md` [existing].

**Steps:**

1. Take only the audit row indexes assigned to this task. Resolve each old reference/query against current source and actual suite/runner/function call graph. Distinguish already repaired, current selected, supported leaf awaiting registration and exclusively historical/retired.
2. Rebind retained checkpoint/review/first-response functions to app.study.position_checkpoint and the pure first_response_codec; current original issued plan/response/completion authority remains protected. Remove only advanced prefix diagnostic/recombination/provider-only fixtures after tracing their callers. Replace old SQL parameters and instrumentation in the retained cases; preserve accepted evidence bytes, invalid/ambiguous holds and no duplicate scheduling.
3. Split a mixed file by exact named case/helper families. Retained assertions get a current owner rebind and native %s semantics; historical-only cases get a source-linked support decision and current inventory removal. Remove no safety assertion merely because its old helper vanished.
4. If a row is already fixed, prove the old reference/query is absent or replaced and link the actual current case/command/result; do not count the historical finding again or fabricate a new rewrite.
5. Validate project import resolution and exact case collection before acquiring the heavy slot. Every retained native proof must have a reachable supported current runner/declared input set; proposed fixed selectors require parser/selection/refusal tests and exact operator command release.
6. Exercise only the changed native owner/consumer path in P14. Preserve real environment ownership, writer/admission isolation, transaction bounds, exact case accounting and cleanup.

**Acceptance:**

- Each assigned historical proof row has a positive, source-linked current disposition and owning executable case or positively evidenced retirement.
- No current selected proof imports a removed project implementation or uses ? with PostgresConnection/psycopg. Genuine SQL question-mark operators/literals are distinguished from parameter markers.
- Current native assertions execute through their advertised runner; historical cases cannot masquerade as current passes.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_position_first_response_codec.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_opening_checkpoint_preparation.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_position_review_reconciliation.py` — cwd `.`; focused; current.

**Integration:** P14 checkpoint2 runs only the applicable selected native cohort. A static scan or collection result is not native execution.

**Material risks:** Old tests can mix useful retained invariants with removed products; blanket deletion or blanket resurrection both misstate support.; Current runner list names stages, not every nested executed assertion: bind the actual nested case inventory and raw native report.

**Exclusions:** Restoring retired optional products; Broad historical schema expansion; New alternate SQL translator; Claiming all native tests passed from import/compile checks

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### P11 — Reconcile current proof contract: Deletion and repertoire allowance native proofs

**Scope:** audit-expansion-proof. Findings: ST012, ST013. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** P03; B23

**Owner/resource conditions:** Apply the shared path lease and exact candidate rules.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `database/tests/check_postgres_deletion.py`; `database/tests/check_postgres_repertoire_limits.py`; `database/tests/test-postgres-docker.mjs`; `database/tests/postgres-test-plan.mjs`; `components.json`; `SPEC.md`.

**Write scope:** `database/tests/check_postgres_deletion.py` [existing]; `database/tests/check_postgres_repertoire_limits.py` [existing]; `backend/tests/test_card_deletion_storage_boundary.py` [existing]; `backend/tests/test_repertoire_settings.py` [existing]; `tests/REGRESSIONS.md` [existing].

**Steps:**

1. Take only the audit row indexes assigned to this task. Resolve each old reference/query against current source and actual suite/runner/function call graph. Distinguish already repaired, current selected, supported leaf awaiting registration and exclusively historical/retired.
2. Adopt current deletion/Study purge owners after BE011 and P03. Rebind missing tactic-admission counts/current queue preparation to actual owners; preserve shared memberships, exact cancellation, current daily limit/no rollover, accepted reviews and active attempts. Retire only removed producer/bundle assertions with positive registration evidence.
3. Split a mixed file by exact named case/helper families. Retained assertions get a current owner rebind and native %s semantics; historical-only cases get a source-linked support decision and current inventory removal. Remove no safety assertion merely because its old helper vanished.
4. If a row is already fixed, prove the old reference/query is absent or replaced and link the actual current case/command/result; do not count the historical finding again or fabricate a new rewrite.
5. Validate project import resolution and exact case collection before acquiring the heavy slot. Every retained native proof must have a reachable supported current runner/declared input set; proposed fixed selectors require parser/selection/refusal tests and exact operator command release.
6. Exercise only the changed native owner/consumer path in P14. Preserve real environment ownership, writer/admission isolation, transaction bounds, exact case accounting and cleanup.

**Acceptance:**

- Each assigned historical proof row has a positive, source-linked current disposition and owning executable case or positively evidenced retirement.
- No current selected proof imports a removed project implementation or uses ? with PostgresConnection/psycopg. Genuine SQL question-mark operators/literals are distinguished from parameter markers.
- Current native assertions execute through their advertised runner; historical cases cannot masquerade as current passes.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_card_deletion_storage_boundary.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_repertoire_settings.py` — cwd `.`; focused; current.

**Integration:** P14 checkpoint2 runs only the applicable selected native cohort. A static scan or collection result is not native execution.

**Material risks:** Old tests can mix useful retained invariants with removed products; blanket deletion or blanket resurrection both misstate support.; Current runner list names stages, not every nested executed assertion: bind the actual nested case inventory and raw native report.

**Exclusions:** Restoring retired optional products; Broad historical schema expansion; New alternate SQL translator; Claiming all native tests passed from import/compile checks

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### P18 — Reconcile current proof contract: Historical position seed/operator/source-fixture support decisions

**Scope:** audit-expansion-proof. Findings: ST012, ST013. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** B00

**Owner/resource conditions:** Apply the shared path lease and exact candidate rules.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `database/tests/position_study/test_owner_mode_operator.py`; `database/tests/position_study/test_seed_idempotence.py`; `database/tests/position_study/repeated_position_acceptance.py`; `database/tests/position_study/test_content_origin_postgres.py`; `database/tests/position_study/test_donor_picker.py`; `database/tests/position_study/italian_acceptance.py`; `database/tests/position_study/test_inventory_readonly.py`; `database/tests/position_study/acceptance.py`; `database/tests/test-postgres-docker.mjs`; `database/tests/postgres-test-plan.mjs`; `components.json`; `SPEC.md`.

**Write scope:** `database/tests/position_study/test_owner_mode_operator.py` [existing]; `database/tests/position_study/test_seed_idempotence.py` [existing]; `database/tests/position_study/repeated_position_acceptance.py` [existing]; `database/tests/position_study/test_content_origin_postgres.py` [existing]; `database/tests/position_study/test_donor_picker.py` [existing]; `database/tests/position_study/italian_acceptance.py` [existing]; `database/tests/position_study/test_inventory_readonly.py` [existing]; `database/tests/position_study/acceptance.py` [existing]; `backend/tests/test_position_learning_contract_values.py` [existing]; `backend/tests/test_position_schedule_occurrences.py` [existing]; `tests/REGRESSIONS.md` [existing].

**Steps:**

1. Take only the audit row indexes assigned to this task. Resolve each old reference/query against current source and actual suite/runner/function call graph. Distinguish already repaired, current selected, supported leaf awaiting registration and exclusively historical/retired.
2. Decide each missing seed/operator/content-origin import against actual supported runtime and SPEC cut. Do not revive removed position_owner_operator/position_seed/game_feedback/recombination to run old tests. For currently active position owners, move necessary seeded-history fixture setup to task-owned native fixture data and retain owner/source/currentness, due/issued/first-response/replay tests through current APIs. Mark only operator-exclusive deployment/cutover procedures historical after supported entrypoint absence is proved; retain original source-linked historical documentation.
3. Split a mixed file by exact named case/helper families. Retained assertions get a current owner rebind and native %s semantics; historical-only cases get a source-linked support decision and current inventory removal. Remove no safety assertion merely because its old helper vanished.
4. If a row is already fixed, prove the old reference/query is absent or replaced and link the actual current case/command/result; do not count the historical finding again or fabricate a new rewrite.
5. Validate project import resolution and exact case collection before acquiring the heavy slot. Every retained native proof must have a reachable supported current runner/declared input set; proposed fixed selectors require parser/selection/refusal tests and exact operator command release.
6. Exercise only the changed native owner/consumer path in P14. Preserve real environment ownership, writer/admission isolation, transaction bounds, exact case accounting and cleanup.

**Acceptance:**

- Each assigned historical proof row has a positive, source-linked current disposition and owning executable case or positively evidenced retirement.
- No current selected proof imports a removed project implementation or uses ? with PostgresConnection/psycopg. Genuine SQL question-mark operators/literals are distinguished from parameter markers.
- Current native assertions execute through their advertised runner; historical cases cannot masquerade as current passes.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_position_learning_contract_values.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_position_schedule_occurrences.py` — cwd `.`; focused; current.

**Integration:** P14 checkpoint2 runs only the applicable selected native cohort. A static scan or collection result is not native execution.

**Material risks:** Old tests can mix useful retained invariants with removed products; blanket deletion or blanket resurrection both misstate support.; Current runner list names stages, not every nested executed assertion: bind the actual nested case inventory and raw native report.

**Exclusions:** Restoring retired optional products; Broad historical schema expansion; New alternate SQL translator; Claiming all native tests passed from import/compile checks

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### P19 — Reconcile current proof contract: Frozen order proof inputs and native SQL

**Scope:** audit-expansion-proof. Findings: ST012, ST013. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** S06

**Owner/resource conditions:** Apply the shared path lease and exact candidate rules.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `database/tests/frozen-order-browser-fixture.py`; `database/tests/test-frozen-cli.py`; `database/tests/test-frozen-postgres.py`; `database/tests/fixtures/frozen_order_staged_plan.py`; `database/tests/test-postgres-docker.mjs`; `database/tests/postgres-test-plan.mjs`; `components.json`; `SPEC.md`.

**Write scope:** `database/tests/frozen-order-browser-fixture.py` [existing]; `database/tests/test-frozen-cli.py` [existing]; `database/tests/test-frozen-postgres.py` [existing]; `database/tests/fixtures/frozen_order_staged_plan.py` [existing]; `backend/tests/test_frozen_opening_order.py` [existing]; `backend/tests/test_frozen_queue_refresh_regression.py` [existing]; `tests/REGRESSIONS.md` [existing].

**Steps:**

1. Take only the audit row indexes assigned to this task. Resolve each old reference/query against current source and actual suite/runner/function call graph. Distinguish already repaired, current selected, supported leaf awaiting registration and exclusively historical/retired.
2. Keep current frozen introduction ordering and protected queue rollback behavior. Rebind shared fixture identity/calendar/current owner calls, use native %s and supported timing/connection hooks. Preserve prior order, half-swap conflict, legacy origin exposure, stale source and active attempt guards. Match source/script/CLI fixture role explicitly rather than counting every retained file as an automatically selected suite.
3. Split a mixed file by exact named case/helper families. Retained assertions get a current owner rebind and native %s semantics; historical-only cases get a source-linked support decision and current inventory removal. Remove no safety assertion merely because its old helper vanished.
4. If a row is already fixed, prove the old reference/query is absent or replaced and link the actual current case/command/result; do not count the historical finding again or fabricate a new rewrite.
5. Validate project import resolution and exact case collection before acquiring the heavy slot. Every retained native proof must have a reachable supported current runner/declared input set; proposed fixed selectors require parser/selection/refusal tests and exact operator command release.
6. Exercise only the changed native owner/consumer path in P14. Preserve real environment ownership, writer/admission isolation, transaction bounds, exact case accounting and cleanup.

**Acceptance:**

- Each assigned historical proof row has a positive, source-linked current disposition and owning executable case or positively evidenced retirement.
- No current selected proof imports a removed project implementation or uses ? with PostgresConnection/psycopg. Genuine SQL question-mark operators/literals are distinguished from parameter markers.
- Current native assertions execute through their advertised runner; historical cases cannot masquerade as current passes.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_frozen_opening_order.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_frozen_queue_refresh_regression.py` — cwd `.`; focused; current.

**Integration:** P14 checkpoint2 runs only the applicable selected native cohort. A static scan or collection result is not native execution.

**Material risks:** Old tests can mix useful retained invariants with removed products; blanket deletion or blanket resurrection both misstate support.; Current runner list names stages, not every nested executed assertion: bind the actual nested case inventory and raw native report.

**Exclusions:** Restoring retired optional products; Broad historical schema expansion; New alternate SQL translator; Claiming all native tests passed from import/compile checks

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### P20 — Reconcile current proof contract: Tactic capture and retained corpus/history native proofs

**Scope:** audit-expansion-proof. Findings: ST012, ST013. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** B22; B31

**Owner/resource conditions:** Apply the shared path lease and exact candidate rules.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `database/tests/check_postgres_tactic_capture.py`; `database/tests/check_postgres_stalemate_swindles.py`; `database/tests/tactics/test_tactics_row_snapshot_postgres.py`; `database/tests/test-postgres-docker.mjs`; `database/tests/postgres-test-plan.mjs`; `components.json`; `SPEC.md`.

**Write scope:** `database/tests/check_postgres_tactic_capture.py` [existing]; `database/tests/check_postgres_stalemate_swindles.py` [existing]; `database/tests/tactics/test_tactics_row_snapshot_postgres.py` [existing]; `backend/tests/test_tactic_capture_boundary.py` [existing]; `backend/tests/test_tactical_catalog.py` [existing]; `backend/tests/test_study_portable_storage_boundary.py` [existing]; `tests/REGRESSIONS.md` [existing].

**Steps:**

1. Take only the audit row indexes assigned to this task. Resolve each old reference/query against current source and actual suite/runner/function call graph. Distinguish already repaired, current selected, supported leaf awaiting registration and exclusively historical/retired.
2. Current tactic capture/catalog/history remains retained. Rebind missing tactic row snapshot/count helpers to current read owner or classify their unselected component support precisely. Stalemate mining or retired Study bundle authoring is not restored; preserve the existing four real tactic/history assertions by a current retained fixture/command where applicable, with original review history unchanged. Coordinate B31 retained exercise runner if frozen exercises are the retained consumer.
3. Split a mixed file by exact named case/helper families. Retained assertions get a current owner rebind and native %s semantics; historical-only cases get a source-linked support decision and current inventory removal. Remove no safety assertion merely because its old helper vanished.
4. If a row is already fixed, prove the old reference/query is absent or replaced and link the actual current case/command/result; do not count the historical finding again or fabricate a new rewrite.
5. Validate project import resolution and exact case collection before acquiring the heavy slot. Every retained native proof must have a reachable supported current runner/declared input set; proposed fixed selectors require parser/selection/refusal tests and exact operator command release.
6. Exercise only the changed native owner/consumer path in P14. Preserve real environment ownership, writer/admission isolation, transaction bounds, exact case accounting and cleanup.

**Acceptance:**

- Each assigned historical proof row has a positive, source-linked current disposition and owning executable case or positively evidenced retirement.
- No current selected proof imports a removed project implementation or uses ? with PostgresConnection/psycopg. Genuine SQL question-mark operators/literals are distinguished from parameter markers.
- Current native assertions execute through their advertised runner; historical cases cannot masquerade as current passes.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_tactic_capture_boundary.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_tactical_catalog.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_study_portable_storage_boundary.py` — cwd `.`; focused; current.

**Integration:** P14 checkpoint2 runs only the applicable selected native cohort. A static scan or collection result is not native execution.

**Material risks:** Old tests can mix useful retained invariants with removed products; blanket deletion or blanket resurrection both misstate support.; Current runner list names stages, not every nested executed assertion: bind the actual nested case inventory and raw native report.

**Exclusions:** Restoring retired optional products; Broad historical schema expansion; New alternate SQL translator; Claiming all native tests passed from import/compile checks

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### P21 — Reconcile current proof contract: Current queue dispatch, opening admission and capacity proof closures

**Scope:** audit-expansion-proof. Findings: ST012, ST013. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** P02; B07; B12; B13

**Owner/resource conditions:** Apply the shared path lease and exact candidate rules.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `database/tests/check_postgres_daily_study_dispatch.py`; `database/tests/check_postgres_opening_capacity.py`; `database/tests/check_postgres_opening_progression.py`; `database/tests/queue_admission/test_postgres.py`; `database/tests/check_postgres_study_opening_admission.py`; `database/tests/study-priority-native-overlap.py`; `database/tests/test-postgres-docker.mjs`; `database/tests/postgres-test-plan.mjs`; `components.json`; `SPEC.md`.

**Write scope:** `database/tests/check_postgres_daily_study_dispatch.py` [existing]; `database/tests/check_postgres_opening_capacity.py` [existing]; `database/tests/check_postgres_opening_progression.py` [existing]; `database/tests/queue_admission/test_postgres.py` [existing]; `database/tests/check_postgres_study_opening_admission.py` [existing]; `database/tests/study-priority-native-overlap.py` [existing]; `backend/tests/test_queue_application_database_split.py` [existing]; `backend/tests/test_study_opening_admission.py` [existing]; `backend/tests/test_opening_capacity_admission.py` [existing]; `tests/REGRESSIONS.md` [existing].

**Steps:**

1. Take only the audit row indexes assigned to this task. Resolve each old reference/query against current source and actual suite/runner/function call graph. Distinguish already repaired, current selected, supported leaf awaiting registration and exclusively historical/retired.
2. Retain current ordinary Study progression, bounded dispatch/admission, source preparation, quiet convergence, frozen priority and foreground contention. Replace real_game_feedback and old private projection imports with current semantic owners only when the same retained invariant exists; producer-exclusive promotion belongs to P04 paused-history disposition. Preserve exact sparse/unlock/transaction budgets and original case identities or explicit replacements; no weakening counts to make a stale fixture pass.
3. Split a mixed file by exact named case/helper families. Retained assertions get a current owner rebind and native %s semantics; historical-only cases get a source-linked support decision and current inventory removal. Remove no safety assertion merely because its old helper vanished.
4. If a row is already fixed, prove the old reference/query is absent or replaced and link the actual current case/command/result; do not count the historical finding again or fabricate a new rewrite.
5. Validate project import resolution and exact case collection before acquiring the heavy slot. Every retained native proof must have a reachable supported current runner/declared input set; proposed fixed selectors require parser/selection/refusal tests and exact operator command release.
6. Exercise only the changed native owner/consumer path in P14. Preserve real environment ownership, writer/admission isolation, transaction bounds, exact case accounting and cleanup.

**Acceptance:**

- Each assigned historical proof row has a positive, source-linked current disposition and owning executable case or positively evidenced retirement.
- No current selected proof imports a removed project implementation or uses ? with PostgresConnection/psycopg. Genuine SQL question-mark operators/literals are distinguished from parameter markers.
- Current native assertions execute through their advertised runner; historical cases cannot masquerade as current passes.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_queue_application_database_split.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_study_opening_admission.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_opening_capacity_admission.py` — cwd `.`; focused; current.

**Integration:** P14 checkpoint2 runs only the applicable selected native cohort. A static scan or collection result is not native execution.

**Material risks:** Old tests can mix useful retained invariants with removed products; blanket deletion or blanket resurrection both misstate support.; Current runner list names stages, not every nested executed assertion: bind the actual nested case inventory and raw native report.

**Exclusions:** Restoring retired optional products; Broad historical schema expansion; New alternate SQL translator; Claiming all native tests passed from import/compile checks

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### P22 — Reconcile current proof contract: Historical schema and retired packaged collection proof decisions

**Scope:** audit-expansion-proof. Findings: ST012, ST013. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** B21; B35

**Owner/resource conditions:** Apply the shared path lease and exact candidate rules.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `database/tests/check_postgres_upgrade.py`; `database/tests/native/test_command_boundary_native_adapter.py`; `database/tests/games_collection/test_packaged_collection.py`; `database/tests/games_collection/study_recovery_acceptance.py`; `database/tests/test-postgres-docker.mjs`; `database/tests/postgres-test-plan.mjs`; `components.json`; `SPEC.md`.

**Write scope:** `database/tests/check_postgres_upgrade.py` [existing]; `database/tests/native/test_command_boundary_native_adapter.py` [existing]; `database/tests/games_collection/test_packaged_collection.py` [existing]; `database/tests/games_collection/study_recovery_acceptance.py` [existing]; `backend/tests/test_worker_command_registration_boundary.py` [existing]; `backend/tests/test_http_command_registration_boundary.py` [existing]; `backend/tests/test_queue_attempt_recovery.py` [existing]; `tests/REGRESSIONS.md` [existing].

**Steps:**

1. Take only the audit row indexes assigned to this task. Resolve each old reference/query against current source and actual suite/runner/function call graph. Distinguish already repaired, current selected, supported leaf awaiting registration and exclusively historical/retired.
2. Trace exact current registrations before acting. Upgrade tests keep actual retained schema/history invariants, use registered migration sources and native SQL; removed Discovery/provider/cutover runtime is not required merely to execute historical DDL. Current command/Study recovery assertions move to the existing native bridge/public owner; collection-only/provider-source tests with no supported product caller become explicitly historical and are removed from current suite inventory. P13 owns current65 lifecycle and P04 owns paused optional identity preservation.
3. Split a mixed file by exact named case/helper families. Retained assertions get a current owner rebind and native %s semantics; historical-only cases get a source-linked support decision and current inventory removal. Remove no safety assertion merely because its old helper vanished.
4. If a row is already fixed, prove the old reference/query is absent or replaced and link the actual current case/command/result; do not count the historical finding again or fabricate a new rewrite.
5. Validate project import resolution and exact case collection before acquiring the heavy slot. Every retained native proof must have a reachable supported current runner/declared input set; proposed fixed selectors require parser/selection/refusal tests and exact operator command release.
6. Exercise only the changed native owner/consumer path in P14. Preserve real environment ownership, writer/admission isolation, transaction bounds, exact case accounting and cleanup.

**Acceptance:**

- Each assigned historical proof row has a positive, source-linked current disposition and owning executable case or positively evidenced retirement.
- No current selected proof imports a removed project implementation or uses ? with PostgresConnection/psycopg. Genuine SQL question-mark operators/literals are distinguished from parameter markers.
- Current native assertions execute through their advertised runner; historical cases cannot masquerade as current passes.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_worker_command_registration_boundary.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_http_command_registration_boundary.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_queue_attempt_recovery.py` — cwd `.`; focused; current.

**Integration:** P14 checkpoint2 runs only the applicable selected native cohort. A static scan or collection result is not native execution.

**Material risks:** Old tests can mix useful retained invariants with removed products; blanket deletion or blanket resurrection both misstate support.; Current runner list names stages, not every nested executed assertion: bind the actual nested case inventory and raw native report.

**Exclusions:** Restoring retired optional products; Broad historical schema expansion; New alternate SQL translator; Claiming all native tests passed from import/compile checks

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

### P24 — Reconcile current proof contract: Mixed native review suite after retained split and receipt repairs

**Scope:** audit-expansion-proof. Findings: ST012, ST013. Prior tasks: wider audit.

**Prerequisites (reviewed source/capability unless explicitly stronger):** P05; P06; B06

**Owner/resource conditions:** Apply the shared path lease and exact candidate rules.

**Shared-file sequence:** Reserve listed paths; consume current owner releases before editing.

**Read first:** `database/tests/native_review/test_postgres.py`; `database/tests/test-postgres-docker.mjs`; `database/tests/postgres-test-plan.mjs`; `components.json`; `SPEC.md`.

**Write scope:** `database/tests/native_review/test_postgres.py` [existing]; `backend/tests/test_position_review_reconciliation.py` [existing]; `backend/tests/test_queue_order_owner.py` [existing]; `tests/REGRESSIONS.md` [existing].

**Steps:**

1. Take only the audit row indexes assigned to this task. Resolve each old reference/query against current source and actual suite/runner/function call graph. Distinguish already repaired, current selected, supported leaf awaiting registration and exclusively historical/retired.
2. Preserve retained review saving, exact operation replay/conflict, frozen queue order, source locks and current manual prefix split placement. Replace removed LearningReviewAdapter/card_schedule_state/postgres_opening_evidence/private queue helpers with current exact owners; retire active real-game promotion expectations only with P04 coverage. Convert remaining SQLite markers and verify the advertised native-split selector still collects its exact case; do not re-run or resurrect every historical case without support evidence.
3. Split a mixed file by exact named case/helper families. Retained assertions get a current owner rebind and native %s semantics; historical-only cases get a source-linked support decision and current inventory removal. Remove no safety assertion merely because its old helper vanished.
4. If a row is already fixed, prove the old reference/query is absent or replaced and link the actual current case/command/result; do not count the historical finding again or fabricate a new rewrite.
5. Validate project import resolution and exact case collection before acquiring the heavy slot. Every retained native proof must have a reachable supported current runner/declared input set; proposed fixed selectors require parser/selection/refusal tests and exact operator command release.
6. Exercise only the changed native owner/consumer path in P14. Preserve real environment ownership, writer/admission isolation, transaction bounds, exact case accounting and cleanup.

**Acceptance:**

- Each assigned historical proof row has a positive, source-linked current disposition and owning executable case or positively evidenced retirement.
- No current selected proof imports a removed project implementation or uses ? with PostgresConnection/psycopg. Genuine SQL question-mark operators/literals are distinguished from parameter markers.
- Current native assertions execute through their advertised runner; historical cases cannot masquerade as current passes.

**Commands (planned, not executed):**

- `make python-file FILE=backend/tests/test_position_review_reconciliation.py` — cwd `.`; focused; current.
- `make python-file FILE=backend/tests/test_queue_order_owner.py` — cwd `.`; focused; current.

**Integration:** P14 checkpoint2 runs only the applicable selected native cohort. A static scan or collection result is not native execution.

**Material risks:** Old tests can mix useful retained invariants with removed products; blanket deletion or blanket resurrection both misstate support.; Current runner list names stages, not every nested executed assertion: bind the actual nested case inventory and raw native report.

**Exclusions:** Restoring retired optional products; Broad historical schema expansion; New alternate SQL translator; Claiming all native tests passed from import/compile checks

**Stop / merge:** Stop after this task acceptance, current consumer adoption, focused proof and exact source/evidence handoff. Do not claim its broader finding or release is complete until the mapped coverage and integration gates also pass. Focused task acceptance + architecture/consumer review + applicable P14/P12/P13 acceptance; pure metadata/contract leaves do not inherit unrelated heavy proof.

## Evidence provenance

The JSON retains source hashes for read inputs and exact original audit rows. Prior independent checks are evidence at their original source; this packet ran no product tests. Source reads and plan consistency checks alone were performed.

- `deep-review/evidence/audit-current.json` — SHA256 `62e629b89d9effeb7d7609fb80b33de847b653441d79ed98bdc26175edbcf75d`.
- `deep-review/qualification/qualification-review.md` — SHA256 `e2c3b83bdaa6814df3667d86882431464097b3d43d92b724ded3f6c727bccd8e`.
- `deep-review/qualification/qualification-review.json` — SHA256 `02e91d8fc96c40ae3289fb7d22c8909f912380badb0463c446c7815a4dc7fcf2`.
- `deep-review/qualification/runner-probe.json` — SHA256 `b1e3857f1e7a16d9eed257ecf1093145098cce1e99b9945f5b20f98a0f029ce3`.
- `deep-review/qualification/routes-and-e01-probe.json` — SHA256 `8e474087df2570a3b7b083ef0059e4d3ebc97be728b2ba163118460205b709bc`.
- `deep-review/backend/verification-log.md` — SHA256 `a37e232af2427c4a13a0550a3413b7066cf5257d898ed6594627aa1a1e378c12`.
- `deep-review/backend/verification.json` — SHA256 `b0715b336e86a977b7eb14f766826f0351320d1ed0696a1be6b9e89df46d9d2f`.
- `continuation-build/tempo-continuation-20261112/plan/tasks.json` — SHA256 `9c173b586b4cc8869938b54d085f41180e9d665cc48847eef0ca6de275d0e005`.

## Planning consistency

Tasks: 60 unique IDs. Storage rows: 264/264 assigned. Proof rows: 758/758 preserved and assigned locally or to companion owners. Product tests executed:0. Missing read paths are listed in the JSON and must be resolved before implementation; proposed write paths are explicitly labeled.
