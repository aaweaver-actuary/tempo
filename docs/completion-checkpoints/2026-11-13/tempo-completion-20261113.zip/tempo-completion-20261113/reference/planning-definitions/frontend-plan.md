# Frontend completion plan

Source: `091ad318b1afaadcb25e5ca44ff526120a202336`. Planning only; no product edits or test executions.

The plan contains **32 bounded tasks** covering every nonclosed frontend audit row. FE011 remains closed. Milestone 1 completes the prior C/D work and review residuals; milestone 2 closes the remaining frontend architecture and explicit policy decisions.

## Critical findings and decisions

Start with C10: the shared initial-202 confirmation currently trusts the response operation ID. The fix must compare the original retained ID before any poll or clearing and then migrate every durable caller; queue GET server-issued identity remains a different protocol. Settings and rename also need real domain-result validation before clearing their journals.

FE05/FE06 repair retained-authority inspection without changing its cutover policy. A nonempty unknown store yields an unknown retained fact; physical registry and offline database naming belong in the adapter. Existing raw bytes remain exportable.

C20/B31/C21 restore the four routes needed by reachable frozen ordinary exercises. Positive queue-to-runner reachability is already established. Retired and ambiguous records remain held with their original identity and do not stop unrelated valid work. B31 consumes the unchanged v1 route baseline and does not wait for grader changes.

The grader default is canonical current Python v1 plus a corrected browser implementation. New local attempts may record implementation revision 2; old missing provenance remains legacy_unknown. Do not relabel/regrade old data, normalize a retained SAN answer, add default fields to the hashed request model, or silently tighten Python acceptance. A real acceptance change requires a real explicit new version.

FE007 spans both workspace and practice-card domain adapters. FE08 publishes pure parsing, FE09 adopts it, FE10 injects runtime diagnostics, and T03 enforces direction for runtime and type-only imports while treating type edges separately from startup reachability.

The independent Learning service is retired by current SPEC. FE30 classifies its serving entry and FE36 removes dormant new issuance/settings controls after current tactics/burial adopt the supported owner. Recovery preserves original authority and bytes. Normal monolith Study and offline/reload remain supported.

## Coverage

| Finding | Current status | Task disposition | Milestone |
| --- | --- | --- | --- |
| FE001 | Open | C10, C11, C12, C13, C14, P12, P16: Bind every initial durable-POST 202 to its original ID, validate domain completion before clear, and remove the permissive helper. Preserve queue GET server-issued semantics and legacy identity-optional receipt compatibility. | 1 |
| FE002 | Open | FE20, FE21: Publish missing neutral board capabilities, then adopt the existing package renderer throughout live Study/dialog wrappers; app retains interaction/domain policy. | 2 |
| FE003 | Open | FE25, FE26, FE29, FE35, P12: Independent semantic review ports, injected controller, out-of-view durable preparation and named invariant-preserving state writes. | 2 |
| FE004 | Open | FE27, FE28, FE29, FE33, FE35, P12, P16: Extract bounded queue transport/application and durable completion, isolate demo queue policy, and narrow consequential store writes. | 2 |
| FE005 | Open | FE05, FE06, P16: Unknown nonempty stores yield semantic holds before cutover; physical registry/database layout resides in the adapter. S03/S04 subsequently consume the release for their separate storage findings. | 1 |
| FE006 | Open | FE22, FE23, FE24: One explicit factory and complete typed adapter table, inert delivery modules and one lazy browser composition; no registration import side effects. | 2 |
| FE007 | Open | FE08, FE09, FE10, T03: Separate pure parsing from mutable diagnostic collection, migrate both domain adapters, inject runtime effects and enforce runtime/type-only dependency direction. | 1 |
| FE008 | Open | C20, C21, C24, FE30, FE36, B31, P06, P12, P16: Restore four current frozen ordinary exercise routes and typed consumers; preserve retired/ambiguous records as nonblocking holds; finish independent serving retirement only after supported consumers adopt the current owner. | 1 for D02 frozen/recovery/classification; 2 for final independent entry retirement |
| FE009 | Open | C22, C23, C24, P16: Current Python v1 semantics remain canonical, browser parity is repaired with comprehensive shared boundary vectors, and new local implementation provenance does not rewrite historical attempts. | 1 |
| FE010 | Open | C10, C13, C14, FE30, FE31, FE32, FE36, P12, P16: Current tactics/burial retain before transport through one owner; preserve bounded legacy readers. Retire obsolete independent settings issuance without conflating current settings domains. | 2 |
| FE011 | Closed | Preserve accepted closure: Preserve accepted Game Review validated public contract; do not reopen or redo its work. | already accepted |
| FE012 | Needs decision | FE30, FE33, FE36, P16: Explicitly retain normal monolith offline behavior as provisional server-reconciled projection with bounded conformance, isolate demo policy, and retire independent fresh issuance. | 2 |
| FE013 | Needs decision | FE34: Record intentional version-pinned FSRS-shaped state as the current supported external contract; no speculative opaque scheduler abstraction. Preserve installed-package proof distinctions. | 2 |

## Prior packet coverage

| Prior task | Accepted baseline and remaining work |
| --- | --- |
| Q0 | Accepted queue/game-review/domain shell work is not reopened. Review residuals remain. Remaining: C10, C11, C12, C13, C14, FE08, FE09, FE10. Focused negatives and shared review journey; FE011 stays Closed. |
| C01 | Canonical initial queue GET acknowledgment is already implemented. Remaining: C10, C11, C12, C13, C14. These are review-discovered durable POST residuals; do not undo server-issued queue identity. |
| C02 | Semantic facts exist but unknown additional stores and physical registry ownership remain. Remaining: FE05, FE06. Unknown data cannot authorize cutover; policy no longer casts or constructs physical registry layout. |
| C03 | Factory import is inert and independent-client isolation already accepted. Remaining: FE06. Preserve inert import and client isolation while moving remaining layout ownership; no repeat factory project. |
| D01 | Dead workspace adapters removed. Remaining: none in this owner. Preserve removal; no restoration of summaries/endgame providers or obsolete tests. |
| D02 | Frozen ordinary exercise positive reachability established; four supporting routes absent. Remaining: C20, C21, FE30. Finite supported/held classification, original-ID restore/replay and four mounted current routes; final broad FE008 also includes FE36. |
| D03 | Fifteen shared golden outcomes do not cover current schema/evaluation divergence or missing offline provenance. Remaining: C22, C23, C24. Canonical current v1 contract, shared stage-aware negative vectors, no rewrite/backfill, old retry hashes preserved. |
| A/B/E/F/G families | Outside this frontend plan; backend/proof/storage/root plans retain initial-packet coverage. Remaining: none in this owner. Cross-area handoffs only: P06 mounts before B31; calendar/settings writers serialize with C10/C14/C24/FE31; T02 records retained test_studies.py owner C22/C23. Do not infer these families are closed from this frontend packet. |

## Readiness, reservations and qualification

Task prerequisites are concrete source-release dependencies. They do not include universal merge/stack gates. Shared file reservations serialize application of source changes even where disjoint contract work can proceed. Group sequential slices into one branch/PR when helpful; keep acceptance and handoffs separately reviewable.

- **C10 → C14 → FE27**: `app/lib/operation-status.ts`, `app/domain/adapters/operation-result-adapter.ts`. C10 publishes strict core; C14 removes old API after all migrations; FE27 consumes queue-specific decoder.
- **C11 → S05**: `app/lib/opening-evidence-journal.ts`. S05 consumes strict frozen checkpoint-ID call release; no parallel journal edits.
- **FE05 → FE06 → S03 → S04 → FE36**: `database/browser/study-connection-storage.ts`, `app/lib/study-client.ts`, `app/lib/study-connection.ts`. FE06 owns physical registry release; storage factory work consumes it. FE36 applies C21 allowlist delta last; no simultaneous client/registry mutation.
- **C11 → C21 → FE23 → FE24 → FE32**: `app/lib/study-command-client.ts`, `app/lib/study-command-delivery.ts`. Retained support policy first, inert delivery extraction next, explicit composition, then burial legacy adoption.
- **C11 → FE23 → FE24**: `app/lib/review-outbox.ts`, `app/lib/teaching-state-outbox.ts`. Exact original-ID release precedes extraction; composition owns registration removal.
- **C14 → C21 → C24 → FE10 → FE33**: `app/lib/offline-training.ts`, `app/domain/offline-training.ts`, `app/views/study_exercise_runner.tsx`. Readiness can proceed in parallel on disjoint contracts; shared source application is serialized in this order. C23 pure grader can proceed independently of C21.
- **C22 → C23**: `backend/tests/test_studies.py`, `tests/fixtures/study-grading.json`. Exclusive frontend grader owner; B34/T02 coordinate inventory without concurrent test mutation.
- **P06 → B31 → B21**: `backend/app/main.py`. Backend owns all edits. Prefix route mount before four frozen routes; later explicit registration assembly consumes both.
- **FE20 → FE21**: `app/components/board/chessboard.tsx`. Package capability release before renderer adoption.
- **FE25 → FE26 → FE29 → FE35**: `app/features/study/contracts.ts`, `app/features/study/browser-services.ts`, `app/features/study/index.ts`. Port contract before controller/adoption and final state narrowing.
- **FE27 → FE28 → FE35**: `app/views/fetchAndInitializeQueue.tsx`, `app/lib/prepared-review-continuation.ts`, `app/features/study/browser-queue.ts`. Transport before application owner before final store write restriction.
- **FE26 → FE29 → FE33 → FE35**: `app/views/home_view.tsx`. One Home writer at a time; no concurrent controller/demo/state rewrites.
- **C14 → FE31**: `app/views/tactics_view.tsx`. Strict receipt ID first; future retained lifecycle second. Calendar owner must coordinate its capture/day patch at the source boundary.
- **C14 → FE32**: `app/lib/training-bury-command.ts`. Do not combine identity fix with legacy durable handoff until the shared owner is released.
- **C20 → C22 → FE30 → FE33 → FE34**: `static/src/README.md`, `app/features/study/README.md`, `backend/app/study/policy/README.md`. Docs can be batched but merge reservations prevent overwriting another owner's contract; each writer edits its own named section.

The owning P12/P16/B31/T03 proof tasks qualify the assembled candidate once after relevant writers finish. Unit tests are not proof of persisted server behavior or real IndexedDB reload. Pure parsing/types, board rendering and documentation decisions do not require unrelated PostgreSQL/browser journeys. Record exact source/runtime/SHA and distinguish implemented, component-tested, assembled-demonstrated, merge-qualified and installed.

## Task index

| Task | Title | Prerequisites | Source scope |
| --- | --- | --- | --- |
| C10 | Fence initial 202 confirmation with the original ID; fix review and settings first | none | Milestone 1 |
| C11 | Bind the remaining Study journal confirmations to their frozen delivery IDs | C10 | Milestone 1 |
| C12 | Bind repertoire-edit confirmations and retained annotation save to original keys | C10 | Milestone 1 |
| C13 | Bind deletion and repertoire settings acknowledgments; validate rename completion | C10 | Milestone 1 |
| C14 | Finish 202 adoption for phone and tactics; remove permissive confirmation entry | C11, C12, C13 | Milestone 1 |
| C20 | Freeze the retained-exercise HTTP and recovery contract before either side changes | none | Milestone 1 |
| C21 | Wire supported frozen exercises and preserve held retained work without queue-wide failure | C20, B31, C14 | Milestone 1 |
| C22 | Choose and document bounded grader-v1 compatibility; repair the pure Python test owner | C20 | Milestone 1 |
| C23 | Align browser grading and validation to current Python v1 using shared boundary vectors | C22 | Milestone 1 |
| C24 | Record new offline grading provenance and reconcile retained v1 answers without rewriting them | C23, C21 | Milestone 1 |
| FE05 | Hold foreign authority cutover when an inspected retained store is unknown and nonempty | none | Milestone 1 |
| FE06 | Move physical authority registry layout and database naming into the storage adapter | FE05 | Milestone 1 |
| FE08 | Publish pure validation facts while retaining the current browser collector facade | none | Milestone 1 |
| FE09 | Adopt pure validation in both domain adapters and computation contracts | FE08 | Milestone 1 |
| FE10 | Inject validation collection at worker and browser composition boundaries | FE09, C14 | Milestone 1 |
| FE20 | Publish the small board adapter capabilities needed by current Study policy | none | Milestone 2 |
| FE21 | Render current Study and dialogs through the shared board package | FE20 | Milestone 2 |
| FE22 | Construct one typed Study session runtime with a complete adapter table | C21 | Milestone 2 |
| FE23 | Separate delivery adapters from outbox/session composition without changing settlement | FE22, C14, C24 | Milestone 2 |
| FE24 | Assemble explicit default Study runtime and remove registration side effects | FE23, FE06 | Milestone 2 |
| FE25 | Publish semantic review ports and map the existing browser owners behind them | FE24 | Milestone 2 |
| FE26 | Run the review controller through injected ports and preserve presentation fences | FE25 | Milestone 2 |
| FE27 | Extract the bounded queue HTTP protocol into an independently testable capability | C14 | Milestone 2 |
| FE28 | Move queue acquisition/reconciliation out of the view into one port-based application owner | FE27, FE25, C21 | Milestone 2 |
| FE29 | Move durable attempt completion and failure preparation out of Home | FE26, FE28 | Milestone 2 |
| FE30 | Classify the independent serving entry and release the supported-shell decision | FE06, C21 | Milestone 1 |
| FE31 | Give current Tactics one retained command lifecycle before transport | FE24, FE30, C14 | Milestone 2 |
| FE32 | Use one burial lifecycle and a bounded reader for existing local markers | FE24, FE30, C14 | Milestone 2 |
| FE33 | Document provisional offline repeats and isolate demo queue policy with conformance | FE30, C24, FE29 | Milestone 2 |
| FE34 | Record intentional FSRS-shaped scheduling API as the current abstraction | none | Milestone 2 |
| FE35 | Restrict queue/attempt writes to named invariant-preserving actions | FE26, FE28, FE29, FE33 | Milestone 2 |
| FE36 | Apply the independent entry retirement after current command consumers adopt their owner | FE30, FE31, FE32 | Milestone 2 |

## Executable task details

The companion JSON is the prompt-generation source. Paths below are repository-relative. New files are labeled; every other path was checked in the pinned checkout. Commands are exact selected future checks, not results from this planning pass.

### C10 — Fence initial 202 confirmation with the original ID; fix review and settings first

**Findings:** FE001. **Prior tasks:** C01, Q0. **Milestone:** 1. **Prerequisites:** none. **Release:** `ORIGINAL_ID_CORE_RELEASED`.

**Read first**

- `AGENTS.md` — current scope, ownership and minimum real proof; distinguish implemented/tested/assembled/installed
- `SPEC.md` — current November 10 reduction scope and retained ordinary Study preservation
- `docs/testing.md` — smallest relevant proof and supported owned runner
- `app/lib/operation-status.ts` — confirmOperationResponse, readReceipt, operationBinding; present helper trusts the returned ID
- `app/domain/adapters/operation-result-adapter.ts` — decodeOperationAcceptance, decodeOperationResult
- `app/lib/opening-evidence-review.ts` — saveEvidenceAwareReview.send; operationKey plus retained aggregate-only suffix
- `app/lib/settings-save.ts` — saveLocalSettings and pendingSave
- `backend/app/command_dispatch.py` — dispatch_command; operation IDs are bounded to 128 characters, not the queue decoder alphabet
- `backend/app/settings_commands.py` — apply_settings returns full current Settings values
- `app/domain/schemas/index.ts` — settingsResponseSchema
- `tests/unit/review-outbox-regressions.test.ts` — optimistic outbox, uncertain-save and evidence fallback cases

**Write reservation**

- `app/lib/operation-status.ts`
- `app/domain/adapters/operation-result-adapter.ts`
- `app/lib/opening-evidence-review.ts`
- `app/lib/settings-save.ts`
- `tests/unit/operation-status-integration-regressions.test.ts`
- `tests/unit/review-outbox-regressions.test.ts`
- `tests/unit/settings-save-pending-regressions.test.ts`

**Ordered steps**

1. Add canonical confirmOriginalOperationResponse(response, expectedOperationId, options). For non-202 return unchanged. For 202 parse unknown JSON, require an object with a nonempty bounded string operation_id exactly equal to the supplied original ID, and classify admissible acknowledgment state through the existing operation-result decoder before any status URL, notification, or journal mutation. Missing/foreign/malformed IDs throw PendingOperationError carrying the expected ID.
2. Do not reuse the queue-only allowed-character restriction to reject a persisted generic operation ID that the gateway accepts. Exact equality and existing gateway length are sufficient; URL-encode only when constructing the request.
3. Keep readOperationResponse legacy receipt identity-optional behavior where currently allowed. Keep queue GET issuance decoding distinct: its initial ID is server allocated. Leave the old permissive confirmOperationResponse only as a temporary migration entry; C14 must remove it after C11-C13 adopt the strict entry.
4. In saveEvidenceAwareReview compute the exact sent Idempotency-Key once per send, including :aggregate-only when retained rejection/fallback requires it, and pass that same key to strict confirmation. Do not regenerate review/reconciliation identity or permit position-study evidence fallback.
5. In saveLocalSettings pass pending.operationId. On both receipt-first completion and direct/confirmed response, validate with the current settingsResponseSchema before removing the saved key/body. Update old partial-response test fixtures to the real full producer shape rather than relaxing the decoder.
6. Promote the supplied deep-review review/settings probes into the owning suites. Preserve the exact initial request bytes and verify no GET to the foreign operation is issued.

**Acceptance**

- Foreign, absent, nonstring, empty, malformed-JSON, unsupported-state and overlength acknowledgment cases cannot poll a foreign ID, clear pending work, report persisted, or advance the active attempt.
- For a valid original-ID 202 and complete original receipt, one review/settings command settles once; pending/blocked/unknown/failed receipt classification remains unchanged.
- Review aggregate-only and reconciliation keys are matched to the actual submitted delivery, not merely the base human-attempt key.
- Settings malformed terminal response retains its original stored body and key; a complete real Settings result clears only after validation.
- No claim of full FE001 closure: the temporary legacy confirmation entry remains for C11-C14.

**Selected future commands**

- `npm run test:unit -- tests/unit/operation-result-decoder.test.ts tests/unit/operation-status-integration-regressions.test.ts tests/unit/review-outbox-regressions.test.ts tests/unit/settings-save-pending-regressions.test.ts`
- `npm run typecheck:browser`

**Shared release qualification**

- integration owner / P12 and P16: On the assembled candidate, one real saved review -> original operation receipt -> authoritative playable successor; inject wrong/missing initial 202 identity and lost acknowledgment, then recover only the original receipt. Reuse tests/browser/study-recovery.spec.ts; add a named fault case. Unit mocks do not establish this claim.

**Risk:** Highest-priority reproduced gap: a foreign 202 can falsely settle the original browser review. The fault is conditional protocol corruption, not evidence of current production data loss. Tightening completed settings fixtures can expose stale mocks.

**Excludes:** No new receipt state machine; No journal consolidation; No changed retry/blocked/failure policy; No browser or stack run by this planning task.

### C11 — Bind the remaining Study journal confirmations to their frozen delivery IDs

**Findings:** FE001. **Prior tasks:** C01, Q0. **Milestone:** 1. **Prerequisites:** C10. **Release:** `JOURNAL_ORIGINAL_IDS_RELEASED`.

**Read first**

- `AGENTS.md` — current scope, ownership and minimum real proof; distinguish implemented/tested/assembled/installed
- `SPEC.md` — current November 10 reduction scope and retained ordinary Study preservation
- `docs/testing.md` — smallest relevant proof and supported owned runner
- `app/lib/review-outbox.ts` — sendReview guided failure marker: queue-fail:${attemptId}
- `app/lib/teaching-state-outbox.ts` — deliver/checkReceipt and record.requestId
- `app/lib/study-command-client.ts` — createStudyCommandDelivery.deliver; existing incomplete 202 guard
- `app/lib/training-failure-outbox.ts` — saveTrainingFailures operationId
- `app/lib/opening-evidence-journal.ts` — flush opening checkpoint delivery: frozenDelivery.operationKey
- `app/lib/operation-status.ts` — confirmOriginalOperationResponse proposed by C10

**Write reservation**

- `app/lib/review-outbox.ts`
- `app/lib/teaching-state-outbox.ts`
- `app/lib/study-command-client.ts`
- `app/lib/training-failure-outbox.ts`
- `app/lib/opening-evidence-journal.ts`
- `tests/unit/teaching-state-outbox-regressions.test.ts`
- `tests/unit/study-command-client-capability.test.ts`
- `tests/unit/training-failure-outbox-regressions.test.ts`
- `tests/unit/opening-evidence-regressions.test.ts`
- `tests/unit/review-outbox-regressions.test.ts`

**Ordered steps**

1. Use strict confirmation for the guided marker with queue-fail:${logicalAttemptId}, teaching with record.requestId, Study command with record.requestId, failure outbox with the persisted operationId, and checkpoint with the already frozen operationKey.
2. Remove the teaching/Study-command ad hoc initial-202 identity branches once the canonical entry enforces both absence and mismatch. Keep their domain acknowledgments, dependent-self-assessment ordering and authoritative generation checks.
3. Preserve background headers, injected fetch/client selection, abort/deadline behavior and the same stored checkpoint body. S05 may refactor the journal only after this exact call-site patch is released.
4. Add parameterized missing/foreign-202 cases to each affected owning suite. For the guided marker, prove marker failure never counts as a review receipt and the later genuine review still follows its existing advisory-marker policy.
5. Report each caller and expected-key expression in the handoff; do not infer one generic key from record.attemptId.

**Acceptance**

- All five journal families preserve original key/payload and emit no foreign status GET on an invalid initial acknowledgment.
- Checkpoint replay uses the frozen hash key and original bytes even after later journal events exist.
- Teaching confirmation still matches cardId/revision/ply/taughtAt; Study command confirmation still matches original attempt/domain receipt.
- No invalid acknowledgment produces committed/discarded/confirmed progression except an independently valid original terminal receipt.

**Selected future commands**

- `npm run test:unit -- tests/unit/teaching-state-outbox-regressions.test.ts tests/unit/study-command-client-capability.test.ts tests/unit/training-failure-outbox-regressions.test.ts tests/unit/opening-evidence-regressions.test.ts tests/unit/review-outbox-regressions.test.ts`
- `npm run typecheck:browser`

**Shared release qualification**

- integration owner / P12 and P16: On the assembled candidate, one real saved review -> original operation receipt -> authoritative playable successor; inject wrong/missing initial 202 identity and lost acknowledgment, then recover only the original receipt. Reuse tests/browser/study-recovery.spec.ts; add a named fault case. Unit mocks do not establish this claim.

**Risk:** Changing key suffixes or consuming one authority response after a generation change would sever recovery. The review marker is advisory and must retain that distinction.

**Excludes:** No storage format changes; No S05 journal lifetime changes; No runtime registration refactor yet.

### C12 — Bind repertoire-edit confirmations and retained annotation save to original keys

**Findings:** FE001. **Prior tasks:** C01, Q0. **Milestone:** 1. **Prerequisites:** C10. **Release:** `AUTHORING_ORIGINAL_IDS_RELEASED`.

**Read first**

- `AGENTS.md` — current scope, ownership and minimum real proof; distinguish implemented/tested/assembled/installed
- `SPEC.md` — current November 10 reduction scope and retained ordinary Study preservation
- `docs/testing.md` — smallest relevant proof and supported owned runner
- `app/lib/analysis-paste-command.ts` — save pasted-analysis command; retained repertoire-edit path
- `app/lib/branch-command.ts` — saveBranchCommand
- `app/lib/branch-removal-command.ts` — remove branch command
- `app/lib/card-revision-command.ts` — revision pending record and result schema
- `app/lib/prefix-split-command.ts` — decidePrefixSplit; manual split remains supported
- `app/utils/position-annotations.ts` — savePositionAnnotation; retained helper has no known mounted save consumer

**Write reservation**

- `app/lib/analysis-paste-command.ts`
- `app/lib/branch-command.ts`
- `app/lib/branch-removal-command.ts`
- `app/lib/card-revision-command.ts`
- `app/lib/prefix-split-command.ts`
- `app/utils/position-annotations.ts`
- `tests/unit/analysis-paste-pending-regressions.test.ts`
- `tests/unit/branch-command-pending-regressions.test.ts`
- `tests/unit/branch-removal-pending-regressions.test.ts`
- `tests/unit/card-revision-pending-regressions.test.ts`
- `tests/unit/prefix-split-pending-regressions.test.ts`
- `tests/unit/position-annotation-pending-regressions.test.ts`

**Ordered steps**

1. At each initial command response, pass the exact pending.operationId to confirmOriginalOperationResponse. Preserve every existing body comparison, pending/blocked handling, endpoint and domain-result validation-before-clear.
2. Add a compact missing/foreign-202 pair to each owning suite. Check the persisted pending record is byte-equivalent, no foreign receipt URL is called, and a retry with the original acknowledgment resolves using the same body.
3. Keep manual prefix split endpoint work with the backend prefix owner. This is only transport identity adoption; do not reimplement split policy or wait for its heavy proof to land this source patch.
4. Preserve annotation read/shape helpers. Retained save can safely use the strict API without claiming a new supported authoring UI.

**Acceptance**

- Every listed durable caller supplies its original saved operation ID before polling.
- Wrong/malformed complete domain payloads still retain pending commands; own completion still clears once.
- No removal or revival is inferred from the legacy word analysis in a retained repertoire command filename.

**Selected future commands**

- `npm run test:unit -- tests/unit/analysis-paste-pending-regressions.test.ts tests/unit/branch-command-pending-regressions.test.ts tests/unit/branch-removal-pending-regressions.test.ts tests/unit/card-revision-pending-regressions.test.ts tests/unit/prefix-split-pending-regressions.test.ts tests/unit/position-annotation-pending-regressions.test.ts`
- `npm run typecheck:browser`

**Shared release qualification**

- P06/P12 integration owner: Exercise current manual split once after backend routes are restored; no extra whole-stack run for the annotation helper. Shared original-ID browser fault case covers transport lifecycle.

**Risk:** This is mostly call-site work but using a new UUID or fresh UI payload during retry would invalidate retained operations.

**Excludes:** No retired authoring UI restoration; No backend main.py edits; No new generic command framework.

### C13 — Bind deletion and repertoire settings acknowledgments; validate rename completion

**Findings:** FE001. **Prior tasks:** C01, Q0. **Milestone:** 1. **Prerequisites:** C10. **Release:** `ENTITY_ORIGINAL_IDS_RELEASED`.

**Read first**

- `AGENTS.md` — current scope, ownership and minimum real proof; distinguish implemented/tested/assembled/installed
- `SPEC.md` — current November 10 reduction scope and retained ordinary Study preservation
- `docs/testing.md` — smallest relevant proof and supported owned runner
- `app/lib/card-delete-command.ts` — delete resultSchema and pending.operationId
- `app/lib/repertoire-delete-command.ts` — deletedRepertoireSchema and retained learnedCards choice
- `app/lib/repertoire-rename-command.ts` — renameRepertoireCommand currently clears unchecked complete.response
- `backend/app/repertoire_commands.py` — rename_repertoire returns {id: repertoire_id, name}
- `app/lib/repertoire-settings-save.ts` — saveRepertoireLimit validateResult

**Write reservation**

- `app/lib/card-delete-command.ts`
- `app/lib/repertoire-delete-command.ts`
- `app/lib/repertoire-rename-command.ts`
- `app/lib/repertoire-settings-save.ts`
- `tests/unit/card-delete-pending-regressions.test.ts`
- `tests/unit/repertoire-delete-pending-regressions.test.ts`
- `tests/unit/repertoire-rename-pending-regressions.test.ts`
- `tests/unit/repertoire-daily-limits.test.tsx`

**Ordered steps**

1. Use strict original-ID confirmation for all four command families, retaining their existing original payloads and delete choices.
2. Add the small rename acknowledgment schema matching the real producer: object with id/name. Validate both receipt-first and newly sent completion against the pending repertoireId and name before clearing.
3. Keep deletion and per-repertoire-settings identity/value validation; do not weaken it to generic response.ok.
4. Add absent/foreign initial-ID cases, malformed or wrong-id/name rename completions, and successful retry using the original journal. Release prefix-free file claims independently of C12.

**Acceptance**

- Invalid original acknowledgment or domain result never clears a pending delete, rename or limit write.
- Valid original result settles once and cannot authorize a different entity or later edited name.
- Existing permanent deletion choice and expected revision are preserved exactly; this task executes no real deletion.

**Selected future commands**

- `npm run test:unit -- tests/unit/card-delete-pending-regressions.test.ts tests/unit/repertoire-delete-pending-regressions.test.ts tests/unit/repertoire-rename-pending-regressions.test.ts tests/unit/repertoire-daily-limits.test.tsx`
- `npm run typecheck:browser`

**Risk:** An unchecked rename result was still a source-visible residual beyond the initial-202 probe. Tests must use the real {id,name} producer shape.

**Excludes:** No storage migration; No live CRUD operations; No deletion policy changes.

### C14 — Finish 202 adoption for phone and tactics; remove permissive confirmation entry

**Findings:** FE001. **Prior tasks:** C01, Q0. **Milestone:** 1. **Prerequisites:** C11, C12, C13. **Release:** `ALL_ORIGINAL_IDS_RELEASED`.

**Read first**

- `AGENTS.md` — current scope, ownership and minimum real proof; distinguish implemented/tested/assembled/installed
- `SPEC.md` — current November 10 reduction scope and retained ordinary Study preservation
- `docs/testing.md` — smallest relevant proof and supported owned runner
- `app/lib/offline-training.ts` — performReplayOfflineAttempts: phone-study and phone-assessment; review branch already delegates to evidence-aware confirmation
- `app/lib/training-bury-command.ts` — buryTrainingEntry saved operationId
- `app/lib/tactic-capture-command.ts` — capture_id
- `app/lib/tactical-catalog.ts` — setPackActivation operationId
- `app/views/tactics_view.tsx` — finish full-shell direct request and independent retained request
- `backend/app/main.py` — tactic_attempt default operation ID is tactic-attempt:${attempt_id} when header absent
- `app/lib/operation-status.ts` — temporary permissive confirmation entry
- `tests/unit/operation-status-integration-regressions.test.ts` — obsolete discovery-admission pass-through test

**Write reservation**

- `app/lib/offline-training.ts`
- `app/lib/training-bury-command.ts`
- `app/lib/tactic-capture-command.ts`
- `app/lib/tactical-catalog.ts`
- `app/views/tactics_view.tsx`
- `app/lib/operation-status.ts`
- `tests/unit/offline-training-regressions.test.ts`
- `tests/unit/training-burial-regressions.test.ts`
- `tests/unit/tactic-capture-regressions.test.tsx`
- `tests/unit/tactic-activation-pending-regressions.test.ts`
- `tests/unit/tactics-polish-regressions.test.tsx`
- `tests/unit/operation-status-integration-regressions.test.ts`

**Ordered steps**

1. Use phone-study:${attempt.attemptId} only for the raw frozen-exercise attempt POST, and phone-assessment:${attempt.attemptId} for its self-assessment. Remove redundant outer confirmation around the already confirmed saveEvidenceAwareReview result; do not guess whether it used aggregate-only.
2. Use the existing burial operationId, tactic capture_id and pack activation operationId. For the remaining direct full-shell tactic response use the actual backend-derived tactic-attempt:${completedAttempt.discoveryId}; an executeStudyRequest result is already confirmed and needs no second poll.
3. After source enumeration finds zero callers of old confirmOperationResponse, delete that permissive export and the stale discovery-specific exception/comment/test. No retained current discovery producer exists; queue GET acceptance stays with its existing decoder.
4. Add missing/foreign-ID tests for phone submit and self-assessment, burial, capture, activation and direct tactic completion. Preserve exact phone IDs and answers, no serverAcknowledged flag, no local tactic progress advancement and no journal removal on the fault.
5. Inspect all /api/operations consumers once: shared decoder or documented adapter, original-ID polling, domain acknowledgment before clearing. Include pgn-import-command and integrity-repair-outbox in this read-only enumeration; do not rewrite their already valid compatibility logic.
6. Release offline-training.ts to C21/C24, training-bury-command.ts to FE32, tactics_view.tsx to FE31 and operation-status.ts to the integration owner.

**Acceptance**

- No production call can confirm an initial durable-command 202 without an expected original ID.
- Legacy receipt identity-optional reads remain supported only where already allowed; new acknowledgment identity is mandatory.
- Wrong initial operation cannot settle phone review/self-assessment or advance tactics, and own-ID recovery completes once.
- Caller inventory is complete, not a grep-based claim that every protocol has identical business validation.

**Selected future commands**

- `npm run test:unit -- tests/unit/operation-status-integration-regressions.test.ts tests/unit/operation-status-study-client-regressions.test.ts tests/unit/offline-training-regressions.test.ts tests/unit/training-burial-regressions.test.ts tests/unit/tactic-capture-regressions.test.tsx tests/unit/tactic-activation-pending-regressions.test.ts tests/unit/tactics-polish-regressions.test.tsx`
- `npm run typecheck:browser`
- `rg -n "confirmOperationResponse|confirmOriginalOperationResponse|/api/operations" app`

**Shared release qualification**

- integration owner / P12 and P16: On the assembled candidate, one real saved review -> original operation receipt -> authoritative playable successor; inject wrong/missing initial 202 identity and lost acknowledgment, then recover only the original receipt. Reuse tests/browser/study-recovery.spec.ts; add a named fault case. Unit mocks do not establish this claim.
- P12/P16: Existing real phone reload/replay and tactic progression after original receipt; one coordinated assembled selection, not a stack per call-site.

**Risk:** Phone helper already resolves fallback identities internally; adding another guessed key would reject valid replay. Pack activation currently has a separate storage-failure policy; changing that policy is outside this identity-only slice.

**Excludes:** No new storage schema; No independent Learning service restoration; No whole-stack test per helper; No FE010 closure merely from helper adoption.

### C20 — Freeze the retained-exercise HTTP and recovery contract before either side changes

**Findings:** FE008. **Prior tasks:** D02. **Milestone:** 1. **Prerequisites:** none. **Release:** `FROZEN_V1_ROUTE_CONTRACT_RELEASED`.

**Read first**

- `AGENTS.md` — current scope, ownership and minimum real proof; distinguish implemented/tested/assembled/installed
- `SPEC.md` — current November 10 reduction scope and retained ordinary Study preservation
- `docs/testing.md` — smallest relevant proof and supported owned runner
- `SPEC.md` — November 10 pass 2: generated exercises frozen ordinary; standalone authoring retired
- `app/views/study_exercise_runner.tsx` — PresentedStudyExercise, AttemptReply, present/feedback, restore/submit/self-assess
- `app/lib/offline-training.ts` — recordOfflineStudyAttempt and performReplayOfflineAttempts
- `backend/app/study_attempt_commands.py` — submit_study_attempt and self_assess_study_attempt
- `backend/app/services/study_attempts.py` — finish_study_attempt result envelope and nested review
- `database/tempo_storage/http_composition/availability.py` — exact retired defense/endgame predicate; frozen published exercise availability
- `database/tempo_storage/ddl/migrations/064_retire_optional_study_producers.sql` — exact retired producer predicates and original operation/record preservation
- `backend/app/main.py` — current mounted application has no four retained exercise routes

**Write reservation**

- `app/domain/study-exercise-transport.ts` (proposed new file)
- `tests/unit/frozen-study-contract.test.ts` (proposed new file)
- `app/features/study/README.md`

**Ordered steps**

1. Write the finite contract table for GET present, POST attempts, POST self-assess and GET feedback. Present fields come from the existing runner shape; attempt completion is the existing finish_study_attempt envelope, including nested review and persisted:true; pending self-assessment is not a completed review. A validated pending_self_assessment:true result is a completed original parent command receipt and must settle its intent as committed so predecessorSettled can release the child. It is not a completed human review and must not advance the card or reviewed count.
2. Publish pure browser decoders for these values. Bind expected study/exercise/revision/attempt where present in the existing route/result contract. Validate FEN/specification projections and array bounds from existing owner contracts; do not render unchecked response casts.
3. Write explicit classifications: current linked published study_exercise is supported frozen ordinary work; old attempt/self-assess with a valid original owner/receipt is retained recovery; exact defense/endgame kinds and ledger-retired producers are held; unknown endpoint/kind/authority is preserved and held. A generic study-command tag alone never means retirement.
4. Use the already established queue -> prepared snapshot -> PracticeCard -> TrainingView reachability as evidence; do not spend another probe deciding whether frozen exercises exist. No live user-data inventory is needed to restore the missing retained capability.
5. Agree B31 route projections and error/hold detail codes with the backend owner in the same handoff. Present must not reveal accepted move lines, required/optional answers, correct options, explanation or rubric; feedback must bind the persisted attempt revision. Preserve all existing attempt IDs, queue identity and request hash semantics.
6. Keep v1 grading semantics and wire bodies in this baseline. Grader version decisions C22-C24 follow, rather than blocking the four-route repair.

**Acceptance**

- Four exact method/path/response contracts and current consumers are listed; backend B31 can implement without inventing a new workflow.
- Pure tests distinguish malformed200, wrong exercise/revision/attempt, genuine pending self-assessment, completed persisted review, retired hold and transport failure.
- Nothing creates/enrolls/edits chapters or exercises or dispatches providers/analysis.
- D02 classification is concrete and released; source reachability is established but assembled completion is not yet claimed.
- Parent command completion and human-review completion are separate: pending self-assessment commits the parent intent, permits only its dependent child, and does not advance the queue.

**Selected future commands**

- `npm run test:unit -- tests/unit/frozen-study-contract.test.ts`
- `npm run typecheck:browser`

**Risk:** The old frontend types omit nested review fields and cast unchecked JSON. New contract must mirror existing handler results, not normalize pending self-assessment into success.

**Excludes:** No backend route implementation here; No main.py edits; No creation/enrollment/PGN-preview restoration; No reclassification of every study-command as retired.

### C21 — Wire supported frozen exercises and preserve held retained work without queue-wide failure

**Findings:** FE008. **Prior tasks:** D02. **Milestone:** 1. **Prerequisites:** C20, B31, C14. **Release:** `FROZEN_BROWSER_RECOVERY_RELEASED`.

**Read first**

- `AGENTS.md` — current scope, ownership and minimum real proof; distinguish implemented/tested/assembled/installed
- `SPEC.md` — current November 10 reduction scope and retained ordinary Study preservation
- `docs/testing.md` — smallest relevant proof and supported owned runner
- `app/views/training_view.tsx` — mounted StudyExerciseRunner for kind study
- `app/views/study_exercise_runner.tsx` — presentation load, retained restore, revealFeedback, submit, self-assess
- `app/lib/study-command-client.ts` — requireRetainedCommand, createStudyCommandDelivery, recoverStudyRequests
- `app/lib/offline-training.ts` — performReplayOfflineAttempts; current non-409 failure aborts remaining pass
- `app/lib/study-client.ts` — learningPaths allowlist and authority generation
- `app/domain/study-exercise-transport.ts` — C20 decoded supported/held response contract (new dependency file from C20)

**Write reservation**

- `app/views/study_exercise_runner.tsx`
- `app/lib/study-command-client.ts`
- `app/lib/offline-training.ts`
- `app/domain/study-exercise-transport.ts` (proposed new file)
- `tests/unit/study-attempt-pending-regressions.test.tsx`
- `tests/unit/study-command-client-capability.test.ts`
- `tests/unit/offline-training-regressions.test.ts`
- `tests/unit/retained-frozen-exercise-recovery.test.tsx` (proposed new file)

**Ordered steps**

1. Replace present/feedback/attempt/self-assess raw casts with C20 decoders. Keep UI loading/save/feedback errors recoverable and preserve generation, original attempt and practice boundary fences.
2. When the original attempt receipt contains pending_self_assessment:true, commit that parent command intent after validation, keep the human attempt pending, and recover the same dependent self-assessment only then. Do not leave the parent intent pending or predecessorSettled will deadlock the child; do not count the parent command as a saved human review.
3. Use exact supported endpoint/kind classification before POST. Receipt-first recovery may inspect the original operation even for held/unknown records, but absence of a receipt never authorizes sending to an unsupported route.
4. For known retired kinds, unsupported authoring endpoints, ambiguous identity and legacy needs_analysis receipts, expose a useful held result containing the original record identity. Preserve stored body/key/revision/receipt bytes; do not mark committed or discarded and do not call a removed endpoint or optional analysis worker.
5. Continue bounded round-robin generic recovery past held unrelated records. For phone replay, retain existing same-card/parent dependency ordering and conflict semantics, but an explicitly classified retired/ambiguous exercise must not abort unrelated later supported attempts. Scope notifications to the retained record.
6. Supported frozen online saves, old generic intent recovery, old phone attempts and dependent self-assessments all use the B31 routes and original operation IDs. A stored offline snapshot does not substitute for current online authority when connected.
7. Add a mixed retained-work fixture: supported frozen move-line + self-assessed explanation, retired defense/endgame, unknown legacy endpoint, and unrelated current opening/tactic review. Prove only supported requests dispatch and unrelated work completes.
8. Give FE06/FE30 the exact allowlist delta as a handoff rather than concurrently editing study-client.ts. Keep original-authority recovery and export available.
9. Add a three-stage regression: unconfirmed/foreign parent202 leaves its child unsent; the valid original parent complete receipt with pending_self_assessment:true commits only the parent and releases the same child; only the valid original completed child review advances/counts once. A foreign/malformed child receipt leaves the human attempt pending; repeated parent/child receipt recovery cannot duplicate a review.

**Acceptance**

- No active supported frozen consumer calls a missing route; malformed payloads and revision/identity changes remain recoverable holds.
- Retired/ambiguous records remain inspectable and byte-preserved, receive no fabricated acknowledgment, and do not prevent unrelated valid Study.
- Self-assessment is sent only after its original parent receipt is confirmed; replay/reload never creates a replacement attempt.
- Actual saved review, feedback and playable successor require the shared B31/P12 assembled proof; passing component mocks alone do not close FE008.
- A parent receipt awaiting self-assessment is committed at the command coordinator, its child becomes eligible, and neither card advancement nor reviewed count occurs until the validated finished review.

**Selected future commands**

- `npm run test:unit -- tests/unit/study-command-client-capability.test.ts tests/unit/study-intent-storage-regressions.test.ts tests/unit/study-attempt-pending-regressions.test.tsx tests/unit/offline-training-regressions.test.ts tests/unit/retained-frozen-exercise-recovery.test.tsx`
- `npm run typecheck:browser`

**Shared release qualification**

- B31 + P12/P16 integration owner: One current frozen move-line through real present -> original attempt command -> persisted feedback -> playable next, one existing phone attempt and one pending self-assessment reload/replay. Include retired/ambiguous nonblocking hold and exact-once receipt/history assertions. Add current frozen browser case; do not resurrect retired authoring browser journey.

**Risk:** Known held work can be skipped across unrelated cards; dependent same-card/self-assessment records cannot be reordered. HTTP404 is not evidence that a saved record is safe to discard.

**Excludes:** No blanket study-command retirement; No automatic record migration/rewrite; No new authoring/provider/engine systems; No silent 404 skip or generic success.

### C22 — Choose and document bounded grader-v1 compatibility; repair the pure Python test owner

**Findings:** FE009. **Prior tasks:** D03. **Milestone:** 1. **Prerequisites:** C20. **Release:** `GRADER_V1_COMPATIBILITY_RELEASED`.

**Read first**

- `AGENTS.md` — current scope, ownership and minimum real proof; distinguish implemented/tested/assembled/installed
- `SPEC.md` — current November 10 reduction scope and retained ordinary Study preservation
- `docs/testing.md` — smallest relevant proof and supported owned runner
- `app/domain/study-exercises.ts` — current browser schema/evaluateStudyAnswer accepts SAN and lacks server bounds
- `backend/app/contracts/study_exercises.py` — current Pydantic v1 bounds/defaults
- `backend/app/study/policy/study_grading.py` — GRADER_VERSION=1, validate_exercise, evaluate_answer
- `backend/app/study_attempt_commands.py` — request.model_dump answer hash; existing attempt replay first
- `app/domain/offline-training.ts` — OfflineAttempt lacks grading provenance
- `backend/app/study/queue_serving.py` — exercise_snapshot emits schema_version1/grader_version1
- `backend/tests/test_studies.py` — retained golden test mixed with removed app.studies.pgn preview import/test
- `tests/fixtures/study-grading.json` — 15 current outcome-only vectors

**Write reservation**

- `backend/app/study/policy/README.md`
- `app/features/study/README.md`
- `backend/tests/test_studies.py`
- `tests/fixtures/study-grading.json`

**Ordered steps**

1. Record the recommended preservation decision: the current Python v1 acceptance/grading path remains authoritative for historical and retained v1 work. Repair browser behavior to that existing semantic contract; identify new browser conformance with a separate implementation revision, not an invented claim that old browser v1 was already equivalent.
2. Define new local provenance as server_contract_version:1 plus browser_implementation_revision:2 (names may follow existing style), recorded only for newly created offline attempts. Missing old provenance is displayed/handled as legacy_unknown, never backfilled by reading or regraded silently.
3. Explicitly freeze existing v1 quirks as compatibility: UCI-only move evaluation; current minimum/maximum arrays and defaults; duplicate selected choices invalid; displayed_order semantics as currently implemented by Python (set equality, not a new uniqueness rule); exact/at-most knight routes; explanation readiness and self-assessment. Different parser rejection versus invalid_submission versus unrecognized are observable outcomes.
4. If an owner deliberately changes Python acceptance (for example stricter displayed_order duplicate handling or globally strict scalar coercion), choose a real grader/schema v2 with a separate versioned path before coding that change. Do not silently stamp changed policy as v1. This optional alternative is not needed to finish the default fix.
5. Rebind backend/tests/test_studies.py: preserve the named golden grader test, remove only the import and obsolete PGN-preview test for deleted app.studies.pgn. Do not restore the module and do not run the mixed stale suite as though valid. Notify inventory owner T02 of the retired named case.
6. Extend the fixture format additively with named expected validation stage and semantic result fields; keep the existing 15 v1 cases unchanged. C23 owns the new comprehensive vectors and runtime adoption.

**Acceptance**

- One written compatibility decision states canonical current semantics, new implementation provenance, old missing-provenance handling and the explicit trigger for a real v2.
- Old attempt/request hashes and persisted grader_version values are unchanged; this task adds no default field to StudyAttemptRequest/model_dump.
- backend/tests/test_studies.py is a runnable pure grader suite with no deleted producer import; retained named cases remain.
- Policy decision is a proposed implementation default grounded in current semantics, not a claim of new user-approved grading behavior.

**Selected future commands**

- `make python-file FILE=backend/tests/test_studies.py`
- `npm run test:unit -- tests/unit/study-exercise-grading.test.ts`

**Risk:** Adding even a default-null provenance field to the hashed request model can break retry identity. A version bump that merely relabels old records is also unsafe.

**Excludes:** No grader modernization; No record rewrite/backfill; No PGN preview restoration; No FSRS policy changes; No new versioned endpoint unless genuine semantic change is separately selected.

### C23 — Align browser grading and validation to current Python v1 using shared boundary vectors

**Findings:** FE009. **Prior tasks:** D03. **Milestone:** 1. **Prerequisites:** C22. **Release:** `GRADER_V1_PARITY_RELEASED`.

**Read first**

- `AGENTS.md` — current scope, ownership and minimum real proof; distinguish implemented/tested/assembled/installed
- `SPEC.md` — current November 10 reduction scope and retained ordinary Study preservation
- `docs/testing.md` — smallest relevant proof and supported owned runner
- `app/domain/study-exercises.ts` — studySpecificationSchema, studyAnswerSchema, studySnapshotSchema, availableKnightRoutes, evaluateStudyAnswer
- `backend/app/contracts/study_exercises.py` — all v1 specification/answer models
- `backend/app/study/policy/study_grading.py` — validate_exercise and evaluate_answer; authoritative unchanged policy
- `tests/fixtures/study-grading.json` — shared schema/outcome vectors
- `tests/unit/study-exercise-grading.test.ts` — current outcome-only driver
- `backend/tests/test_studies.py` — C22 pure fixture driver

**Write reservation**

- `app/domain/study-exercises.ts`
- `tests/fixtures/study-grading.json`
- `tests/unit/study-exercise-grading.test.ts`
- `backend/tests/test_studies.py`

**Ordered steps**

1. Change only browser parsing/evaluation and shared test drivers to conform to current Python v1. Parse UCI explicitly before chess.js evaluation: SAN such as Nf3 is invalid_submission under v1 even if chess.js can execute it. Never normalize a retained answer from SAN to UCI before replay.
2. Cover schema-stage array limits from the real models: move answers 1..40, square answers 0..64, knight answer path 0..4, choices 1..12/displayed order0..12; accepted lines1..20, options2..12, targets1..8, hop counts0..3. Include text/default/extra-field/scalar cases where runtime parsers currently differ. Do not add guessed bounds to inner accepted lines, candidate_region or correct_option_ids that the current server does not impose.
3. Implement the server validate_exercise invariants for the browser path that uses frozen snapshots: legal board/UCI accepted lines, square rubric uniqueness/disjointness/region coverage, actual starting knight, ordered hop bounds, target uniqueness and option/correct-ID validity.
4. Fixture runner must distinguish specification schema rejection, specification semantic invalidity, answer schema rejection, and returned assessment. Compare full semantic assessment (outcome and omitted/extra/outside_region; feedback strings where part of existing contract), not just an outcome boolean.
5. Add positive/negative edge vectors: 0/max/over-limit arrays; SAN/legal UCI/illegal UCI/promotion; repeated squares/option IDs; empty and duplicated displayed_order under existing server behavior; knight zero hops, exact/at-most, static occupied destinations/start return, unreachable with nonempty path; explanation ready=false and self-assessment.
6. Keep the old v1 server implementation intact. If a current Python result is surprising, encode it as compatibility and report it; do not quietly change both implementations until tests agree.

**Acceptance**

- Both current runtimes produce the same accepted/rejected stage and semantic assessment for the shared comprehensive v1 corpus.
- Existing 15 vectors remain valid; illegal/SAN differences and array-bound mismatches have named negative regressions.
- No persistence, scheduler or transport changes are mixed into pure grading.
- An unsupported snapshot/version is held explicitly by callers, not cast into v1.

**Selected future commands**

- `npm run test:unit -- tests/unit/study-exercise-grading.test.ts`
- `make python-file FILE=backend/tests/test_studies.py`
- `npm run typecheck:browser`

**Risk:** Python defaults/coercions and TS strict validation differ; matching only currently emitted UI answers would miss replay/schema compatibility. Tightening Python to make matching easier is outside this slice.

**Excludes:** No v1 server semantic change; No optional analysis/open-judgment service; No automatic old-record regrading; No native/whole-stack gate for pure parity alone.

### C24 — Record new offline grading provenance and reconcile retained v1 answers without rewriting them

**Findings:** FE009, FE008. **Prior tasks:** D03, D02. **Milestone:** 1. **Prerequisites:** C23, C21. **Release:** `GRADER_PROVENANCE_REPLAY_RELEASED`.

**Read first**

- `AGENTS.md` — current scope, ownership and minimum real proof; distinguish implemented/tested/assembled/installed
- `SPEC.md` — current November 10 reduction scope and retained ordinary Study preservation
- `docs/testing.md` — smallest relevant proof and supported owned runner
- `app/domain/offline-training.ts` — OfflineAttempt answer/assessment/selfRating
- `app/lib/offline-training.ts` — recordOfflineStudyAttempt, recordOfflineAttempt, performReplayOfflineAttempts
- `app/views/study_exercise_runner.tsx` — offline local assessment and self-assessment
- `backend/app/study_attempt_commands.py` — existing attempt answer hash and v1 assessment
- `backend/app/services/study_attempts.py` — persisted server result authority

**Write reservation**

- `app/domain/offline-training.ts`
- `app/lib/offline-training.ts`
- `app/views/study_exercise_runner.tsx`
- `tests/unit/offline-training-regressions.test.ts`
- `tests/unit/study-attempt-pending-regressions.test.tsx`
- `tests/unit/study-exercise-grading.test.ts`

**Ordered steps**

1. Attach C22 provenance only when a new offline frozen-exercise attempt is durably retained. Snapshot semantic version remains1; the separate browser implementation revision identifies corrected conformance. Preserve old objects/answers without adding a guessed provenance value.
2. Expose a pure read classification for legacy_unknown/current/supported-other/unsupported provenance. Existing server receipts remain authoritative; never overwrite historical local assessment, original answer, selfRating, request/attempt ID or retained revision to manufacture parity.
3. Replay the original answer and existing wire body under the same phone-study/phone-assessment IDs. Do not insert provenance into StudyAttemptRequest or its answer-hash input in the default compatibility policy.
4. If legacy local assessment differs from current server v1 result, preserve both facts and publish the existing warning/conflict/held treatment. A definitive invalid_submission is a visible retained rejection/hold and does not fabricate a review; a genuine persisted server receipt may settle its own original attempt once. Dependent same-card repeats follow the actual server requeue result.
5. Unsupported or ambiguous provenance must not block unrelated current attempts; reuse C21 scoped hold/recovery behavior. Never silently run all old answers through the corrected grader during storage load.
6. Test current provenance, missing provenance, old SAN saved as local unrecognized but server invalid, zero-length legacy answer, genuine self-assessment, duplicate replay, and an unrelated valid review later in the same pass.

**Acceptance**

- Every newly retained offline frozen answer identifies the grader contract and browser implementation used.
- Legacy records keep original identity/answer/rating/assessment/revision bytes; missing version remains honestly unknown.
- No review count or queue advancement occurs solely because local grading once said correct; original server receipt is required on replay.
- Exactly-once phone retry and self-assessment still work under current v1; explicit mismatch is inspectable and scoped.

**Selected future commands**

- `npm run test:unit -- tests/unit/offline-training-regressions.test.ts tests/unit/study-attempt-pending-regressions.test.tsx tests/unit/study-exercise-grading.test.ts`
- `npm run typecheck:browser`

**Shared release qualification**

- P12/P16 + B31: Real IndexedDB reload and actual HTTP replay of one new conformant frozen answer and one old missing-provenance retained answer, with stable IDs/body and server review counts. One self-assessed record; one invalid/retired record cannot stall unrelated valid Study.

**Risk:** Legacy local projections can differ from authoritative grading. Retrying under a new key or rewriting the answer would create a new operation and corrupt history.

**Excludes:** No blanket retained-record rewrite; No inferred old provenance; No default field in backend request hash; No server policy/version change; No provider analysis.

### FE05 — Hold foreign authority cutover when an inspected retained store is unknown and nonempty

**Findings:** FE005. **Prior tasks:** C02. **Milestone:** 1. **Prerequisites:** none. **Release:** `UNKNOWN_STORE_FACTS_RELEASED`.

**Read first**

- `AGENTS.md` — current scope, ownership and minimum real proof; distinguish implemented/tested/assembled/installed
- `SPEC.md` — current November 10 reduction scope and retained ordinary Study preservation
- `docs/testing.md` — smallest relevant proof and supported owned runner
- `database/browser/study-connection-storage.ts` — readRetainedStudyData; inspectRetainedStudyAuthority
- `app/domain/study-authority.ts` — RetainedWorkFact and RetainedAuthorityInspection
- `app/lib/study-client.ts` — assertStudyAuthority existing resume/recover/cutover policy
- `tests/unit/study-learning-connection-regressions.test.ts` — authority transition and malformed foreign storage cases
- `tests/unit/study-client-factory-regressions.test.ts` — semantic fake storage

**Write reservation**

- `database/browser/study-connection-storage.ts`
- `tests/unit/study-learning-connection-regressions.test.ts`
- `tests/unit/study-client-factory-regressions.test.ts`

**Ordered steps**

1. Enumerate recognized stores separately for tempo-study-intents and offline-training formats. Nonempty additional stores must yield disposition unknown; an empty unknown store does not alone prove retained work. Do not classify known metadata/teaching/event stores as unknown merely because they are not intent queues.
2. For a named offline authority retain the already decoded database authority; for an unrecognized/global store without an established binding emit authority null. Do not infer trusted authority from arbitrary row fields in an unknown format.
3. Keep assertStudyAuthority unchanged and test its exact matrix: terminal facts never block; nonterminal facts bound to the target authority do not block; cutover rejects foreign or authority-null facts; registered resume/recover tolerates facts bound to other registered authorities but still rejects authority-null/unregistered foreign facts. The new global unknown-store fact intentionally holds such transitions; do not promise all same-authority resumes remain allowed. Existing normal-build requests do not call this guard per request; do not add a product-wide lock.
4. Promote the deep-review nonempty unknown-store probe into the owning suite. Include unknown global/foreign/current/registered cases and preserve original keys/values/raw export.
5. Check known terminal-only intents and acknowledged phone records still permit cutover, and known nonterminal records still block it. No upgrade transaction, deletion, or write is performed during inspection.

**Acceptance**

- A nonempty unrecognized foreign store can no longer look like empty retained work.
- Read-only inspection and raw export leave original entries/keys intact, including malformed values.
- Terminal-only recognized data, same-authority-bound unknown facts, registered foreign recovery and authority-null unknown facts obey the explicit transition matrix. Original raw bytes remain intact.
- Empty/missing database detection, blocked connections and incompatible schemas remain truthful storage errors.

**Selected future commands**

- `npm run test:unit -- tests/unit/study-learning-connection-regressions.test.ts tests/unit/study-client-factory-regressions.test.ts tests/unit/operation-status-study-client-regressions.test.ts`
- `npm run typecheck:browser`

**Shared release qualification**

- integration owner/P16: One real IndexedDB reconnect/cutover test with unknown retained data and reload; no PostgreSQL stack required for this storage boundary.

**Risk:** Synthetic future-store gap exists on both inspected revisions. Overbroad unknown facts could strand same-authority recovery; underbroad facts permit unsafe cutover.

**Excludes:** No registry redesign; No record rewriting; No authority-policy change; No new browser database version.

### FE06 — Move physical authority registry layout and database naming into the storage adapter

**Findings:** FE005. **Prior tasks:** C02, C03. **Milestone:** 1. **Prerequisites:** FE05. **Release:** `AUTHORITY_ADAPTER_CONTRACT_RELEASED`.

**Read first**

- `AGENTS.md` — current scope, ownership and minimum real proof; distinguish implemented/tested/assembled/installed
- `SPEC.md` — current November 10 reduction scope and retained ordinary Study preservation
- `docs/testing.md` — smallest relevant proof and supported owned runner
- `app/lib/study-client.ts` — StudyClientStorage, offlineDatabaseFor, authorities, retainedStudyData, connectStudyWithAuthority
- `app/domain/study-authority.ts` — semantic retained facts
- `database/browser/study-connection-storage.ts` — authority registry read/write and retained database inspection
- `app/lib/study-connection.ts` — browserStorage and defaultStudyClient composition
- `tests/unit/study-client-factory-regressions.test.ts` — inert factory and isolated clients

**Write reservation**

- `app/domain/study-authority.ts`
- `database/browser/study-connection-storage.ts`
- `app/lib/study-client.ts`
- `app/lib/study-connection.ts`
- `tests/unit/study-client-factory-regressions.test.ts`
- `tests/unit/study-learning-connection-regressions.test.ts`
- `tests/unit/operation-status-study-client-regressions.test.ts`

**Ordered steps**

1. Publish independently declared semantic AuthorityIdentity/RegisteredAuthority facts and a storage port: read registered origin/workspace identities, bind an authority, inspect retained work, export retained bytes, and supply an opaque offline-store locator to composition. Keep semantic authority identity and transition rules in the client.
2. Move tempo-offline-training naming, offlineDatabase registry-field parsing/validation and JSON serialization behind the existing browser storage adapter. Keep the exact v1 registry keys, database names and bytes; read/validate old registry without migration.
3. Have storage inspection discover its registered database names internally instead of receiving a client callback that exposes physical registry fields. The client supplies semantic authority descriptors only.
4. Preserve session credential storage behavior and opt-in restoration. Do not conflate session secrets with the non-secret authority registry; preserve malformed-registry holds and double authority check around bootstrap.
5. Update composition and fake-port tests. Demonstrate a client backed by an in-memory semantic registry with no IndexedDB names, raw JSON registry or physical offlineDatabase property.
6. Release the semantic contract to S03/S04 storage factory work. The storage owner may later parameterize handles; it must consume this port rather than moving the physical layout back to app policy.

**Acceptance**

- study-client.ts contains no physical database/object-store names, offlineDatabase casts, registry JSON parse/stringify or storage-layout rules.
- Factory import remains inert; two clients retain isolated credentials, generation fences, bodies and notifications.
- Reload/resume/recover/cutover outcomes and byte-preserving export are unchanged except FE05 accepted unknown-store correction.
- Existing registry bytes are read compatibly; no automatic rebinding, store rename or data migration.

**Selected future commands**

- `npm run test:unit -- tests/unit/study-client-factory-regressions.test.ts tests/unit/study-learning-connection-regressions.test.ts tests/unit/operation-status-study-client-regressions.test.ts`
- `npm run typecheck:browser`

**Shared release qualification**

- P16: Reuse FE05 real IndexedDB reconnect/reload selection; this refactor does not require an unrelated database/server proof.

**Risk:** Authority registration and bootstrap can race with another tab. Moving parsing must preserve both checks and original recovery semantics, not introduce a generic registry framework.

**Excludes:** No new storage service; No C03 reimplementation; inert import already accepted; No new credentials/authentication design; No ST003/ST004 closure by relocation alone.

### FE08 — Publish pure validation facts while retaining the current browser collector facade

**Findings:** FE007. **Prior tasks:** Q0. **Milestone:** 1. **Prerequisites:** none. **Release:** `PURE_VALIDATION_CONTRACT_RELEASED`.

**Read first**

- `AGENTS.md` — current scope, ownership and minimum real proof; distinguish implemented/tested/assembled/installed
- `SPEC.md` — current November 10 reduction scope and retained ordinary Study preservation
- `docs/testing.md` — smallest relevant proof and supported owned runner
- `app/lib/data-validation.ts` — parseData, validRecords, recordIdentity, reportDataDiagnostic and mutable diagnostics/listeners
- `app/lib/validated-data.ts` — browser parseData/validRecords wrappers and readJsonResponse
- `app/domain/adapters/workspace-adapters.ts` — current effectful domain dependency
- `app/domain/adapters/practice-card-adapters.ts` — second effectful domain dependency, including direct reportDataDiagnostic calls

**Write reservation**

- `app/domain/validation.ts` (proposed new file)
- `app/lib/data-validation.ts`
- `app/lib/validated-data.ts`
- `tests/unit/pure-validation-contract.test.ts` (proposed new file)
- `tests/unit/validated-data-regressions.test.ts`

**Ordered steps**

1. Publish ValidationIssue and ValidationEffects/reporter types in app/domain/validation.ts. Extract record identity, Zod issue formatting and value/list parsing there. The module must have no collector singleton, listeners, Date/clock, queueMicrotask, debug reporting or browser dependency.
2. Give pure callers a result/throw contract with explicit optional diagnostic/reporting capabilities; no capability means no publication. Preserve existing error wording, record identity priorities and successful values. An injected effect is the caller's explicit choice, never imported global state.
3. Keep app/lib/data-validation.ts as the owning collector adapter: bounded history, deduplication, timestamps, subscriptions and the existing public parse signatures delegate to the pure implementation with explicit collector effects. Keep validated-data.ts adding reportDebugError. Existing runtime callers therefore remain behaviorally stable before FE09/FE10.
4. Add tests exercising parse/list filtering with no sink, an explicit fake sink, suppressed publication, duplicate bad records and original Error/context shape. Guard time/microtask/global reporter access during pure execution.
5. Release this independently declared contract to FE09 and storage S03/S04; do not move browser registry/storage policy into the new module.

**Acceptance**

- The new pure module can execute malformed and successful inputs without mutating diagnostics or reading time.
- Existing browser collector behavior remains through the compatibility facade until explicit consumer migration.
- Domain parsing semantics and public reporter/error fields are concrete and documented; this task alone does not claim FE007 closure.

**Selected future commands**

- `npm run test:unit -- tests/unit/pure-validation-contract.test.ts tests/unit/validated-data-regressions.test.ts`
- `npm run typecheck:browser`

**Risk:** Changing collector behavior while extracting pure logic can hide existing validation warnings. Preserve the facade first, then migrate domain callers explicitly.

**Excludes:** No schema acceptance change; No diagnostics framework; No domain adapter migration in this slice; No full-stack requirement.

### FE09 — Adopt pure validation in both domain adapters and computation contracts

**Findings:** FE007. **Prior tasks:** Q0. **Milestone:** 1. **Prerequisites:** FE08. **Release:** `DOMAIN_VALIDATION_ADOPTION_RELEASED`.

**Read first**

- `AGENTS.md` — current scope, ownership and minimum real proof; distinguish implemented/tested/assembled/installed
- `SPEC.md` — current November 10 reduction scope and retained ordinary Study preservation
- `docs/testing.md` — smallest relevant proof and supported owned runner
- `app/domain/adapters/workspace-adapters.ts` — repertoireLinesFromPayload, validateWorkspacePayload
- `app/domain/adapters/practice-card-adapters.ts` — queueRecordWithCompatibleOpeningEvidence, mapQueueCardToPracticeCard, mapPackagedPuzzleToPracticeCard, queueCardsFromPayload
- `app/lib/essential-study-computation.ts` — computeEssentialStudyTask
- `app/lib/optional-study-computation.ts` — computeOptionalStudyTask
- `app/lib/study-result-decoder.ts` — decodeStudyResult
- `app/domain/validation.ts` — FE08 pure contract (new dependency file from FE08)

**Write reservation**

- `app/domain/adapters/workspace-adapters.ts`
- `app/domain/adapters/practice-card-adapters.ts`
- `app/lib/essential-study-computation.ts`
- `app/lib/optional-study-computation.ts`
- `app/lib/study-result-decoder.ts`
- `tests/unit/domain-validation-boundary.test.ts` (proposed new file)
- `tests/unit/study-worker-regressions.test.ts`
- `tests/unit/position-study-worker-result.test.ts`

**Ordered steps**

1. Replace every domain import from app/lib/data-validation with the FE08 pure types/functions. Cover both adapters, including direct invalid-opening-evidence, position-presentation and queue-record diagnostics in practice-card-adapters.
2. Thread the explicit effects contract through each domain adapter and the essential/optional computation and result-decoder functions. Preserve optional reporter compatibility at public wrappers where needed; do not import the collector to manufacture a default.
3. Preserve queue record compatibility, unknown workspace URL pass-through, partial valid-record filtering, mapping/card identity and shouldPublishDiagnostics fencing. Unsupported optional records remain invalid records; they do not become successful empty datasets.
4. Update pure computation tests to inject a recorder when they assert diagnostics. Add direct negative tests for both adapters: invalid input cannot touch the global collector, while an injected sink receives the expected raw record/source/identity.
5. Hand T03 the exact allowed pure module and neutral @tempo/board-ui type import. No app/domain -> app/lib or app/components dependency remains, even type-only. FE10 supplies runtime collector composition.

**Acceptance**

- Both current effectful domain dependencies are removed, including direct diagnostic calls in practice-card-adapters.
- Computation/result-decoder signatures expose all validation effects and can run without browser diagnostics.
- Old returned values, error messages, filtering and identity fences are preserved.
- Guard owner T03 can install negative controls without an exception for data-validation.

**Selected future commands**

- `npm run test:unit -- tests/unit/domain-validation-boundary.test.ts tests/unit/study-worker-regressions.test.ts tests/unit/position-study-worker-result.test.ts tests/unit/validated-data-regressions.test.ts`
- `npm run typecheck:browser`

**Shared release qualification**

- T03: Reject runtime and type-only app/domain -> effectful app/lib or app/components; allow neutral board-ui type-only imports and distinguish them from startup runtime dependencies.

**Risk:** Migrating only workspace-adapters would leave the same FE007 violation in practice-card-adapters. A hidden default sink would preserve the architectural defect.

**Excludes:** No worker topology change; No browser diagnostics removal; No queue semantics change; No guard tooling edits in parallel with T03.

### FE10 — Inject validation collection at worker and browser composition boundaries

**Findings:** FE007. **Prior tasks:** Q0. **Milestone:** 1. **Prerequisites:** FE09, C14. **Release:** `DOMAIN_DIAGNOSTICS_COMPOSITION_RELEASED`.

**Read first**

- `AGENTS.md` — current scope, ownership and minimum real proof; distinguish implemented/tested/assembled/installed
- `SPEC.md` — current November 10 reduction scope and retained ordinary Study preservation
- `docs/testing.md` — smallest relevant proof and supported owned runner
- `app/lib/study-worker-handler.ts` — installStudyWorker; clears collector and returns dataDiagnostics with result
- `app/lib/background-study.ts` — fallback validation/computation and generation-fenced worker diagnostics
- `app/lib/bulk-study.ts` — decodeStudyResult and worker diagnostics replay
- `app/utils/cards.ts` — practiceCardFromQueue, convertPackagedPuzzleRecordIntoPracticeCard
- `app/lib/offline-training.ts` — savePreparedTraining maps queueRecordWithCompatibleOpeningEvidence
- `app/lib/study-computation.ts` — computeStudyTask compatibility wrapper
- `app/lib/study.worker.ts` — passes computeEssentialStudyTask to installStudyWorker
- `app/lib/optional-study.worker.ts` — passes computeOptionalStudyTask to installStudyWorker

**Write reservation**

- `app/lib/study-worker-handler.ts`
- `app/lib/background-study.ts`
- `app/lib/bulk-study.ts`
- `app/utils/cards.ts`
- `app/lib/offline-training.ts`
- `app/lib/study-computation.ts`
- `tests/unit/study-worker-regressions.test.ts`
- `tests/unit/workspace-publication-regressions.test.ts`
- `tests/unit/offline-training-regressions.test.ts`
- `tests/unit/domain-validation-boundary.test.ts` (proposed new file)

**Ordered steps**

1. At each actual runtime caller pass the current collector/reporting effects explicitly. installStudyWorker supplies a worker-local collector capability to its compute callback; the existing essential/optional worker entries remain inert delegates.
2. Preserve worker request validation, per-task clearing, result diagnostics, error diagnostics and duration fields. Do not import browser debug-reporting or storage into a worker entry or pure computation module.
3. In background/bulk fallback paths inject reportDebugError plus the collector with the existing generation/publication fence. A superseded response must not repopulate cleared diagnostics or show a new notification.
4. In cards.ts and offline prepared mapping inject the browser collector at the call boundary, preserving valid-card filtering and quota/retention behavior. Keep computeStudyTask as a pure compatibility wrapper unless an effects argument is explicitly supplied.
5. Run selected existing publication/worker/phone regressions; use direct adapter tests to prove no hidden collector dependency. Report full FE007 closure only after T03 negative controls and these runtime behavior checks pass.

**Acceptance**

- Current browser/worker diagnostics remain visible at their original runtime boundaries, including invalid opening-evidence and invalid position diagnostics.
- Pure computation and domain imports stay effect-free by default; no implicit fallback singleton is reintroduced.
- Stale workspace result publication stays fenced; one runtime validation failure does not contaminate the next worker task.
- FE007 is eligible for closure with FE08/FE09 and T03; this source adoption requires no unrelated database/server journey.

**Selected future commands**

- `npm run test:unit -- tests/unit/domain-validation-boundary.test.ts tests/unit/validated-data-regressions.test.ts tests/unit/study-worker-regressions.test.ts tests/unit/workspace-publication-regressions.test.ts tests/unit/offline-training-regressions.test.ts tests/unit/study-worker-entry-closure.test.ts`
- `npm run typecheck:browser`

**Risk:** Worker diagnostics currently depend on a shared collector within each worker. Preserve its per-request lifetime while making the injection explicit.

**Excludes:** No automatic diagnostic persistence; No whole-stack test; No worker startup of optional authoring systems; No storage policy changes.

### FE20 — Publish the small board adapter capabilities needed by current Study policy

**Findings:** FE002. **Prior tasks:** broader audit. **Milestone:** 2. **Prerequisites:** none. **Release:** `BOARD_ADAPTER_CONTRACT_RELEASED`.

**Read first**

- `AGENTS.md` — current scope, ownership and minimum real proof; distinguish implemented/tested/assembled/installed
- `SPEC.md` — current November 10 reduction scope and retained ordinary Study preservation
- `docs/testing.md` — smallest relevant proof and supported owned runner
- `app/components/board/chessboard.tsx` — legality/hint/sound/keyboard policy and Chessground lifecycle
- `packages/board-ui/src/types.ts` — BoardProps/BoardHandle/BoardShape current public contract
- `packages/board-ui/src/controller.ts` — BoardController input generations and cancellation
- `packages/board-ui/src/Board.tsx` — renderer and geometry lifecycle
- `app/lib/performance.ts` — installTempoDragCapture currently reads concrete Api.state
- `packages/board-ui/README.md` — presentation and caller ownership

**Write reservation**

- `packages/board-ui/src/types.ts`
- `packages/board-ui/src/index.ts`
- `packages/board-ui/src/controller.ts`
- `packages/board-ui/src/Board.tsx`
- `app/lib/performance.ts`
- `app/components/board/chessboard.tsx`
- `packages/board-ui/tests/controller.test.ts`
- `packages/board-ui/tests/Board.test.tsx`
- `packages/board-ui/consumer/public-types.ts`

**Ordered steps**

1. Produce a checked mapping of every legacy prop to existing BoardProps: owner+positionKey to stable identity, external revision+reset to revision/clearInput, visual orientation, legal/free/select mode, destinations, check, last move, shapes, lock, layoutAnchor, keyboard container and focus.
2. Keep chess rules, promotion choice, hints and exposure callback, sounds, help dialog, preference state and persistent owner in the application adapter. Existing package properties already cover the main rendering/input needs; do not add app stores or chess.js to board-ui.
3. Remove the performance helper's need for mutable Chessground Api by accepting a narrow read-only input snapshot callback. Snapshot includes active/started drag, source square, original pointer, orientation, bounds, animation settings and displayed piece coordinates needed by current measurements; it exposes no renderer object, setters or DOM-owned mutable arrays.
4. Add only the corresponding optional package handle/event seam needed to supply current diagnostic measurements. Keep diagnostics opt-in from the caller; importing/rendering the package must not install application telemetry. Preserve input-generation and disposal fences around callbacks.
5. Adapt the existing legacy renderer to supply the same neutral snapshot callback temporarily so this preparatory contract slice preserves diagnostics before FE21 switches rendering.
6. Extend installed-consumer type fixtures and focused package tests for the narrow capability, detached data and disposal. Do not use a public getApi escape hatch.

**Acceptance**

- No application policy must reach a private package file or raw Chessground Api to adopt Board.
- Optional diagnostic reads/events cannot mutate the renderer, retain obsolete callbacks or add global app effects.
- Current move/hint/sound/keyboard/geometry capability mapping is complete and sufficient for FE21.
- Package remains app/backend/worker independent; no FE002 closure until actual current consumers adopt it.

**Selected future commands**

- `npm --prefix packages/board-ui run typecheck`
- `npm --prefix packages/board-ui test`
- `npm run test:unit -- tests/unit/board-move-feedback-regressions.test.tsx tests/unit/performance-report-regressions.test.ts`
- `npm run typecheck:browser`

**Shared release qualification**

- board integration owner: After FE21 adoption, use the package-owned backend-free native board qualifier and the selected current application UI case. This preparatory API change itself needs no whole-stack database run.

**Risk:** Preserving raw renderer diagnostics through a getApi backdoor would keep the old coupling. Dropping measurement behavior silently would invalidate existing board evidence.

**Excludes:** No new telemetry framework; No new board library; No chess legality moved into package; No native/browser run by this planning packet.

### FE21 — Render current Study and dialogs through the shared board package

**Findings:** FE002. **Prior tasks:** broader audit. **Milestone:** 2. **Prerequisites:** FE20. **Release:** `SHARED_BOARD_ADOPTED`.

**Read first**

- `AGENTS.md` — current scope, ownership and minimum real proof; distinguish implemented/tested/assembled/installed
- `SPEC.md` — current November 10 reduction scope and retained ordinary Study preservation
- `docs/testing.md` — smallest relevant proof and supported owned runner
- `app/components/board/chessboard.tsx` — Chessboard wrapper
- `app/components/chessboard.tsx` — compatibility re-export
- `app/components/board/persistent-board-shell.tsx` — persistent owner and publication props
- `app/state/board-shell-store.ts` — BoardPresentation shape contract and sameBoardShapes
- `app/features/game-review/GameReviewView.tsx` — existing public package consumer
- `packages/board-ui/REGRESSIONS.md` — package renderer case ownership

**Write reservation**

- `app/components/board/chessboard.tsx`
- `app/components/board/persistent-board-shell.tsx`
- `app/state/board-shell-store.ts`
- `app/responsive.css`
- `tests/unit/board-authoritative-restoration-regressions.test.tsx`
- `tests/unit/board-drag-preservation-regressions.test.tsx`
- `tests/unit/board-shortcuts-regressions.test.tsx`
- `tests/unit/board-move-feedback-regressions.test.tsx`
- `tests/unit/shared-board-shell-training-regressions.test.tsx`
- `tests/unit/shared-board-shell-tactics-regressions.test.tsx`
- `tests/unit/shared-board-shell-mount-regressions.test.tsx`

**Ordered steps**

1. Replace only Chessground construction/set/destroy, drawing mutation, geometry/resize lifecycle and deferred callback fencing in the legacy wrapper with public Board/BoardHandle. Keep the policy mapped by FE20 in the wrapper.
2. Use one stable identity from owner and positionKey; changing same-FEN owner/attempt must invalidate. Repeated semantically equivalent props and fresh handlers must preserve held input; reset and rejected same-FEN moves must use revision or clearInput.
3. Convert shared shell shapes to renderer-neutral BoardShape values at the wrapper boundary, preserving brush/label/piece/last-move data and detached arrays. Do not expose raw Api or add a second Chessground lifecycle in a helper.
4. Keep existing application keyboard/help/focus, hint exposure and move/capture/check/promotion sound behavior. Use public package CSS and remove only demonstrably duplicated renderer CSS; preserve external layout and test locators where meaningful.
5. Rebind application tests that mock raw Chessground to the public Board boundary for application policy, and retain true interaction/restoration assertions in package/native tests. Do not delete named regression obligations because their old private implementation is gone.
6. Check current Study, Tactics, frozen exercise and repair/editor modal consumers, plus existing Game Review; identify optional unavailable views without reviving them. Release the named regression mapping to the test inventory owner.

**Acceptance**

- Only packages/board-ui owns Chessground construction/set/destroy for current browser presentation.
- Application wrapper still owns legality/hints/sound/keyboard and persistent ownership; lock, same-FEN replacement, unmount and drawn-shape fencing retain behavior.
- Equivalent status/annotation/theme updates preserve held drag; genuine identity/mode/orientation changes cancel and restore authoritative FEN.
- Current local frontend native UI demonstrates drag/drawing/keyboard/geometry through the package, and Game Review remains validated.

**Selected future commands**

- `npm run test:unit -- tests/unit/board-authoritative-restoration-regressions.test.tsx tests/unit/board-drag-preservation-regressions.test.tsx tests/unit/board-shortcuts-regressions.test.tsx tests/unit/board-move-feedback-regressions.test.tsx tests/unit/shared-board-shell-training-regressions.test.tsx tests/unit/shared-board-shell-tactics-regressions.test.tsx tests/unit/shared-board-shell-mount-regressions.test.tsx`
- `npm --prefix packages/board-ui test`
- `npm run typecheck:browser`

**Shared release qualification**

- board integration owner / P12: Use supported backend-free controlled UI lane for current wrapper and package native BUI-N01..N05 where affected; require one current Study/Tactics/GameReview owner-switch case. No backend suite for a renderer-only change.

**Risk:** Wrapper has more application behavior than the package; wholesale replacement loses policy. Old tests inspect raw renderer internals and need honest ownership rebind, not relaxed assertions.

**Excludes:** No engine/workbench resurrection; No change to grading/queue policy; No whole-stack mandatory gate for board rendering; No duplicate renderer behind compatibility facade.

### FE22 — Construct one typed Study session runtime with a complete adapter table

**Findings:** FE006. **Prior tasks:** broader audit. **Milestone:** 2. **Prerequisites:** C21. **Release:** `SESSION_RUNTIME_FACTORY_RELEASED`.

**Read first**

- `AGENTS.md` — current scope, ownership and minimum real proof; distinguish implemented/tested/assembled/installed
- `SPEC.md` — current November 10 reduction scope and retained ordinary Study preservation
- `docs/testing.md` — smallest relevant proof and supported owned runner
- `app/lib/study-session-runtime.ts` — global adapters Map, registerStudyDeliveryAdapter, currentStore/session
- `packages/study-session/src/index.ts` — createStudySession, LearningClient, Settlement, lease/settlement behavior
- `app/lib/study-command-client.ts` — commandKinds and explicit retired kinds
- `database/browser/study-intent-storage.ts` — existing IntentStore ownership; S04 will parameterize its composition

**Write reservation**

- `app/features/study/session-runtime.ts` (proposed new file)
- `app/features/study/session-contracts.ts` (proposed new file)
- `tests/unit/study-runtime-construction.test.ts` (proposed new file)

**Ordered steps**

1. Create a pure createStudyRuntime factory accepting a supplied IntentStore supplier/currentness capability and a finite typed adapter-entry table. It creates the existing createStudySession only when requested, reuses it for the same supplied store, and disposes the old session on an explicit store/authority lifetime change.
2. Declare exact known kinds: review, teaching, study-command, tactic-command, burial-command, settings-command, defense-command, endgame-command. Require a delivery or explicit held adapter for every known kind before retaining/delivering any work; reject duplicate entries and missing supported kinds at construction.
3. Unknown retained kind produces a visible held error preserving original identity; a new unknown kind is rejected before retention. Held adapters never call transport. No global registry mutation or default singleton occurs on import.
4. Keep the current package as sole lease/settlement/receipt owner. Do not implement a second session state machine, scheduler or persistent store in the new factory.
5. Add a public consumer test with fake IntentStore/adapters for missing/duplicate kinds, held unknown work, same-store reuse, store replacement/dispose, and no calls at import.

**Acceptance**

- Factory is inert and independently usable without default browser composition or vi.mock of app storage.
- Construction-time invariants catch missing/duplicate supported adapters, while old unknown records remain inspectable holds.
- Store rotation disposes exactly the old session and cannot deliver stale work through a new authority.
- No FE006 closure yet: old module side effects remain until FE23/FE24 adoption.

**Selected future commands**

- `npm run test:unit -- tests/unit/study-runtime-construction.test.ts`
- `npm run typecheck:browser`

**Risk:** The saved kind set contains deliberately retired compatibility records. Treating missing adapters as empty work would lose their recovery meaning.

**Excludes:** No adapter implementation changes yet; No global registry; No schema/lease algorithm changes; No new browser runtime service.

### FE23 — Separate delivery adapters from outbox/session composition without changing settlement

**Findings:** FE006. **Prior tasks:** broader audit. **Milestone:** 2. **Prerequisites:** FE22, C14, C24. **Release:** `INERT_DELIVERY_ADAPTERS_RELEASED`.

**Read first**

- `AGENTS.md` — current scope, ownership and minimum real proof; distinguish implemented/tested/assembled/installed
- `SPEC.md` — current November 10 reduction scope and retained ordinary Study preservation
- `docs/testing.md` — smallest relevant proof and supported owned runner
- `app/lib/review-outbox.ts` — deliverLegacyReview, checkLegacyReviewReceipt, sendReview and local error/domain types
- `app/lib/teaching-state-outbox.ts` — deliver, checkReceipt, confirmedTeaching
- `app/lib/study-command-client.ts` — createStudyCommandDelivery and assessResponse
- `app/lib/review-transport.ts` — current client generation binding
- `app/features/study/session-contracts.ts` — FE22 supported and held kind contract (new dependency file from FE22)

**Write reservation**

- `app/lib/review-delivery.ts` (proposed new file)
- `app/lib/teaching-delivery.ts` (proposed new file)
- `app/lib/study-command-delivery.ts` (proposed new file)
- `app/lib/review-outbox.ts`
- `app/lib/teaching-state-outbox.ts`
- `app/lib/study-command-client.ts`
- `tests/unit/review-outbox-regressions.test.ts`
- `tests/unit/teaching-state-outbox-regressions.test.ts`
- `tests/unit/study-command-client-capability.test.ts`

**Ordered steps**

1. Extract cohesive delivery/checkReceipt factories for review, teaching and command families into proposed delivery modules. Supply the current client, store/currentness supplier and exact evidence/diagnostic callbacks explicitly; factories import no session composition root.
2. Keep error/receipt types in a neutral existing/proposed contract owner only if needed to avoid a cycle; do not make delivery modules import an outbox facade that imports composition. Prefer passing small required callbacks over copying review policy.
3. Preserve current original-ID confirmation, review reconciliation/aggregate-only evidence behavior, claim handling, dependent-command ordering, domain-result validation and completed-receipt rules exactly.
4. Keep old public outbox/client exports available through their current facade during this preparatory change. Replace top-level registration only in FE24, once all three inert factories are ready; do not leave one adapter missing from the current app.
5. Add import tests that fail if loading a delivery module opens browser storage, mutates a registry or creates a session. Existing owning regression tests exercise the same functions through the facade.

**Acceptance**

- Three inert, explicit adapter factories can be constructed with fake clients/stores; no implementation imports the default session composition.
- Existing domain acknowledgments, receipt identity, original bytes and authority fences are unchanged.
- No copied second review delivery algorithm and no circular dependency through compatibility facades.
- The old app remains wired until the single FE24 switch; this preparatory task alone does not close hidden registration.

**Selected future commands**

- `npm run test:unit -- tests/unit/review-outbox-regressions.test.ts tests/unit/teaching-state-outbox-regressions.test.ts tests/unit/study-command-client-capability.test.ts tests/unit/operation-status-study-client-regressions.test.ts`
- `npm run typecheck:browser`

**Risk:** Review delivery currently shares many local helpers/types with its outbox; careless extraction creates a composition cycle or loses evidence-fallback safeguards.

**Excludes:** No business settlement rewrite; No journal merge; No new retry logic; No backend registration change.

### FE24 — Assemble explicit default Study runtime and remove registration side effects

**Findings:** FE006. **Prior tasks:** broader audit. **Milestone:** 2. **Prerequisites:** FE23, FE06. **Release:** `SESSION_ADAPTER_COMPOSITION_RELEASED`.

**Read first**

- `AGENTS.md` — current scope, ownership and minimum real proof; distinguish implemented/tested/assembled/installed
- `SPEC.md` — current November 10 reduction scope and retained ordinary Study preservation
- `docs/testing.md` — smallest relevant proof and supported owned runner
- `app/lib/study-session-runtime.ts` — current default session owner
- `app/lib/review-outbox.ts` — reviewStudySession and registration call
- `app/lib/teaching-state-outbox.ts` — registration call/flush session lookup
- `app/lib/study-command-client.ts` — defaultDelivery registration loop and execute/recover lookups
- `app/lib/study-connection.ts` — defaultStudyClient
- `app/features/study/session-runtime.ts` — FE22 factory (new dependency file from FE22)

**Write reservation**

- `app/lib/study-runtime-composition.ts` (proposed new file)
- `app/lib/study-session-runtime.ts`
- `app/lib/review-outbox.ts`
- `app/lib/teaching-state-outbox.ts`
- `app/lib/study-command-client.ts`
- `tests/unit/study-composition-regressions.test.ts`
- `tests/unit/study-runtime-construction.test.ts` (proposed new file)
- `tests/unit/study-intent-storage-regressions.test.ts`

**Ordered steps**

1. Create one browser composition module supplying defaultStudyClient, existing storage supplier and every known delivery/held adapter to FE22. Instantiate lazily at the existing session entry so importing a public delivery/contract does not start it.
2. Make study-session-runtime.ts a thin compatibility entry to the explicit composed runtime, with no mutable registerStudyDeliveryAdapter API. Remove the three top-level registration calls/loop after all adapters are supplied.
3. Route review/teaching/command submit and recovery through the same runtime instance for a given existing store. Keep no duplicate createStudySession in Home/controllers or delivery factories.
4. Settings/defense/endgame compatibility kinds receive the explicit supported/held decisions from C21 and FE30. Until FE30 is integrated, preserve current classification instead of silently retiring a supported command by omission.
5. Add a fresh-import order permutation test proving any supported caller works without side-effect import prerequisites; importing delivery modules alone creates no global registration. Test stale store/session disposal and held old kinds.
6. Release SESSION_ADAPTER_COMPOSITION_RELEASED to S04; storage factory adoption consumes the injected supplier rather than reintroducing a composition import in database/browser.

**Acceptance**

- Zero production registerStudyDeliveryAdapter calls/exports remain; one complete typed composition constructs the session.
- Import order cannot determine whether a saved review/teaching/command has a delivery adapter.
- Saved bodies/IDs, session lease/settlement semantics and old held kinds remain unchanged.
- Factory/adapters public imports are inert; only explicit app composition supplies concrete storage/transport.

**Selected future commands**

- `npm run test:unit -- tests/unit/study-runtime-construction.test.ts tests/unit/study-composition-regressions.test.ts tests/unit/study-command-client-capability.test.ts tests/unit/review-outbox-regressions.test.ts tests/unit/teaching-state-outbox-regressions.test.ts tests/unit/study-intent-storage-regressions.test.ts`
- `npm run typecheck:browser`

**Shared release qualification**

- P12/P16: Reuse one coordinated assembled original-review/teaching/command replay selection on the final composition; no separate stack per factory extraction.

**Risk:** Composition must avoid a cycle: default composition imports inert delivery modules, and public outbox facades may call composition; inert delivery modules never import those facades.

**Excludes:** No storage lifecycle duplication; No new service/container; No changes to package settlement internals; No application startup in contracts.

### FE25 — Publish semantic review ports and map the existing browser owners behind them

**Findings:** FE003. **Prior tasks:** broader audit. **Milestone:** 2. **Prerequisites:** FE24. **Release:** `STUDY_REVIEW_PORTS_RELEASED`.

**Read first**

- `AGENTS.md` — current scope, ownership and minimum real proof; distinguish implemented/tested/assembled/installed
- `SPEC.md` — current November 10 reduction scope and retained ordinary Study preservation
- `docs/testing.md` — smallest relevant proof and supported owned runner
- `app/features/study/controller.ts` — StudyReviewIdentity/SubmitOptions, PendingReview leak, AuthorityBinding
- `app/lib/review-outbox.ts` — PendingReview, ReviewFlushResult, ReviewReplayError
- `app/lib/prepared-review-continuation.ts` — PreparedNextIdentity/PreparedContinuation and advancement
- `app/state/training-store.ts` — attempt token, queue/readiness and named actions
- `app/features/study/index.ts` — public feature exports

**Write reservation**

- `app/features/study/contracts.ts` (proposed new file)
- `app/features/study/browser-services.ts` (proposed new file)
- `app/features/study/index.ts`
- `tests/unit/study-public-services.test.ts` (proposed new file)

**Ordered steps**

1. Define semantic ReviewIntent, ReviewIdentity, confirmation/failure outcomes, attempt token, prepared continuation and narrow review/progression ports in contracts.ts. Copy the meaning of existing fields; do not expose PendingReview, IntentRecord, database handles, Zustand setters or concrete error classes.
2. Group existing capabilities by responsibility: retain/flush/recover/read pending facts; capture/check authority lifetime; read current attempt and perform named progression; publish diagnostics/notifications. Map concrete outbox/session/store methods in one browser-services adapter, preserving actual identity and conflict classification.
3. Export only semantic types and construction/use contracts through features/study index. Keep the existing controller API available until FE26 adopts the adapter.
4. Add a second consumer using fake semantic ports with no app-internal vi.mock; demonstrate retain, pending/committed/conflicted facts and stale-authority rejection.

**Acceptance**

- Public review types import only neutral domain contracts, not storage/outbox/React-store implementations.
- Concrete mapping is explicit and round-trips original identity without inventing an attempt ID.
- Fake-port consumer does not implement IndexedDB or a global Zustand store.

**Selected future commands**

- `npm run test:unit -- tests/unit/study-public-services.test.ts tests/unit/study-controller-boundary.test.ts`
- `npm run typecheck:browser`

**Risk:** An overly broad port that exports getState/setState or PendingReview merely renames the coupling. Keep semantic operations small and preserve existing authority lifetime checks.

**Excludes:** No new session or scheduler; No controller behavior change in this preparatory task.

### FE26 — Run the review controller through injected ports and preserve presentation fences

**Findings:** FE003. **Prior tasks:** broader audit. **Milestone:** 2. **Prerequisites:** FE25. **Release:** `STUDY_CONTROLLER_PORT_ADOPTION_RELEASED`.

**Read first**

- `AGENTS.md` — current scope, ownership and minimum real proof; distinguish implemented/tested/assembled/installed
- `SPEC.md` — current November 10 reduction scope and retained ordinary Study preservation
- `docs/testing.md` — smallest relevant proof and supported owned runner
- `app/features/study/controller.ts` — useStudyReviewController, submit, captureConfirmation, progressConfirmedReview, reconcilePreparedQueue
- `app/views/home_view.tsx` — useStudyReviewController composition call
- `app/features/study/browser-services.ts` — FE25 concrete adapter (new dependency file from FE25)
- `tests/unit/study-controller-review.test.ts` — existing mocks and review states
- `tests/unit/study-controller-progression.test.ts` — unmount/supersession/prepared progression

**Write reservation**

- `app/features/study/controller.ts`
- `app/features/study/browser-services.ts` (proposed new file)
- `app/features/study/index.ts`
- `app/views/home_view.tsx`
- `tests/unit/study-controller-review.test.ts`
- `tests/unit/study-controller-progression.test.ts`
- `tests/unit/study-controller-boundary.test.ts`

**Ordered steps**

1. Inject FE25 services at the Home composition call and replace controller imports of training-store, study-intent-storage, review-outbox, notifications and debug modules with semantic port calls. Leave React presentation lifecycle in the hook.
2. Preserve capture-time authority/store identity, attempt ID+generation, transition generation, unmount abort and same-card pending ordering across every await. Do not advance from a generic response.ok or local phase alone.
3. Rewrite owning tests to exercise the public hook using renderHook and supplied fake ports rather than mocking app internals. Include two independent controllers/services with no shared mutable store.
4. Keep prepared continuation admission checks delegated to its existing adapter; move its semantic value types into the public contract without giving the controller raw store mutation.

**Acceptance**

- Controller has no concrete browser storage, global training-store, outbox or notification imports.
- Pending/foreign/unmounted/superseded completion cannot acquire or install a successor; a valid original receipt advances once.
- Partial flush success plus later error, stale prepared continuation and retry-after-queue-failure retain their existing behavior.
- Public controller is substitutable with fake ports; final state-write restriction is FE35.

**Selected future commands**

- `npm run test:unit -- tests/unit/study-controller-boundary.test.ts tests/unit/study-controller-review.test.ts tests/unit/study-controller-progression.test.ts tests/unit/study-shell-composition-regressions.test.tsx tests/unit/review-attempt-confirmation-regressions.test.tsx`
- `npm run typecheck:browser`

**Shared release qualification**

- integration owner / P12 and P16: On the assembled candidate, one real saved review -> original operation receipt -> authoritative playable successor; inject wrong/missing initial 202 identity and lost acknowledgment, then recover only the original receipt. Reuse tests/browser/study-recovery.spec.ts; add a named fault case. Unit mocks do not establish this claim.

**Risk:** Async presentation fences are correctness policy, not cosmetic hook machinery. Port extraction must preserve captured authority rather than rereading a different current client after await.

**Excludes:** No React state-machine replacement; No new global store; No queue protocol change.

### FE27 — Extract the bounded queue HTTP protocol into an independently testable capability

**Findings:** FE004. **Prior tasks:** broader audit. **Milestone:** 2. **Prerequisites:** C14. **Release:** `QUEUE_TRANSPORT_PORT_RELEASED`.

**Read first**

- `AGENTS.md` — current scope, ownership and minimum real proof; distinguish implemented/tested/assembled/installed
- `SPEC.md` — current November 10 reduction scope and retained ordinary Study preservation
- `docs/testing.md` — smallest relevant proof and supported owned runner
- `app/views/fetchAndInitializeQueue.tsx` — fetchQueueWindow, waitForQueueRetry, followQueueIssuance, loadTodayQueueWithRetry
- `app/domain/adapters/operation-result-adapter.ts` — queue server-issued acknowledgment decoder
- `app/domain/transport.ts` — StudyNextExerciseOutcome
- `tests/unit/queue-issuance-pending-regressions.test.ts` — existing original issuance identity cases

**Write reservation**

- `app/features/study/queue-transport.ts` (proposed new file)
- `app/views/fetchAndInitializeQueue.tsx`
- `tests/unit/queue-issuance-pending-regressions.test.ts`
- `tests/unit/study-queue-status-regressions.test.ts`
- `tests/unit/study-queue-transport.test.ts` (proposed new file)

**Ordered steps**

1. Move the current HTTP polling/retry functions into createQueueTransport with explicit fetch/base URL, clock/timer and cancellation capabilities. Reuse existing decoders; no store, React, localStorage, notifications or singleton client import.
2. Preserve server-issued initial operation identity, subsequent poll identity, bounded timeout/Retry-After/transient hold behavior and foreground/background classification. Completed receipt triggers a fresh authoritative queue read, never installs response as a queue.
3. Make the existing view helper compose this capability without changing acquisition ordering yet. Add fake-transport tests for abort, malformed/foreign receipt, completed hold, pending, explicit foreground_wait and unknown operation.
4. Release the transport contract to FE28 and retain the current producer-wire tests.

**Acceptance**

- The protocol is executable through the public capability without React/global state.
- No retry creates a new issuance identity or treats optional preparation as a queue veto.
- Current unit regressions remain; source relocation alone does not claim playable-next acceptance.

**Selected future commands**

- `npm run test:unit -- tests/unit/operation-result-decoder.test.ts tests/unit/queue-issuance-pending-regressions.test.ts tests/unit/study-queue-status-regressions.test.ts tests/unit/queue-producer-wire-regressions.test.ts tests/unit/study-queue-transport.test.ts`
- `npm run typecheck:browser`

**Risk:** Queue GET obtains its ID from the server and must not inherit the durable POST requirement for a locally chosen ID. Preserve this distinction.

**Excludes:** No queue policy/scheduler change; No backend changes; No independent service restoration.

### FE28 — Move queue acquisition/reconciliation out of the view into one port-based application owner

**Findings:** FE004. **Prior tasks:** broader audit. **Milestone:** 2. **Prerequisites:** FE27, FE25, C21. **Release:** `QUEUE_APPLICATION_RELEASED`.

**Read first**

- `AGENTS.md` — current scope, ownership and minimum real proof; distinguish implemented/tested/assembled/installed
- `SPEC.md` — current November 10 reduction scope and retained ordinary Study preservation
- `docs/testing.md` — smallest relevant proof and supported owned runner
- `app/views/fetchAndInitializeQueue.tsx` — fetchAndInitializeQueue, eligibleQueueCards, loadEligibleOfflineQueue, retainPendingFailures
- `app/state/training-store.ts` — hydrateLocalQueue and protected active attempt rules
- `app/lib/prepared-review-continuation.ts` — confirmation and prepared-next fences
- `app/lib/offline-training.ts` — prepared queue/replay authority
- `app/features/study/queue-transport.ts` — FE27 protocol (new dependency file from FE27)

**Write reservation**

- `app/features/study/queue-application.ts` (proposed new file)
- `app/features/study/queue-policy.ts` (proposed new file)
- `app/features/study/browser-queue.ts` (proposed new file)
- `app/views/fetchAndInitializeQueue.tsx`
- `app/lib/prepared-review-continuation.ts`
- `tests/unit/study-queue-application.test.ts` (proposed new file)
- `tests/unit/desktop-queue-regressions.test.ts`
- `tests/unit/prepared-queue-readiness-regressions.test.ts`
- `tests/unit/phone-queue-preparation-regressions.test.ts`

**Ordered steps**

1. Create one cohesive queue application factory with grouped ports for transport, retained reviews/failures/phone snapshots, card mapping, named queue installation/current-attempt checks, cache, and notices/clock. Keep request generation and AbortController lifetime inside that factory.
2. Extract pure eligibility/reconciliation decisions over supplied facts. Preserve pending/confirmed/conflicted filtering, same-card phone dependency checks, guided failure retention, protected active attempt and the ban on authorizing a prefetched successor after filtering the authoritative connected head.
3. Put concrete store/browser/worker bindings in browser-queue.ts. Leave fetchAndInitializeQueue.tsx as compatibility exports/composition only. Compute authority-sensitive cache locator at explicit composition/lifetime, not by restoring a connection during pure module import.
4. Maintain cached offline versus connected authority: offline uses same-day issued prepared content and retained parent links; connected queue receipt requires a fresh read. Preserve optional cache-quota success, shell verification, bounded recovery and preparation notices.
5. Add tests constructing the queue application directly with in-memory ports and no React/localStorage/global store: stale generation, canceled mapping, retained active card, invalid current head, retired record followed by valid work, failed queue read with eligible offline snapshot.

**Acceptance**

- Queue application imports no React, concrete global store or browser persistence module.
- Compatibility view module contains no durable orchestration or direct queue-layout writes.
- All installation paths pass expected attempt/authority/generation checks; cache/offline projections cannot fabricate current server authority.
- Existing phone/desktop/queue readiness tests plus direct fake-port test pass; assembled journey is centralized.

**Selected future commands**

- `npm run test:unit -- tests/unit/study-queue-application.test.ts tests/unit/desktop-queue-regressions.test.ts tests/unit/prepared-queue-readiness-regressions.test.ts tests/unit/phone-queue-preparation-regressions.test.ts tests/unit/queue-issuance-pending-regressions.test.ts tests/unit/study-cached-startup-regressions.test.tsx`
- `npm run typecheck:browser`

**Shared release qualification**

- integration owner / P12 and P16: On the assembled candidate, one real saved review -> original operation receipt -> authoritative playable successor; inject wrong/missing initial 202 identity and lost acknowledgment, then recover only the original receipt. Reuse tests/browser/study-recovery.spec.ts; add a named fault case. Unit mocks do not establish this claim.
- P16: Retained active phone card survives reload/reconnect and one original review replays once; reuse current phone browser selection.

**Risk:** Filtering a connected issued head must not promote a cached successor into authority. This invariant is easy to lose while simplifying the large helper.

**Excludes:** No generic repository/event bus; No full queue rewrite; No reset of attempt identity; No new optional preparation workflow.

### FE29 — Move durable attempt completion and failure preparation out of Home

**Findings:** FE004, FE003. **Prior tasks:** broader audit. **Milestone:** 2. **Prerequisites:** FE26, FE28. **Release:** `HOME_DURABLE_ACTIONS_RELEASED`.

**Read first**

- `AGENTS.md` — current scope, ownership and minimum real proof; distinguish implemented/tested/assembled/installed
- `SPEC.md` — current November 10 reduction scope and retained ordinary Study preservation
- `docs/testing.md` — smallest relevant proof and supported owned runner
- `app/views/home_view.tsx` — persistExplicitAttemptFailure, finish/completeAttempt, prepare callback, offline review branch
- `app/lib/opening-evidence-journal.ts` — begin/complete/partial capture lifecycle; S05 owns journal storage refactor
- `app/lib/training-failure-outbox.ts` — enqueueTrainingFailure and flushTrainingFailures
- `app/lib/offline-training.ts` — recordOfflineAttempt
- `app/features/study/contracts.ts` — semantic ReviewIntent ports (new dependency file from FE25)

**Write reservation**

- `app/features/study/attempt-completion.ts` (proposed new file)
- `app/features/study/browser-services.ts` (proposed new file)
- `app/views/home_view.tsx`
- `tests/unit/study-attempt-completion.test.ts` (proposed new file)
- `tests/unit/review-attempt-confirmation-regressions.test.tsx`
- `tests/unit/study-regressions.test.tsx`

**Ordered steps**

1. Extract cohesive completion/failure preparation actions with supplied current attempt/card facts and original presentation token. Move durable failure command construction, opening completion capture and semantic review intent construction out of Home.
2. For connected review, retain the exact intent before send and preserve guided failure/evidence rules. For offline completion, retain through the existing phone owner before installing the resulting eligible queue; never advance on storage failure.
3. Home keeps keyboard/board interaction, UI phase and rendered errors. It calls named application actions and consumes semantic events; it does not compose PendingReview/FrozenStudyRequest or write persisted queue layouts.
4. Add direct port tests for storage quota, delayed original failure marker, stale attempt replacement, guided status and duplicate completion. Preserve existing current UI behavior and release Home to FE33 demo extraction.

**Acceptance**

- Home contains no direct review/failure durable payload construction or direct phone record write.
- Original completedAt/evidence/attempt/guided facts are captured once and survive retries.
- Storage failure cannot increment reviewed count or install next attempt; stale completion cannot affect the replacement.
- Final FE004 closure includes FE33 demo extraction and FE35 state-write restrictions.

**Selected future commands**

- `npm run test:unit -- tests/unit/study-attempt-completion.test.ts tests/unit/review-attempt-confirmation-regressions.test.tsx tests/unit/study-regressions.test.tsx tests/unit/opening-evidence-offline-quota.test.ts`
- `npm run typecheck:browser`

**Shared release qualification**

- integration owner / P12 and P16: On the assembled candidate, one real saved review -> original operation receipt -> authoritative playable successor; inject wrong/missing initial 202 identity and lost acknowledgment, then recover only the original receipt. Reuse tests/browser/study-recovery.spec.ts; add a named fault case. Unit mocks do not establish this claim.

**Risk:** Durable capture timing is part of the review contract; moving construction later can accidentally use a replacement card or a new timestamp.

**Excludes:** No S05 journal ownership edits; No move-rule/board policy changes; No schedule changes.

### FE30 — Classify the independent serving entry and release the supported-shell decision

**Findings:** FE008, FE010, FE012. **Prior tasks:** D02. **Milestone:** 1. **Prerequisites:** FE06, C21. **Release:** `SUPPORTED_SHELL_CLASSIFICATION_RELEASED`.

**Read first**

- `AGENTS.md` — current scope, ownership and minimum real proof; distinguish implemented/tested/assembled/installed
- `SPEC.md` — current November 10 reduction scope and retained ordinary Study preservation
- `docs/testing.md` — smallest relevant proof and supported owned runner
- `SPEC.md` — explicit independent Learning service/database retirement
- `static/src/study-main.tsx` — StudyConnectionBoundary serving entry
- `scripts/study-composition.ts` — study target entry substitution and emitted module inventory
- `vite.static.config.ts` — TEMPO_TARGET=study and __TEMPO_STUDY__
- `app/components/study-connection-boundary.tsx` — bootstrap/settings/new connection and retained export
- `app/components/study-settings-panel.tsx` — obsolete /api/study/settings mutation
- `app/lib/study-client.ts` — authority contracts and original service recovery
- `backend/app/main.py` — no /api/study/bootstrap or /api/study/settings route

**Write reservation**

- `static/src/README.md`
- `app/features/study/README.md`

**Ordered steps**

1. Read the existing study target entry substitution, imports and public build tests. Record the current producer/consumer map for bootstrap, settings, new issuance, retained receipts and retained export. This is bounded source/build-manifest classification; do not start a browser or a retired service to discover the absence already established in main.py.
2. Apply current SPEC: the independent Learning service/database is retired; the supported product is the current monolith Study including frozen ordinary exercises and offline/reload. Default dormant serving disposition is a recovery-only hold/export surface or removal of the unused serving target while preserving reachable recovery. State this as the current implementation direction, not a newly invented grading/runtime policy.
3. Release which current callers FE31/FE32 must adopt into the supported existing command owner before deleting mode-specific mutation paths. FE36 owns the final entry/control removal. Keep source classification separate from that later mutation so dependencies do not form a cycle.
4. Preserve independent authority factories/inspection required for old original-authority work. Retained settings to /api/study/settings and unsupported issuance are held; do not translate/rebind their IDs/bodies.
5. If concrete evidence shows a currently supported consumer contrary to this map, integration owner resolves its narrow contract with the current backend before removal. Never restore the retired independent service as a shortcut.

**Acceptance**

- A finite path/consumer/support table distinguishes current monolith support from independent recovery-only retained work.
- FE31/FE32 have a concrete composition target and FE36 has explicit controls/entry points to retire after adoption.
- Existing retained data/authority contracts are preserved; no active source behavior is modified by this decision slice.
- No decision is deferred generically and no new user approval is required for the SPEC-derived default.

**Selected future commands**

- `git diff --check -- static/src/README.md app/features/study/README.md`

**Risk:** A dormant source branch can still contain valuable retained-work recovery code. Removing serving must not delete data or redirect original authority.

**Excludes:** No product code edit in this slice; No new independent service/bootstrap; No record migration; No live user-data inventory required for source classification.

### FE31 — Give current Tactics one retained command lifecycle before transport

**Findings:** FE010. **Prior tasks:** broader audit. **Milestone:** 2. **Prerequisites:** FE24, FE30, C14. **Release:** `TACTIC_COMMAND_LIFECYCLE_RELEASED`.

**Read first**

- `AGENTS.md` — current scope, ownership and minimum real proof; distinguish implemented/tested/assembled/installed
- `SPEC.md` — current November 10 reduction scope and retained ordinary Study preservation
- `docs/testing.md` — smallest relevant proof and supported owned runner
- `app/views/tactics_view.tsx` — finish; full shell currently POSTs without durable retention
- `app/lib/study-command-client.ts` — executeStudyRequest and retainedStudyRequest
- `backend/app/main.py` — tactic_attempt idempotency key and result shape
- `app/lib/tactics-progress.ts` — local progress advancement

**Write reservation**

- `app/lib/tactic-attempt-command.ts` (proposed new file)
- `app/views/tactics_view.tsx`
- `tests/unit/tactics-polish-regressions.test.tsx`
- `tests/unit/study-command-client-capability.test.ts`
- `tests/unit/tactic-attempt-pending.test.ts` (proposed new file)

**Ordered steps**

1. Create a small semantic tactic-attempt facade that uses the existing typed command/session owner. Freeze puzzle/deck/source-FEN/moves/rating/correct/clean/attempt ID before transport and retain it durably. Use kind tactic-command and the existing tactic scope (progressKey plus puzzle ID), endpoint /api/tactics/attempt, and exact current field names attempt_id/puzzle_id/deck_id/correct/clean/source_fen/moves/rating; do not rely on the generic default kind.
2. Use tactic-attempt:${attempt_id} for new full-shell operation identity, matching the current implicit backend key; preserve any already retained explicit requestId/body instead of converting it. Remove the independentStudy conditional that selects another lifecycle.
3. Keep the view token fence and local progress update only after validated original receipt; a reload can resume through the retained request. Failed storage means no POST and no local progress.
4. Add negative tests for quota/retention failure, lost acknowledgment/reload, foreign202, malformed tactic result, same puzzle on another deck and replaced UI attempt. Existing original result is replayed once.

**Acceptance**

- Every supported current tactic attempt is retained before send and can recover original identity after reload.
- Build mode does not choose a separate submission state machine.
- No duplicate tactic progress/history from original receipt retry; local progress remains deck scoped.

**Selected future commands**

- `npm run test:unit -- tests/unit/tactic-attempt-pending.test.ts tests/unit/tactics-polish-regressions.test.tsx tests/unit/study-command-client-capability.test.ts tests/unit/shared-board-shell-tactics-regressions.test.tsx`
- `npm run typecheck:browser`

**Shared release qualification**

- P12/P16: Current packaged tactic completion with lost acknowledgment/reload retains the original operation and exactly one progress/history effect.

**Risk:** Current full-shell tactic state exists only in the view; retaining it must not generate a different logical attempt during retry.

**Excludes:** No pack/capture lifecycle rewrite; No new study session; No legacy body conversion.

### FE32 — Use one burial lifecycle and a bounded reader for existing local markers

**Findings:** FE010. **Prior tasks:** broader audit. **Milestone:** 2. **Prerequisites:** FE24, FE30, C14. **Release:** `BURIAL_COMMAND_LIFECYCLE_RELEASED`.

**Read first**

- `AGENTS.md` — current scope, ownership and minimum real proof; distinguish implemented/tested/assembled/installed
- `SPEC.md` — current November 10 reduction scope and retained ordinary Study preservation
- `docs/testing.md` — smallest relevant proof and supported owned runner
- `app/lib/training-bury-command.ts` — buryTrainingEntry, finishTrainingBurial, pendingTrainingBurialEntry, recoverTrainingBurial
- `database/browser/adapters/practice/training-burial-command.ts` — retained operation/body/marker keys
- `app/lib/study-command-client.ts` — burial-command validation and generic retained request
- `app/views/home_view.tsx` — burial callback and queue refresh completion

**Write reservation**

- `app/lib/training-bury-command.ts`
- `app/lib/study-command-client.ts`
- `app/lib/study-command-delivery.ts` (proposed new file)
- `database/browser/adapters/practice/training-burial-command.ts`
- `tests/unit/training-burial-regressions.test.ts`
- `tests/unit/training-burial-caller-regressions.test.tsx`
- `tests/unit/study-command-client-capability.test.ts`

**Ordered steps**

1. Route new supported burials through the existing retained command/session owner for every supported composition. Remove build-flag-selected fresh submission logic.
2. Preserve existing local operation/body/marker records through a narrow compatibility reader. If adopting one known pending legacy command into the existing intent store is necessary, use its original operation ID and exact serialized body; retain legacy bytes until durable adoption and validated original receipt plus required queue refresh. Never bulk migrate or clear on load.
3. If generic payloads need an optional raw body representation for this one legacy replay, use it only for the frozen transport bytes and preserve the semantic parsed value for validation. Existing intent records are unchanged; do not reserialize legacy bytes to a new operation.
4. Keep committed-but-not-refreshed burial recovery separate from command settlement: no extra bury mutation while the marker only awaits queue reconciliation.
5. Test crashes between durable adoption and legacy cleanup, absent/blocked/failed/original receipt, stale queue entry, foreign202 and repeated queue-refresh failure. Recovery must choose the known old command before starting any new one.

**Acceptance**

- One supported fresh burial lifecycle retains before send; no build-mode mutation branch remains.
- Legacy record identity/body/marker survive any interrupted handoff and cannot create a second burial.
- Queue-refresh failure keeps useful pending identity; valid receipt cannot be mistaken for a playable successor.
- No unrelated local key scan or database rewrite is introduced.

**Selected future commands**

- `npm run test:unit -- tests/unit/training-burial-regressions.test.ts tests/unit/training-burial-caller-regressions.test.tsx tests/unit/study-command-client-capability.test.ts`
- `npm run typecheck:browser`

**Shared release qualification**

- P16/P12: One existing local burial marker survives reload and interrupted adoption/refresh, settles its original receipt once and then installs a valid queue. No whole-stack loop per compatibility case.

**Risk:** Two stores during a handoff can become two authorities. Keep a single original ID and do not clear the old representation before its durable replacement/receipt is established.

**Excludes:** No blanket legacy journal migration; No new state machine; No clearing uncertain work; No service restoration.

### FE33 — Document provisional offline repeats and isolate demo queue policy with conformance

**Findings:** FE012, FE004. **Prior tasks:** broader audit. **Milestone:** 2. **Prerequisites:** FE30, C24, FE29. **Release:** `OFFLINE_DEMO_POLICY_RELEASED`.

**Read first**

- `AGENTS.md` — current scope, ownership and minimum real proof; distinguish implemented/tested/assembled/installed
- `SPEC.md` — current November 10 reduction scope and retained ordinary Study preservation
- `docs/testing.md` — smallest relevant proof and supported owned runner
- `app/lib/offline-training.ts` — offlineRepeatPosition and recordOfflineAttempt scheduling projection
- `app/views/home_view.tsx` — demo initialization, local queue writes, Again/first-clean repeat handling
- `packages/scheduling/src/tempo_scheduling/_scheduler.py` — schedule_review requeue/mode/first-clean logic
- `app/domain/transport.ts` — BackendQueueCard metadata
- `tests/unit/study-single-card-contract.test.ts` — independent cannot manufacture attempt authority
- `tests/unit/offline-training-regressions.test.ts` — current provisional phone repeat semantics

**Write reservation**

- `app/features/study/demo-queue.ts` (proposed new file)
- `app/lib/offline-training.ts`
- `app/views/home_view.tsx`
- `app/domain/offline-training.ts`
- `tests/fixtures/offline-repeat-policy.json` (proposed new file)
- `tests/unit/offline-training-regressions.test.ts`
- `tests/unit/study-single-card-contract.test.ts`
- `packages/scheduling/tests/test_offline_repeat_contract.py` (proposed new file)
- `app/features/study/README.md`

**Ordered steps**

1. Record the SPEC-compatible decision: normal monolith prepared-phone repeats remain a provisional local projection, server receipts/scheduling remain authoritative; demo is a distinct local demonstration policy; the retired independent service/recovery surface authorizes no fresh offline attempts.
2. Extract Home demo queue initialization/completion/burial/reorder persistence into one cohesive demo-queue adapter with explicit storage/time input and named results. Preserve current demo repeat position4 and first-clean end-of-queue behavior as demo behavior; do not describe it as FSRS scheduling.
3. Create a versioned conformance fixture for the supported phone projection fields, comparing relevant requeue/mode decisions to current schedule_review with explicit complete FSRS input and times. Cover guided-as-Again, first clean/reinforcement, normal/light/hard, last-five failure threshold and missing legacy metadata. Record both current projection and canonical server outputs for an intentional provisional difference; never call that full scheduler parity. No FSRS runs in the browser.
4. Use current semantics as the decision baseline. Preserve existing same-day, invalid-history and requiresConnectedGrading holds. Do not add a blanket hold merely because optional legacy metadata is absent. For a demonstrated divergence, document whether it is the deliberately provisional projection or an existing required-parity bug before changing newly created projections; any changed projection gets a new explicit local policy version and a named vector. Existing retained parent chains/answers and server replay remain unchanged.
5. New prepared/projection metadata may identify the local projection policy; old saved records without it remain readable and are not rewritten. No policy change is silently applied to a retained queue.
6. Home becomes a caller of demo/online/offline application actions rather than a writer of tempo-daily-queue, tempo-cards-left, reviewed/failure counters or scheduler projections. Preference-only localStorage writes may remain.

**Acceptance**

- Each mode has a concrete authority/support classification and a runnable current owner.
- Supported relevant repeat decisions have versioned owner-backed conformance cases. Intentional provisional differences are explicit, not claimed as parity; no new independent offline authority is created.
- Demo remains explicitly distinct and does not claim real saved review/schedule authority.
- Home no longer persists queue layouts; retained phone attempts, parent chains and unacknowledged work are preserved.

**Selected future commands**

- `npm run test:unit -- tests/unit/offline-training-regressions.test.ts tests/unit/study-single-card-contract.test.ts tests/unit/study-regressions.test.tsx`
- `uv run --directory packages/scheduling --locked --no-editable python -m pytest tests/test_offline_repeat_contract.py -q`
- `npm run typecheck:browser`

**Shared release qualification**

- P16: Reuse actual phone outage/reload/replay case to prove provisional queue advancement and original server reconciliation; demo adapter requires no PG stack.

**Risk:** Offline requeue is not the full FSRS algorithm. Matching only Again=4 can hide hard/light/first-clean distinctions; expanding into a second scheduler would be worse.

**Excludes:** No browser FSRS clone; No new due-date authority; No record reset/migration; No demo becoming production; No independent Learning resurrection.

### FE34 — Record intentional FSRS-shaped scheduling API as the current abstraction

**Findings:** FE013. **Prior tasks:** broader audit. **Milestone:** 2. **Prerequisites:** none. **Release:** `SCHEDULER_ABSTRACTION_DECISION_RECORDED`.

**Read first**

- `AGENTS.md` — current scope, ownership and minimum real proof; distinguish implemented/tested/assembled/installed
- `SPEC.md` — current November 10 reduction scope and retained ordinary Study preservation
- `docs/testing.md` — smallest relevant proof and supported owned runner
- `packages/scheduling/README.md` — pinned FSRS6.3.2 state and explicit clock/day contract
- `packages/scheduling/src/tempo_scheduling/__init__.py` — public exported schedule/position/init/clone operations
- `packages/scheduling/src/tempo_scheduling/_scheduler.py` — complete fsrs_card_json input
- `packages/scheduling/src/tempo_scheduling/_position_schedule.py` — initial_position_state, clone_state
- `backend/app/services/scheduler.py` — outer legacy environmental defaults
- `packages/scheduling/tests/test_purity.py` — fresh installed child processes
- `backend/tests/test_scheduling_boundary.py` — backend dependency guard

**Write reservation**

- `packages/scheduling/README.md`
- `backend/app/study/policy/README.md`

**Ordered steps**

1. Record the bounded current decision: complete FSRS6.3.2 Card JSON is intentionally part of the supported scheduling API at this product stage. Consumers supply explicit time/day/allocated identity; scheduling owns validation and algorithm semantics. This is a vendor-shaped stable contract, not an implementation-independent promise.
2. Document the credible tradeoff: a future algorithm/vendor/state-format change will require scheduler-owned versioning/migration. The existing initial_position_state API already removes the need for callers to construct fresh position state; do not add an opaque-memory framework without a concrete replacement requirement.
3. List current installed-package deterministic/purity qualification separately from checkout imports and preserve it. This docs-only decision changes no package behavior or runtime semantics.
4. Close FE013 by accepted documented abstraction choice; if integration owner explicitly selects replaceability instead, it must be a separate concrete implementation scope with a state-compatibility plan, not this packet pretending an opaque type alone solves it.

**Acceptance**

- Public docs explicitly answer whether serialized FSRS Card is supported and pin its compatibility expectations.
- Identity allocation, aware instant and Study day remain owner-supplied; no environmental APIs move into pure scheduling.
- No unrelated scheduler refactor is required to resolve the decision row.

**Selected future commands**

- `git diff --check -- packages/scheduling/README.md backend/app/study/policy/README.md`

**Shared release qualification**

- integration owner: No new executable test for documentation-only decision. If behavior/export bytes change, use existing installed package qualification: from packages/scheduling, uv sync --locked --no-editable; uv run --locked --no-editable python -m build; uv run --locked --no-editable python -m pytest tests. Do not claim checkout tests as installed evidence.

**Risk:** Intentional API coupling has a future replacement cost. Hiding it in an opaque wrapper now adds complexity without a current substitute requirement.

**Excludes:** No new opaque scheduler framework; No FSRS mathematics/state rewrite; No schema migration; No mandatory full stack.

### FE35 — Restrict queue/attempt writes to named invariant-preserving actions

**Findings:** FE003, FE004. **Prior tasks:** broader audit. **Milestone:** 2. **Prerequisites:** FE26, FE28, FE29, FE33. **Release:** `STUDY_STATE_BOUNDARY_CLOSED`.

**Read first**

- `AGENTS.md` — current scope, ownership and minimum real proof; distinguish implemented/tested/assembled/installed
- `SPEC.md` — current November 10 reduction scope and retained ordinary Study preservation
- `docs/testing.md` — smallest relevant proof and supported owned runner
- `app/state/training-store.ts` — TrainingStoreState, selectTrainingActions, useTrainingStore, hydrateQueue/hydrateLocalQueue/advanceCachedQueue
- `app/features/study/browser-services.ts` — review state adapter (new dependency file from FE25)
- `app/features/study/browser-queue.ts` — queue installation adapter (new dependency file from FE28)
- `app/lib/prepared-review-continuation.ts` — direct practiceCards setState
- `app/views/home_view.tsx` — remaining queue/attempt setters after FE29/FE33
- `app/lib/debug-reporting.ts` — read-only state consumer

**Write reservation**

- `app/state/training-store.ts`
- `app/features/study/browser-services.ts` (proposed new file)
- `app/features/study/browser-queue.ts` (proposed new file)
- `app/lib/prepared-review-continuation.ts`
- `app/views/home_view.tsx`
- `tests/unit/training-store-regressions.test.ts`
- `tests/unit/study-controller-boundary.test.ts`
- `tests/unit/prepared-queue-readiness-regressions.test.ts`

**Ordered steps**

1. Hide the raw Zustand setState export for production consumers. Keep efficient read selectors/getSnapshot and expose named actions for authoritative queue installation, prepared reconciliation, confirmed-entry remembering, attempt reset/phase change and authorized successor advancement.
2. Move remaining grouped queue/attempt mutations from adapters/prepared continuation into those named actions with expected attempt ID/generation/authority and existing protected active-state checks. Do not remove harmless local presentation setters solely for cosmetic purity.
3. Migrate current production callers to the narrowed surface; tests may use an explicit test-only fixture initializer rather than an exported production backdoor. Demo initialization/completion uses its approved adapter results.
4. Add negative tests for stale attempt/generation, same-FEN replacement, pending save, conflicted current head, later guided failure and superseded reconciliation. Confirm unauthorized arbitrary queue install cannot be expressed through the public feature port.
5. Coordinate T03 final boundary map for the narrowed surface. FE003/FE004 closure requires all view, controller, queue and demo task acceptances, not this export rename alone.

**Acceptance**

- No production caller outside the owning state/application adapter can arbitrarily set queue/attempt fields.
- Progression writes pass named actions preserving attempts and authoritative issuance; read selectors remain efficient.
- Current controller/queue can be independently tested with fake semantic ports; Home composes presentation only.
- No earlier frozen/phone/receipt recovery semantics are lost when global setters become private.

**Selected future commands**

- `npm run test:unit -- tests/unit/training-store-regressions.test.ts tests/unit/study-controller-boundary.test.ts tests/unit/study-controller-progression.test.ts tests/unit/desktop-queue-regressions.test.ts tests/unit/prepared-queue-readiness-regressions.test.ts`
- `npm run typecheck:browser`

**Shared release qualification**

- integration owner / P12 and P16: On the assembled candidate, one real saved review -> original operation receipt -> authoritative playable successor; inject wrong/missing initial 202 identity and lost acknowledgment, then recover only the original receipt. Reuse tests/browser/study-recovery.spec.ts; add a named fault case. Unit mocks do not establish this claim.

**Risk:** Raw store access is widely used for reads; removing all store imports would inflate scope. Restrict consequential writes while preserving read selectors and local presentation state.

**Excludes:** No global state rewrite; No second session; No broad UI redesign; No public test-only mutation backdoor.

### FE36 — Apply the independent entry retirement after current command consumers adopt their owner

**Findings:** FE008, FE010, FE012. **Prior tasks:** broader audit. **Milestone:** 2. **Prerequisites:** FE30, FE31, FE32. **Release:** `RETIRED_SHELL_SERVING_CLOSED`.

**Read first**

- `AGENTS.md` — current scope, ownership and minimum real proof; distinguish implemented/tested/assembled/installed
- `SPEC.md` — current November 10 reduction scope and retained ordinary Study preservation
- `docs/testing.md` — smallest relevant proof and supported owned runner
- `SPEC.md` — explicit independent Learning service/database retirement
- `static/src/study-main.tsx` — StudyConnectionBoundary serving entry
- `scripts/study-composition.ts` — study target entry substitution and emitted module inventory
- `vite.static.config.ts` — TEMPO_TARGET=study and __TEMPO_STUDY__
- `app/components/study-connection-boundary.tsx` — bootstrap/settings/new connection and retained export
- `app/components/study-settings-panel.tsx` — obsolete /api/study/settings mutation
- `app/lib/study-client.ts` — authority contracts and original service recovery
- `backend/app/main.py` — no /api/study/bootstrap or /api/study/settings route

**Write reservation**

- `static/src/study-main.tsx`
- `scripts/study-composition.ts`
- `app/components/study-connection-boundary.tsx`
- `app/components/study-settings-panel.tsx`
- `app/lib/study-client.ts`
- `tests/unit/study-composition-regressions.test.ts`
- `tests/unit/study-build-closure-regressions.test.ts`
- `tests/unit/study-learning-connection-regressions.test.ts`

**Ordered steps**

1. Apply the FE30 support table after FE31 and FE32 release the current tactic/burial callers. Remove dormant new issuance/settings controls from static/src/study-main.tsx and its connected boundary; retain the explicitly selected recovery-only hold/export surface or remove the unused serving target only when recovery remains reachable.
2. Update scripts/study-composition.ts and build closure expectations to the actual supported entry. Recovery-only modules cannot create new attempts, call bootstrap/settings or activate retired optional producers.
3. Apply the C21 exact retained route allowlist delta in study-client.ts under the FE06 semantic adapter contract. Preserve original-authority receipt/export access; retired/unknown records remain held and cannot become new monolith commands.
4. Remove obsolete study-settings mutation UI after confirming normal settings continues through saveLocalSettings. Preserve retained settings bytes and display their held status; do not send them to another endpoint.
5. Add regressions that recovery/export works with existing malformed/foreign records while all new issuance/mutation controls are absent. Re-run current monolith composition and single-card contracts to ensure normal offline/reload remains supported.

**Acceptance**

- No active supported UI promises bootstrap/settings/new issuance from a service removed by current SPEC.
- Existing authority-bound data is readable/exportable and never cleared or rebound automatically.
- Normal monolith Study, offline phone/reload and current frozen exercise routes remain usable.
- An explicit source-backed support decision resolves the mode ambiguity for FE010/FE012; no blanket study-command retirement.

**Selected future commands**

- `npm run test:unit -- tests/unit/study-composition-regressions.test.ts tests/unit/study-build-closure-regressions.test.ts tests/unit/study-learning-connection-regressions.test.ts tests/unit/study-single-card-contract.test.ts`
- `npm run typecheck:browser`

**Shared release qualification**

- P16: Recovery-only surface preserves original retained foreign/current records across reload; it performs no new issuance or grade. Normal monolith browser remains the release journey.

**Risk:** A dormant source branch can still contain valuable retained-work recovery code. Removing serving must not delete data or redirect original authority.

**Excludes:** No independent Learning service/bootstrap restoration; No new auth service; No blanket command-kind retirement; No live data inspection required merely to implement the SPEC-derived default.

