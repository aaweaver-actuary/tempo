# Tempo: deeper review and next steering

**Recommendation: continue with a focused steering handoff under the existing integration owner.** Most of the previous continuation's practical implementation has landed. Preserve those gains and direct the next work at reproduced recovery defects, supported routes that currently have no HTTP owner, the remaining calendar boundary, and the accuracy of qualification claims. I found no evidence supporting a blanket rollback or a restart of all A–G work.

This is a source and evidence review with independently executed component checks and diagnostic reproductions. It is not a fresh PostgreSQL/browser release qualification or inspection of the installed Mac. All results below keep that distinction.

## 1. What changed since the last review

| State | Verified or recorded value |
| --- | --- |
| Previous review | `799b66234b8be386a33d980df10b8b1d9a9d8b36` |
| Current reviewed main | `091ad318b1afaadcb25e5ca44ff526120a202336` |
| Current Git tree | `e727a9d8580122b215f9f7f941b32129ea1a8249` |
| Merges in the interval | 16 PRs; 195 changed paths, 5,696 insertions and 2,780 deletions, including generated audit and documentation files |
| Reported installed release | `d79ae4fcc4b006985114d85b5fb9a5aca8becbf1`, schema 65; recorded verification at `2026-11-12T19:31:39Z` |
| Installed→current source delta | 18 paths, all tests/fixtures/runner/audit; no application, storage implementation, scheduling or schema change |
| Audit status | 55 original findings retained: 14 Closed, 37 Open, 4 Needs decision |

The four previously held PRs, #991/#992/#993/#995, are merged, as are #997–#1008. There is no remaining merge action for these reviewed PRs. Other older open PRs exist; this review does not authorize absorbing their scopes. GitHub PR metadata and Git ancestry, rather than stale draft language in PR bodies, establish these states. The main ref was checked again after the source review and remained at 091ad318.

| Delivered slice | PRs | Assessment |
| --- | --- | --- |
| Current backend/storage guides and audit | [#998](https://github.com/aaweaver-actuary/tempo/pull/998), [#1003](https://github.com/aaweaver-actuary/tempo/pull/1003) | Bounded guide reconciliation landed. Subsequent proof changes have made a few current testing descriptions stale again. |
| Maturity, codec, receipts and Game Review | [#991](https://github.com/aaweaver-actuary/tempo/pull/991), [#992](https://github.com/aaweaver-actuary/tempo/pull/992), [#993](https://github.com/aaweaver-actuary/tempo/pull/993), [#995](https://github.com/aaweaver-actuary/tempo/pull/995) | Useful source improvements, followed by coordinated qualification. Receipt validation does not finish the initial acknowledgment boundary. |
| Q0 and native bridge | [#997](https://github.com/aaweaver-actuary/tempo/pull/997), [#1002](https://github.com/aaweaver-actuary/tempo/pull/1002) | Exact native selector/refusal and stronger assembled cases. Q0 also fixes task-history timestamp comparison. |
| PGN, Rust and alias cleanup | [#999](https://github.com/aaweaver-actuary/tempo/pull/999), [#1000](https://github.com/aaweaver-actuary/tempo/pull/1000), [#1001](https://github.com/aaweaver-actuary/tempo/pull/1001) | Appropriately narrow changes. E01's current file passes; three fake-SQL tests have limited discriminating power. |
| Backend and browser continuation | [#1005](https://github.com/aaweaver-actuary/tempo/pull/1005), [#1006](https://github.com/aaweaver-actuary/tempo/pull/1006) | Six-counter ownership, fresh scheduling state, captured calendar, queue acknowledgment, semantic authority facts, inert client factory and retired-adapter removal are real improvements. Partial findings remain partial. |
| Current reader and audit | [#1007](https://github.com/aaweaver-actuary/tempo/pull/1007), [#1008](https://github.com/aaweaver-actuary/tempo/pull/1008) | Reader proof now targets minimal read-only Game Review. Audit records six further closures and the d79 installation. |
| Maintained Study proof | [#1004](https://github.com/aaweaver-actuary/tempo/pull/1004) | Merged at current main. Its finite maintained selection is explicitly partial; it does not finish all E02 or restore the retained HTTP boundary. |

The audit moved from 6 Closed / 44 Open / 4 Needs decision / 1 Partially addressed to 14 Closed / 37 Open / 4 Needs decision. The eight additional closures are BE022, ST010, ST001, ST007, BE006, BE016, ST009 and FE011. I compared the HTML registry, workbook and root progress: all 55 IDs remain; statuses agree; original finding text and acceptance criteria were not rewritten to produce the count. These are recorded audit dispositions, not eight fresh native acceptance runs by this review. [Current progress](https://github.com/aaweaver-actuary/tempo/blob/091ad318b1afaadcb25e5ca44ff526120a202336/tempo-low-fruit-20261112/progress/merge-review.json).

## 2. What this review independently verified

Three independent reviewers examined backend/storage, frontend/recovery, and qualification/installation evidence. I reconciled their findings against the complete merge interval, current specification, prior task graph, audit artifacts and GitHub state.

| Area | Actual current-source result | Limit |
| --- | --- | --- |
| Backend/scheduling/Learning | 241 passed, 9 failed; 2 native cases deliberately deselected | Nine failures are pre-existing stale APIs/fixtures, detailed below. No PostgreSQL run. |
| Frontend existing selection | 327 passed across 16 files; browser TypeScript check exited 0 | Vitest/jsdom/fake IndexedDB, not a real browser. |
| Frontend adversarial probes | Four intended invariant assertions fail on both baseline and current source | Reproduces three initial-202 false-settlement cases and unknown-store cutover. Deliberate red probes are not counted as passing acceptance. |
| Frozen exercise reachability | Two current-source consumer probes pass | Shows prepared-storage→mapper→actual TrainingView/runner reachability and connected request to absent presentation route; no live data census. |
| Qualification boundary tests | 66 passed, no skips | Bridge refusal, selector, reader safety, PGN and task-history boundaries; some file coverage overlaps backend review, so these counts are not summed. |
| Runner diagnostic probes | Reject altered partial receipts, browser failures/retries and alternate selections; cleanup runs after injected failure | Pure option/plan probes, not execution of the heavy stages. |
| Mounted application routes | Actual assembled FastAPI route inventory has 58 routes; zero matches for the three prefix-split and four frozen-exercise paths | Application composition only; no server/database started. |

No Docker executable was available here. Native PostgreSQL, real-browser acceptance, installed images/modes and live cadence were not rerun. The scheduling grimp guard and Rust tools were not independently rerun; those results remain prior reported evidence. Frontend dependencies and workspace outputs were installed/built in a task-owned checkout. The reviewed product checkout remained clean.

Exact commands, logs or clearly labeled execution ledgers, reproducers, source pins and limitations accompany this report under `evidence/`. The backend ledger is a transcription of observed commands/counts and tool result identifiers, not invented raw stdout.

## 3. Findings that should drive the next session

### 1 — Initial acknowledgment identity can falsely settle a real pending command

**Highest priority. Confirmed conditional defect; pre-existing and already listed as FE001 residual.**

`confirmOperationResponse` reads the operation ID from the initial HTTP 202 and follows it without comparing the original command ID. The later receipt decoder correctly validates against the ID it was given, but that ID can already be foreign. Missing-ID 202 responses pass through unchanged, and some callers treat their successful HTTP status as confirmation. [Confirmation helper](https://github.com/aaweaver-actuary/tempo/blob/091ad318b1afaadcb25e5ca44ff526120a202336/app/lib/operation-status.ts#L31-L39).

The probe sent a review with idempotency key `review-attempt:deep-original`. A simulated initial 202 named a foreign operation; the helper fetched that foreign receipt. The real outbox marked the original review committed, returned its original attempt as persisted and emptied pending reviews, although the response's attempt ID was foreign. Settings probes separately demonstrated clearing the original key/body after foreign-ID or missing-ID 202. All three reproduce on both the old and new source pins.

This establishes false browser settlement and lost pending retry eligibility under the supplied faulty response. It is not evidence of a production incident, occurrence rate, or deletion of the original database history. The conditional nature is a reason to keep the repair small, not to leave the invariant unprotected.

**Next fix:** pass and validate the exact original operation ID at every durable command confirmation, before any foreign poll or journal mutation. Reuse the current decoder and preserve valid original replay. Queue GET issuance is a separate seam: its server chooses the operation ID, and C01 already adds safe acknowledgment validation there. Do not require a nonexistent client command ID for that request. Promote the reproduced cases into owning tests and run one disposable real-receipt browser recovery journey. See `evidence/frontend/frontend-review.md`, JSON and probe logs.

### 2 — Retained Study controls still have no mounted HTTP owner

**Current product functionality gaps, present before this tranche.**

Manual prefix splitting remains explicit in [SPEC's reduction amendment](https://github.com/aaweaver-actuary/tempo/blob/091ad318b1afaadcb25e5ca44ff526120a202336/SPEC.md#L25-L45). Its reachable training suggestions, home callbacks and editor request preview/accept/reject routes that are absent from the real router. The existing native accept/reject handlers and native transaction proof do not make the UI controls work. Existing browser cases that intercept these endpoints also do not prove backend reachability.

Frozen ordinary exercises have a similarly concrete path. Current queue projections still join published exercises; prepared storage retains their snapshots; the adapter maps them to Study cards; the actual TrainingView mounts the runner. Two focused probes execute that consumer path. Connected presentation requests a missing route despite a retained snapshot. Attempts, self-assessment and feedback routes are also absent, while existing broker handlers and storage remain. This is more than an unused import. The exact route/producer traces are in the frontend and qualification reports.

**Next fix:** restore the finite supported transport through existing owners. Do manual prefix split first, then frozen-exercise compatibility. Prove real HTTP receipt/reload/replay and playable next, preserving active attempts and accepted identities. Classify retired and ambiguous records narrowly; retain their bytes with useful holds and prevent them blocking unrelated ordinary Study. Do not revive standalone authoring or classify every `study-command` as retired. Wider TS/Python grader modernization remains after that support decision, unless a demonstrated required case exposes a specific grading blocker.

### 3 — Settings still asks for the host day, which can suppress the configured day's refresh

**Confirmed function-level BE003 defect; native impact remains to be established.**

At `2026-11-12T02:00Z`, with a UTC host and unchanged `America/New_York` settings, the current settings path requests November 12 even though the Study day is November 11. A later request for November 11 sees the future singleton and returns without signaling the current projection. This control flow is executed against the real functions with storage fakes. [Settings boundary](https://github.com/aaweaver-actuary/tempo/blob/091ad318b1afaadcb25e5ca44ff526120a202336/backend/app/settings_commands.py#L35-L49); [singleton selection](https://github.com/aaweaver-actuary/tempo/blob/091ad318b1afaadcb25e5ca44ff526120a202336/backend/app/services/durable_tasks.py#L271-L290).

The likely consequence is a missing or stale current-day queue remaining unrefreshed until the local date catches up; that symptom was not observed on native PostgreSQL or the installed UI. Both the host-date settings call and singleton rule predate the reviewed interval. Recent context propagation is beneficial and the audit correctly leaves BE003 open.

**Next fix:** capture one instant and choose the effective saved Study timezone for the new settings follow-up. An isolated unchanged-zone correction can ship independently; an implementation that also changes timezone updates needs an explicit backwards-day policy and proof. Preserve immutable receipts and accepted-generation dates while using the existing owner's generation/continuation mechanism for new current-day work; do not freeze the mutable singleton, remove the guard globally or rewrite history. Limit missing-`queue_date` compatibility to supported producers or accepted generations demonstrated by source/history; no arbitrary malformed dictionary or live-data census creates a new gate. Current new-task acceptance already fills the day correctly. Use the supplied reproducer and one native settings/coalescing regression; no scheduling redesign is indicated.

### 4 — Unknown retained stores can be mistaken for no retained work

**Reproduced conditional cutover gap; pre-existing, and an unmet part of C02 acceptance.**

A version-2 foreign offline database containing the expected empty stores plus a nonempty unknown store is exported without losing its bytes. The semantic fact mapper ignores the extra store, however, so authority transition is allowed. The same red probe reproduces on baseline and head. [Storage fact mapper](https://github.com/aaweaver-actuary/tempo/blob/091ad318b1afaadcb25e5ca44ff526120a202336/database/browser/study-connection-storage.ts#L62-L105).

No live unknown store was inspected, and this probe does not show deletion. It shows that an unrecognized retained record fails to hold the affected authority transition.

**Next fix:** emit a scoped unknown/hold fact for nonempty unrecognized stores, preserving existing known terminal semantics and approved same-authority/registered recovery. Retain raw export and keys unchanged; verify actual IndexedDB reload. This can follow the initial-202 fix in the same worker lane as a separate small PR. Full FE005 physical registry separation and FE007 diagnostic purity are lower-priority structural residuals, not prerequisites for this correction.

### 5 — E02's partial acceptance is honest, but shared durability lost an HTTP assertion

**New qualification coverage regression in #1004, alongside valid bounded improvements.**

The maintained selection fixes and executes concrete current checks, validates its finite inventory and preserves explicit exclusions. Source comparison independently confirms its native evidence can be reused across the final browser locator change, and that the merged tree differs from the qualified candidate only in three audit artifacts. Those are good grounds for accepting a bounded harness repair.

The prefix-split HTTP check was nevertheless replaced inside a shared durability function. Full/durability/study consumers also run the native substitute. Only the maintained selection receives the explicit partial scope; broader reporting and CI validation do not check that HTTP limitation. A future green broad run could therefore imply transport coverage that no longer exists. No green full run was observed here. [Shared runner](https://github.com/aaweaver-actuary/tempo/blob/091ad318b1afaadcb25e5ca44ff526120a202336/database/tests/test-postgres-docker.mjs); [plan](https://github.com/aaweaver-actuary/tempo/blob/091ad318b1afaadcb25e5ca44ff526120a202336/database/tests/postgres-test-plan.mjs); [CI stage validation](https://github.com/aaweaver-actuary/tempo/blob/091ad318b1afaadcb25e5ca44ff526120a202336/scripts/ci-run-layer.mjs#L106-L115).

**Next fix:** restore genuine HTTP proof with the retained route repair. Until then, carry the limitation through every affected mode, or preserve the unmet HTTP check outside the explicit partial lane. Use the existing runner/report mechanism.

The selected Study-only browser case has another finite limitation: after worker restart it ignores the replay response and merely asserts the review count remains three. Rejected replay could satisfy that assertion. It genuinely saves three reviews and exercises the first two successor boards; the last successor is only identified in the UI. Capture the actual original replay result and exercise the final board before claiming all three playable transitions. Its 62.16-second stage duration is not a cadence measurement. Native maintained cases separately cover exact replay. [Browser case](https://github.com/aaweaver-actuary/tempo/blob/091ad318b1afaadcb25e5ca44ff526120a202336/tests/browser/study-only-mode.spec.ts#L60-L70).

## 4. Remaining proof and evidence maintenance

The nine failing backend cases are not newly discovered product regressions. Five admission tests still reference removed modules/APIs or retired automatic feedback. Four deletion cases use a fake that deliberately lacks the native adapter API the current storage owner requires. Their baseline attribution was checked at function/API level. Rebind supported invariants to current owners and retire only exclusively obsolete expectations; do not call these whole files green based on passing selected native cases.

E01's current PGN file independently passes all 20 cases. Three rebound fake-storage tests still accept wrong SQL projections/relations or a plain SELECT instead of the intended advisory lock. Temporary in-process mutations demonstrated that blind spot. The actual inspected production SQL is correct. Strengthen those three discriminating assertions when convenient; it is not a reason to restore the retired facade or rerun a large native campaign.

Proof documentation also needs a small update: reader docs still describe E03 as pending or mention historical ten-table ACLs, while current E03 uses the retained three-table Game Review surface. The root progress record still calls #1004 an open draft. All three audit representations agree with one another, but agreement does not make that statement current.

GitHub submitted-review lists and combined commit statuses are empty for final heads of #1002/#1004/#1005/#1006/#1007/#1008. Their narratives report independent review and qualification; the raw Mac-native reports named in those narratives were not available here. These API queries are not a complete check-run inventory. Absence of a GitHub review submission does not prove no independent review happened, and current AGENTS explicitly rejects a universal Guardian receipt gate. Future handoffs should attach or reference the actual bounded review outcome, head/tree and accessible evidence in the existing PR. Do not add an artificial approval process.

## 5. Reconciliation of the previous 25-task continuation

“Complete” below concerns the assigned bounded slice, not every broader architecture finding. Native/browser/install evidence is reported unless separately listed as independently executed above.

| Task | Current disposition |
| --- | --- |
| Q0 | Merged; coordinated native/browser qualification and installation reported. Initial-202 residual remains separate. |
| A01, A02 | Current-owner guide slices delivered via #998/#1003; update newly stale proof descriptions as maintenance. |
| B01 | Bounded unused-alias deletion delivered; BE005 is not fully closed. |
| B02 | Six-counter sharing delivered and component-verified; broader BE011 purge ownership remains. |
| B03 | Scheduling initializer delivered and component-verified; native/assembled acceptance reported. |
| B04 | Complete probe handoff unverified in inspected evidence; do not infer completion from no code diff. |
| E00 | Exact native bridge delivered; refusal tests verified, native execution reported. |
| E01 | Current PGN file rebound and independently green; three SQL assertion blind spots remain. |
| E02 | Merged finite partial proof; full residual categories and shared HTTP limitation remain. |
| E03 | Current read-only reader proof delivered; native execution reported; boundary/refusal tests verified. |
| E04 | Conditional lifecycle work not established or needed solely because test-only main advanced; inspect actual installed→target transition for a future product release. |
| G00 | Complete delivered caller/disposition map unverified; main callsites and explicit residuals traced in this review. |
| G01 | Pure conversion/captured context delivered and focused-component verified. |
| G02 | Partial; historical missing-day task disposition remains. |
| G03 | Partial; settings boundary remains host-day. |
| G04 | Finite native/browser qualification reported; whole-calendar acceptance remains incomplete. |
| C01 | Server-issued queue acknowledgment validation delivered and tested; distinct durable-command expected-ID gap remains. |
| C02 | Partial; semantic facts delivered, unknown-store hold acceptance unmet, physical registry coupling remains. |
| C03 | Inert factory and explicit composition delivered; relevant component and type checks pass. |
| D01 | Retired workspace adapters removed; retained validation/recovery coverage passes. |
| D02 | Deferred supported-exercise recovery work now has a concrete positive producer/consumer trace and finite route gap. |
| D03 | Deferred behind D02 support/compatibility classification; do not start broad grader work preemptively. |
| F01 | Duplicate Rust constructor removed; current source retains one active algorithm. Prior Rust verification reported. |
| F02 | Deferred witness-policy cleanup; no need to create lifecycle-sensitive work merely to occupy a worker. |

## 6. Parallel execution and release order

Use **three creator lanes plus the integration owner**:

| Lane | First slice | Next slice / dependency |
| --- | --- | --- |
| Browser recovery | Original-ID acknowledgment fence | Unknown-store hold follows as a separate small change. |
| Calendar | Settings current-day follow-up | Finite missing-day treatment after exact supported disposition. Independent of other lanes. |
| Retained transport | Manual prefix preview/accept/reject | Frozen ordinary exercises next; integrate the shared original-ID correction before final recovery qualification. |
| Integration owner | Accurate E02 scope, replay assertions, current progress/docs, review and shared-file reservations | One heavy disposable qualification slot; merge accepted subsets, then install useful product releases. |

Source work can proceed concurrently where files and contracts do not overlap. Serialize shared operation transport, route registration, runner and regression inventory edits. Do not make the confirmed original-ID fix wait for every historical E02 case or all remaining 37 audit findings. As capacity frees, repair the named stale tests and SQL assertions. Reuse unchanged-input evidence; repeat tests to resolve actual changed risks.

The credible counterargument is to finish more architecture extraction while the current work is fresh. That would close visible audit rows and may reduce future maintenance. I would still prioritize these functional boundaries: the recovery, route and calendar failures have concrete mechanisms and narrow fixes, while the remaining registry/diagnostic/witness refactors offer less immediate user benefit and introduce additional interface or lifecycle work. A blanket rollout pause would also be disproportionate to inherited, explicitly open residuals; deliver accepted corrections incrementally.

## 7. Installation and authority

The installation assertion is recorded in #1008 and current audit progress: d79, schema 65, five-image identity, services and modes, with no claim of human live Study cadence. This review corroborates source continuity but does not recertify that host. The later main changes do not establish new installed behavior and do not, by themselves, call for reinstalling unchanged product code.

The steering prompt explicitly carries the existing user authority to implement, commit, push and publish scoped PRs; to merge exact accepted heads when the integration owner releases them; and for the owner or designated operator to install an accepted merged product release on the verified registered machine. It preserves real platform/access controls and normal backup/recovery safeguards. A capability failure should yield an exact handoff, not another broad permission question. No merge or installation was performed during this review; these PRs were already merged when inspected.

Read `STEERING-PROMPT.txt` to execute. `LAUNCHER.txt` is the short message to paste to the integration owner. Supporting area reports, results and reproducers are under `evidence/`. They support this bounded follow-up and retain the distinctions between observed facts, reported execution and inferred live impact.
