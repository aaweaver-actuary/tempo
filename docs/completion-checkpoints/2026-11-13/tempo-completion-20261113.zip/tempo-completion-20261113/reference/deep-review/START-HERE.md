# Tempo steering handoff

Start the integration owner first with `LAUNCHER.txt` and this extracted folder.

1. Read `REVIEW.md` for current source/install state, independently observed findings, prior-task dispositions and the recommended release order.
2. Execute `STEERING-PROMPT.txt`. It contains the bounded three-lane assignment, acceptance requirements, shared-file sequencing and explicit push/merge/install authority.
3. Use `evidence/backend`, `evidence/frontend` and `evidence/qualification` for technical traces, reproductions, commands and limitations. `evidence/github` holds the captured PR claims and review/status metadata.

The reproductions intentionally expose current failures. They are not implementation patches. Run them only from an isolated task checkout with its declared dependencies; they make no claim about live data prevalence. See `evidence/REPRODUCING.md`.

Reviewed main: `091ad318b1afaadcb25e5ca44ff526120a202336`. Fetch current main once and inspect any later delta before starting. Do not relaunch every task from the previous continuation packet or treat retired historical work as a new assignment.
