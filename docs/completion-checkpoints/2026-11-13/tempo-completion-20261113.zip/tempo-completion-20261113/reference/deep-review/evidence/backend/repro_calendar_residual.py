"""Read-only function-level proof of the documented BE003 settings residual.

Uses current application functions with storage fakes; makes no database or
service connection and does not establish PostgreSQL or live-user behavior.
"""

from datetime import date, datetime, timezone
from unittest.mock import patch
import json

from app import settings_commands
from app.contracts.transport.settings import Settings
from app.services import durable_tasks
from tempo_learning_review import review_day_at
from tempo_storage.queue_refresh import foreground


NOW = datetime(2026, 11, 12, 2, tzinfo=timezone.utc)
ZONE = "America/New_York"
host_day = NOW.date()
study_day = review_day_at(NOW, ZONE)
events = []
captured_request = []


class HostDate:
    @staticmethod
    def today():
        return host_day


settings = Settings(timezone=ZONE, new_cards_per_day=11)
request = settings_commands.SettingsRequest(
    settings, frozenset({"timezone", "new_cards_per_day"})
)
with (
    patch.object(settings_commands, "date", HostDate),
    patch.object(settings_commands.storage, "locked_settings", return_value={
        **settings.model_dump(), "new_cards_per_day": 10
    }),
    patch.object(settings_commands.storage, "store_settings"),
    patch.object(settings_commands, "request_queue_refresh_in_transaction",
                 side_effect=lambda database, day: captured_request.append(day)),
):
    settings_commands.apply_settings(object(), request)

assert captured_request == ["2026-11-12"]
assert study_day.isoformat() == "2026-11-11"

# Model the already persisted singleton created for that future host day. The
# real request function must choose whether to schedule the actual Study day.
future_task = {
    "id": "original-current-task", "generation": 7, "state": "queued",
    "payload_json": json.dumps({"queue_date": captured_request[0]}),
}
with (
    patch.object(durable_tasks, "_now", return_value=NOW),
    patch.object(durable_tasks.storage, "lock_or_create_current_queue_task",
                 return_value=(future_task, False)),
    patch.object(foreground, "signal_queue_refresh_in_transaction",
                 side_effect=lambda database, day: events.append(("signal", day))),
    patch.object(durable_tasks.storage, "prepare_task_upsert",
                 side_effect=AssertionError("Unexpected task replacement")),
):
    returned = durable_tasks._request_current_queue_in_transaction(
        object(), {"queue_date": study_day.isoformat()}, priority=10,
        max_attempts=5, delay_seconds=0, minimum_generation=0,
    )

assert returned == future_task
assert events == []
print(json.dumps({
    "source_settings_file": settings_commands.__file__,
    "source_task_file": durable_tasks.__file__,
    "now": NOW.isoformat(), "configured_zone": ZONE,
    "host_day": host_day.isoformat(), "study_day": study_day.isoformat(),
    "settings_refresh_day": captured_request[0],
    "subsequent_current_day_request_returned_task": returned,
    "current_day_refresh_signals": events,
    "proof_level": "current-source function execution with storage fakes; no native or live run",
}, indent=2))
