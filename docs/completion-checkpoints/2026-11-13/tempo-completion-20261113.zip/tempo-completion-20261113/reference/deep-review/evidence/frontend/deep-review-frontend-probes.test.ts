import { afterEach, expect, it, vi } from "vitest";
import { saveLocalSettings } from "../../app/lib/settings-save";
import { enqueuePendingReview, flushPendingReviews, pendingReviews } from "../../app/lib/review-outbox";
import { studyIntentStore } from "../../database/browser/study-intent-storage";
import { assertStudyAuthority, retainedStudyData } from "../../app/lib/study-connection";

afterEach(() => { vi.unstubAllGlobals(); });

it("deep review: a foreign initial 202 must not settle the original saved review", async () => {
  const original = { backendId: "original-card", queueEntryId: 99101, attemptId: "deep-original",
    outcome: "again" as const, guided: false, expectedRevision: 3, completedAt: "2026-11-12T21:00:00Z" };
  await enqueuePendingReview(original);
  const requests: { method: string; url: string; key: string | null }[] = [];
  vi.stubGlobal("fetch", vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = String(input), method = init?.method ?? "GET";
    requests.push({ method, url, key: new Headers(init?.headers).get("Idempotency-Key") });
    if (method === "POST") return Response.json({ operation_id: "review-attempt:foreign-review", state: "queued" }, { status: 202 });
    if (url.endsWith("/api/operations/review-attempt%3Aforeign-review")) return Response.json({
      operation_id: "review-attempt:foreign-review", state: "complete", response: {
        persisted: true, attempt_id: "foreign-review", review_id: 9123, requeue_entry_id: null,
      },
    });
    return Response.json({ operation_id: "review-attempt:deep-original", state: "unknown" });
  }));
  const outcome = await flushPendingReviews().then(result => ({ result }), error => ({ error: String(error) }));
  const record = await (await studyIntentStore()).get("review:deep-original");
  console.info("DEEP_REVIEW_FOREIGN_ACK", JSON.stringify({ requests, outcome, pending: pendingReviews(), state: record?.state, receipt: record?.receipt }));
  expect(record?.state).not.toBe("committed");
  expect(pendingReviews()).toContainEqual(expect.objectContaining({ attemptId: original.attemptId }));
});

it.each(["foreign", "missing"])("deep review: %s initial 202 must retain settings identity and bytes", async kind => {
  const requests: { method: string; url: string; key: string | null }[] = [];
  let savedDuringSend: string | null = null;
  vi.stubGlobal("fetch", vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = String(input), method = init?.method ?? "GET";
    requests.push({ method, url, key: new Headers(init?.headers).get("Idempotency-Key") });
    if (method === "PUT") {
      savedDuringSend = localStorage.getItem("tempo-pending-settings-save-v1");
      return Response.json(kind === "foreign" ? { operation_id: "other-settings", state: "queued" } : { state: "queued" }, { status: 202 });
    }
    return Response.json({ operation_id: "other-settings", state: "complete", response: { new_cards_per_day: 88 } });
  }));
  const outcome = await saveLocalSettings({ new_cards_per_day: 12 }).then(() => "resolved", error => String(error));
  const retained = localStorage.getItem("tempo-pending-settings-save-v1");
  console.info("DEEP_SETTINGS_ACK", JSON.stringify({ kind, requests, outcome, savedDuringSend, retained }));
  expect(retained).toBe(savedDuringSend);
  expect(outcome).not.toBe("resolved");
});

it("deep review: a nonempty unknown retained store must not be classified as no work", async () => {
  const databaseName = `tempo-offline-training:${encodeURIComponent("https://foreign.example:study:workspace")}`;
  await new Promise<void>((resolve, reject) => {
    const open = indexedDB.open(databaseName, 2);
    open.onupgradeneeded = () => {
      for (const name of ["training", "opening_attempts", "opening_events", "unknown_retained_work"]) open.result.createObjectStore(name);
    };
    open.onerror = () => reject(open.error);
    open.onsuccess = () => {
      const database = open.result, transaction = database.transaction("unknown_retained_work", "readwrite");
      transaction.objectStore("unknown_retained_work").put({ requestId: "saved-unknown-id", body: "original bytes" }, "original");
      transaction.oncomplete = () => { database.close(); resolve(); };
      transaction.onabort = () => { database.close(); reject(transaction.error); };
    };
  });
  const before = await retainedStudyData();
  const outcome = await assertStudyAuthority("https://target.example", "workspace").then(() => "allowed", error => ({ kind: error.kind }));
  const after = await retainedStudyData();
  console.info("DEEP_UNKNOWN_STORE", JSON.stringify({ outcome, preserved: JSON.stringify(before) === JSON.stringify(after), retainedStore: before.databases[databaseName].unknown_retained_work }));
  expect(outcome).toEqual({ kind: "authority" });
  expect(after).toEqual(before);
});
