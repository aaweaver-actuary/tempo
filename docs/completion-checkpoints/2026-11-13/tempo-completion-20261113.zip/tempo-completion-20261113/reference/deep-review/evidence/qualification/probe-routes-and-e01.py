"""Read-only route inventory and temporary E01 test mutations; no native resources.

Run with a compatible Tempo Python test environment. The optional first argument
is the source root. A successful run reproduces the reviewed limitations; it is
not native product qualification.
"""
import importlib.util
import json
from pathlib import Path
import sys
from unittest.mock import patch

sys.dont_write_bytecode = True
root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1] / 'source'
paths = ['backend', 'database', 'packages/scheduling/src', 'packages/chess-core/src',
         'packages/evidence-math/src', 'packages/game-review-contracts/src',
         'contracts/game-evidence/src', 'services/learning/application/src']
sys.path[:0] = [str(root / path) for path in paths]

from app.main import app
from starlette.routing import Match
from tempo_storage.commands.receipts import storage as receipts

requests = [
    ('GET', '/api/cards/probe/prefix-split'),
    ('POST', '/api/cards/probe/prefix-split'),
    ('POST', '/api/cards/probe/prefix-split/reject'),
    ('GET', '/api/studies/probe/exercises/probe/present'),
    ('POST', '/api/studies/probe/exercises/probe/attempts'),
    ('POST', '/api/studies/probe/exercises/probe/attempts/probe/self-assess'),
    ('GET', '/api/studies/probe/exercises/probe/attempts/probe/feedback'),
]
routes = []
for method, path in requests:
    scope = dict(type='http', method=method, path=path, root_path='', headers=[], query_string=b'')
    matches = [dict(path=getattr(route, 'path', None), match=match.name)
               for route in app.routes if (match := route.matches(scope)[0]) is not Match.NONE]
    routes.append(dict(method=method, path=path, matches=matches))
    assert matches == [], (method, path, matches)

spec = importlib.util.spec_from_file_location('e01_review_tests', root / 'backend/tests/test_pgn_import_storage_boundary.py')
tests = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tests)
mutations = []
with patch.object(tests.storage, 'existing_card_ids', lambda db, ids: db.execute_native(
        'SELECT wrong_projection FROM wrong_table WHERE value=ANY(%s)', (ids,))), \
     patch.object(tests.storage, 'deleted_card_ids', lambda db, ids: db.execute_native(
        'SELECT wrong_projection FROM wrong_table WHERE value=ANY(%s)', (ids,))):
    tests.test_current_import_card_identity_projections_preserve_empty_and_existing_rows()
    mutations.append('identity projection test passed with both wrong table/column queries')

def no_lock(writer, operation_id):
    receipts._receipt_connection(writer).execute('SELECT %s', (operation_id,))

with patch.object(receipts, 'lock_operation', no_lock):
    tests.test_current_import_receipt_lock_preserves_original_identity_and_opaque_writer()
    mutations.append('receipt lock test passed with SELECT parameter and no lock')
with patch.object(receipts, 'operation_status', lambda db, operation_id: db.raw.execute(
        'SELECT wrong_projection FROM wrong_table WHERE id=%s', (operation_id,)).fetchone()):
    tests.test_retained_import_storage_preserves_full_receipt_tuple_and_raw_json()
    mutations.append('receipt projection test passed with wrong table/column query')

print(json.dumps(dict(scope='pure route inventory and in-process mutations; no source edits, server or database',
                     route_count=len(app.routes), routes=routes, e01_mutations=mutations), indent=2))
