// Read-only diagnostic of the existing finite runner functions. No services start.
import assert from 'node:assert/strict';
import { resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = process.argv[2] ? resolve(process.argv[2]) : fileURLToPath(new URL('../source/', import.meta.url));
const { parsePostgresTestOptions } = await import(pathToFileURL(resolve(root, 'database/tests/postgres-test-options.mjs')));
const { postgresTestStages, maintainedQueueCases, unresolvedQueueCases, verifyMaintainedQueueReceipt,
  verifyMaintainedBrowserReceipt, executePostgresTestPlan } = await import(pathToFileURL(resolve(root, 'database/tests/postgres-test-plan.mjs')));

const stages = postgresTestStages(parsePostgresTestOptions(['--mode', 'study', '--maintained-study-proof'], {}, root));
assert.deepEqual(stages, ['compose_config', 'image_build', 'startup', 'service_health',
  'maintained_study_queue_receipts', 'maintained_study_only', 'study_durability', 'study_isolation', 'browser', 'cleanup']);
const queue = { case_set: 'maintained-six', scope: 'partial', execution: 'completed', executed_count: 6,
  cases: maintainedQueueCases, excluded_cases: unresolvedQueueCases, unresolved_owner_cases: unresolvedQueueCases };
verifyMaintainedQueueReceipt(queue);
for (const delta of [{ scope: 'all-eight' }, { executed_count: 5 }, { cases: maintainedQueueCases.slice(1) },
  { excluded_cases: [] }, { execution: 'starting' }]) assert.throws(() => verifyMaintainedQueueReceipt({ ...queue, ...delta }));
const browser = { stats: { expected: 1, skipped: 0, unexpected: 0, flaky: 0 }, suites: [{ specs: [{
  title: 'study_only_mode_preserves_foreground_review_and_queue_progression across reload and resumption',
  tests: [{ results: [{ status: 'passed', retry: 0 }] }],
}] }] };
verifyMaintainedBrowserReceipt(browser);
for (const result of [{ status: 'skipped', retry: 0 }, { status: 'passed', retry: 1 }, { status: 'failed', retry: 0 }]) {
  const altered = structuredClone(browser);
  altered.suites[0].specs[0].tests[0].results = [result];
  assert.throws(() => verifyMaintainedBrowserReceipt(altered));
}
for (const extra of [['--browser-grep', 'anything'], ['--native-check', 'position-grade-effects'], ['--skip-browser']]) {
  assert.throws(() => parsePostgresTestOptions(['--mode', 'study', '--maintained-study-proof', ...extra], {}, root));
}
for (const environment of [{ TEMPO_PG_STALE_DELIVERY_ONLY: '1' }, { TEMPO_RELEASE_CANDIDATE_MODE: 'borrow' }]) {
  assert.throws(() => parsePostgresTestOptions(['--mode', 'study', '--maintained-study-proof'], environment, root));
}
const calls = [];
const actions = Object.fromEntries(stages.map(stage => [stage, () => {
  calls.push(stage);
  if (stage === 'maintained_study_queue_receipts') throw new Error('injected native failure');
}]));
await assert.rejects(executePostgresTestPlan(stages, actions, async (_, action) => action()), /injected native failure/);
assert.deepEqual(calls, [...stages.slice(0, 5), 'cleanup']);
console.log(JSON.stringify({ probe: 'direct imported option/plan/receipt functions',
  scope: 'pure runner logic; no Docker/browser/native execution', selected: stages,
  queue_negative_mutations: 5, browser_negative_mutations: 3, alternate_selection_refusals: 5,
  failure_cleanup_verified: true }, null, 2));
