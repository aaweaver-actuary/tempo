# Backend verification execution log

Source: `091ad318b1afaadcb25e5ca44ff526120a202336`. Baseline: `799b66234b8be386a33d980df10b8b1d9a9d8b36`.

This ledger records actual local executions and tool-output identifiers. It is not a raw stdout transcript. No native service or Docker run occurred.

Interpreter: `/workspace/scratch/0943a4b61604/python-deps/venv/bin/python` (Python3.12.14). FSRS6.3.2. Explicit source PYTHONPATH and `PYTHONDONTWRITEBYTECODE=1`; pytest cache disabled.

## backend-focused

Working directory: `/workspace/scratch/98ef0fd314f3/deep-review/source/backend`

Command: `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$PWD:$PWD/../database:$PWD/../packages/scheduling/src:$PWD/../packages/chess-core/src:$PWD/../packages/evidence-math/src:$PWD/../packages/game-review-contracts/src:$PWD/../contracts/game-evidence/src:$PWD/../services/learning/application/src" /workspace/scratch/0943a4b61604/python-deps/venv/bin/python -m pytest -p no:cacheprovider tests/test_observation_summary.py tests/test_opening_baseline_maturity.py tests/test_position_first_response_codec.py tests/test_study_calendar.py tests/test_position_introductions.py tests/test_position_queue_admission.py -k 'not native' -q`

Observed: **67 passed, 5 failed**, 2 native deselected in 1.27s. Exit1. Tool chunk `ee1219`.

- `tests/test_position_queue_admission.py::test_due_consumers_apply_position_ownership_only_when_schema_present` — ImportError: removed tempo_storage.study.conflicts (line16).
- `tests/test_position_queue_admission.py::test_refresh_consumes_prepared_due_before_advancing` — AttributeError: removed refresh.read_storage.native_configured (line137).
- `tests/test_position_queue_admission.py::test_new_position_issue_fences_source_before_existing_queue_locks_and_rolls_back_stale_head` — AttributeError: removed queue_storage.is_postgres_connection (line630).
- `tests/test_position_queue_admission.py::test_urgent_game_target_is_selected_when_natural_due_is_false` — ImportError: retired tempo_storage.study.game_feedback (line718).
- `tests/test_position_queue_admission.py::test_changed_urgency_rolls_back_inserted_position_plan` — ImportError: retired tempo_storage.study.game_feedback (line850).

## affected-consumers

Working directory: `/workspace/scratch/98ef0fd314f3/deep-review/source/backend`

Command: `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$PWD:$PWD/../database:$PWD/../packages/scheduling/src:$PWD/../packages/chess-core/src:$PWD/../packages/evidence-math/src:$PWD/../packages/game-review-contracts/src:$PWD/../contracts/game-evidence/src:$PWD/../services/learning/application/src" /workspace/scratch/0943a4b61604/python-deps/venv/bin/python -m pytest -p no:cacheprovider tests/test_position_review_reconciliation.py tests/test_scheduling_review_application.py tests/test_tactic_capture_boundary.py tests/test_card_deletion_storage_boundary.py tests/test_card_edits_storage_boundary.py tests/test_durable_task_enqueue_identity.py -q`

Observed: **40 passed, 4 failed** in 1.00s. Exit1. Tool chunk `8401a0`.

- `tests/test_card_deletion_storage_boundary.py::test_cancellation_queries_then_clocks_fetches_and_rechecks_only_exact_matches[False]` — AttributeError: Compatible.execute_native (line109).
- `tests/test_card_deletion_storage_boundary.py::test_purge_preserves_identifier_reads_clock_points_fixed_targets_and_tombstones` — AttributeError: Compatible.execute_native (line131).
- `tests/test_card_deletion_storage_boundary.py::test_repertoire_delete_keeps_shared_owner_retention_policy_and_refresh_after_writes[keep]` — AttributeError: Compatible.execute_native (line188).
- `tests/test_card_deletion_storage_boundary.py::test_repertoire_delete_keeps_shared_owner_retention_policy_and_refresh_after_writes[delete]` — AttributeError: Compatible.execute_native (line188).

## position-scheduling

Working directory: `/workspace/scratch/98ef0fd314f3/deep-review/source/packages/scheduling`

Command: `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$PWD/src:$PWD/../../backend:$PWD/../../database:$PWD/../evidence-math/src:$PWD/../../services/learning/application/src" /workspace/scratch/0943a4b61604/python-deps/venv/bin/python -m pytest -p no:cacheprovider tests/test_position_schedule.py -q`

Observed: **92 passed, 0 failed** in 0.09s. Exit0. Tool chunk `0054c3`.


## learning-application

Working directory: `/workspace/scratch/98ef0fd314f3/deep-review/source/services/learning/application`

Command: `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$PWD/src:$PWD/../../../packages/scheduling/src" /workspace/scratch/0943a4b61604/python-deps/venv/bin/python -m pytest -p no:cacheprovider tests/test_application.py -q`

Observed: **42 passed, 0 failed** in 0.07s. Exit0. Tool chunk `e94b99`.


## Calendar reproduction

Executed `/workspace/scratch/98ef0fd314f3/deep-review/backend/repro_calendar_residual.py` under the same backend source environment; exit0, tool chunk `b26e7e`.

- UTC host/instant: `2026-11-12T02:00:00+00:00`; configured timezone: `America/New_York`.
- Actual Study day: `2026-11-11`; settings refresh day observed: `2026-11-12`.
- Subsequent actual-day task request returned the unchanged future-day task and emitted no current-day refresh signal.
- Uses real application functions with storage fakes. Native queue/user impact was not executed.

## Baseline attribution

All five failing function ASTs identical at baseline. conflicts.py and game_feedback.py absent at baseline; native_configured and is_postgres_connection absent from their source owners at baseline.

Compatible fixture already deliberately rejects execute_native at baseline; storage native calls unchanged since baseline. Two repertoire-delete parameterizations share a function whose only post-baseline body change is later expected calendar-event assertion, never reached by failure. The calendar fixture itself was updated, but native-fixture mismatch predates this tranche.

## Not run

- Native PostgreSQL acceptance, including two deliberately deselected position cases
- Browser/assembled acceptance
- Installed Mac service or image inspection
- Scheduling import-linter/grimp guard: grimp is absent from available existing venv
