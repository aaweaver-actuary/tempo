# Tempo backend/domain/storage review

## Verdict

The integrated backend work is largely sound and appropriately bounded. I found **no newly introduced backend runtime defect that justifies rolling back the merged tranche**. The observation, maturity, and first-response extractions preserve their prior behavior. Fresh position-state construction now belongs to the scheduling package while storage retains allocation, authority fences, and the transaction. The calendar changes improve real active callers, but **BE003 is correctly still partial**.

The highest-value remaining backend work is a concrete existing settings-calendar defect: an ordinary settings save can request the host's next day, after which the singleton queue task refuses requests for the actual configured Study day. That control flow is reproduced here; its live queue/UI impact is an inference awaiting one focused native regression. Nine failing tests are stale fixture/API problems that predate this tranche, not demonstrated runtime regressions.

Reviewed baseline: `799b66234b8be386a33d980df10b8b1d9a9d8b36`. Reviewed current main: `091ad318b1afaadcb25e5ca44ff526120a202336`. Worktree: `/workspace/scratch/98ef0fd314f3/deep-review/source`. No product files, remote state, database, Docker resource, or installed service was changed.

## 1. Confirmed existing calendar defect: settings can request tomorrow

**Classification:** documented BE003 residual, with a confirmed function-level semantic defect. Not introduced by PR1005. Priority: next bounded backend fix; no rollback recommendation.

At `backend/app/settings_commands.py:49`, settings still queues `date.today()` independently of the saved Study timezone. At `backend/app/services/durable_tasks.py:287-290`, an existing singleton whose queue date is greater than the requested date is returned unchanged. That early return precedes the current-day refresh signal at line323.

The scratch reproducer executes the real `apply_settings` and `_request_current_queue_in_transaction` functions with storage fakes:

- Instant and host: `2026-11-12T02:00:00Z`, UTC host.
- Saved timezone remains `America/New_York`; this is **not** a timezone-change edge case.
- Actual Study day is `2026-11-11`.
- Settings refresh requests `2026-11-12`.
- A subsequent request for `2026-11-11` returns the future-day task without signaling the current-day projection.

This establishes the application control flow, not PostgreSQL persistence, live queue symptoms, or user latency. **Impact inference:** if the configured day's projection is missing or stale, it can remain unrefreshed until the local date catches up. Existing playable entries can continue to work. The problem is stronger than a cosmetic date mismatch because the “keep the newer task day” rule suppresses recovery requests for the intended day.

The settings file is unchanged from the baseline, and the future-day early return is preexisting. PR1005 explicitly excludes the settings-zone residual, and the current audit leaves BE003 open. This is a useful refinement of an existing finding, not grounds to reopen accepted B02/B03 work.

**Minimal follow-up:** capture one instant and use the effective configured Study timezone for the new settings operation's follow-up. Preserve all explicit accepted task days, operation IDs, and receipt replay. For an unchanged timezone, the correct follow-up is the configured current Study day. For a timezone change, explicitly choose and document which saved configuration governs the new follow-up; a defensible default is the newly saved zone, but a backwards date change must be coherent with the existing singleton rule. Do not silently remove that guard, overwrite previously accepted task days, or use this as an excuse for a new scheduler.

**Decisive test:** reproduce the unchanged-zone case above through settings and queue coalescing, then add an east-to-west zone change with an outstanding accepted task. Assert the chosen current day is actually signaled while original accepted-day receipts and identities replay exactly. One focused native test for this boundary is justified; the whole product need not be requalified just to develop the fix.

Reproducer: `repro_calendar_residual.py` in this report directory.

## 2. Historical missing-day tasks remain an explicit compatibility question

`backend/app/services/durable_tasks.py:271-275` now fills the day at new current-task acceptance using the configured calendar, and explicit input days are retained. That is the right boundary.

`backend/app/services/postgres_queue_refresh.py:682` still falls back to the host date when an accepted task lacks `queue_date`. The missing-epoch branch at lines685-705 persists that selected day. This is unchanged legacy handling, not a demonstrated fault in current new-task creation. No live missing-day record was inspected.

The next task should finish the exact support/disposition map: explicit day always wins; a genuinely supported missing-day historical task needs a documented one-time treatment. The source alone cannot recover an original day that was never persisted. Do not backfill all history or recompute accepted work under today's zone on each slice. Keep BE003 partial until this compatibility question and settings are settled.

## 3. What the integrated source does well

### Observation summary — B02 / partial BE011

The six-counter helper at `backend/app/study/policy/observation_summary.py:4-20` exactly preserves prior semantics: response means non-None, incorrect means exactly False, assistance requires a response, and clean/manual-failure/corrected retain `int(...)` conversion and its errors.

Both actual callers use it: incremental checkpoint persistence at `backend/app/study/position_checkpoint.py:146-179` and deletion rebuilding at `backend/app/card_deletion.py:88-105`. Signed new-minus-old deltas, distinct clean-day accounting, sorted decision/index order, original JSON, and SQL orchestration are unchanged. The new tests exercise both real callers using reducer-generated prefixes and surviving observations. These pass independently.

Purge orchestration is still owned by the Repertoire application. The change correctly removes duplicate calculation without claiming full BE011 ownership repair.

### Fresh position scheduling — B03 / ST001

`packages/scheduling/src/tempo_scheduling/_position_schedule.py:30-48` provides typed `InitialPositionState`, rejects nonpositive/noninteger IDs and naive instants, retains the pinned FSRS version, and creates Learning step-zero state without a fabricated review.

Both application callers inject it at `backend/app/services/position_queue_admission.py:270-279` and `383-388`. Storage at `database/tempo_storage/study/position_introductions.py:213-230` retains the sealed introduction fence, sequence allocation, insertion and borrowed transaction. Construction failure propagates to the transaction owner; no storage-to-application import or second scheduler was added.

The 92 selected pure scheduling tests and non-native introduction cases pass. The native test explicitly covers failed construction/insertion rollback, retained history and a busy fence, but I did not execute PostgreSQL acceptance here. PR1005 reports that native proof and assembled acceptance; the parent review owns corroborating its receipts.

### Captured calendar — G01 through G03, partial BE003

The context at `backend/app/study/policy/clock.py:13-22` delegates to the existing `review_day_at`. The composition boundary at `backend/app/services/study_calendar.py:8-13` reads the clock and timezone once. The review adapter at `backend/app/services/learning_review_adapter.py:109-137` caches policy as well as the clock/day; reconciliation receives the captured values at lines237-253.

The recorded review instant remains separate from the current local day. Reconciliation fallback uses captured time/day instead of ambient calls (`review_reconciliation.py:130`, `192-202`). Tactic locks, due dates, queue placement, capture, supported authored completion, split, content follow-ups, startup and read observations now receive the context. Required new parameters have real callers updated. Tests cover explicit zones, offset instants, both DST transitions, host-TZ independence, local/unknown fallback, receipt replay, original issued origin and split day agreement.

That is useful active behavior, not merely an unused helper. It is also not full calendar closure: settings and historical missing-day tasks remain.

### PR991, PR992 and PR1002

The maturity helper at `backend/app/study/policy/opening_maturity.py:4-7` is an exact augmentation extraction; normal/replay paired-caller tests pass. It does not change either caller's history selection or scheduling policy.

The first-response codec is an exact move into `backend/app/study/position_learning/first_response_codec.py`; checkpoint aliases retain identity while issuance and grade readers use the pure codec directly. Canonical bytes, digest, adjudication and issued-plan binding tests pass, including an import test that blocks transport/storage/checkpoint startup. I found no new defect in the extraction.

The task-history change at `database/tempo_storage/durable_tasks/storage.py:302-305` casts retained text timestamps to `timestamptz` for instant comparison, preserving stored strings/history. Its focused adapter regression passes. That test alone is not a PostgreSQL execution receipt; PR1002's browser/native claims remain distinct.

## 4. Nine stale tests remain in affected files

Independent source runs produced **241 passed, 9 failed, and 2 deliberately deselected native cases**. Failures are not relabeled as success. Full commands, node IDs, environment and output identifiers are in `verification-log.md` and `verification.json`.

| File | Result relevant to this review | Failure cause |
| --- | --- | --- |
| `test_position_queue_admission.py` | Five failures among selected non-native cases | Removed `conflicts`, `native_configured`, `is_postgres_connection`, and two retired `game_feedback` cases |
| `test_card_deletion_storage_boundary.py` | Four failures | A `Compatible` fake deliberately lacks `execute_native`, which the current native storage owner requires |
| New observation/maturity/codec/calendar and non-native introduction coverage | Passed | No failure in selected new behavior |
| Position scheduling package subset | 92 passed | Includes fresh state, allocation validation, no-clock behavior and real FSRS transitions |
| Pure Learning application | 42 passed | Includes recorded receipt replay and calendar contracts |

**Baseline attribution is source-verified.** All five failing admission function ASTs are identical to baseline. Their missing symbols/modules were already absent at baseline. The deletion fake already rejects `execute_native` at baseline, and its storage's native calls are unchanged. The two keep/delete cases share a function whose post-baseline body edit is a later expected calendar-event assertion; execution fails before that assertion. These are existing proof-maintenance gaps exposed by the review.

**Minimal repair:** rebind the retained due-refresh and source/currentness tests to current owners; retire the two automatic-feedback tests under the current SPEC. For deletion, use a current native-capability fake for orchestration and preserve exact-match cancellation, retention/shared ownership, tombstone and refresh ordering assertions. Do not reintroduce retired APIs or turn the file into a broad skipped compatibility suite. The exact maintained native case can be valid independently of stale sibling tests; the whole file cannot be claimed green.

## 5. Reconciliation against the prior packet

| Task | Honest status | Scope and evidence |
| --- | --- | --- |
| B01 | Complete for bounded source slice | Unused aliases removed; BE005 still partial. Not every originally proposed test suite rerun here. |
| B02 | Complete for source/component slice | Both real computation consumers share exact policy. BE011 still partial; unrelated deletion fixture failures recorded. |
| B03 | Complete in source and focused components; reported native qualification | Both actual callers inject scheduling initializer. Native/assembled execution not independently repeated here. |
| B04 | Unverified handoff | No completed reachability probe deliverable found in inspected source/PR evidence; no implementation diff alone cannot show whether a read-only probe occurred. |
| G00 | Unverified as a complete delivered map | Important callsites traced and residuals documented; no complete original-row disposition handoff found in inspected evidence. |
| G01 | Complete in source and focused components | Sole policy conversion and captured review/replay context. Scheduling import guard not independently executed here. |
| G02 | Partial | Active commands adopted context; new-task day fill fixed; historical missing-day worker disposition unresolved. |
| G03 | Partial | Authoring/startup/read callers adopted context; settings path remains host-day. |
| G04 | Partial, with finite native/browser qualification reported | Reported journey acceptance does not satisfy full-calendar closure while supported settings/residual authority remains. |

This table is not inferred from PR numbers. It distinguishes observed source changes and executed tests from delivery/installation assertions.

## 6. Source versus installed behavior and stop condition

The used Python3.12.14 venv was `/workspace/scratch/0943a4b61604/python-deps/venv/bin/python`; the originally supplied older path was absent. Explicit current-checkout paths were supplied for backend, storage, scheduling, Learning, chess, evidence and contracts. Printed module paths prove the tests imported current source, not a stale installed Tempo package. FSRS was6.3.2. Bytecode and pytest cache were disabled; the checkout remained clean.

The production source diff from claimed installed revision `d79ae4fcc4b006985114d85b5fb9a5aca8becbf1` to current main is empty for `backend/app`, `database/tempo_storage`, scheduling source and Learning application source. That supports source continuity; it does not establish installed images or modes. I did not inspect the Mac or execute services. Native PostgreSQL, browser and assembled acceptance were not rerun under this review's explicit boundary. The available venv lacks grimp, so the import-linter suite was inspected but not independently executed.

**Recommended steering:** retain the accepted extractions; fix the settings current-day follow-up with an explicit zone-change policy and immutable accepted-day replay; finish the finite missing-day disposition; repair only the named supported stale tests and retire obsolete ones. Stop when the changed calendar boundary and its focused native/current-day behavior are proved. There is no evidence here for rollback, a broad scheduling rewrite, another framework, or a universal new gate.
