# Tempo deep frontend and browser-boundary review

Reviewed baseline `799b66234b8be386a33d980df10b8b1d9a9d8b36` against current main `091ad318b1afaadcb25e5ca44ff526120a202336`, with special attention to PR #1006 C01/C02/C03/D01 and the Q0 receipt, integrity, and Game Review changes. Read AGENTS, the current SPEC amendments, component guidance, and the finite test-selection policy. The main review worktree remained clean. All test additions, dependency installation, and build outputs are confined to detached disposable worktrees under this report directory; no product edits, Docker, database, installed service, or browser profile changes were made.

## Judgment

The batch makes genuine bounded improvements. C01 now centrally validates the initial queue-issuance acknowledgment, C02 moves retained-record interpretation into its storage adapter, C03 provides an inert factory import, and D01 removes dead workspace adapter paths while retaining generic validation and recovery tests. I found no newly introduced frontend functional regression in the reviewed delta.

The most valuable next frontend repair is **FE001's documented initial-202 original-ID gap**. It is more consequential than an incomplete architectural closure: a focused negative test proves that a foreign operation acknowledgment can commit the original browser review using the foreign receipt. I reproduced the same failure on the baseline, so this is an existing residual, not a regression caused by #1006 or Q0.

The next retained-functionality question is D02's frozen-exercise transport gap. There is a positive current producer-to-consumer path, not merely an imported obsolete component, but four required HTTP routes are absent. FE005's remaining registry coupling and FE007's mutable diagnostics dependency are lower-priority structural work. Keep them partial; do not turn their closure into a prerequisite for the two concrete functional repairs.

## 1. FE001: the initial 202 can falsely settle the original saved review

**Priority:** P1 next repair because it crosses review settlement authority, with a conditional trigger. No production occurrence or server data loss was observed.

**Evidence:** Independently executed on both baseline and current main. See `probe-results.log`, `baseline-probe-results.log`, and `deep-review-frontend-probes.test.ts`.

`app/lib/operation-status.ts:31-39` clones a 202 body, takes its `operation_id`, and polls that ID. It has no expected-original-ID argument. If the ID is absent, it returns the 202 unchanged. `readReceipt` subsequently checks a receipt against the ID selected from that acknowledgment, so the later check cannot recover the missing relationship to the submitted command.

`app/lib/opening-evidence-review.ts:40-45` has the exact original operation key and sends it in `Idempotency-Key`, but does not pass it to the confirmer. `app/lib/review-outbox.ts:377-385` then commits the original review when the resulting body says `persisted: true`.

The actual diagnostic sequence was:

1. Enqueue review attempt `deep-original` for `original-card` with its answer, revision, and timestamp.
2. POST with `Idempotency-Key: review-attempt:deep-original`.
3. Inject HTTP 202 naming `review-attempt:foreign-review`.
4. The application GETs the foreign operation, whose complete receipt says `persisted: true` and `attempt_id: foreign-review`.
5. `flushPendingReviews()` reports `persistedAttemptIds: ["deep-original"]`; `pendingReviews()` is empty; the original review journal is `committed` with the foreign receipt.

This establishes false browser settlement and removal from pending retry eligibility without original persistence proof. It does not establish that a live server lost a committed review. A mismatched or corrupt acknowledgment is required; ordinary valid own-ID responses still pass the existing suite. That is a credible reason against calling this an emergency rollback, but not against repairing this small boundary before more extraction work.

Two settings probes establish related consequences at `app/lib/settings-save.ts:43-61`:

| Initial response | Observed behavior | Required behavior |
| --- | --- | --- |
| 202 names another settings operation; its receipt completes | Original saved key/body cleared and save resolves | Preserve original key/body; do not poll foreign operation |
| 202 has no operation ID | Save resolves and clears original key/body without any status GET | Keep command unconfirmed and preserve retry identity |

The new tests for foreign **poll receipts** in the migrated callers do not cover this initial acknowledgment seam. The source records already keep FE001 open for this reason. The missing distinction is between a server-issued queue operation, whose ID the browser learns from a GET acknowledgment, and a durable command, whose original ID the browser already owns.

**Smallest repair:** Add an explicit expected original operation ID to the canonical command-confirmation entry point and supply it at durable command callers. Reject a missing, malformed, or different ID before constructing the status URL or mutating the journal. Preserve the exact reconciliation and aggregate-only suffixes already used by reviews. Keep legacy missing-identity *poll receipt* compatibility separate. Any genuinely retained non-operation 202 caller should have an explicit exception supported by current producer evidence; the stale discovery comment should not silently exempt all callers.

Do not create another receipt state machine or general transport layer. Queue GET acknowledgment validation, `readOperationResponse(originalId)`, the existing study-command mismatch guard at `study-command-client.ts:73-80`, and blocked-operation retry that polls its original ID already have distinct useful responsibilities.

**Decisive proof:** Promote the negative review and settings cases into their owning suites. Assert original bytes/ID remain, no foreign status request occurs, no active attempt advances, and correct own-ID completion still settles exactly once. Then demonstrate one real transport/browser initial-202 mismatch followed by original receipt recovery and an authoritative playable successor. Repeating a broad happy-path suite would not answer that question.

## 2. D02: frozen ordinary exercises remain reachable, but their HTTP surface is absent

**Classification:** Existing supported-path gap, not introduced by this batch. Scope and actual installed record prevalence still require owner confirmation; blanket retirement would conflict with current product intent.

`SPEC.md:39-43` retires standalone authoring and automatic generation while retaining generated exercises as frozen ordinary exercises, including content, schedule state, reviews, and lineage. Current code still supplies these to the product:

| Stage | Current source and behavior |
| --- | --- |
| Queue membership | `database/tempo_storage/queue_refresh/eligibility.py:12-28` retains due/new published `study_exercise` eligibility; `queue_refresh/admissions.py:161-175` checks and appends them |
| Queue read | `http_composition/queue_projection.py:25-35` selects published exercise cards, joins their Study, and returns `study_id` and `study_exercise_id` |
| Retirement filter | `http_composition/availability.py:8-10` excludes Defense/Endgames and their precise admission prefixes, not ordinary `study_exercise` cards |
| Current HTTP producer | `backend/app/main.py:737-761` exposes queue/window and queue/prepared through `product_composition/study.py:14-31` |
| Issuance | `backend/app/services/queue_next_card.py:85-89` retains non-opening legacy issuance; the position-opening policy does not classify these as retired |
| Prepared snapshot | `product_composition/study.py:142-152` attaches the current specification through `study/queue_serving.py:62-70` |
| Frontend mapping | `app/domain/adapters/practice-card-adapters.ts:73-75,125-127` maps `study_exercise` to `kind: study`, retaining Study/exercise IDs and snapshot |
| Mounted consumer | `app/views/training_view.tsx:571-578` mounts `StudyExerciseRunner` for that card |

The mounted online runner calls presentation at `study_exercise_runner.tsx:106`, feedback at `:201`, and attempt/self-assessment recovery at `:224-235`. Retained offline replay posts to the same attempt and self-assessment surfaces at `offline-training.ts:237-249,290-309`.

Two additional scratch consumer tests passed through the real frontend composition: a valid prepared snapshot was saved/read through the existing IndexedDB adapter, mapped by `loadEligibleOfflineQueue`, and rendered by the actual `TrainingView` as the Study exercise prompt without a network request. The same mapped card in connected mode called the missing presentation endpoint and rendered its 404, even though the card contained the frozen snapshot. See `frozen-reachability-results.log` and `deep-review-frozen-reachability.test.tsx`. This establishes executable frontend reachability; native PostgreSQL selection and live record prevalence remain unmeasured.

The four missing surfaces are:

| Method | Required path |
| --- | --- |
| GET | `/api/studies/{study_id}/exercises/{exercise_id}/present` |
| POST | `/api/studies/{study_id}/exercises/{exercise_id}/attempts` |
| POST | `/api/studies/{study_id}/exercises/{exercise_id}/attempts/{attempt_id}/self-assess` |
| GET | `/api/studies/{study_id}/exercises/{exercise_id}/attempts/{attempt_id}/feedback` |

Source search finds no mounted owner. The independent qualification reviewer additionally matched these methods/paths against the actual 58-route `app.main` FastAPI router and obtained no match, without running lifespan, a server, or a database (`../qualification/routes-and-e01-probe.json`, independently read here). The broker command handlers nevertheless remain registered at `backend/app/tasks.py:47` and `study_attempt_commands.py:208-209`, with native storage available. This is a finite transport gap around retained behavior, not evidence that all underlying operations should be recreated.

Online absence produces the runner's `loadError` and a reload-only Retry at `study_exercise_runner.tsx:353`. Offline replay preserves the attempt but throws on HTTP 404 before acknowledging it; that pass stops before later entries. Existing runner tests mock these routes, so they cannot prove the real route exists.

**Smallest next action:** Assign a bounded compatibility slice to the current Study owner. Trace one eligible frozen ordinary exercise and one retained offline attempt, classify supported versus explicitly retired/ambiguous provenance, and restore only the required read/dispatch surfaces over existing handlers/storage. A genuinely unsupported record should receive an explicit recoverable hold with original IDs/body/receipt preserved. Do not mark every `study-command` retired or resurrect standalone Studies authoring.

**Decisive proof:** An actual supported frozen exercise goes through HTTP presentation, submission, feedback, original receipt recovery, and a playable next card. An existing offline attempt and a self-assessment recover without identity/body changes. Explicitly retired and ambiguous records remain inspectable and do not block unrelated valid Study. No claim is made that this review established installed database prevalence or ran that assembled journey.

The qualification reviewer owns the related manual prefix-split route gap. Its frontend exposure is also real (`training_view.tsx:467-480`, `practice-card-adapters.ts:68-71`) and its broker handlers remain registered. Keep that as a separate retained-interface repair rather than absorbing it into D02.

## 3. C02/FE005: useful fact extraction, with a further inherited unknown-store gap

The new `RetainedWorkFact` contract is independent of browser record layout. `assertStudyAuthority` now uses those facts rather than directly reading intent/prepared/opening record fields. The malformed-foreign-training correction is explicit and bounded: missing `attempts` becomes an unknown fact, foreign cutover holds, and same-authority or registered recovery retains the previous policy. Current tests check terminal states, unknown delivery states, original bytes, and recovery behavior.

A further negative probe shows that a nonempty unknown object store is omitted from the semantic facts. `study-connection-storage.ts:29-51` requires the known stores but permits extras and reads all values for export. The mapper at `:69-103` interprets only known intents, opening attempts, training snapshots, and legacy keys. A foreign version-2 offline database containing the required empty stores plus a nonempty `unknown_retained_work` store is therefore exported accurately but produces no nonterminal fact. `study-client.ts:149-159` allows cutover to another authority.

The probe reports **bytes preserved, cutover allowed**. No deletion was observed. Baseline produces the same result; this is a newly demonstrated existing C02 acceptance gap, not a regression. It is conditional on an unrecognized populated retained store, and no such live store was inspected.

**Minimal repair:** At the storage adapter, classify nonempty unrecognized stores as a scoped unknown fact or explicit incompatible-schema outcome. Preserve recognized terminal rules and approved same-authority/registered recovery. Verify keys and values remain unchanged. No global registry redesign, mutation, or journal framework is needed.

The already recorded structural residual also remains: `study-client.ts:19-27` exposes raw registry JSON strings, `:44-45,78-94` derives physical database names and interprets/casts `offlineDatabase`, and `:232-235` serializes the binding. This is architectural coupling, not demonstrated new runtime damage. A later assigned slice can move physical registry decoding/naming behind the existing adapter while leaving authority-transition policy in the client.

## 4. C03, D01, FE007, and Q0: what the evidence actually supports

**C03:** `app/lib/study-client.ts` imports only a type-only domain contract and Zod; no singleton, browser storage, transport, or listener is constructed on import. Runtime callbacks are explicit. Session restore occurs only on client construction with opt-in persistence. `study-connection.ts` remains the compatibility composition and supplies defaults. The absence/throwing-global import cases, two-client credential isolation, original request bytes/signals, stale-generation authentication, activity hold release, and reconnect cases all passed. Existing consumers have not all migrated to independent clients, which is correctly outside the claim.

**C01:** `operation-result-adapter.ts:43-52` checks safe acknowledgment ID/state through the canonical result vocabulary. `fetchAndInitializeQueue.tsx:221-241` polls exactly that acknowledged server-created ID, requires identity in the receipt, rejects invalid states, and never installs `receipt.response` as a queue. Completion triggers another authoritative queue read at `:249-257`. Abort, bounds, and `Retry-After` mechanics are unchanged. This seam does not close the durable-command initial-202 gap above.

**D01 and FE007:** The dead Games summary/Endgame template adapter branches and unused analysis adapter were removed; retained cache/diagnostic tests were rebound to the current repertoire producer. The shell type now uses public `@tempo/board-ui`, avoiding the private component type edge. However, `workspace-adapters.ts:4` still imports runtime parsing from `data-validation.ts`; the latter owns a mutable diagnostic/listener singleton at `:24-38` and parsing writes to it at `:98-107`. This is a parse-time side effect and dependency-direction residual, not proof of browser startup or bundle harm. FE007's partial status is accurate. If assigned later, split pure parsing from injected collection/reporting and add a type-aware negative dependency test; do not claim closure from file relocation.

**Q0 receipt migration:** The changed caller polls now use the canonical decoder, preserve malformed/foreign poll receipts, and in several paths validate completion payloads before deleting retained state. Integrity repair keeps its special retry metadata and legacy no-payload recovery without a second protocol-state enum. Relevant existing tests pass. This is a real improvement even though initial acknowledgment binding remains incomplete.

**Game Review and integrity UI:** The new pure Game Review decoder checks arrays, legal UCI replay, coherent FENs, comparison variants/bounds, and saved orientation before rendering. Malformed successful replies become recoverable errors; stale requests cannot overwrite newer input. Removing the retired optional position-summary request from the integrity dialog avoids that dead dependency. I found no new fault in these changed paths. Passing unit/component cases and source inspection do not independently re-establish the previously reported native/browser installation evidence.

## 5. Verification and limits

| Check | Independently observed result |
| --- | --- |
| Selected current unit tests | **327 passed across 16 files**, 11.22 seconds |
| Browser TypeScript check | **Exit 0**, `tsc -p tsconfig.browser.json --noEmit --incremental false` |
| Current negative probes | Four intended invariant assertions fail, directly exposing the review foreign-ID, settings foreign-ID, settings missing-ID, and unknown-store cases |
| Baseline negative probes | Same four failures; establishes that the observed behaviors predate the review range |
| Frozen prepared/connected reachability | **Two passed**, through actual prepared storage, mapper, and mounted TrainingView; connected case observes the expected absent-route error |
| Source review worktree | Clean; no product edits |

The finite unit selection covers the canonical decoder, queue issuance/status, client factory/operation binding/reconnect, workspace/cache/diagnostics, integrity outbox/dialog, Game Review contract/view, review-client capability, and settings persistence. Exact command and files are in `frontend-review.json`. The baseline uses the task-owned dependencies and package outputs after checking that `package.json`, lockfile, and all three built workspace packages are unchanged between revisions.

Runtime: Node 24.22.1, npm 11.9.0, Vitest 5.0.1, jsdom/fake-indexeddb. Dependencies were installed only in `frontend/test-source`; all three package builds were local to that checkout. These tests establish JavaScript/storage-adapter behavior, not native IndexedDB, a live PostgreSQL transaction, assembled browser recovery, or installed release behavior. No new native/browser/installation pass is claimed.

The first prepared-reachability fixture omitted four required queue-projection metadata fields and failed schema validation before reaching the product path. The fixture was corrected to the current schema, with no assertion or product changes, and both cases then passed. The initial failure log is retained. The TypeScript command's independently observed exit-0 receipt is recorded separately in `typecheck-browser-receipt.json`; the command produced no diagnostic output.

## 6. D03 stop point and steering

Keep D03 deferred until the retained dual-runtime support/recovery contract is settled by D02. The existing snapshot declares `grader_version: 1` (`study-exercises.ts:25-27`), while `OfflineAttempt` has no grader version (`domain/offline-training.ts:7-32`) and `recordOfflineStudyAttempt` saves assessment/answer without one (`offline-training.ts:198-209`). TypeScript/Python input bounds also differ (`study-exercises.ts:18-23` versus `contracts/study_exercises.py:74-99`). Those are concrete reasons to define compatibility before policy changes, not a reason to launch a general grader rewrite now.

Recommended frontend sequence: repair expected-original-ID confirmation; repair the finite retained exercise transport contract with appropriate backend ownership; close the bounded unknown-store fact gap; then decide whether the remaining physical registry and diagnostic dependency cuts justify their implementation cost. Preserve acknowledged partial progress and keep installed acceptance claims tied to their actual source and runner evidence.
