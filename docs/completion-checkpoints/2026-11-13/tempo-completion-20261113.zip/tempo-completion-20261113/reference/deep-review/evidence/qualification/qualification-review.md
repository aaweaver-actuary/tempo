# Tempo qualification review

## Judgement

The reviewed changes materially improve finite, executable proof. The E00 bridge refuses empty, skipped, duplicated or incomplete pytest execution. E03 now exercises the actual saved/pasted Game Review HTTP producer with packaged source hashes, a read-only database role and before/after Study snapshots. E02 labels its maintained selection partial and retains the excluded owners instead of calling them passed.

**Merging #1004 is defensible as a finite test-harness repair. It does not establish full E02 completion, a healthy full/durability lane, or installed acceptance of current main.** One coverage change needs particular attention: the prefix-split HTTP check was replaced inside a shared durability action, so ordinary full/durability runs also lose that HTTP assertion, although only the maintained selection receives the explicit partial acceptance label.

The missing prefix-split transport is a current retained-product defect, present before this review baseline. Manual Study prefix splitting remains in the specification and the normal packaged UI still calls its endpoints. This is the highest-value next boundary to repair and exercise. Do not classify the route as retired merely because the native command test passes.

No product code, remote state, installation or live data was changed by this review. Source worktree was clean after the checks.

## Scope and evidence limits

- Baseline: `799b66234b8be386a33d980df10b8b1d9a9d8b36`.
- Reviewed main: `091ad318b1afaadcb25e5ca44ff526120a202336`, tree `e727a9d8580122b215f9f7f941b32129ea1a8249`.
- Principal PRs: [#997](https://github.com/aaweaver-actuary/tempo/pull/997), [#1002](https://github.com/aaweaver-actuary/tempo/pull/1002), [#999](https://github.com/aaweaver-actuary/tempo/pull/999), [#1007](https://github.com/aaweaver-actuary/tempo/pull/1007), [#1004](https://github.com/aaweaver-actuary/tempo/pull/1004).
- PR bodies and comments were read from the root review's GitHub captures at `deep-review/evidence/prs.json` and `pr-comments.json`. Their reported native/browser outcomes are secondary evidence in this review; the underlying Mac-native report files named in those bodies were not independently available here.
- This environment has Python 3.12.14 and Node 24.22.1, but no Docker executable. The initial full runner `--list` attempt stopped at missing `chess.js`; this was a dependency failure before discovery, not a failed native/browser case. A compatible existing Python venv was then reused for the focused pure/boundary tests. No native PostgreSQL, Docker, browser or live installation rerun is claimed.

## Independently verified results

The current source passed **66 focused Python tests** across these six files, with no skips: `database/tests/test_position_native_pytest_bridge.py`, `database/tests/test_native_split_pytest_bridge.py`, `backend/tests/test_packaged_game_review_reader_boundary.py`, `backend/tests/test_queue_attempt_recovery.py`, `backend/tests/test_pgn_import_storage_boundary.py`, and `backend/tests/test_durable_task_enqueue_identity.py`. These are bridge, refusal, selector, fake-storage and source-boundary checks; they are not native acceptance. The eight position bridge unittest cases also passed separately before the shared environment was available; those eight overlap the 66 and should not be added to it.

Direct calls to the real dependency-free option/plan modules confirmed the ten maintained stages, rejected five altered queue receipts, rejected three skipped/failed/retried browser results, rejected five alternate selection/environment combinations, and ran cleanup after an injected maintained-queue failure. These were small diagnostic probes of existing functions, not a new qualification runner.

A pure assembled FastAPI route inventory found 58 routes and **zero matches** for GET and POST `/api/cards/probe/prefix-split`, and POST `/api/cards/probe/prefix-split/reject`. No server or database was started. At the frontend reviewer's request the same inventory also confirmed zero matches for four retained exercise present/attempt/self-assess/feedback paths; that separate retained-exercise finding is owned by the frontend review.

Two source-equivalence claims in #1004 are independently correct:

| Comparison | Actual differences | Consequence |
| --- | --- | --- |
| Native-qualified `a46019d0d0526f31fab88d410603c360653dab40` → browser-qualified `2c5a32140d5fad3cc791bf39d912b34f2b4d50f3` | Only two Settings navigation calls in `tests/browser/study-only-mode.spec.ts` | Reusing the earlier native results for this final browser locator repair is justified by unchanged native/product/fixture/runner inputs. |
| Final qualified `2c5a32140d5fad3cc791bf39d912b34f2b4d50f3` → merged `091ad318b1afaadcb25e5ca44ff526120a202336` | Only `tempo-architecture-audit.html`, `tempo-architecture-registry.xlsx`, and `tempo-low-fruit-20261112/progress/merge-review.json` | The reviewed merge tree preserves the qualified executable and browser inputs. Actual tree `e727a9d8…` matches the recorded merge-tree simulation. |

The actual trees are `3809d8bad7ee49afec336fc85f2e6bec8014806a` at a460 and `4665bf298ab80f406f42e76481c7d66ce2c30992` at 2c5a.

## Findings, ordered by practical value

### QF-01 — Retained manual prefix splitting has no HTTP route

**Priority: high. Classification: pre-existing product functionality gap, not introduced by #1004.**

[SPEC.md lines 25–45](https://github.com/aaweaver-actuary/tempo/blob/091ad318b1afaadcb25e5ca44ff526120a202336/SPEC.md#L25-L45) retains manual Study prefix splitting while retiring advanced prefix workflows and automatic recombination. The normal production web image runs `build:local`, which makes `independentStudy` false. The training suggestion remains reachable for a multi-move opening with at least three Again entries and no recorded rejection. It wires real Accept/Reject callbacks; the editor also requests a preview.

The actual consumers are [training_view.tsx](https://github.com/aaweaver-actuary/tempo/blob/091ad318b1afaadcb25e5ca44ff526120a202336/app/views/training_view.tsx#L467-L480), [home_view.tsx](https://github.com/aaweaver-actuary/tempo/blob/091ad318b1afaadcb25e5ca44ff526120a202336/app/views/home_view.tsx#L1369-L1400), [prefix-split-command.ts](https://github.com/aaweaver-actuary/tempo/blob/091ad318b1afaadcb25e5ca44ff526120a202336/app/lib/prefix-split-command.ts#L28-L75), and [card_editor.tsx](https://github.com/aaweaver-actuary/tempo/blob/091ad318b1afaadcb25e5ca44ff526120a202336/app/views/card_editor.tsx#L108-L139). The backend retains `cards.prefix_split.accept`/`reject` registration in [prefix_split_commands.py](https://github.com/aaweaver-actuary/tempo/blob/091ad318b1afaadcb25e5ca44ff526120a202336/backend/app/prefix_split_commands.py#L36-L96), but none of the three HTTP routes exists in the assembled router. Baseline 799 also lacks these routes.

**Impact:** a supported user action reaches no transport endpoint. The native command's transaction success does not make the UI action work. The existing prefix-split browser tests intercept these endpoints, so they do not establish backend reachability.

**Minimal next action:** reconnect the three finite routes to the existing read/command owners, preserving revision, original operation ID, source/currentness, active-attempt and queue placement checks. Add one real disposable HTTP/browser acceptance that previews/accepts, confirms the original durable receipt and exact split rows, reloads/replays without a second effect, and plays the authoritative successor; cover rejection with the existing local contract plus a real route assertion. Do not restore advanced prefix evaluation or recombination. Backend owns transport; frontend owns its existing consumer; the integration owner runs one assembled proof.

### QF-02 — Shared durability no longer proves prefix-split HTTP

**Priority: medium. Classification: introduced qualification coverage regression in #1004.**

The prior `verifyForegroundAndStudyDurability` performed GET preview and POST accept. Current [test-postgres-docker.mjs lines 759–761 and 875–896](https://github.com/aaweaver-actuary/tempo/blob/091ad318b1afaadcb25e5ca44ff526120a202336/database/tests/test-postgres-docker.mjs#L759-L761) instead invokes an injected Python program inside the foreground worker. Its [fixture](https://github.com/aaweaver-actuary/tempo/blob/091ad318b1afaadcb25e5ca44ff526120a202336/tests/fixtures/postgres-study-prefix-split.py) honestly labels itself `native-command-durability-not-HTTP`, checks the owned database/schema and membership, and verifies one split plus exact replay.

However, this helper is shared by full, durability and study plans. [postgres-test-plan.mjs](https://github.com/aaweaver-actuary/tempo/blob/091ad318b1afaadcb25e5ca44ff526120a202336/database/tests/postgres-test-plan.mjs#L8-L30) retains the same `study_durability` stage. Only `--maintained-study-proof` emits `partial-maintained-study-not-full-E02` and the explicit unresolved-transport receipt; other modes retain their mode name as acceptance scope. [validatePostgresScenarios](https://github.com/aaweaver-actuary/tempo/blob/091ad318b1afaadcb25e5ca44ff526120a202336/scripts/ci-run-layer.mjs#L106-L115) checks identity, stage inventory and exit codes, not this reduced transport coverage.

**Impact:** a future successful full/durability run could be read as preserving its earlier HTTP proof when it no longer does. No such successful full run was observed here, and other known residual owners still block those broad paths. This is a claim/coverage hazard, not evidence that #1004's explicitly partial native results are false.

**Minimal next action:** restore the actual HTTP proof as part of QF-01. Until then, carry the unresolved transport limitation in every consuming mode or leave the normal HTTP check failing outside the explicit partial lane. Reuse existing plan/report machinery; no new evidence framework is needed.

### QF-03 — Browser restart replay can pass after a rejected resend

**Priority: medium. Classification: pre-existing proof limitation in the retained browser case.**

[study-only-mode.spec.ts lines 65–70](https://github.com/aaweaver-actuary/tempo/blob/091ad318b1afaadcb25e5ca44ff526120a202336/tests/browser/study-only-mode.spec.ts#L65-L70) restarts workers, resends the first original review, discards its `APIResponse`, and then asserts only that reviews remain three. A 4xx or 5xx resend rejection also leaves three reviews and satisfies this check. It proves absence of an observed duplicate under resend, not successful replay acceptance.

The test does save three actual reviews and exercises the first two successor boards. Its final fourth queue entry is checked by rendered identity at lines 60–64, but no fourth-board legal move or input-enabled assertion is made. Thus it should not be promoted into a claim of three verified saved-review-to-playable-successor transitions, or a latency measurement. #1004 correctly disclaims interpreting the 62.16-second stage as cadence; preserve that limitation.

**Minimal next action:** capture and validate the replay response or settle its exact original operation receipt, compare the original result and final queue identity, and retain the three-review count. If a claim of three playable transitions is desired, make one legal move on the final successor without inventing an extra completed review. Existing native maintained cases independently assert exact replay and therefore support the finite native acceptance despite this browser limitation.

### QF-04 — Three rebound E01 tests accept incorrect SQL

**Priority: low; nonblocking. Classification: observed unit-test blind spot, not a demonstrated production SQL defect.**

The fake `Borrowed` driver returns preloaded rows regardless of SQL. The receipt projection, existing/deleted identity projection and receipt lock tests in [test_pgn_import_storage_boundary.py lines 177–256](https://github.com/aaweaver-actuary/tempo/blob/091ad318b1afaadcb25e5ca44ff526120a202336/backend/tests/test_pgn_import_storage_boundary.py#L177-L256) check parameters and fake output but not the intended query/lock. Temporary in-process mutations confirmed all three can remain green when the projection queries address the wrong table/column or the lock is replaced by a plain `SELECT %s` with no lock. No file was changed by that experiment.

The current production queries and lock are correct on inspection. E01 legitimately retires the removed approval facade and keeps a focused borrowed-owner boundary; it never claims native persistence proof. This gap therefore does not invalidate its 20 passing cases or justify restoring obsolete facade APIs.

**Minimal next action:** strengthen the existing three tests to reject wrong projections/relations and missing advisory lock, including a nonempty deleted-ID result, then update their existing regression inventory descriptions. Keep the proof boundary narrow; do not add an unrelated native suite.

### QF-05 — Current proof documentation still describes retired/pending evidence

**Priority: low. Classification: stale canonical documentation.**

`database/tests/README.md` still calls E03 pending and says its reader script targets historical feedback relations with ten ACLs. `docs/testing.md` also describes the old producer and ten-relation proof. Current E03 verifies three current relations and saved/pasted comparison. `tests/REGRESSIONS.md` lines 6785–6790 still names E01's removed inert-facade case and retired preview/INTRANS behavior. `tempo-low-fruit-20261112/progress/merge-review.json` still describes #1004 as an open draft checkpoint even though it is merged in current main.

**Minimal next action:** update those existing records to distinguish accepted finite E00/E01/E03, the reported d79 installation, merged partial E02 and its exact residual owners. This is evidence alignment, not authority to close broader findings or require reinstalling unchanged product code.

## Assessment of the principal claims

| Slice | Actual source behavior | Assessment of reported acceptance |
| --- | --- | --- |
| E00 / #997 | Finite native selector, hash-locked pytest dependencies, fresh database with parent marker, exact node collection and setup/call/teardown, owned cleanup on failure/success. | Sound bounded bridge. Source and local refusal tests support no skip/zero-selection escape. PR #1002/#997 report the real 1/1 native pass; this review did not rerun it. |
| Q0 / #1002 | Real operation receipts, malformed/foreign response rejection while preserving original journals, two actual subsequent opening boards at each viewport, task-history timestamp cast. | Stronger assembled evidence than a health/200 check. Reported 13 distinct browser passes across retained successful attempts and focused reruns is properly separated from earlier failures. Native unchanged-input reuse is explicitly disclosed. The cast unit test is a shape/borrowed-read guard; browser native execution is the separate SQL evidence. |
| E01 / #999 | Six stale facade cases rebound to current PGN/receipt owners; original batches, identities, lifecycle and discard checks remain. | Scoped proof repair is justified. 20/20 is independently included in the 66 current passes. QF-04 limits SQL semantics inferred from fake replies. |
| E03 / #1007 | Current three-table reader ACLs, no API writer URL, exact schema ledger, six declared packaged file hashes, immutable image identities, real list/saved/pasted HTTP, exact before/after selected Study/fixture rows, owned seed cleanup. | Appropriate minimal read-only Game Review proof. It does not prove retired feedback, provider intake, all possible repertoire cases or installed behavior. Six browser and four single-case native passes are reported secondary evidence. |
| E02 / #1004 | Fixed maintained six plus nine Study-only assertions, five current priority cases, eighteen opening variants and restart, shared durability, isolation and one browser case. Default eight queue cases and six priority cases remain. | Honest partial acceptance. Exact reuse/merge equivalence is verified. Preserve four categories of residual and QF-02/QF-03 limits. No full E02 closure follows. |

The four E02 residual categories remain: real-game obligation queue owner; retired opening-evidence reconciliation queue owner; historical priority 49→48→49 rollback, unexecuted; prefix-split HTTP transport. The first three need finite classification under current product retention requirements, not automatic restoration of retired producers. The fourth is required retained functionality and has concrete live consumers.

## Source binding and installation distinction

The native bridge records HEAD and immutable image ID, but normal runner mode sets the revision from `git rev-parse HEAD` and does not enforce clean worktree/source-byte equality. Its source test imports run from the mounted checkout. The clean-source guard currently exists for release-candidate reuse, not every ordinary native invocation. Accordingly, a native JSON receipt alone is not proof of exact clean commit bytes; keep the actual source/tree/clean-status comparison with any reused acceptance. #1007 explicitly reports clean source and an exact tree; #1004 provides verifiable executable-input comparisons. No contradictory runtime source binding was observed, so this is a limit of the reusable artifact, not a finding that those runs used wrong code. Reuse the existing clean-source/tree checks when the owner prepares the next qualification; do not build another receipt platform.

The repository and PRs report installation `d79ae4fcc4b006985114d85b5fb9a5aca8becbf1`, schema 65, five-image receipt, verified at `2026-11-12T19:31:39Z`. This review independently verifies that **d79→091ad changes only test/harness/fixture and audit files**, with no application, storage implementation, scheduler or schema delta. It does not independently inspect the current live host. There is no basis here for calling 091ad installed, and no new product behavior requiring a test-only reinstall is identified.

## Review traceability

The root reviewer’s fresh GitHub inspection is retained in `deep-review/evidence/review-traceability.json`: the final heads of #1002/#1004/#1005/#1006/#1007/#1008 had no submitted GitHub reviews and no combined commit statuses returned by those queried endpoints. This does not establish check-run absence, erase local review, or create a new required GitHub approval gate. Current AGENTS explicitly allows a bounded Guardian-like review without a universal special receipt. It does mean the durable evidence found here for independent review and native success is mainly the PR narratives and audit summary, rather than the actual reviewer findings and underlying native reports.

Preserve the existing reviewers’ scoped conclusions and the referenced result artifacts or exact hashes/locations in the existing PR or release record when preparing the next handoff. This is a traceability repair, not a reason to repeat unchanged broad tests or demand new permission.

## Recommended next move

Prioritize the retained HTTP boundary over broad proof cleanup: repair manual prefix preview/accept/reject using existing owners and restore its real HTTP acceptance, while strengthening the retained Study-only replay assertion in the same proof-owner handoff if convenient. Coordinate this with the separately identified frozen-exercise transport gap; do not recreate retired authoring/provider systems. Then classify the two legacy queue cases and historical rollback explicitly, using the current specification and retained-data obligations to decide whether to retire, replace or qualify them.

The credible counterargument is that #1004 was expressly a partial harness task and should not have been forced to repair product routes. That is correct and supports accepting its bounded merge. It does not support treating the missing retained routes as obsolete, closing full E02, or allowing the global durability stage to conceal the transport omission.
