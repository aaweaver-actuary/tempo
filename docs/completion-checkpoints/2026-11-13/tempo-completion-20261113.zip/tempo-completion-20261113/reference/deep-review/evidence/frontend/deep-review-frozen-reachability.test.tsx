import { render, screen } from "@testing-library/react";
import { afterEach, expect, it, vi } from "vitest";
import TrainingView from "../../app/views/training_view";
import { mapQueueCardToPracticeCard } from "../../app/domain/adapters/practice-card-adapters";
import { savePreparedTraining, readPreparedTraining, requiresConnectedGrading } from "../../app/lib/offline-training";
import { loadEligibleOfflineQueue } from "../../app/views/fetchAndInitializeQueue";

vi.mock("../../app/components/chessboard", () => ({ Chessboard: () => <div data-testid="board" /> }));
afterEach(() => vi.unstubAllGlobals());
const fen = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
const card = {
  id: "frozen-card", queue_entry_id: 99201, kind: "exercise", content_type: "study_exercise",
  start_fen: fen, moves: ["e2e4"], repertoire_name: "Frozen ordinary", repertoire_source: "Study",
  study_id: "frozen-study", study_exercise_id: "frozen-exercise", revision: 1,
  study_snapshot: { schema_version: 1, grader_version: 1, exercise_id: "frozen-exercise", revision: 1, fen,
    specification: { type: "move_line", prompt: "Frozen exercise is reachable", hint: "", explanation: "Reference",
      mode: "single", grading_policy: "reference", accepted_lines: [["e2e4"]] } },
};
const props = { dateLabel: "Today", serviceError: "", refreshDatabaseQueue: vi.fn(), cardsLeft: 1,
  boardTheme: "brown" as const, pieceSet: "cburnett" as const, rateCard: vi.fn(async () => undefined),
  handleAttemptFailure: vi.fn(), resetCardAttempt: vi.fn(), onMove: vi.fn() };

it("deep review: existing prepared storage and queue mapper deliver frozen exercises into the mounted Study runner", async () => {
  await savePreparedTraining({ local_date: "2026-11-12", prepared_at: "2026-11-12T21:00:00Z", cards: [card], count: 1,
    projection: { state: "ready", generation: 1, updated_at: "2026-11-12T21:00:00Z", refresh_pending: 0, last_error: null } });
  const stored = await readPreparedTraining();
  expect(stored).not.toBeNull();
  expect(requiresConnectedGrading(stored!.cards[0])).toBe(false);
  const mapped = await loadEligibleOfflineQueue(stored!);
  expect(mapped[0]).toMatchObject({ kind: "study", studyId: "frozen-study", studyExerciseId: "frozen-exercise" });
  const fetcher = vi.fn(); vi.stubGlobal("fetch", fetcher);
  render(<TrainingView {...props} card={mapped[0]} offlineQueue />);
  expect(await screen.findByText("Frozen exercise is reachable")).toBeTruthy();
  expect(fetcher).not.toHaveBeenCalled();
  console.info("DEEP_FROZEN_PREPARED_REACHABLE", JSON.stringify({ storedKind: stored!.cards[0].content_type, mappedKind: mapped[0].kind, mountedPrompt: true, requests: 0 }));
});

it("deep review: connected queue card uses the missing presentation route even when a frozen snapshot exists", async () => {
  const mapped = mapQueueCardToPracticeCard(card);
  const requests: string[] = [];
  vi.stubGlobal("fetch", vi.fn(async (input: RequestInfo | URL) => { requests.push(String(input)); return Response.json({ detail: "Not Found" }, { status: 404 }); }));
  render(<TrainingView {...props} card={mapped} />);
  expect((await screen.findByRole("alert")).textContent).toContain("Not Found");
  expect(requests).toEqual(["http://127.0.0.1:8000/api/studies/frozen-study/exercises/frozen-exercise/present"]);
  console.info("DEEP_FROZEN_CONNECTED_ROUTE", JSON.stringify({ mappedKind: mapped.kind, requests, alert: "Not Found" }));
});
