# Reproducing the review observations

Use an isolated checkout of `091ad318b1afaadcb25e5ca44ff526120a202336` with its declared development dependencies. Baseline comparisons use `799b66234b8be386a33d980df10b8b1d9a9d8b36`. The absolute paths in captured logs identify the original review environment and are not installation targets. Substitute your task checkout and compatible Python environment.

These are diagnostic reproductions, not product qualification. They start no service and operate on fakes or application composition. Do not aim them at a live browser profile or database.

## Frontend

In the task checkout, install the lockfile's dependencies normally, then run `npm run build:packages` to build only that checkout's workspace outputs. The review used Node 24.22.1, npm 11.9.0, Vitest 5.0.1 and jsdom/fake IndexedDB.

Copy `frontend/deep-review-frontend-probes.test.ts` and `frontend/deep-review-frozen-reachability.test.tsx` to the task checkout's `tests/unit/` directory. From the checkout root, run `./node_modules/.bin/vitest run --maxWorkers=2 tests/unit/deep-review-frontend-probes.test.ts tests/unit/deep-review-frozen-reachability.test.tsx`. The first file has four deliberately red invariant assertions on the reviewed source; the second has two positive reachability cases. Treat the expected failures as evidence to repair, not as a passing regression suite. After implementing the actual fixes, integrate the meaningful assertions into the existing owning suites.

`frontend-review.json` records the 16-file existing selection and browser typecheck command. `typecheck-browser-receipt.json` explicitly records exit 0; the empty stdout log alone is not the completion claim. The initially invalid frozen fixture and its corrected run are both retained. Baseline and current negative probes produced the same failures.

## Backend calendar

Use the compatible project Python test environment. Set PYTHONPATH to the task checkout's `backend`, `database`, `packages/scheduling/src`, `packages/chess-core/src`, `packages/evidence-math/src`, `packages/game-review-contracts/src`, `contracts/game-evidence/src` and `services/learning/application/src` directories. Then execute `backend/repro_calendar_residual.py` from this evidence folder with that interpreter. The script patches only clock/storage capabilities in process and executes the current settings/coalescing functions; its successful exit demonstrates the existing wrong-day behavior. It is not a native acceptance test, and its existing defect assertions will need changing after a repair.

Exact historical commands, module environment, case IDs and results are in `backend/verification-log.md` and `verification.json`. The log is a labeled execution ledger, not a raw stdout capture. Nine named stale tests failed; two native tests were deliberately deselected. Preserve that distinction.

## Qualification diagnostic probes

Run `node qualification/probe-runner-contracts.mjs /absolute/path/to/task-checkout` from this evidence folder. The supplied checkout argument is important after extracting the handoff. This imports the actual option/plan functions, asserts their finite selectors and validates failure cleanup without starting the runner's heavy actions.

With a compatible Python environment, run `python qualification/probe-routes-and-e01.py /absolute/path/to/task-checkout`. It supplies current source import paths itself, inventories the composed FastAPI routes and temporarily replaces three fake-test functions in process. Exit 0 reproduces the absent routes and test blind spots; once repaired, these diagnostic assumptions should no longer succeed. It edits no source and starts no database/server. `routes-and-e01-probe.json` is the captured reviewed result, not a future expected acceptance receipt.

## Evidence levels

`github/` preserves the fetched PR narratives/comments and limited review/status metadata. Their native/browser/install statements were reported by the prior integration session; this review did not retrieve the raw Mac-native reports or repeat those runs. Current source tree equivalence was independently checked. The files under `qualification/` state the exact comparison and four E02 residual categories.

The steering prompt calls for actual disposable native/browser acceptance when the relevant product boundary is changed. These small probes are an efficient starting point and do not replace that acceptance.
