# Mission and completion contract

## Assignment

Finish the outstanding Tempo continuation and the remaining work in the fixed architecture audit, qualify the resulting retained product, merge accepted changes, install a useful accepted release on the registered local machine, and verify actual installed use. This packet is an execution assignment for its receiving integration owner. The packet author has prepared and reviewed instructions; preparation is not implementation.

The scope is deliberately finite: the original 25 continuation tasks, the defects identified in the subsequent deep review, and the 55 existing audit finding IDs. Fourteen audit findings are recorded closed at the preparation baseline; 37 are open and four need a decision. The task and finding maps preserve all of them. An unrelated GitHub issue, old roadmap or newly noticed independent improvement does not join this assignment automatically.

“Finish the whole thing” means the owner continues beyond the first successful release. A release is a checkpoint. The owner must not call the packet complete while an assigned task is partial, deferred, blocked, unreviewed at a material changed boundary, or awaiting required real-use evidence. At the same time, individual accepted fixes can merge and ship while independent work continues.

## Two checkpoints, one final outcome

**Checkpoint 1 — outstanding continuation and retained behavior.** Resolve every unfinished acceptance from Q0/A–G and the deep review: original-operation confirmation, retained-storage holds, actual supported Study transport, calendar semantics, retained grading/compatibility, lifecycle witness work, applicable current lifecycle proof, stale proof sources, truthful qualification scope and installed-use evidence. Preserve completed work and its valid source-bound evidence.

**Checkpoint 2 — fixed audit completion.** Complete or evidence-resolve every remaining applicable criterion in the original 55 findings, including the larger interface/ownership and component enforcement work that the low-fruit packet had left for later. This is a later wave of this assignment, not an indefinitely deferred backlog. It does not authorize new features, architectural replacement programmes or an arbitrary table-count/code-size target.

The four candidate findings permit an explicit, justified decision to retain an intentional abstraction. That outcome needs a documented support boundary, real consumer/source evidence and the applicable focused check. It is not automatic permission to rewrite four subsystems. Confirmed findings cannot be closed by renaming a facade, moving a file without adoption, passing adjacent tests, or weakening their original criteria.

## Final completion conditions

The final Goal Checker must establish all of the following:

1. Every original continuation row has an exact current disposition and evidence. Previously partial/deferred work has either completed its acceptance or has a valid conditional no-work disposition proved from the current supported scope. A bounded probe is complete when its concrete result and required successor are recorded; its larger finding stays open until the applicable implementation and proof finish. Do not mistake probe completion for completion of its successor.
2. Every task in `plan/tasks.json` has an evidence-supported terminal outcome. `partial`, `deferred`, `blocked`, `implemented only`, `not run`, and `awaiting Andy` are not complete. Conditional no-work outcomes are allowed only where the task explicitly permits them and the triggering condition has been checked.
3. All 55 finding IDs retain their original source observations and criteria. Each applicable finding is closed with evidence of actual consumer adoption and preserved behavior; candidate no-change resolutions are explicit. The HTML/workbook/current progress agree. Historical facts remain historical.
4. Tests establish the changed boundary: focused pure/component checks, genuine native transaction/lock/migration tests where applicable, real browser persistence/transport where mocks are insufficient, and a coordinated assembled saved-review → authoritative playable-next journey. Selected exclusions have explicit supported/retired dispositions, not disguised passes.
5. Accepted source has merged to the intended main branch. Review and evidence bind the actual relevant source, dependencies, fixtures and runtime inputs. Hosted CI absence is reported honestly; actual repository required protections remain honored.
6. The accepted product release is installed on the verified registered machine with exact source/image/schema/mode identities and supported recovery safeguards. A later documentation-only commit need not force reinstallation; explain why the installed product inputs match the accepted release. If executable/package/lifecycle inputs change, invalidate and renew the affected acceptance.
7. A genuine due Study review in the installed app has been saved, confirmed under its original identity, followed by an authoritative playable next card that Andy can actually use. Capture the observed outcome without manufacturing a human review or editing history. If this observation cannot occur yet, report `SOURCE_MERGED_INSTALLED — LIVE_ACCEPTANCE_PENDING`, not `COMPLETE`.
8. No active assigned worker, unresolved shared-file ownership, task-owned resource leak or unintegrated accepted branch is silently left behind. Cleanup applies only to verified task-owned resources.

## Evidence-backed retirement and conditional work

Some old tests or compatibility branches refer exclusively to features explicitly retired by current SPEC. Positive classification can justify deleting them and replacing mixed retained assertions with current-owner tests. Preserve ambiguous rows, accepted identities and any still-supported recovery. Retiring a stale test does not retire a supported user feature merely because its route is missing.

The original audit inventories are historical review leads. A raw row/cursor inside its own persistence implementation is not automatically a public-interface violation. Classify each inventoried function or proof row at current source, and change only the confirmed applicable boundary. This prevents a 264-function checklist from becoming 264 gratuitous abstractions while retaining complete coverage of the reported finding.

If the actual installation is already schema 65, select its applicable current-to-target update/recovery proof. Historical `current63` refusal remains a safeguard; it is not authority to rebuild obsolete products or weaken the refusal. Changes to lifecycle code still need their affected acceptance even without a schema bump.

## Honest stopping states

`COMPLETE` is available only after all final conditions above. `BLOCKED_EXTERNAL` names the precise missing capability, required user interaction or unresolved consequential product choice, completed independent work, safe current release and exact resumption action. The owner continues ready independent tasks before stopping at such a blocker. A failed test is not an access blocker; missing host access is not a failed product test.

Do not promise execution after the host/session ends. Before context or quota exhaustion, save the real task heads, accepted inputs, resource ownership and next ready IDs in the single run ledger. A replacement agent resumes that state; it does not restart planning or re-audit unchanged accepted work.
