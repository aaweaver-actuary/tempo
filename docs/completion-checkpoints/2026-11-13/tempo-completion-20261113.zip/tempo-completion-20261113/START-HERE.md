# Tempo completion packet

Prepared from the November 12 review; assembled November 13, 2026 UTC.

**Start one integration owner with LAUNCHER.txt, then OWNER-PROMPT.txt.** The owner runs the sequence and gives each creator one bounded prompt from `prompts/`. The user does not need to manage the individual handoffs.

The goal is to finish the remaining original continuation and every applicable criterion in the fixed architecture audit, qualify and merge the accepted product, install it on the registered local machine, and observe genuine installed Study use. A successful release is a checkpoint. It does not close unrelated unfinished tasks or audit rows.

## What is known

The preparation source is `091ad318b1afaadcb25e5ca44ff526120a202336`. The earlier installed product was reported as `d79ae4fcc4b006985114d85b5fb9a5aca8becbf1`, schema65, with Study-only on and managed feedback inactive. The source after that installation changed test/harness/audit inputs, not the product. The audit remains **14 Closed, 37 Open, four Needs decision**. A genuine live installed review-to-next transition remains unobserved in the supplied evidence.

The packet was prepared through source review, reconciliation and planning checks. It contains no newly implemented product change, product-test pass, merge or installation. Read CURRENT-STATE.md for the evidence boundaries. Fetch current main once at execution and inspect any newer delta; preserve valid existing work.

## Read in this order

1. `OWNER-PROMPT.txt` — complete assignment and dispatch loop.
2. `MISSION-AND-DONE.md` and `AUTHORITY.md` — exact finish line and direct authority to push, merge and install.
3. `plan/SEQUENCING.md` and `plan/TASK-INDEX.md` — priorities, readiness, shared-file sequencing and 129 small task cards.
4. `plan/original-25.json` and `plan/findings-55.json` — original criteria, inherited completed work and explicit remaining coverage.
5. The selected worker's `prompts/<ID>.txt` and `COMMON-WORKER.md` — exact paths, steps, commands, acceptance, exclusions and handoff.
6. `runbooks/`, `roles/` and the existing run ledger — qualification, review, installation and honest completion.

## How much to parallelize

Start **three light workers**: C10, B01 and P06. As their specific contracts and files are released, dispatch successors. Keep **one heavy native/browser/lifecycle operator**. If resources and file ownership permit, the owner can expand to four to six light workers; on a four-agent host, use the owner plus three workers and reuse a slot for review.

The 129 cards are deliberately small enough for weaker creators. They are **not 129 simultaneous agents or 129 mandatory PRs**. The owner can give the same worker successive related cards and batch a few coherent tasks into one reviewable PR. A large part of the storage/proof inventory is classification or evidence-backed no-change work; it is not a mandate to rewrite 264 functions or restore every historical test.

## Where supporting material lives

| Material | Location |
| --- | --- |
| Current task graph, events and exact stages | `plan/tasks.json` |
| Every write reservation and shared path | `plan/ownership.json`, `plan/ownership.csv` |
| All 264 original storage-function rows | `plan/storage-functions-264.json` |
| All 758 original proof rows | `plan/proof-rows-758.json` |
| Current audit, workbook and raw evidence | `reference/audit-current.json`, audit HTML/XLSX |
| Original A–G prompts and earlier sequencing | `reference/prior-continuation/` and its ZIP |
| Later deep review, negative reproductions and receipts | `reference/deep-review/` and its ZIP |
| Exact detailed planning definitions and closure maps | `reference/planning-definitions/` |
| Independent review of this packet | `review/` |
| Optional structural validation | `tools/check_packet.py` |

Earlier prompts are historical references. The new task map carries unfinished acceptance forward and preserves already accepted work. New IDs and original continuation IDs are separate namespaces; for example, new B01 is the calendar decision task, while original B01 was the completed alias deletion.

## Completion discipline

The owner may merge and install a coherent accepted release while independent work continues. The final product must include every accepted product change, with relevant source/input evidence. All applicable fixed findings must be closed or explicitly resolved as intentional supported decisions; all original tasks must have valid dispositions. A candidate finding can permit a justified no-change outcome. A confirmed finding cannot be closed by adjacent tests or a renamed facade.

A genuine review in Andy's installed app remains its own final observation. If the code is accepted and installed but that observation has not happened, report `SOURCE_MERGED_INSTALLED — LIVE_ACCEPTANCE_PENDING`. Save exact state and next actions before context or host interruption. One coordinated programme can span replacement agents; no prompt can guarantee that the entire audit fits one uninterrupted session.
