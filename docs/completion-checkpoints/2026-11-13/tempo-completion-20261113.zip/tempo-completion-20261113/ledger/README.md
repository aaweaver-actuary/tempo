# One current execution ledger

The templates are conveniences for the integration owner. They are not new repository approval machinery. Extend an existing current completion ledger when present; otherwise initialize `STATE-TEMPLATE.json` in the existing `tempo-low-fruit-20261112/progress/` area as `completion-run.json`. Keep one authoritative status record. PRs, test logs and the original audit remain linked evidence.

Record each task's actual base/head, changed inputs, owner, file/resource custody, released capability, executed evidence, review, residual, merge and applicable install state. `source_released` allows a downstream worker to consume that exact reviewed interface/implementation; it does not imply qualification or merge. Native/browser/lifecycle results may qualify a coherent candidate before its component heads merge.

For example, T01 releases its reviewed witness source and focused checks; P13 tests the candidate containing it; successful applicable P13 acceptance permits T01's merge. Requiring T01 already merged before P13 could begin would create an artificial cycle.

Keep original continuation IDs under `original_tasks` and new packet IDs under `tasks`; their reused letters/numbers are different namespaces. An inherited original task can remain accepted while a broader audit successor is still open. A new probe can finish after its exact result is recorded, while its implementation successor/finding remains incomplete.

Allowed terminal task outcomes are `accepted_and_merged`, `accepted_evidence_only`, or `accepted_no_change`. The latter two require affirmative evidence and a task-appropriate justification; they cannot conceal a failed or deferred implementation. Every task's actual acceptance text still governs. Installation/live observation tasks require those observations rather than an evidence-only shortcut.

The structural check helper in `tools/` can catch missing IDs, nonterminal states and missing evidence fields. It does not validate a test result, prove a review was independent, establish installed identity or replace the final Goal Checker. Never fill in a state only to satisfy the helper.

At interruption, record the actual safe release, unfinished acceptance, external blockers, active resource custody and next ready IDs. Stop task-owned resources safely when required. Do not promise work will continue after the host/session ends.
