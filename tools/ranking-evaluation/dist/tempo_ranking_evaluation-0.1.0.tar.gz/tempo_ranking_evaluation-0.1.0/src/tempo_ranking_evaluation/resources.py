"""Packaged corpus lookup; no repository-relative runtime paths."""
from importlib.resources import files
from pathlib import Path


def installed_corpus_directory() -> Path:
    # Wheels are installed unpacked; fail clearly for an unsupported zip importer.
    resource=files('tempo_ranking_evaluation').joinpath('corpus')
    path=Path(str(resource))
    if not path.is_dir():raise ValueError('Packaged corpus directory is unavailable')
    return path
