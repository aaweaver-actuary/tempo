# Component-local regression inventory

Authoritative local owner; qualification rejects missing/zero/skipped required cases.
Legacy source assertions originate at d0485d9f; donor harness assertions at c3bccdf9.
Estimator-only tests remain explicitly adapter-owned.

- `test_computed_snapshot_replays_without_recalculation_and_reserved_bundle_conflict` — tests/test_cli.py
- `test_installed_cli_compare_matches_documented_example_and_mathematical_score` — tests/test_cli.py
- `test_installed_cli_errors_have_exit_two_json_stderr_and_no_report` — tests/test_cli.py
- `test_cli_protects_input_existing_and_alias_outputs_and_leaves_no_partial_file` — tests/test_cli.py
- `test_cli_serialized_ceiling_applies_before_stdout_and_file_creation` — tests/test_cli.py
- `test_cli_write_failure_removes_only_new_partial_output` — tests/test_cli.py
- `test_cli_compare_amplification_is_rejected_before_rank` — tests/test_cli.py
- `test_complete_corpus_validates_unselected_scenario_content_before_rank` — tests/test_cli.py
- `test_installed_cli_bytes_are_hash_seed_timezone_independent_for_score` — tests/test_cli.py
- `test_harness_all_thirteen_scenarios_have_substantive_legal_evidence` — tests/test_harness.py
- `test_harness_routes_reference_true_supporting_prefix_parents` — tests/test_harness.py
- `test_harness_unknown_probability_candidate_has_unassigned_authored_reply` — tests/test_harness.py
- `test_harness_hand_calculated_metrics_and_stable_ties` — tests/test_harness.py
- `test_harness_partial_bounds_unknown_mass_and_sensitivity_reversals` — tests/test_harness.py
- `test_harness_other_policy_selection_does_not_change_italian_or_ruy_results` — tests/test_harness.py
- `test_harness_permuted_manifest_and_selection_replay_identically` — tests/test_harness.py
- `test_harness_permuted_snapshot_keeps_metrics_but_changes_content_identity` — tests/test_harness.py
- `test_harness_rejects_invalid_snapshot_and_score_contract_before_ranking` — tests/test_harness.py
- `test_harness_rejects_invalid_manifest_without_partial_report` — tests/test_harness.py
- `test_harness_rejects_empty_unknown_or_duplicate_selection` — tests/test_harness.py
- `test_harness_invalid_top_k_is_not_a_success` — tests/test_harness.py
- `test_harness_invalid_digest_and_size_budgets` — tests/test_harness.py
- `test_harness_cli_offline_hash_seed_and_clock_independent_replay_preserves_inputs` — tests/test_harness.py
- `test_harness_precomputed_lookup_detaches_supplied_results` — tests/test_harness.py
- `test_harness_rejects_misattributed_scenario_before_ranking` — tests/test_harness.py
- `test_harness_bounds_report_amplification_before_ranking` — tests/test_harness.py
- `test_shadow_evaluation_performs_no_writes_and_preserves_immutable_inputs` — tests/test_ranking.py
- `test_shadow_ranking_is_deterministic_with_stable_ties_and_input_permutations` — tests/test_ranking.py
- `test_shadow_compare_rejects_external_ranks_that_contradict_scores` — tests/test_ranking.py
- `test_shadow_compare_rejects_external_tied_scores_out_of_production_order` — tests/test_ranking.py
- `test_shadow_scored_order_uses_card_id_after_equal_score_and_production_rank` — tests/test_ranking.py
- `test_shadow_top_k_spearman_and_rank_displacement_match_hand_calculation` — tests/test_ranking.py
- `test_shadow_production_order_baseline_yields_identity_comparison` — tests/test_ranking.py
- `test_shadow_missing_and_invalid_scores_remain_visible` — tests/test_ranking.py
- `test_shadow_shared_card_identity_and_fractional_concentration_are_preserved` — tests/test_ranking.py
- `test_shadow_empty_singleton_and_unknown_metadata_are_explicit` — tests/test_ranking.py
- `test_shadow_all_unscorable_and_scorer_failures_are_not_false_success` — tests/test_ranking.py
- `test_shadow_invalid_candidate_identity_or_incomplete_order_is_rejected` — tests/test_ranking.py
- `test_shadow_invalid_top_k_is_rejected` — tests/test_ranking.py
- `test_shadow_duplicate_scorers_unknown_results_and_context_mismatch_are_rejected` — tests/test_ranking.py
- `test_shadow_snapshot_roundtrip_replay_is_deterministic_and_digest_bound` — tests/test_ranking.py
- `test_shadow_shorter_card_scorer_is_explicit_example_with_missing_evidence` — tests/test_ranking.py
- `test_shadow_external_results_with_inconsistent_score_and_rank_are_rejected` — tests/test_ranking.py
- `test_shadow_large_fixture_retains_every_physical_card_without_probability_inputs` — tests/test_ranking.py
- `test_shadow_incomplete_membership_metadata_uses_unknown_bucket` — tests/test_ranking.py
- `test_shadow_invalid_metadata_shape_and_naive_as_of_are_rejected` — tests/test_ranking.py
- `test_shadow_external_unscorable_result_without_reason_is_rejected` — tests/test_ranking.py
- `test_shadow_selected_policy_rejects_foreign_candidates_before_scoring` — tests/test_ranking.py
- `test_shadow_policy_context_validation_applies_to_empty_evaluations` — tests/test_ranking.py
- `test_shadow_missing_or_foreign_policy_cannot_be_ranked_or_serialized` — tests/test_ranking.py
- `test_shadow_policy_snapshot_replay_and_comparison_retain_and_fence_identity` — tests/test_ranking.py
- `test_shadow_legacy_snapshot_is_only_global_diagnostic` — tests/test_ranking.py
